// // src/hooks/DataContext.tsx
// import React, { createContext, useContext, useState, ReactNode } from 'react';
// import { DifferenceType } from '@/types/DifferenceType';

// interface DifferenceContextType {
//   differenceHostsData: DifferenceType | null;
//   setDifferenceHostsData: (data: DifferenceType | null) => void;
// }

// const DifferenceContext = createContext<DifferenceContextType | undefined>(undefined);

// export const DataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
//   const [differenceHostsData, setDifferenceHostsData] = useState<DifferenceType | null>(null);

//   return (
//     <DifferenceContext.Provider value={{ differenceHostsData, setDifferenceHostsData }}>
//       {children}
//     </DifferenceContext.Provider>
//   );
// };

// export const useData = () => {
//   const context = useContext(HostContext);
//   if (!context) {
//     throw new Error('useData must be used within a DataProvider');
//   }
//   return context;
// };
