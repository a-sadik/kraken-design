// src/services/RoleService.ts

import { AxiosError } from "axios";

// import files
import { PersonShortResponseDTO } from "@/types/dto/PersonDTO"; // need to change to RoleDTO
import apiClient from "../apiClientHttp";
import { ErrorResponse } from "@/exceptions/ErrorResponse";

const path = "/roles";

// Function to get all roles
export const getAllRoles = async (): Promise<PersonShortResponseDTO[]> => {
  try {
    const response =
      await apiClient.dataApiClient.get<PersonShortResponseDTO[]>(path);

    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error("Error to get all roles:", err.response?.data.message);
    throw err;
  }
};
