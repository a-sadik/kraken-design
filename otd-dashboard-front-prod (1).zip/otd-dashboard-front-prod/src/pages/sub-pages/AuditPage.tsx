// src/pages/primary/CertifcatesPage.tsx

import { FC } from "react";

// import files
import AuditDataTable from "@/components/data-tables/AuditDataTable";

const CertifcatesPage: FC = () => {
  // const [openModal, setOpenModal] = useState(false);

  return <AuditDataTable />;
};

export default CertifcatesPage;
