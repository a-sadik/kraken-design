// src/components/data-tables/EntityDataTable.tsx

import { useMemo, useState, useCallback } from "react";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import {
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  IconButton,
  Typography,
  Tooltip,
  Switch,
} from "@mui/material";
import {
  MRT_GlobalFilterTextField,
  MRT_ShowHideColumnsButton,
  MRT_TableContainer,
  MRT_TablePagination,
  MRT_ToggleDensePaddingButton,
  MRT_ToggleFiltersButton,
  useMaterialReactTable,
  type MRT_ColumnDef,
} from "material-react-table";
import KeyboardIcon from "@mui/icons-material/Keyboard";
import VisibilityIcon from "@mui/icons-material/Visibility";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import { CiExport } from "react-icons/ci";

import WidgetMainContainer from "@/components/containers/WidgetMainContainer";
import { getCssVariableValue } from "@/utils/getDynamicColor";
import "@/styles/reliability-data-table.css";
import "@/styles/colors.css";

// Exemple d'import d'un formulaire d'ajout (vous pouvez l'adapter selon votre implémentation)
import AddForm from "@/components/forms/AddForm";

// Définition du type pour l'entité
export type EntityData = {
  action: string;
  nom: string;
  manager: string;
  DateDeCreation: string;
};

// Données initiales (exemple)
const initialEntities: EntityData[] = [
  {
    action: "Said",
    nom: "Said",
    manager: "East Daphne",
    DateDeCreation: "20/02/2025",
  },
  {
    action: "samir",
    nom: "samir",
    manager: "East Daphne",
    DateDeCreation: "05/03/2025",
  },
  {
    action: "hamid",
    nom: "hamid",
    manager: "East Daphne",
    DateDeCreation: "25/03/2025",
  },
  {
    action: "brahim",
    nom: "brahim",
    manager: "East Daphne",
    DateDeCreation: "27/03/2025",
  },
  {
    action: "test1",
    nom: "Mohammed",
    manager: "East Daphne",
    DateDeCreation: "10/03/2025",
  },
];

const EntityDataTable = () => {
  // États pour gérer les entités
  const [entities, setEntities] = useState<EntityData[]>(initialEntities);

  // États pour la gestion des dialogues (ajout, vue, modification, suppression)
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);
  const [selectedEntity, setSelectedEntity] = useState<EntityData | null>(null);
  const [openViewDialog, setOpenViewDialog] = useState<boolean>(false);
  const [openEditDialog, setOpenEditDialog] = useState<boolean>(false);
  const [editedEntity, setEditedEntity] = useState<EntityData | null>(null);
  const [openDeleteDialog, setOpenDeleteDialog] = useState<boolean>(false);
  const [entityToDelete, setEntityToDelete] = useState<EntityData | null>(null);

  // Référence pour le bouton Show/Hide (optionnel)
  // const showHideButtonRef = useRef(null);

  // Gestion de l'ouverture du formulaire d'ajout
  const handleOpenAddEntity = useCallback(() => {
    setIsAddModalOpen(true);
  }, []);

  // Gestion de la soumission du formulaire d'ajout
  const handleSubmitAddEntity = (newEntity: {
    nom: string;
    manager: string;
  }) => {
    const today = new Date();
    const formattedDate = today.toLocaleDateString(); // Vous pouvez adapter le format selon vos besoins
    const newEntityData: EntityData = {
      action: newEntity.nom,
      nom: newEntity.nom,
      manager: newEntity.manager,
      DateDeCreation: formattedDate,
    };
    setEntities((prev) => [...prev, newEntityData]);
    setIsAddModalOpen(false);
  };

  // Gestion des actions du tableau
  const handleView = (entity: EntityData) => {
    setSelectedEntity(entity);
    setOpenViewDialog(true);
  };

  const handleEdit = (entity: EntityData) => {
    setEditedEntity(entity);
    setOpenEditDialog(true);
  };

  const handleSaveEdit = () => {
    if (editedEntity) {
      // Mise à jour de l'entité dans le state
      setEntities((prev) =>
        prev.map((item) =>
          item.nom === editedEntity.nom ? editedEntity : item,
        ),
      );
      setOpenEditDialog(false);
    }
  };

  const handleDelete = (entity: EntityData) => {
    setEntityToDelete(entity);
    setOpenDeleteDialog(true);
  };

  const handleConfirmDelete = () => {
    if (entityToDelete) {
      setEntities((prev) =>
        prev.filter((item) => item.nom !== entityToDelete.nom),
      );
      setOpenDeleteDialog(false);
    }
  };

  // Définition des colonnes pour material-react-table
  const columns = useMemo<MRT_ColumnDef<EntityData>[]>(
    () => [
      {
        accessorKey: "action",
        header: "Action",
        size: 120,
        Cell: ({ row }) => (
          <Box display="flex" gap={1}>
            <Tooltip title="Voir">
              <IconButton onClick={() => handleView(row.original)}>
                <VisibilityIcon />
              </IconButton>
            </Tooltip>
            <Tooltip title="Modifier">
              <IconButton onClick={() => handleEdit(row.original)}>
                <EditIcon />
              </IconButton>
            </Tooltip>
            <Tooltip title="Supprimer">
              <IconButton onClick={() => handleDelete(row.original)}>
                <DeleteIcon />
              </IconButton>
            </Tooltip>
          </Box>
        ),
      },
      {
        accessorKey: "nom",
        header: "Nom",
        size: 150,
      },
      {
        accessorKey: "manager",
        header: "Manager",
        size: 150,
      },
      {
        accessorKey: "DateDeCreation",
        header: "Date de Création",
        size: 150,
      },
    ],
    [],
  );

  // Configuration du tableau avec material-react-table
  const table = useMaterialReactTable({
    columns,
    data: entities,
    initialState: { showGlobalFilter: true },
    muiSearchTextFieldProps: {
      sx: {
        "& .MuiOutlinedInput-root": {
          border: "none",
          boxShadow: "none",
          borderBottom: "1px solid gray",
          borderRadius: "0px",
        },
        "& .MuiOutlinedInput-notchedOutline": {
          display: "none",
        },
      },
    },
  });

  // Thème personnalisé basé sur Material UI
  const primaryColor = getCssVariableValue("--primary-color");
  const customTheme = createTheme({
    palette: {
      primary: { main: primaryColor },
    },
  });

  return (
    <ThemeProvider theme={customTheme}>
      <Box
        mb={3}
        display="flex"
        justifyContent="space-between"
        alignItems="center"
      >
        <Typography className="data-table-title">Liste des Entités</Typography>
        <Box display="flex" gap={2}>
          <Button
            variant="contained"
            color="primary"
            startIcon={<KeyboardIcon />}
            onClick={handleOpenAddEntity}
            className="button-add"
          >
            <Typography className="text-button-add">Ajouter</Typography>
          </Button>
        </Box>
      </Box>
      <WidgetMainContainer sx={{ borderColor: "--primary-color" }}>
        {/* Barre d'outils externe du tableau */}
        <Box
          sx={{
            display: "flex",
            flexDirection: "row",
            gap: "16px",
            justifyContent: "space-between",
            alignItems: "center",
            backgroundColor: "inherit",
            borderRadius: "4px",
            mb: 1,
          }}
        >
          <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
            <MRT_ShowHideColumnsButton
              table={table}
              sx={{ color: primaryColor }}
            />
            <Typography variant="body2" sx={{ color: primaryColor }}>
              Colonnes
            </Typography>
          </Box>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
            <MRT_ToggleFiltersButton
              table={table}
              sx={{ color: primaryColor }}
            />
            <Typography variant="body2" sx={{ color: primaryColor }}>
              Filtres
            </Typography>
          </Box>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
            <CiExport style={{ color: primaryColor, fontSize: "16px" }} />
            <Typography variant="body2" sx={{ color: primaryColor }}>
              Export
            </Typography>
          </Box>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
            <MRT_ToggleDensePaddingButton
              table={table}
              sx={{ color: primaryColor }}
            />
            <Typography variant="body2" sx={{ color: primaryColor }}>
              Dense
            </Typography>
          </Box>
          <Switch size="small" color="primary" />
          <MRT_GlobalFilterTextField table={table} />
        </Box>

        {/* Tableau */}
        <MRT_TableContainer table={table} />
        <Box sx={{ display: "flex", justifyContent: "flex-end" }}>
          <MRT_TablePagination table={table} />
        </Box>
      </WidgetMainContainer>

      {/* --- DIALOGS --- */}

      {/* Détails de l'entité */}
      <Dialog
        open={openViewDialog}
        onClose={() => setOpenViewDialog(false)}
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle>Détails de l'entité</DialogTitle>
        <DialogContent>
          {selectedEntity && (
            <Box>
              <Typography>
                <strong>Nom :</strong> {selectedEntity.nom}
              </Typography>
              <Typography>
                <strong>Manager :</strong> {selectedEntity.manager}
              </Typography>
              <Typography>
                <strong>Date de création :</strong>{" "}
                {selectedEntity.DateDeCreation}
              </Typography>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenViewDialog(false)} color="primary">
            Fermer
          </Button>
        </DialogActions>
      </Dialog>

      {/* Modifier l'entité */}

      <Dialog
        open={openEditDialog}
        onClose={() => setOpenEditDialog(false)}
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle>Modifier l'entité</DialogTitle>
        <DialogContent>
          {editedEntity && (
            <Box display="flex" flexDirection="column" gap={2} mt={2}>
              <TextField
                label="Nom"
                fullWidth
                value={editedEntity.nom}
                onChange={(e) =>
                  setEditedEntity({ ...editedEntity, nom: e.target.value })
                }
              />
              <TextField
                label="Manager"
                fullWidth
                value={editedEntity.manager}
                onChange={(e) =>
                  setEditedEntity({ ...editedEntity, manager: e.target.value })
                }
              />
              <TextField
                label="Date de création"
                type="date"
                fullWidth
                value={editedEntity.DateDeCreation}
                onChange={(e) =>
                  setEditedEntity({
                    ...editedEntity,
                    DateDeCreation: e.target.value,
                  })
                }
                InputLabelProps={{ shrink: true }}
              />
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenEditDialog(false)} color="secondary">
            Annuler
          </Button>
          <Button onClick={handleSaveEdit} color="primary" variant="contained">
            Enregistrer
          </Button>
        </DialogActions>
      </Dialog>

      {/* Confirmation de suppression */}
      <Dialog
        open={openDeleteDialog}
        onClose={() => setOpenDeleteDialog(false)}
        fullWidth
        maxWidth="xs"
      >
        <DialogTitle>Confirmation</DialogTitle>
        <DialogContent>
          <Typography>
            Êtes-vous sûr de vouloir supprimer l'entité{" "}
            <strong>{entityToDelete?.nom}</strong> ?
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenDeleteDialog(false)} color="secondary">
            Annuler
          </Button>
          <Button
            onClick={handleConfirmDelete}
            color="error"
            variant="contained"
          >
            Supprimer
          </Button>
        </DialogActions>
      </Dialog>

      {/* --- Formulaire d'ajout d'entité --- */}
      <AddForm
        open={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onSubmit={handleSubmitAddEntity}
        adminType="Entité"
      />
    </ThemeProvider>
  );
};

export default EntityDataTable;
