import { BiLogoPostgresql } from "react-icons/bi";
import { SiMongodb, SiOracle } from "react-icons/si";

export const steps = ["Type de ressource", "Spécifications"];

export const clusterOptions = [
  { value: "PostgreSQL", label: "Cluster PostgreSQL", icon: BiLogoPostgresql },
  { value: "Oracle RAC", label: "Cluster Oracle RAC", icon: SiOracle },
  { value: "MongoDB", label: "Cluster MongoDB", icon: SiMongodb },
];

export const osOptions = [
  { value: "RedHat", label: "RedHat Linux" },
  { value: "Windows", label: "Windows Server" },
  { value: "AIX", label: "IBM AIX" },
];

export const osVersionOptions = {
  RedHat: ["7.9", "8.5", "8.8", "9.1"],
  Windows: ["2019", "2022"],
  AIX: ["7.2", "7.3"],
};

export const datacenterOptions = [
  { value: "MLY", label: "Casablanca MLY" },
  { value: "YEM", label: "casablanca YAACOUB EL MANSOUR" },
];

export const environmentOptions = [
  { value: "prod", label: "Production" },
  { value: "pré-prod", label: "Pré-production" },
  { value: "dev", label: "Développement" },
  { value: "test", label: "Test" },
  { value: "recette", label: "Recette" },
  { value: "formation", label: "Formation" },
  { value: "provisoire", label: "Provisoire" },
];
