// src/components/forms/certificates/CreateInternCertificateForm.tsx

import { useEffect, useState } from "react";
import { useForm, Controller, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z as zod } from "zod";
import {
  TextField,
  Button,
  Grid,
  Autocomplete,
  Typography,
  CircularProgress,
  Box,
  Alert,
  InputAdornment,
  IconButton,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import AddIcon from "@mui/icons-material/Add";

// imports files
import { SolutionDetailResponseDTO } from "@/types/dto/response/solution/SolutionDetailResponseDTO";
import { getAllSolutions } from "@/services/SolutionService";
import { getAllCertificateTypes } from "@/services/CertificateService";

// import messages
import {
  required_certificate_target,
  required_common_name,
  required_dns_max_lenght,
  required_dns_max_nbr,
  required_dns_min_lenght,
  MAX_DNS_LENGTH,
  required_dns_min_nbr,
  required_one_solution,
  required_unique_dns,
} from "@/utils/customMessages";
import {
  placeholder_common_name,
  placeholder_one_solution,
  required_domain_name_select,
} from "@/utils/customMessages";
import { WEB_SERVEUR_3 } from "@/pages/sub-pages/CertifcatesPage";

const BLOCKED_DOMAINS = [".attijariwafa.net", ".attijariwafa.com"];
const DOMAIN_BLOCKED_MESSAGE =
  "Le domaine sera ajouté automatiquement. Veuillez saisir uniquement le nom sans le domaine.";

// Fonction utilitaire pour vérifier si une valeur contient un domaine bloqué
const containsBlockedDomain = (value: string): boolean => {
  return BLOCKED_DOMAINS.some((domain) =>
    value.toLowerCase().includes(domain.toLowerCase()),
  );
};

// Schéma de validation avec Zod
const getFormSchema = (isDeleteMode: boolean) =>
  zod.object({
    certificate_target: isDeleteMode
      ? zod.string().optional()
      : zod.string().trim().min(1),
    // field 1
    common_name: isDeleteMode
      ? zod.string().optional()
      : zod
          .string()
          .trim()
          .min(1, required_common_name)
          .refine((value) => !containsBlockedDomain(value), {
            message: DOMAIN_BLOCKED_MESSAGE,
          }),
    // field 2
    dns: isDeleteMode
      ? zod.array(zod.string()).optional()
      : zod
          .array(
            zod
              .string()
              .min(1, required_dns_min_lenght)
              .max(MAX_DNS_LENGTH, required_dns_max_lenght)
              .refine((value) => !containsBlockedDomain(value), {
                message: DOMAIN_BLOCKED_MESSAGE,
              }),
          )
          .min(1, required_dns_min_nbr)
          .max(5, required_dns_max_nbr)
          .refine(
            (values) => {
              // Vérifier les doublons dans les DNS
              const uniqueValues = new Set(values);
              return uniqueValues.size === values.length;
            },
            { message: required_unique_dns },
          ),
    // field 3
    certificate_type: isDeleteMode
      ? zod.string().optional()
      : zod
          .union([zod.string(), zod.literal(null)])
          .refine((val) => val !== null, {
            message: required_certificate_target,
          }),
    // field 4
    description: isDeleteMode
      ? zod.string().optional()
      : zod.string().trim().min(1),
    // field 5 - reste identique
    solution: isDeleteMode
      ? zod
          .object({
            solution_id: zod.number(),
            solution_name: zod.string(),
            solution_popularity: zod.string(),
            domain: zod
              .object({
                domain_id: zod.number(),
                domain_name: zod.string(),
                pole: zod.object({
                  pole_id: zod.number(),
                  pole_name: zod.string(),
                  entity: zod.object({
                    entity_id: zod.number(),
                    entity_name: zod.string(),
                  }),
                }),
              })
              .optional(),
          })
          .optional()
      : zod
          .union([
            zod.object({
              solution_id: zod.number(),
              solution_name: zod.string(),
              solution_popularity: zod.string(),
              domain: zod
                .object({
                  domain_id: zod.number(),
                  domain_name: zod.string(),
                  pole: zod.object({
                    pole_id: zod.number(),
                    pole_name: zod.string(),
                    entity: zod.object({
                      entity_id: zod.number(),
                      entity_name: zod.string(),
                    }),
                  }),
                })
                .optional(),
            }),
            zod.literal(null),
          ])
          .refine((val) => val !== null, { message: required_one_solution }),
  });

export type InternCertificateFormData = zod.infer<
  ReturnType<typeof getFormSchema>
>;

const FormLabel = ({
  label,
  isRequired = false,
}: {
  label: string;
  isRequired?: boolean;
}) => (
  <Typography
    variant="body1"
    sx={{
      fontWeight: "bold",
      display: "flex",
      alignItems: "center",
      mb: "0.5rem",
      fontSize: "1.2rem",
    }}
  >
    {label}
    {isRequired && (
      <span style={{ color: "var(--error-color)", marginLeft: 2 }}>*</span>
    )}
  </Typography>
);

interface InternCertificateFormProps {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  initialData: any;
  onSubmit: (data: InternCertificateFormData) => void;
  isEditMode: boolean;
  isViewMode: boolean;
  isDeleteMode: boolean;
  errorMessage: string | null;
}

export function InternCertificateForm({
  initialData,
  onSubmit,
  isEditMode,
  isViewMode,
  isDeleteMode,
  errorMessage,
}: InternCertificateFormProps) {
  const formSchema = getFormSchema(isDeleteMode);

  const {
    control,
    register,
    handleSubmit,
    formState: { errors, isValid },
    setValue,
    watch,
    trigger,
    setError,
    clearErrors,
  } = useForm<InternCertificateFormData>({
    resolver: zodResolver(formSchema),
    mode: "all",
    defaultValues: initialData || {
      certificate_target: "Interne",
      solution: null,
      description: "",
      common_name: "",
      dns: [""],
      certificate_type: WEB_SERVEUR_3,
    },
  });

  const { fields, append, remove } = useFieldArray<any | null>({
    control,
    name: "dns",
  });

  const watchCommonName = watch("common_name");
  const watchDns = watch("dns");

  // Auto-populate first DNS with common name and domain extension
  useEffect(() => {
    if (watchCommonName) {
      const firstDNS = `${watchCommonName}`;
      setValue("dns.0", firstDNS);
      trigger("dns");
    }
  }, [watchCommonName, setValue, trigger]);

  // Vérification de l'unicité des DNS après chaque modification
  useEffect(() => {
    if (!isDeleteMode && watchDns && watchDns.length > 1) {
      // Vérifier les doublons
      const uniqueDns = new Set(
        watchDns.filter((dns) => dns && dns.trim() !== ""),
      );

      if (
        uniqueDns.size !==
        watchDns.filter((dns) => dns && dns.trim() !== "").length
      ) {
        setError("dns", {
          type: "custom",
          message: "Les DNS doivent être uniques",
        });
      } else {
        clearErrors("dns");
      }
    }
  }, [watchDns, isDeleteMode, setError, clearErrors]);

  // S'assurer que le tableau DNS a toujours au moins un élément
  useEffect(() => {
    if (fields.length === 0) {
      append("");
    }
  }, [fields.length, append]);

  const controlledFields = fields.map((field, index) => {
    return {
      ...field,
      isFirstField: index === 0,
      value: watch(`dns.${index}`),
    };
  });

  useEffect(() => {
    if (initialData) {
      // Si des données initiales sont fournies, remplissez les valeurs du formulaire
      Object.keys(initialData).forEach((key) => {
        setValue(
          key as keyof InternCertificateFormData,
          initialData[key as keyof InternCertificateFormData],
        );
      });

      // S'assurer que le tableau DNS a au moins un élément
      if (!initialData.dns || initialData.dns.length === 0) {
        setValue("dns", [""]);
      }
    }
  }, [initialData, setValue]);

  // loading data from api
  const [solutions, setSolutions] = useState<SolutionDetailResponseDTO[]>([]);
  const [loadSolutions, setLoadSolutions] = useState<boolean>(false);
  const [certificateTypes, setCertificateTypes] = useState<string[]>([]);
  const [loadCertificateTypes, setLoadCertificateTypes] =
    useState<boolean>(false);

  const fetchSolutions = async () => {
    setLoadSolutions(true);
    try {
      const solutionData: SolutionDetailResponseDTO[] = await getAllSolutions();

      if (Array.isArray(solutionData)) {
        setSolutions(solutionData);
      } else {
        console.error(
          "Les données reçues ne sont pas un tableau",
          solutionData,
        );
        setSolutions([]);
      }
    } catch (error) {
      console.error("Erreur lors du chargement des solutions :", error);
      setSolutions([]);
    } finally {
      setLoadSolutions(false);
    }
  };

  const fetchCertificateTypes = async () => {
    setLoadCertificateTypes(true);
    try {
      const certificateTypesData: string[] = await getAllCertificateTypes();

      if (Array.isArray(certificateTypesData)) {
        setCertificateTypes(certificateTypesData);
      } else {
        console.error(
          "Les données reçues ne sont pas un tableau",
          certificateTypesData,
        );
        setCertificateTypes([]);
      }
    } catch (error) {
      console.error("Erreur lors du chargement des certificate types :", error);
      setCertificateTypes([]);
    } finally {
      setLoadCertificateTypes(false);
    }
  };

  // Fonction pour valider si on peut ajouter un nouveau DNS
  const validateAddDns = () => {
    if (watchDns && watchDns.some((dns) => !dns || dns.trim() === "")) {
      return false; // Ne pas permettre d'ajouter un nouveau DNS si un champ existant est vide
    }
    return true;
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <Grid container spacing={2}>
        {!isDeleteMode ? (
          <>
            {/* Champ common_name */}
            <Grid item xs={12} md={12}>
              <FormLabel label="Common name" isRequired />
              <TextField
                {...register("common_name")}
                error={!!errors.common_name}
                helperText={errors.common_name?.message}
                fullWidth
                disabled={isViewMode}
                placeholder={placeholder_common_name}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <Typography className="text-button-add">
                        .attijariwafa.net
                      </Typography>
                    </InputAdornment>
                  ),
                }}
              />
            </Grid>

            {/* DNS Fields */}
            <Grid container item xs={12} md={12}>
              <Grid item xs={12}>
                <FormLabel label="DNS" isRequired />
                {errors.dns && errors.dns.message && (
                  <Typography color="error" variant="caption" sx={{ ml: 2 }}>
                    {errors.dns.message}
                  </Typography>
                )}
              </Grid>

              {controlledFields.map((field, index) => (
                <Grid item xs={12} key={field.id}>
                  <TextField
                    {...register(`dns.${index}`)}
                    error={
                      !!errors.dns?.[index] ||
                      (errors.dns && !!errors.dns.message)
                    }
                    helperText={errors.dns?.[index]?.message}
                    fullWidth
                    disabled={index === 0 || isViewMode} // First DNS is always disabled
                    label={`DNS.${index + 1}${index === 0 ? " (généré automatiquement)" : ""}`}
                    placeholder={
                      index === 0
                        ? "Généré à partir du Common Name"
                        : required_domain_name_select
                    }
                    margin="dense"
                    value={
                      index === 0 ? `${watchCommonName}` : watch(`dns.${index}`)
                    }
                    InputProps={{
                      endAdornment: (
                        <InputAdornment position="end">
                          <Typography className="text-button-add">
                            .attijariwafa.net
                          </Typography>
                          {index > 0 && (
                            <>
                              <Typography component="span" sx={{ mx: 1 }}>
                                {" "}
                                |{" "}
                              </Typography>
                              <IconButton
                                aria-label="delete"
                                color="error"
                                size="large"
                                onClick={() => remove(index)}
                                disabled={isViewMode}
                              >
                                <DeleteIcon />
                              </IconButton>
                            </>
                          )}
                        </InputAdornment>
                      ),
                    }}
                    sx={{
                      marginTop: "10px",
                      backgroundColor:
                        index === 0 ? "rgba(0, 0, 0, 0.04)" : "transparent",
                    }}
                    onChange={(e) => {
                      setValue(`dns.${index}`, e.target.value);
                      trigger("dns");
                    }}
                  />
                </Grid>
              ))}
            </Grid>

            <Grid
              item
              xs={12}
              sx={{
                alignItems: "center",
                justifyContent: "flex-end",
                display: "flex",
              }}
            >
              <Button
                variant="contained"
                size="small"
                onClick={() => {
                  if (validateAddDns()) {
                    append("");
                    setTimeout(() => trigger("dns"), 0);
                  }
                }}
                disabled={
                  isViewMode ||
                  !validateAddDns() ||
                  (watchDns && watchDns?.length >= 5)
                }
                sx={{
                  width: "auto",
                  color: "success.contrastText",
                }}
                endIcon={<AddIcon />}
              >
                Ajouter un DNS
              </Button>
            </Grid>

            {/* Certificate Types Field */}
            {/* <Grid item xs={12} md={12}>
              <FormLabel label="Type" isRequired />
              <Controller
                name="certificate_type"
                control={control}
                render={({ field }) => (
                  <FormControl fullWidth error={!!errors.certificate_type}>
                    <Select
                      {...field}
                      displayEmpty
                      disabled={isViewMode}
                      variant="outlined"
                    >
                      {certificateTemplates.map((template) => (
                        <MenuItem key={template} value={template}>
                          {template}
                        </MenuItem>
                      ))}
                    </Select>
                    {errors.certificate_type && (
                      <Typography color="error" variant="caption">
                        {errors.certificate_type.message}
                      </Typography>
                    )}
                  </FormControl>
                )}
              />
            </Grid> */}

            <Grid item xs={12} md={12}>
              <FormLabel label="Type" isRequired />
              <Controller
                name="certificate_type"
                control={control}
                render={({ field }) => (
                  <Autocomplete
                    {...field}
                    options={certificateTypes || []} // Utilisez un tableau vide par défaut
                    getOptionLabel={(option) => option}
                    disabled={isViewMode}
                    loading={loadCertificateTypes}
                    onOpen={fetchCertificateTypes}
                    onChange={(_, value) => field.onChange(value || null)}
                    isOptionEqualToValue={(option, value) => option === value}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        placeholder={placeholder_one_solution}
                        error={!!errors.certificate_type}
                        helperText={
                          errors.certificate_type?.message ||
                          (loadCertificateTypes ? "Chargement..." : "")
                        }
                        InputProps={{
                          ...params.InputProps,
                          endAdornment: (
                            <>
                              {loadCertificateTypes && (
                                <CircularProgress color="inherit" size={20} />
                              )}
                              {params.InputProps.endAdornment}
                            </>
                          ),
                        }}
                      />
                    )}
                  />
                )}
              />
            </Grid>

            {/* Description Field */}
            <Grid item xs={12} md={12}>
              <FormLabel label="Description" isRequired />
              <TextField
                {...register("description")}
                variant="outlined"
                fullWidth
                multiline
                rows={3}
                placeholder="Entrez une description ou un commentaire"
                error={!!errors.description}
                helperText={errors.description?.message}
                disabled={isViewMode}
              />
            </Grid>

            {/* Champ Solution */}
            <Grid item xs={12} md={12}>
              <FormLabel label="Solution" isRequired />
              <Controller
                name="solution"
                control={control}
                render={({ field }) => (
                  <Autocomplete
                    {...field}
                    value={field.value as SolutionDetailResponseDTO | null}
                    options={solutions || []}
                    getOptionLabel={(option) => {
                      return option.solution_name
                        ? `${option.solution_name} (${option.domain?.pole?.entity?.entity_name || ""})`
                        : "";
                    }}
                    disabled={isViewMode}
                    loading={loadSolutions}
                    onOpen={fetchSolutions}
                    onChange={(_, value) => field.onChange(value || null)}
                    isOptionEqualToValue={(option, value) =>
                      option.solution_id === value?.solution_id
                    }
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        placeholder={placeholder_one_solution}
                        error={!!errors.solution}
                        helperText={
                          errors.solution?.message ||
                          (loadSolutions ? "Chargement..." : "")
                        }
                        InputProps={{
                          ...params.InputProps,
                          endAdornment: (
                            <>
                              {loadSolutions && (
                                <CircularProgress color="inherit" size={20} />
                              )}
                              {params.InputProps.endAdornment}
                            </>
                          ),
                        }}
                      />
                    )}
                  />
                )}
              />
            </Grid>
          </>
        ) : (
          <Box margin="2rem">
            Êtes-vous sûr de vouloir supprimer cet certificat.
          </Box>
        )}

        {errorMessage !== null && (
          <Grid item xs={12}>
            <Alert variant="filled" severity="error">
              <Typography variant="body1">{errorMessage}</Typography>
            </Alert>
          </Grid>
        )}

        {/* Bouton Soumettre */}
        {!isViewMode && (
          <Grid
            item
            xs={12}
            sx={{
              alignItems: "center",
              justifyContent: "flex-end",
              display: "flex",
            }}
          >
            <Button
              type="submit"
              variant="contained"
              size="large"
              color="primary"
              disabled={isDeleteMode ? false : !isValid}
              sx={{
                width: "auto",
              }}
            >
              {isEditMode ? "Modifier" : isDeleteMode ? "Supprimer" : "Envoyer"}
            </Button>
          </Grid>
        )}
      </Grid>
    </form>
  );
}
