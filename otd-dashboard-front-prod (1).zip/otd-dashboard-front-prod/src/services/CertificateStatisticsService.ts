// src/services/CertificateStatisticsService.ts

import apiClient from "./apiClientHttp";

// Types pour les statistiques
export interface CertificateStats {
  total: number;
  createdToday: number;
  expiringSoon: number;
  expiring30Days: number;
  expired: number;
  byType: Record<string, number>;
  byState: Record<string, number>;
  expirationTimeline: ExpirationTimelineItem[];
}

export interface ExpirationTimelineItem {
  organization: any;
  issuer: any;
  certificate_id: string;
  common_name: string;
  exp_date: string;
  daysUntilExpiration: number;
  status: "expired" | "expiring-soon" | "warning" | "safe" | "active";
  certificate_type: string;
  applicant: string;
}

export interface ChartData {
  typeChart: Array<{ type: string; count: number }>;
  stateChart: Array<{ id: string; value: number; label: string }>;
}

export interface CertificateStatisticsResponse {
  statistics: CertificateStats;
  charts: ChartData;
  lastUpdated: string;
}

export interface FilteredCertificateStatisticsResponse
  extends CertificateStatisticsResponse {
  certificates: Array<{
    certificate_id: string;
    common_name: string;
    certificate_type: string;
    certificate_state: string;
    exp_date: string;
    created_at: string;
    applicant: string;
  }>;
  filters: {
    startDate?: string;
    endDate?: string;
    certificateType?: string;
    certificateState?: string;
  };
}

/**
 * Récupère les statistiques générales des certificats
 */
export const getCertificatesStatistics =
  async (): Promise<CertificateStatisticsResponse> => {
    try {
      const response = await apiClient.dataApiClient.get(
        "/certificates/statistiques",
      );
      return response.data;
    } catch (error) {
      console.error("Erreur lors de la récupération des statistiques:", error);
      throw error;
    }
  };

export const getFilteredCertificatesStatistics = async (filters: {
  startDate?: string;
  endDate?: string;
  certificateType?: string;
  certificateState?: string;
}): Promise<FilteredCertificateStatisticsResponse> => {
  try {
    const params = new URLSearchParams();
    if (filters.startDate) params.append("startDate", filters.startDate);
    if (filters.endDate) params.append("endDate", filters.endDate);
    if (filters.certificateType)
      params.append("certificateType", filters.certificateType);
    if (filters.certificateState)
      params.append("certificateState", filters.certificateState);

    const response = await apiClient.dataApiClient.get(
      `/certificates/statistiques/filtered?${params.toString()}`,
    );
    return response.data;
  } catch (error) {
    console.error(
      "Erreur lors de la récupération des statistiques filtrées:",
      error,
    );
    throw error;
  }
};
