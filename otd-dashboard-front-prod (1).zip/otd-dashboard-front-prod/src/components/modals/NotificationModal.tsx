import React from "react";
import { Typography, Stack } from "@mui/material";
import MyModal from "@/components/modals/MyModal";

interface NotificationModalProps {
  open: boolean;
  onClose: () => void;
  email: string | undefined;
  notifiedAt: string | undefined;
}

const NotificationModal: React.FC<NotificationModalProps> = ({
  open,
  onClose,
  email,
  notifiedAt,
}) => {
  return (
    <MyModal open={open} onClose={onClose} title="Détails de la notification">
      <Stack spacing={2} px={2} py={1}>
        <Typography>
          <strong>Email de notification:</strong> {email || "Non spécifié"}
        </Typography>
        <Typography>
          <strong>Date d’envoi:</strong>{" "}
          {notifiedAt ? new Date(notifiedAt).toLocaleString() : "Non envoyé"}
        </Typography>
      </Stack>
    </MyModal>
  );
};

export default NotificationModal;
