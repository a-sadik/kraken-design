// src/types/view/DataResponseDTO.ts

export default interface DataResponseDTO {
  hostname: string;
  ip_addresses: string[];
  os: string | null;
  solution_name: string | null;
  environments: string[];
  domain: string | null;
  pole: string;
  entity: string;
  technicals_admins: string | null;
  functionals_admins: string | null;
  tam: string | null;
  server_nature: string[];
  solution_popularity: string | null;
  solution_role: string | null;
  solution_deployed: string | null;
  solution_type: string | null;
  // solution_depoyed_version: string | null;
  pci: string | null;
}
