// src/types/dto/response/solution/SolutionShortDTO.ts

export interface SolutionShortDTO {
  solution_id: number;
  solution_name: string;
  solution_popularity: string;
  solution_type: string;
  solution_role: string;
  psi: string;
}
