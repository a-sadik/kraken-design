/* eslint-disable @typescript-eslint/no-explicit-any */
// src/components/data-tables/OpenshiftDataTable.tsx

import { useState, useEffect, useMemo, Dispatch, SetStateAction } from "react";

import { AxiosError } from "axios";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import { DataGrid } from "@mui/x-data-grid";
import {
  IconButton,
  Box,
  Button,
  Typography,
  Divider,
  Link,
  Card,
  CardContent,
  CircularProgress,
} from "@mui/material";
import VisibilityIcon from "@mui/icons-material/Visibility";
import PlayCircleFilledIcon from "@mui/icons-material/PlayCircleFilled";
import DownloadIcon from "@mui/icons-material/Download";
import TaskIcon from "@mui/icons-material/Task";
import VerifiedUserIcon from "@mui/icons-material/VerifiedUser";
import AutorenewIcon from "@mui/icons-material/Autorenew";
import KeyboardIcon from "@mui/icons-material/Keyboard";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import UnpublishedIcon from "@mui/icons-material/Unpublished";
import GppBadIcon from "@mui/icons-material/GppBad";

import {
  Timeline,
  TimelineItem,
  TimelineSeparator,
  TimelineConnector,
  TimelineContent,
  TimelineDot,
} from "@mui/lab";

// import Files
import WidgetMainContainer from "../containers/WidgetMainContainer";
import CustomTooltip from "../basics/CustomToolTip";
import CustomBadge from "../basics/CustomBadge";
import CustomToolBarHome from "./CustomToolBarHome";
import CustomLoading from "../basics/CustomLoading";
import MyModal from "../modals/MyModal";
import { getCssVariableValue } from "@/utils/getDynamicColor";
import { getHealthBackendData } from "@/services/ServerService";
import {
  getAllCertificates,
  getCertificateById,
  validateCertificate,
  rejectCertificate,
  renewCertificateWithOldKey,
  createOneInternCertificate,
} from "@/services/CertificateService";
import CertificateView from "@/types/view/CertificateView";
import {
  CertificateDetailResponseDTO,
  CertificateResponseDTO,
} from "@/types/dto/response/CertificateResponseDTO";
import { ErrorResponse } from "../../exceptions/ErrorResponse";

// imports style
import "@/styles/reliability-data-table.css";

// Import messages
import {
  service_unavailable,
  service_failure,
  service_data,
} from "@/utils/customMessages";
import { OpenshiftForm, OpenshiftFormData } from "../forms/OpenshiftForm";
import {
  InternCertificateRequestDTO,
  CertificateAfterCreatingRequestDTO,
} from "@/types/dto/request/CertificateRequestDTO";
import { internCertificateDataFormToReq } from "@/mappers/CertificateMapper";
import { getFormatedDate } from "@/utils";

const PREFIX_PATH = import.meta.env.VITE_PREFIX_DATA_PATH;
const SUFFIX_PATH = import.meta.env.VITE_SUFFIX_DATA_PATH;
const SERVER_PORT = import.meta.env.VITE_DATA_SERVER_PORT;
const path = `${PREFIX_PATH}:${SERVER_PORT}/${SUFFIX_PATH}/certificates`;

interface OpenshiftDataTableProps {
  openModal: boolean;
  setOpenModal: Dispatch<SetStateAction<boolean>>;
}
interface CertificateAdd {
  crt: CertificateResponseDTO;
  class: string;
}

export default function OpenshiftDataTable({
  openModal,
  setOpenModal,
}: OpenshiftDataTableProps) {
  const [isInterne, setIsInterne] = useState(true);
  const [isExterne, setIsExterne] = useState(true);
  const [isInProgress, setIsInProgress] = useState(false);
  const [selectedRowData, setSelectedRowData] =
    useState<CertificateView | null>(null);
  const [modalType, setModalType] = useState<string>("");
  const [certificates, setCertificates] = useState<CertificateView[] | null>(
    [],
  );

  const [openModalDisplay, setOpenModalDisplay] = useState(false);
  const [openModalValidate, setOpenModalValidate] = useState(false);
  const [certificateAdd, setCertificateAdd] = useState<CertificateAdd | null>(
    null,
  );

  // const [idRowToFlash, setIdRrowToFlash] = useState(-1);

  if (isExterne == true && isInterne == true) {
    setIsExterne(true);
    setIsInProgress(true);
    setIsInterne(true);
  }

  const [certificateById, setCertificateById] =
    useState<CertificateDetailResponseDTO | null>(null);
  const [loading, setLoading] = useState(false);
  const [errorOperationMsg, setErrorOperationMsg] = useState<string | null>(
    null,
  );
  const [errorServiceMsg, setErrorServiceMsg] = useState<string | null>(null);
  const [columnVisibility, setColumnVisibility] = useState({});

  // Fonction pour récupérer les données des certificats
  const fetchCertificates = async () => {
    setLoading(true);
    setErrorOperationMsg(null);
    setErrorServiceMsg(null);
    try {
      await getHealthBackendData();
      const data = await getAllCertificates();
      setCertificates(data);
      setErrorServiceMsg(null);
    } catch (err) {
      const error = err as AxiosError;
      console.error("Erreur lors de la récupération des certificats :", err);
      if (error.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCertificates();
  }, []);

  const handleDisplayData = async (row: any, operationType: string) => {
    try {
      setCertificateAdd(null);
      setLoading(true);
      setSelectedRowData(row);
      setModalType(operationType);
      setOpenModalDisplay(true);
      await getHealthBackendData();
      const data = await getCertificateById(row.id);
      setCertificateById(data);
    } catch (error) {
      const err = error as AxiosError;
      console.error("Failed to fetch certificat data by ID:", error);
      if (err.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    } finally {
      setLoading(false);
    }
  };

  const handleValidateData = async (row: any) => {
    try {
      setCertificateAdd(null);
      setLoading(true);
      setSelectedRowData(row);
      setModalType("");
      setOpenModalValidate(true);
      await getHealthBackendData();
      const data = await getCertificateById(row.id);
      setCertificateById(data);
    } catch (error) {
      const err = error as AxiosError;
      console.error("Failed to fetch certificat data by ID:", error);
      if (err.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    } finally {
      setLoading(false);
    }
  };

  const handleAddManual = (section: string) => {
    setModalType(section);
    setOpenModal(true);
  };

  const handleCloseModal = () => {
    setModalType("");
    setSelectedRowData(null);
    setOpenModal(false);
    setErrorOperationMsg(null);
  };
  const handleCloseModalDisplay = () => {
    setModalType("");
    setCertificateById(null);
    setOpenModalDisplay(false);
    setErrorOperationMsg(null);
  };
  const handleCloseModalValidate = () => {
    setModalType("");
    setCertificateById(null);
    setOpenModalValidate(false);
    setErrorOperationMsg(null);
  };

  const addCertificate = async (
    dataCertificate: InternCertificateRequestDTO,
  ) => {
    try {
      setLoading(true);
      await getHealthBackendData();
      const data: any = await createOneInternCertificate(dataCertificate);
      setCertificateAdd({ crt: data, class: "flash" });
    } catch (error) {
      const err = error as AxiosError;
      console.error("Failed to add certificate :", error);
      if (err.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    } finally {
      setOpenModalDisplay(false);
      fetchCertificates();
    }
  };

  const renewExpireCertificate = async (row: any) => {
    try {
      setLoading(true);
      await renewCertificateWithOldKey(row.id);
    } catch (error) {
      const err = error as AxiosError;
      console.error("Failed to add certificate :", error);
      if (err.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    } finally {
      setOpenModalValidate(false);
      fetchCertificates();
    }
  };

  const validateNewCertificate = async (id: number) => {
    const dataCertificate: CertificateAfterCreatingRequestDTO = {
      action_comment: "",
    };

    try {
      setLoading(true);
      const data: any = await validateCertificate(id, dataCertificate);
      setCertificateAdd({ crt: data, class: "flash" });
    } catch (error) {
      const err = error as AxiosError;
      console.error("Failed to add certificate :", error);
      if (err.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    } finally {
      handleCloseModalValidate();
      fetchCertificates();
    }
  };

  const rejectNewCertificate = async (id: number) => {
    const dataCertificate: CertificateAfterCreatingRequestDTO = {
      action_comment: "",
    };

    try {
      setLoading(true);
      const data: any = await rejectCertificate(id, dataCertificate);
      setCertificateAdd({ crt: data, class: "flash_red" });
    } catch (error) {
      const err = error as AxiosError;
      console.error("Failed to add certificate :", error);
      if (err.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    } finally {
      handleCloseModalValidate();
      fetchCertificates();
    }
  };

  const handleActionSubmit = async (data: OpenshiftFormData) => {
    const dataCertificate: InternCertificateRequestDTO =
      internCertificateDataFormToReq(data);

    await getHealthBackendData();
    try {
      switch (modalType) {
        case "Ajout":
          await addCertificate(dataCertificate);
          break;
        // case 'Modification':
        //     await updateServer(selectedRowData ? selectedRowData.id : 0, dataCertificate, dataSolutionIds);
        //     break;
        // case 'Suppression':
        //     await deleteServer(selectedRowData ? selectedRowData.id : 0);
        //     break;
        default:
          console.log("Operation not defined");
      }
      const data = await getAllCertificates();
      setCertificates(data);
      setOpenModal(false);
      setSelectedRowData(null);
      setErrorOperationMsg(null);
    } catch (error) {
      const err = error as AxiosError<ErrorResponse>;

      if (err.status === 409) {
        setErrorOperationMsg(
          err.response?.data.message || "Undefined message error",
        );
      } else if (err.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    }
  };

  const defaultVisibleColumns: Record<string, boolean> = {
    actions: true,
    "Réf de ticket iTop": true,
    Référence: false,
    Type: true,
    "Common Name": true,
    "Statut de la demande": true,
    "Statut de ticket": true,
    "Date d'expiration": true,
    Demandeur: true,
    Validateur: false,
    Solution: true,
  };

  const initialVisibility = (columns: any[]) => {
    const initialVisibility: Record<string, boolean> = {};

    columns.forEach((column) => {
      initialVisibility[column.field] =
        defaultVisibleColumns[column.field] || false;
    });
    setColumnVisibility(initialVisibility);
  };

  const getResponsiveWidth = (key: string) => {
    const screenWidth = window.innerWidth;

    const tableColumns = [
      "Common Name",
      "Statut de la demande",
      "Statut de ticket",
    ];
    const tableColumns2 = ["Interne/Externe"];
    const tableColumns3 = [
      "Solution",
      "Demandeur",
      "Validateur",
      "Date d'expiration",
    ];

    if (screenWidth < 600) {
      if (tableColumns.includes(key)) return 75;
      else if (tableColumns2.includes(key)) return 65;
      else if (tableColumns3.includes(key)) return 120;
      return 80;
    } else if (screenWidth < 960) {
      if (tableColumns.includes(key)) return 140;
      else if (tableColumns2.includes(key)) return 65;
      else if (tableColumns3.includes(key)) return 180;
      return 100;
    } else {
      if (tableColumns.includes(key)) return 160;
      else if (key === tableColumns[2] || key === tableColumns[3]) return 220;
      else if (tableColumns3.includes(key)) return 140;
      else if (tableColumns2.includes(key)) return 65;
      return 120;
    }
  };

  const getEtapeActive = (demande: string): number => {
    if (demande === undefined) {
      return 0;
    } else if (["En cours", "Créer"].includes(demande)) {
      return 1;
    } else if (["Fermer", "Rejeter"].includes(demande)) {
      return 2;
    }
    return -1;
  };

  const styles = {
    etapeEnCours: {
      backgroundColor: "#ffc107", // Jaune

      color: "#000",

      border: "1px solid #ffc107",
    },

    etapeTerminee: {
      backgroundColor: "#fff", // Vert

      color: "#6bcd3a",

      border: "1px solid #6bcd3a",
    },

    etapeRejeter: {
      backgroundColor: "#fff", // Vert

      color: "#cc3300",

      border: "1px solid #cc3300",
    },

    etapeAVenir: {
      backgroundColor: "#f8f9fa", // Gris clair

      color: "#6c757d",

      border: "1px solid #dee2e6",
    },
  };

  function valueContent(value: any, key: string, params: any) {
    if (
      value === null ||
      value === "" ||
      (Array.isArray(value) && value.length === 0)
    ) {
      return (
        <span
          style={{
            textAlign: "center",
            fontWeight: "bold",
            fontSize: "2rem",
            display: "inline-block",
          }}
        >
          -
        </span>
      );
    }
    if (typeof value === "object" && !Array.isArray(value)) {
      return (
        <CustomTooltip title={JSON.stringify(value, null, 2)}>
          <span>{Object.values(value).join(", ")}</span>
        </CustomTooltip>
      );
    }

    if (["Statut de ticket"].includes(key)) {
      return (
        <div className="progress-container">
          <div className="progress-line"></div>
          {[<PlayCircleFilledIcon />, <TaskIcon />, <VerifiedUserIcon />].map(
            (_, i) => {
              const etapeActive = getEtapeActive(value);
              const getStepStyle = () => {
                if (i === etapeActive) {
                  if (value === "Rejeter") return styles.etapeRejeter; // Rouge - Rejeter
                  if (value === "Fermer") return styles.etapeTerminee; // Vert - Terminé
                  return styles.etapeEnCours; // Jaune - En cours
                } else if (i < etapeActive) {
                  return styles.etapeTerminee; // Vert - Terminé
                } else {
                  return styles.etapeAVenir; // Gris - À venir
                }
              };

              return (
                <div key={i} className="progress-step">
                  <span className="progress-circle" style={getStepStyle()}>
                    {i === 2 && value !== "Rejeter" && value !== "Fermer" ? (
                      <IconButton
                        onClick={() => handleValidateData(params.row)}
                        style={getStepStyle()}
                      >
                        <VerifiedUserIcon />
                      </IconButton>
                    ) : (
                      <>
                        {value === "Fermer" ? (
                          <VerifiedUserIcon />
                        ) : (
                          <GppBadIcon />
                        )}
                      </>
                    )}
                  </span>
                </div>
              );
            },
          )}
        </div>
      );
    }

    // if (["Réf de ticket iTop"].includes(key)) {
    //   return (
    //     <Link
    //       color="primary"
    //       href={`https://itop.attijariwafa.net/pages/UI.php?operation=details&class=UserRequest&id=${params.row.itop_ticket_num}`}
    //       underline="always"
    //       rel="noopener"
    //       target="_blank"
    //       sx={{
    //         alignItems: "center",
    //         justifyContent: "flex-start",
    //         display: "flex",
    //       }}
    //     >
    //       <DownloadIcon />
    //       {value}
    //     </Link>
    //   );
    // }

    if (["Common Name"].includes(key)) {
      return (
        <CustomTooltip
          title={params.row.dns ? Object.values(params.row.dns).join(", ") : ""}
        >
          <Link
            color="primary"
            href={`${path}/download/${params.row.id}`}
            underline="always"
            rel="noopener"
            target="_blank"
            sx={{
              alignItems: "center",
              justifyContent: "flex-start",
              display: "flex",
            }}
          >
            <DownloadIcon />
            {value}
          </Link>
        </CustomTooltip>
      );
    }

    if (Array.isArray(value)) {
      if (key === "Statut de la demande") {
        return (
          <>
            {value.map((val, index) => {
              if (val === "Expiré" || val === "Rejeté") {
                return (
                  <CustomBadge
                    key={index}
                    text={val}
                    backgroundColor={getCssVariableValue(
                      "--certifcate-badge-error-contrastText",
                    )}
                    textColor={getCssVariableValue("--certifcate-badge-error")}
                    textSize={"0.8rem"}
                    withBorder
                    borderColor={getCssVariableValue(
                      "--certifcate-badge-error",
                    )}
                  />
                );
              } else if (val === "En cours de signature") {
                return (
                  <CustomBadge
                    key={index}
                    text={val}
                    backgroundColor={getCssVariableValue(
                      "--certifcate-badge-warning-contrastText",
                    )}
                    textColor={getCssVariableValue(
                      "--certifcate-badge-warning",
                    )}
                    textSize={"0.8rem"}
                    withBorder
                    borderColor={getCssVariableValue(
                      "--certifcate-badge-warning",
                    )}
                  />
                );
              } else if (val === "Activé") {
                return (
                  <CustomBadge
                    key={index}
                    text={val}
                    backgroundColor={getCssVariableValue(
                      "--certifcate-badge-success-contrastText",
                    )}
                    textColor={getCssVariableValue(
                      "--certifcate-badge-success",
                    )}
                    textSize={"0.8rem"}
                    withBorder
                    borderColor={getCssVariableValue(
                      "--certifcate-badge-success",
                    )}
                  />
                );
              } else {
                return (
                  <CustomBadge
                    key={index}
                    text={val}
                    backgroundColor={getCssVariableValue(
                      "--certifcate-badge-renew-contrastText",
                    )}
                    textColor={getCssVariableValue("--certifcate-badge-renew")}
                    textSize={"0.8rem"}
                    withBorder
                    borderColor={getCssVariableValue(
                      "--certifcate-badge-renew",
                    )}
                  />
                );
              }
            })}
          </>
        );
      }
    }

    if (["Date d'expiration"].includes(key)) {
      return (
        <CustomTooltip title={value !== null ? getFormatedDate(value) : ""}>
          <span>{getFormatedDate(value)}</span>
        </CustomTooltip>
      );
    }

    return (
      <CustomTooltip title={value !== null && value}>
        <span>{value}</span>
      </CustomTooltip>
    );
  }

  const columns = useMemo(() => {
    if (certificates && certificates.length === 0) return [];

    const actionColumn = {
      field: "actions",
      headerName: "Actions",
      width: 125,
      sortable: false,
      filterable: false,
      renderCell: (params: any) => (
        <div
          style={{
            display: "flex",
            gap: "8px",
            alignItems: "center",
            justifyContent: "flex-start",
            marginLeft: "18px",
          }}
        >
          <IconButton
            onClick={() => handleDisplayData(params.row, "Visualisation")}
            className="icon-button certifcate"
            sx={{ mt: "1.2rem" }}
          >
            <VisibilityIcon className="data-table-icon-button" />
          </IconButton>
          <IconButton
            onClick={() => renewExpireCertificate(params.row)}
            className="icon-button certifcate-renew"
            sx={{
              mt: "1.2rem",
              display:
                params.row["Statut de la demande"].includes(
                  "En cours de signature",
                ) || params.row["Statut de la demande"].includes("Rejeté")
                  ? "none"
                  : "inline-flex",
            }}
          >
            <AutorenewIcon className="data-table-icon-button" />
          </IconButton>
        </div>
      ),
    };
    const dataColumns = Object.keys(
      Array.isArray(certificates) ? certificates[0] : [],
    )
      .filter((key) => key !== "id")
      .map((key) => ({
        field: key,
        headerName: key,
        description: key,
        width: getResponsiveWidth(key),
        // width: 80,
        fontSize: "2rem",
        renderCell: (params: any) => valueContent(params.value, key, params),
        sortable: true,
        sortComparator: (v1: string | [], v2: string | []) => {
          if (Array.isArray(v1) && Array.isArray(v2)) {
            return v1.join(", ").localeCompare(v2.join(", ")); // Transformer les tableaux en string pour comparer
          }
          if (typeof v1 === "string" && typeof v2 === "string") {
            return v1.localeCompare(v2);
          }
          return 0; // Par défaut, ne change pas l'ordre
        },
      }));
    initialVisibility([actionColumn, ...dataColumns]);

    return [actionColumn, ...dataColumns];
  }, [certificates]);

  const customTheme = createTheme({
    palette: {
      primary: { main: getCssVariableValue("--certifcate-main-color") },
      success: {
        main: getCssVariableValue("--certifcate-badge-success"),
        contrastText: getCssVariableValue(
          "--certifcate-badge-success-contrastText",
        ),
      },
    },
  });

  const filteredRows = useMemo(() => {
    setCertificateAdd(null);

    return (
      certificates &&
      certificates.filter((row) => {
        const isInterneCert =
          isInterne &&
          row["Interne/Externe"] &&
          row["Interne/Externe"].includes("Interne");
        const isExterneCert =
          isExterne &&
          row["Interne/Externe"] &&
          row["Interne/Externe"].includes("Externe");

        const isInProgressCert =
          isInProgress &&
          row["Statut de la demande"] &&
          row["Statut de la demande"].includes("En cours de signature");

        if (isInProgress) {
          if (isInterne || isExterne) {
            return (
              (isInterneCert && isInProgressCert) ||
              (isExterneCert && isInProgressCert)
            );
          }
        } else {
          if (isInterne || isExterne) {
            return isInterneCert || isExterneCert;
          }
        }

        return true;
      })
    );
  }, [isInterne, isExterne, isInProgress, certificates]);

  if (loading) return <CustomLoading />;
  else if (errorServiceMsg !== null) {
    return (
      <>
        <Box
          color="error.main"
          sx={{ textAlign: "center", marginTop: 2, fontWeight: "bold" }}
        >
          {errorServiceMsg}
        </Box>
      </>
    );
  } else
    return (
      <ThemeProvider theme={customTheme}>
        {/* <Button
          variant="contained"
          color="primary"
          startIcon={<KeyboardIcon />}
          onClick={() => setIsInterne(true)}
          className="button-add"
        >
          <Typography className="text-button-add">Interne</Typography>
        </Button>
        <Button
          variant="contained"
          color="primary"
          startIcon={<KeyboardIcon />}
          onClick={() => setIsExterne(true)}
          className="button-add"
        >
          <Typography className="text-button-add">Externe</Typography>
        </Button> */}
        <Box>
          <Box
            display="flex"
            justifyContent="space-between"
            alignItems="center"
            mb={3}
          >
            {/* Texte aligné à gauche */}
            <Typography className="data-table-title">
              {certificates && certificates.length === 0
                ? "Aucun certificat disponible"
                : "Liste des Namespaces"}
            </Typography>

            {/* Conteneur pour les boutons à droite */}
            <Box display="flex" gap={2}>
              <Button
                variant="contained"
                color="primary"
                startIcon={<KeyboardIcon />}
                onClick={() => handleAddManual("Ajout")}
                className="button-add"
              >
                <Typography className="text-button-add">Ajouter</Typography>
              </Button>
            </Box>
          </Box>
          {certificates && certificates.length !== 0 && (
            <WidgetMainContainer sx={{ borderColor: "--primary-color" }}>
              <DataGrid
                rows={filteredRows!}
                columns={columns}
                getRowClassName={(params) =>
                  params.row.id == certificateAdd?.crt?.certificate_id
                    ? certificateAdd?.class
                    : ""
                }
                getRowId={(row) => row.id}
                pageSizeOptions={[5, 10, 25, 50]}
                initialState={{
                  pagination: {
                    paginationModel: { pageSize: 25, page: 0 },
                  },
                  columns: {
                    columnVisibilityModel: columnVisibility,
                  },
                }}
                onColumnVisibilityModelChange={(newModel) =>
                  setColumnVisibility(newModel)
                }
                slots={{ toolbar: CustomToolBarHome }}
                slotProps={{
                  toolbar: {
                    existProductionFilter: true,
                    existPoleFilter: false,
                  } as any,
                }}
                sx={{
                  border: "none",
                  "& .MuiDataGrid-columnHeaderTitle": {
                    fontWeight: "bold",
                  },
                }}
              />
            </WidgetMainContainer>
          )}
          <MyModal
            mainColor="--certifcate-main-color"
            open={openModal}
            onClose={handleCloseModal}
            title={
              modalType === "Importer"
                ? "Importer des serveurs"
                : `${modalType} d'un namespace`
            }
            data={selectedRowData || {}}
          >
            <OpenshiftForm
              initialData={modalType !== "Ajout" ? certificateById : undefined}
              onSubmit={handleActionSubmit}
              isEditMode={modalType === "Modification" ? true : false}
              isViewMode={modalType === "Visualisation" ? true : false}
              isDeleteMode={modalType === "Suppression" ? true : false}
              errorMessage={errorOperationMsg}
            />
          </MyModal>

          {/* Visualisation d'un namespace */}
          <MyModal
            mainColor="--certifcate-main-color"
            open={openModalDisplay}
            onClose={handleCloseModalDisplay}
            // title={modalType === "Importer" ? "Importer des certificats" : `${modalType} d'un namespace`}
            title={`${modalType} d'un namespace`}
            data={certificateById || {}}
          >
            {certificateById ? (
              <Box sx={{ width: "400px" }}>
                {/* Informations Générales en haut */}
                <Box>
                  <Typography
                    variant="h5"
                    fontWeight="bold"
                    sx={{ mb: "0.3rem" }}
                  >
                    {certificateById.solution?.solution_name}
                  </Typography>
                  <Typography sx={{ fontSize: "1.3rem" }}>
                    Common Name
                  </Typography>
                  <Typography
                    sx={{ fontSize: "1rem", mb: "0.3rem" }}
                    color="textSecondary"
                  >
                    {certificateById.common_name}
                  </Typography>
                  <Typography sx={{ fontSize: "1.3rem" }}>DNS</Typography>
                  {certificateById.dns?.map((d, index) => (
                    <Typography
                      sx={{ fontSize: "1rem", mb: "0.3rem" }}
                      color="textSecondary"
                    >
                      {index + 1}. {d}
                    </Typography>
                  ))}
                  {/* <Typography color="textSecondary">{certificateById.dns?.join(", ")}</Typography> */}
                </Box>
                <Divider sx={{ my: "10px" }} />

                {/* Timeline */}
                <Timeline position="alternate">
                  {/* Demandeur */}
                  <TimelineItem>
                    <TimelineSeparator>
                      <TimelineDot color="primary">
                        <CheckCircleIcon />
                      </TimelineDot>
                      <TimelineConnector />
                    </TimelineSeparator>
                    <TimelineContent>
                      <Typography variant="h6">Demandé par</Typography>
                      <Typography color="textSecondary">
                        {certificateById.applicant.toLocaleLowerCase()}
                      </Typography>
                    </TimelineContent>
                  </TimelineItem>

                  {/* Création du Ticket iTop */}
                  <TimelineItem>
                    <TimelineSeparator>
                      <TimelineDot color="warning">
                        <CheckCircleIcon />
                      </TimelineDot>
                      <TimelineConnector />
                    </TimelineSeparator>
                    <TimelineContent>
                      <Typography variant="h6">Ticket iTop</Typography>
                      <Link
                        color="primary"
                        href={`https://itop.attijariwafa.net/pages/UI.php?operation=details&class=UserRequest&id=${certificateById.itop_ticket_num}`}
                        underline="always"
                        rel="noopener"
                        target="_blank"
                      >
                        <Typography variant="subtitle1">
                          {certificateById.itop_ticket_ref}
                        </Typography>
                      </Link>
                      <Typography color="textSecondary">
                        {getFormatedDate(certificateById.created_at)}
                      </Typography>
                    </TimelineContent>
                  </TimelineItem>

                  {/* Demande de certificat */}
                  <TimelineItem>
                    <TimelineSeparator>
                      <TimelineDot color="primary">
                        <CheckCircleIcon />
                      </TimelineDot>
                      <TimelineConnector />
                    </TimelineSeparator>
                    <TimelineContent>
                      <Typography variant="h6">Référence</Typography>
                      <Typography variant="subtitle1">
                        {certificateById.certificate_request_ref}
                      </Typography>
                      <Typography variant="subtitle1" color="textSecondary">
                        {certificateById.certificate_target}
                      </Typography>
                    </TimelineContent>
                  </TimelineItem>

                  {/* Validateur */}
                  <TimelineItem>
                    <TimelineSeparator>
                      <TimelineDot
                        color={
                          certificateById.ticket_state === "Rejeter"
                            ? "error"
                            : certificateById.ticket_state === "Fermer"
                              ? "success"
                              : "info"
                        }
                      >
                        {certificateById.validator ? (
                          <CheckCircleIcon />
                        ) : (
                          <CircularProgress size={20} />
                        )}
                      </TimelineDot>
                    </TimelineSeparator>
                    <TimelineContent>
                      {certificateById.validator ? (
                        <>
                          <Typography variant="h6">
                            {certificateById.ticket_state === "Rejeter"
                              ? "Rejeté "
                              : "Validé "}{" "}
                            par
                          </Typography>
                          <Typography color="textSecondary">
                            {certificateById.validator.toLocaleLowerCase()}
                          </Typography>
                          <Typography color="textSecondary">
                            {getFormatedDate(certificateById.validated_at)}
                          </Typography>
                        </>
                      ) : (
                        <Typography sx={{ fontSize: "1.2rem" }}>
                          En cours de signature
                        </Typography>
                      )}
                    </TimelineContent>
                  </TimelineItem>
                </Timeline>

                {/* Date d'expiration en bas */}
                {certificateById.exp_date && (
                  <>
                    <Divider sx={{ my: 2 }} />
                    <Box sx={{ textAlign: "center", mt: 2 }}>
                      <Typography variant="h6">Date d'expiration</Typography>
                      <Typography color="textSecondary">
                        {getFormatedDate(certificateById.exp_date!)}
                      </Typography>
                    </Box>
                  </>
                )}
              </Box>
            ) : (
              <Typography>Aucune donnée disponible</Typography>
            )}
          </MyModal>

          {/* Validation/Refus d'un namespace */}
          <MyModal
            mainColor="--certifcate-main-color"
            open={openModalValidate}
            onClose={handleCloseModalValidate}
            title={"Validation de la demande"}
            data={certificateById || {}}
          >
            {certificateById ? (
              <Box sx={{ p: 2 }}>
                <Typography variant="h5">
                  {`Demande de certificat ${certificateById.certificate_target} pour `}
                  <b>{`${certificateById.solution?.solution_name} `} </b>
                </Typography>
                <Card
                  variant="outlined"
                  sx={{
                    marginTop: "20px",
                    width: "80%",
                    marginX: "auto",
                    bgcolor: "#f1f8ff",
                  }}
                >
                  <CardContent>
                    <Typography variant="h6" component="p">
                      <b>[req_distinguished_name]</b>
                    </Typography>
                    <Typography variant="h6" component="p">
                      countryName = {certificateById.config_file.countryName}
                    </Typography>
                    <Typography variant="h6" component="p">
                      stateOrProvinceName ={" "}
                      {certificateById.config_file.stateOrProvinceName}
                    </Typography>
                    <Typography variant="h6" component="p">
                      localityName = {certificateById.config_file.localityName}
                    </Typography>
                    <Typography variant="h6" component="p">
                      organizationName ={" "}
                      {certificateById.config_file.organizationName}
                    </Typography>
                    <Typography variant="h6" component="p">
                      organizationalUnitName ={" "}
                      {certificateById.config_file.organizationalUnitName}
                    </Typography>
                    <Typography variant="h6" component="p">
                      commonName ={" "}
                      <b>{certificateById.config_file.commonName}</b>
                    </Typography>
                    <Typography variant="h6" component="p">
                      emailAddress = {certificateById.config_file.emailAddress}
                    </Typography>
                    <Typography variant="h6" component="p">
                      postalCode = {certificateById.config_file.postalCode}
                    </Typography>
                    <Typography variant="h6" component="p">
                      streetAddress ={" "}
                      {certificateById.config_file.streetAddress}
                    </Typography>
                    <Typography variant="h6" component="p">
                      <b>[req_ext]</b>
                    </Typography>
                    <Typography variant="h6" component="p">
                      subjectAltName ={" "}
                      {certificateById.config_file.subjectAltName}
                    </Typography>
                    <Typography variant="h6" component="p">
                      <b>[alt_names]</b>
                    </Typography>
                    <Typography variant="h6" component="p">
                      <b>DNS.1</b> = {certificateById.config_file.commonName}
                    </Typography>
                    {certificateById.dns &&
                      certificateById.dns.map((value, index) => (
                        <Typography variant="h6" component="p">
                          <b>{`DNS.${index + 2}`}</b> = {value}
                        </Typography>
                      ))}
                  </CardContent>
                </Card>
                <Divider sx={{ my: 2 }} />
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <Button
                    variant="outlined"
                    sx={{ marginX: "5px" }}
                    endIcon={<UnpublishedIcon />}
                    color="error"
                    onClick={() =>
                      rejectNewCertificate(certificateById.certificate_id)
                    }
                  >
                    Rejeter
                  </Button>
                  <Button
                    variant="contained"
                    sx={{ marginX: "5px" }}
                    endIcon={<CheckCircleIcon />}
                    onClick={() =>
                      validateNewCertificate(certificateById.certificate_id)
                    }
                  >
                    Valider
                  </Button>
                </Box>
              </Box>
            ) : (
              <Typography>Aucune donnée disponible</Typography>
            )}
          </MyModal>
        </Box>
      </ThemeProvider>
    );
}
