import React from "react";
import { Box, Container, Typography, Link } from "@mui/material";

const FooterBar: React.FC = () => {
  return (
    <Box
      component="footer"
      sx={{
        backgroundColor: "black",
        color: "white",
        py: 3,
        mt: "auto",
        width: "100%",
      }}
    >
      <Container maxWidth="lg">
        <Typography variant="body1" align="center">
          &copy; {new Date().getFullYear()} Attijariwafa bank. Tous droits
          réservés.
        </Typography>
        <Typography variant="body2" align="center">
          <Link href="/terms" color="inherit">
            Conditions d'utilisation
          </Link>
          {" | "}
          <Link href="/privacy" color="inherit">
            Politique de confidentialité
          </Link>
        </Typography>
      </Container>
    </Box>
  );
};

export default FooterBar;
