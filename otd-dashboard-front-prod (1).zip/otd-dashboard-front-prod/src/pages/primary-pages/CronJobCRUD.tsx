/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { useEffect, useState } from 'react';
import { Container, Typography, Divider, Paper, Box } from '@mui/material';
import fetchWithAuth from '@/middleware/fetch-auth';
import CronJobForm from './CronJobCRUD/CronJobForm';
import CronJobList from './CronJobCRUD/CronJobList';
import NotificationSnackbar from './CronJobCRUD/NotificationSnackbar';
import { CRONJOBS_BaseUrl } from '@/config/api.config';

const API_BASE = CRONJOBS_BaseUrl();

const CronJobCRUD = () => {
  const [jobs, setJobs] = useState<any[]>([]);
  const [editingJob, setEditingJob] = useState<any | null>(null);
  const [form, setForm] = useState({ name: '', command: '', interval: 30, active: false, description: '' });
  const [snackbar, setSnackbar] = useState<{ message: string; severity: 'success' | 'error' } | null>(null);

  const showSnackbar = (message: string, severity: 'success' | 'error') => setSnackbar({ message, severity });
  const resetForm = () => { setForm({ name: '', command: '', interval: 30, active: false, description: '' }); setEditingJob(null); };

  const fetchJobs = async () => {
    try {
      const res = await fetchWithAuth(API_BASE, { method: 'GET' });
      const data = await res.json();
      setJobs(data);
    } catch (error) {
      showSnackbar(`Erreur lors du chargement des jobs: ${error}`, 'error');
    }
  };

  useEffect(() => { fetchJobs(); }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const jobData = {
      name: form.name,
      command: `python manage.py ${form.command}`,
      interval: Number(form.interval),
      active: form.active,
      description: form.description,
    };

    try {
      if (editingJob) {
        await fetchWithAuth(`${API_BASE}${editingJob.id}/`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(jobData),
        });
        showSnackbar('Job modifié avec succès', 'success');
      } else {
        await fetchWithAuth(API_BASE, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(jobData),
        });
        showSnackbar('Job créé avec succès', 'success');
      }
      resetForm();
      fetchJobs();
    } catch (error) {
      showSnackbar('Erreur lors de la soumission', 'error');
    }
  };

  const handleEdit = (job: any) => {
    setEditingJob(job);
    setForm({
      name: job.name,
      command: job.command.replace('python manage.py ', ''),
      interval: job.interval,
      active: job.active,
      description: job.description || '',
    });
  };

  const handleDelete = async (id: number) => {
    try {
      await fetchWithAuth(`${API_BASE}${id}/`, { method: 'DELETE' });
      showSnackbar('Job supprimé', 'success');
      fetchJobs();
    } catch (error) {
      showSnackbar('Erreur lors de la suppression', 'error');
    }
  };

  return (
    <Container maxWidth="md" sx={{ mt: 4 }}>
      <Paper elevation={3} sx={{ p: 4, backgroundColor: '#f9f9f9' }}>
        <Typography variant="h4" gutterBottom color="primary">Gestion des Cronjobs</Typography>
        <CronJobForm
          {...form}
          editingJob={editingJob}
          onChange={(field, value) => setForm((prev) => ({ ...prev, [field]: value }))}
          onSubmit={handleSubmit}
          onCancel={resetForm}
        />
      </Paper>

      <Divider sx={{ my: 4 }} />
      <Box>
        <CronJobList jobs={jobs} onEdit={handleEdit} onDelete={handleDelete} />
      </Box>
      <NotificationSnackbar snackbar={snackbar} onClose={() => setSnackbar(null)} />
    </Container>
  );
};

export default CronJobCRUD;