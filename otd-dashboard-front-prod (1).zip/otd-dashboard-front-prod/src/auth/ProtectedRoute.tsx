
// src/components/ProtectedRoute.tsx
import { useEffect, useRef, useState } from "react";
import { Navigate, useLocation } from "react-router-dom";
import type { ReactNode } from "react";
import { keycloak } from "./keycloakConnectAdapter";

type ProtectedRouteProps = {
  children: ReactNode;
  /** Optional custom loader while auth is checking */
  fallback?: ReactNode;
};

export const ProtectedRoute = ({ children, fallback }: ProtectedRouteProps) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);
  const [error, setError] = useState<unknown>(null);
  const location = useLocation();
  const isMounted = useRef(true);

  useEffect(() => {
    isMounted.current = true;

    const checkAuth = async () => {
      try {
        // If your adapter returns a function, keep the double call; otherwise call directly.
        // Example A (double-call):
        // const auth = await keycloak.protect()();
        // Example B (single-call):
        // const auth = await keycloak.protect();

        const protectFn = keycloak.protect?.();
        const auth = typeof protectFn === "function"
          ? await protectFn()
          : await keycloak.protect();

        if (isMounted.current) {
          setIsAuthenticated(Boolean(auth));
        }
      } catch (e) {
        if (isMounted.current) {
          setError(e);
          setIsAuthenticated(false);
        }
      }
    };

    checkAuth();

    return () => {
      isMounted.current = false;
    };
  }, []);

  // Still checking
  if (isAuthenticated === null) {
    return (
      <>
        {fallback ?? <div>Loading...</div>}
      </>
    );
  }

  // Optional: show a generic error state (you can customize)
  if (error) {
    // You may want to log error or send to monitoring here
    return (
      <Navigate
        to="/login"
        replace
        state={{ from: location, error: String(error) }}
      />
    );
  }

  // Authenticated → render children
  if (isAuthenticated) {
    return <>{children}</>;
  }

  // Not authenticated → redirect to login, preserve original location
  return (
    <Navigate
      to="/login"
      replace
      state={{ from: location }}
    />
  );
};
