// src/services/DeltaService.ts

import axios, { AxiosError } from "axios";

// import files
import { mapData } from "@/mappers/DataMapper";
import { ErrorResponse } from "@/exceptions/ErrorResponse";
import { ResultDeltaView } from "@/types/view/ResultDeltaView";

const PREFIX_PATH = import.meta.env.VITE_PREFIX_SOURCE_PATH;
const SUFFIX_PATH = import.meta.env.VITE_SUFFIX_SOURCE_PATH;
const SERVER_PORT = import.meta.env.VITE_SOURCE_SERVER_PORT;
const path = `${PREFIX_PATH}:${SERVER_PORT}/${SUFFIX_PATH}/delta`;

export const getDelta = async (source: string, destination: string) => {
  try {
    if (source === "inventaire") source = "inventory";
    else if (destination === "inventaire") destination = "inventory";

    const response = await axios.get(
      `${path}?base=${source}&compare=${destination}`,
    );

    // Mapper les données
    const existingVMs = mapData(response.data?.existingVMs);
    const baseMissingVMs = mapData(response.data?.baseMissingVMs);
    const compareMissingVMs = mapData(response.data?.compareMissingVMs);

    // Construire l'objet HostType
    const result: ResultDeltaView = {
      base: source,
      compare: destination,
      existing: existingVMs as [],
      baseMissing: baseMissingVMs as [],
      compareMissing: compareMissingVMs as [],
    };

    return result;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error("Error fetching delta of server data:", err.response?.data);
    throw err;
  }
};
