// ✅ EditPostModal.tsx

import { useEffect, useState } from "react";
import {
  TextField,
  Button,
  Box,
  Grid,
  Typography,
  CircularProgress,
  Snackbar,
  Alert,
} from "@mui/material";
import { useForm } from "react-hook-form";
import { z as zod } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

import MyModal from "@/components/modals/MyModal";
import { updatePost } from "@/services/admin/PostService";

const formSchema = zod.object({
  new_name: zod.string().trim().min(1, "Le nouveau nom est requis."),
});

type FormEditPost = zod.infer<typeof formSchema>;

interface EditPostModalProps {
  open: boolean;
  onClose: () => void;
  onSave: () => void;
  postId: number;
  currentName: string;
}

export const EditPostModal: React.FC<EditPostModalProps> = ({
  open,
  onClose,
  onSave,
  postId,
  currentName,
}) => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isValid },
  } = useForm<FormEditPost>({
    resolver: zodResolver(formSchema),
    mode: "all",
    defaultValues: {
      new_name: "",
    },
  });

  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successSnackbar, setSuccessSnackbar] = useState(false);

  useEffect(() => {
    if (open) {
      reset();
      setErrorMessage(null);
    }
  }, [open, reset]);

  const handleSave = async (data: FormEditPost) => {
    setErrorMessage(null);
    setLoading(true);
    setSuccessSnackbar(true);
    try {
      await updatePost(postId, { post_name: data.new_name });

      onSave();
      onClose();
    } catch (error) {
      console.error("Erreur lors de la modification du post:", error);
      setErrorMessage("Échec de la modification du post.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <MyModal open={open} onClose={onClose} title="Modifier un Post">
        <form onSubmit={handleSubmit(handleSave)}>
          <Grid container spacing={2} sx={{ p: 2 }}>
            {/* Champ nom actuel */}
            <Grid item xs={12} container spacing={2} alignItems="center">
              <Grid item xs={4}>
                <Typography fontWeight="bold">Nom actuel</Typography>
              </Grid>
              <Grid item xs={8} style={{ width: 500 }}>
                <TextField
                  fullWidth
                  value={currentName}
                  InputProps={{ readOnly: true }}
                />
              </Grid>
            </Grid>

            {/* Nouveau nom */}
            <Grid item xs={12} container spacing={2} alignItems="center">
              <Grid item xs={4}>
                <Typography fontWeight="bold">Nouveau nom</Typography>
              </Grid>
              <Grid item xs={8}>
                <TextField
                  {...register("new_name")}
                  error={!!errors.new_name}
                  helperText={errors.new_name?.message}
                  fullWidth
                  placeholder="Entrer un nouveau nom"
                />
              </Grid>
            </Grid>

            {/* Erreur globale */}
            {errorMessage && (
              <Grid item xs={12}>
                <Alert severity="error" variant="filled">
                  {errorMessage}
                </Alert>
              </Grid>
            )}
          </Grid>

          {/* Boutons */}
          <Box textAlign="right" px={2} pb={2}>
            <Button onClick={onClose} sx={{ mr: 1 }}>
              Annuler
            </Button>
            <Button
              type="submit"
              variant="contained"
              disabled={!isValid || loading}
            >
              {loading ? (
                <CircularProgress size={20} color="inherit" />
              ) : (
                "Modifier"
              )}
            </Button>
          </Box>
        </form>
      </MyModal>

      {/* Snackbar succès */}
      <Snackbar
        open={successSnackbar}
        autoHideDuration={3000}
        onClose={() => setSuccessSnackbar(false)}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <Alert
          onClose={() => setSuccessSnackbar(false)}
          severity="success"
          variant="filled"
        >
          Poste à été créer avec succès !
        </Alert>
      </Snackbar>
    </>
  );
};
