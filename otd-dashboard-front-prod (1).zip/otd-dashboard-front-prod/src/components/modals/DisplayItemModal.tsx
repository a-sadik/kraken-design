import React, { useEffect, useState } from "react";
import {
  Typography,
  CircularProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Box,
  Button,
} from "@mui/material";
import axios from "axios";
import MyModal from "@/components/modals/MyModal";

interface Props {
  open: boolean;
  onClose: () => void;
  title: string;
  url: string;
}

export const DisplayItemModal: React.FC<Props> = ({
  open,
  onClose,
  title,
  url,
}) => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open && url) {
      setLoading(true);
      axios
        .get(url)
        .then((res) => setData(res.data))
        .finally(() => setLoading(false));
    }
  }, [open, url]);

  const renderContent = () => {
    if (loading) {
      return (
        <Box textAlign="center" my={3}>
          <CircularProgress />
        </Box>
      );
    }

    if (Array.isArray(data)) {
      return (
        <TableContainer component={Paper} sx={{ mt: 2 }}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>
                  <strong>Nom</strong>
                </TableCell>
                <TableCell>
                  <strong>Manager</strong>
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {data.map((item: any, index: number) => (
                <TableRow key={index}>
                  <TableCell>{item.name}</TableCell>
                  <TableCell>{item.manager?.name || "Non défini"}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      );
    }

    if (data) {
      return (
        <Box mt={2}>
          <Typography variant="subtitle1">
            <strong>Nom:</strong> {data.name}
          </Typography>
          <Typography variant="subtitle1">
            <strong>Manager:</strong> {data.manager?.name || "Non défini"}
          </Typography>
        </Box>
      );
    }

    return <Typography>Pas de données disponibles.</Typography>;
  };

  return (
    <MyModal open={open} onClose={onClose} title={`Détails : ${title}`}>
      <Box sx={{ minWidth: 500, px: 2, pt: 1 }}>
        {renderContent()}

        <Box textAlign="right" mt={3}>
          <Button onClick={onClose} variant="outlined">
            Fermer
          </Button>
        </Box>
      </Box>
    </MyModal>
  );
};
