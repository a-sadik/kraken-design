// src/types/enums/PCI.ts

export enum PCI {
  P1 = "P1",
  P2 = "P2",
  P3 = "P3",
  P4 = "P4",
}
