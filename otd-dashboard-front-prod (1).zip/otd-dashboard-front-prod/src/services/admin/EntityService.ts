// src/services/EntityService.ts

import { AxiosError } from "axios";

// import files
import {
  EntityRequestDTO,
  EntityDetailtResponseDTO,
  EntityShortResponseDTO,
} from "@/types/dto/EntityDTO";

import { ErrorResponse } from "@/exceptions/ErrorResponse";
import apiClient from "../apiClientHttp";

const path = `/entities`;

// Function to recieve all entities
export const getAllEntities = async (): Promise<EntityShortResponseDTO[]> => {
  try {
    const response = await apiClient.dataApiClient.get<
      EntityShortResponseDTO[]
    >(`${path}`);

    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error(
      "Error fetching all entitys data:",
      err.response?.data.message,
    );
    throw err;
  }
};

// Function to recieve one entity by id
export const getEntityById = async (
  id: number,
): Promise<EntityDetailtResponseDTO | null> => {
  try {
    const response =
      await apiClient.dataApiClient.get<EntityDetailtResponseDTO | null>(
        `${path}/${id}`,
      );
    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error("Error fetching entity data by id:", err.response?.data);
    throw error;
  }
};

// Function to create entity
export const createEntity = async (
  reqBody: EntityRequestDTO,
): Promise<EntityShortResponseDTO | null> => {
  try {
    const response =
      await apiClient.dataApiClient.post<EntityShortResponseDTO | null>(
        `${path}`,
        reqBody,
      );
    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error("Error creating new entity:", err.response?.data);
    throw error;
  }
};

// Function to update entity
export const updateEntity = async (
  id: number,
  reqBody: EntityRequestDTO,
): Promise<EntityRequestDTO | null> => {
  try {
    const response =
      await apiClient.dataApiClient.put<EntityDetailtResponseDTO | null>(
        `${path}/${id}`,
        reqBody,
      );
    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error("Error updating new entity:", err.response?.data);
    throw error;
  }
};
