import React, { useState, useEffect, useRef } from "react";
import {
  Box,
  Card,
  CardContent,
  Typography,
  Grid,
  Paper,
  Chip,
  IconButton,
  Tooltip,
  Alert,
  CircularProgress,
  Stack,
  Divider,
  LinearProgress,
  Tab,
  Tabs,
  Button,
} from "@mui/material";
import {
  Server,
  Monitor,
  AlertTriangle,
  CheckCircle,
  XCircle,
  RefreshCw,
  Activity,
  Network,
  Shield,
  PieChart,
} from "lucide-react";
import { getBadgeColorEnvironment } from "@/utils/getDynamicColor";
import { hardware_info_openshift_info, hardware_info_power_info, hardware_info_x86_info, Server_Stats, Server_StatsRefresh } from "@/config/api.config";
import fetchWithAuth from "@/middleware/fetch-auth";

const orderedEnvironments = [
  "Production",
  "Préproduction",
  "Recette",
  "Développement",
  "Technique",
  "POC",
  "Intégration",
  "Formation",
  "Sans environnement",
];

// Couleurs et thème
export const colors = {
  entity: "#fce38a",
  pole: "#c6b3ff",
  domain: "#b3ffcc",
  solution: "#b3e6ff",
  solution_actives: "#f2b3ff",
  namespace: "#a8e6b1",
  deployment: "#f3aebd",
  server: "#99caff",
  pod: "#ffd699",
  inventoryServer: "#d1c4e9",
  reliableServer: "#c5e1a5",
};

const osColors = {
  Windows: "#99caff",
  Linux: "#a8e6b1",
  MacOS: "#f3aebd",
  AIX: "#fce38a",
  Default: "#7fb2e6",
};

export const modernTheme = {
  primary: "#2563EB",
  secondary: "#7C3AED",
  accent: "#059669",
  surface: "#FFCE14",
  background: "#F1F5F9",
  surfaceVariant: "#e04434",
  outline: "#CBD5E1",
  shadow: "rgba(15, 23, 42, 0.12)",
  cardBackground: "#FFFFFF",
  textPrimary: "#1E293B",
  textSecondary: "#475569",
  gradients: {
    primary: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
    secondary: "linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",
    info: "linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)",
    success: "linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)",
    warning: "linear-gradient(135deg, #ff9a9e 0%, #fad0c4 100%)",
    error: "linear-gradient(135deg, #ff758c 0%, #ff7eb3 100%)",
  },
};

interface ApplicationData {
  solution_name: string;
  total_cpu: string;
  total_ram: string;
  total_disk: string;
}

interface OpenshiftAppData {
  solution_name: string;
  total_cpu_m: string | null;
  total_request_cpu_m: string | null;
  total_ram_mi: string | null;
  total_request_ram_mi: string | null;
}

interface PowerInfoData {
  solution_name: string;
  cpu_limit_total: string;
  cpu_request_total: string;
  total_ram: string;
}

// Types pour les données
interface ServerData {
  solutions_count: number;
  namespaces_count: number;
  isolated_servers_rate: number;
  calculated_at: string;
  vmware_count: number;
  power_count: number;
  bigfix_count: number;
  inventory_count: number;
  isolated_servers: {
    power: number;
    bigfix: number;
    vmware: number;
    inventory: number;
  };
  signed_servers_count: number;
  expired_servers_count: number;
  unsigned_servers_count: number;
  fiable_servers_count: number;
  fibale_namespaces_count: number;
  fibale_solutions_count: number;
  activated_solutions_count: number;
  architecture_distribution: {
    x86: number;
    power: number;
  };
  os_ratio: {
    linux: number;
    windows: number;
  };
  duplicate_ips: {
    [env: string]: {
      [ip: string]: number;
    };
  };
  duplicate_hostnames: {
    [hostname: string]: number;
  };
  server_count_by_nature: Array<{ [nature: string]: [number, string] }>;
  top_applications?: ApplicationData[];
}

// Composant DonutChart
const DonutChart: React.FC<{
  data: Array<{
    label: string;
    value: number;
    percentage: number;
    color: string;
  }>;
  size?: number;
  strokeWidth?: number;
  title?: string;
  centerValue: string;
  centerLabel: string;
}> = ({
  data,
  size = 200,
  strokeWidth = 20,
  title,
  centerValue,
  centerLabel,
}) => {
    const radius = (size - strokeWidth) / 2;
    const circumference = 2 * Math.PI * radius;
    const [animated, setAnimated] = useState(false);

    useEffect(() => {
      setAnimated(true);
    }, []);

    let cumulativePercentage = 0;

    return (
      <Box display="flex" flexDirection="column" alignItems="center">
        <Box position="relative" width={size} height={size}>
          <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
            <circle
              cx={size / 2}
              cy={size / 2}
              r={radius}
              fill="none"
              stroke="#e0e0e0"
              strokeWidth={strokeWidth}
            />
            {data.map((item, index) => {
              const strokeDasharray = `${(item.percentage / 100) * circumference} ${circumference}`;
              const strokeDashoffset =
                (-cumulativePercentage * circumference) / 100;
              cumulativePercentage += item.percentage;

              return (
                <circle
                  key={index}
                  cx={size / 2}
                  cy={size / 2}
                  r={radius}
                  fill="none"
                  stroke={item.color}
                  strokeWidth={strokeWidth}
                  strokeDasharray={strokeDasharray}
                  strokeDashoffset={strokeDashoffset}
                  strokeLinecap="round"
                  transform={`rotate(-90 ${size / 2} ${size / 2})`}
                  style={{
                    transition: "stroke-dasharray 1s ease-in-out",
                    strokeDasharray: animated
                      ? strokeDasharray
                      : `0 ${circumference}`,
                  }}
                />
              );
            })}
          </svg>
          <Box
            position="absolute"
            top="50%"
            left="50%"
            sx={{ transform: "translate(-50%, -50%)" }}
            textAlign="center"
          >
            <Typography
              variant="h4"
              fontWeight="bold"
              color={modernTheme.primary}
            >
              {centerValue}
            </Typography>
            <Typography variant="body2" color={modernTheme.textSecondary}>
              {centerLabel}
            </Typography>
          </Box>
        </Box>
        {title && (
          <Typography variant="h6" sx={{ mt: 2, mb: 1, fontWeight: 600 }}>
            {title}
          </Typography>
        )}
        <Stack spacing={1} sx={{ mt: 2 }}>
          {data.map((item, index) => (
            <Box key={index} display="flex" alignItems="center" gap={1}>
              <Box
                width={12}
                height={12}
                bgcolor={item.color}
                borderRadius="50%"
                sx={{ boxShadow: "0 2px 4px rgba(0,0,0,0.1)" }}
              />
              <Typography variant="body2" sx={{ fontSize: "0.875rem" }}>
                <strong>{item.label}:</strong> {item.value.toLocaleString()} (
                {item.percentage.toFixed(1)}%)
              </Typography>
            </Box>
          ))}
        </Stack>
      </Box>
    );
  };

// Composant GaugeChart
const GaugeChart: React.FC<{
  value: number;
  max: number;
  label: string;
  color?: string;
  size?: number;
}> = ({ value, max, label, color = modernTheme.primary, size = 150 }) => {
  const percentage = Math.min((value / max) * 100, 100);
  const [animated, setAnimated] = useState(false);
  const [pathLength, setPathLength] = useState(0);

  // Référence pour mesurer la longueur du chemin
  const pathRef = useRef<SVGPathElement>(null);

  useEffect(() => {
    setAnimated(true);
  }, []);

  // Calcul de la longueur réelle du chemin
  useEffect(() => {
    if (pathRef.current) {
      const length = pathRef.current.getTotalLength();
      setPathLength(length);
    }
  }, [size]);

  const strokeDasharray = pathLength > 0
    ? `${(percentage / 100) * pathLength} ${pathLength}`
    : "0 0";

  return (
    <Box display="flex" flexDirection="column" alignItems="center">
      <Box position="relative" width={size} height={size / 2 + 20}>
        <svg
          width={size}
          height={size / 2 + 20}
          viewBox={`0 0 ${size} ${size / 2 + 20}`}
        >
          {/* Chemin de référence pour mesurer la longueur */}
          <path
            ref={pathRef}
            d={`M 20 ${size / 2} A ${size / 2 - 20} ${size / 2 - 20} 0 0 1 ${size - 20} ${size / 2}`}
            fill="none"
            stroke="transparent"
            strokeWidth="12"
          />

          {/* Fond de la jauge */}
          <path
            d={`M 20 ${size / 2} A ${size / 2 - 20} ${size / 2 - 20} 0 0 1 ${size - 20} ${size / 2}`}
            fill="none"
            stroke="#e0e0e0"
            strokeWidth="12"
            strokeLinecap="round"
          />

          {/* Jauge colorée */}
          <path
            d={`M 20 ${size / 2} A ${size / 2 - 20} ${size / 2 - 20} 0 0 1 ${size - 20} ${size / 2}`}
            fill="none"
            stroke={color}
            strokeWidth="12"
            strokeLinecap="round"
            strokeDasharray={strokeDasharray}
            strokeDashoffset={animated ? "0" : pathLength.toString()}
            style={{
              transition: "stroke-dasharray 1s ease-in-out",
            }}
          />
        </svg>
        <Box
          position="absolute"
          bottom={10}
          left="50%"

          sx={{ transform: "translateX(-50%)" }}
          textAlign="center"
        >
          <Typography variant="h5" fontWeight="bold" color={color}>
            {percentage.toFixed(1)}%
          </Typography>
          <Typography variant="caption" color={modernTheme.textSecondary}>
            {value}/{max}
          </Typography>
        </Box>
      </Box>
      <Typography
        variant="body2"
        color={modernTheme.textSecondary}
        sx={{ mt: 1, fontWeight: 500 }}
      >
        {label}
      </Typography>
    </Box>
  );
};

// Composant IpBadge
const IpBadge: React.FC<{
  ip: string;
  count: number;
}> = ({ ip, count }) => {
  const severityColors = {
    error: "#ff758c",
    warning: "#ff9a9e",
    info: "#4facfe",
  };

  const severity = count > 2 ? "error" : count > 1 ? "warning" : "info";
  const color = severityColors[severity];

  return (
    <Box
      sx={{
        display: "inline-block",
        position: "relative",
        borderRadius: "16px",
        padding: "6px 12px",
        background: "rgba(255, 255, 255, 0.2)",
        backdropFilter: "blur(5px)",
        border: `1px solid ${color}`,
        boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
        transition: "all 0.3s ease",
        "&:hover": {
          transform: "translateY(-2px)",
          boxShadow: `0 6px 10px ${color}40`,
        },
      }}
    >
      <Typography
        variant="body1"
        fontFamily="monospace"
        sx={{
          fontWeight: 600,
          color: color,
        }}
      >
        {ip}
      </Typography>
      <Box
        sx={{
          position: "absolute",
          top: -8,
          right: -8,
          width: 24,
          height: 24,
          borderRadius: "50%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: color,
          color: "white",
          fontWeight: "bold",
          fontSize: "0.75rem",
        }}
      >
        {count}
      </Box>
    </Box>
  );
};

// Composant HostnameBadge
const HostnameBadge: React.FC<{
  hostname: string;
  count: number;
}> = ({ hostname, count }) => {
  const severityColors = {
    error: "#ff758c",
    warning: "#ff9a9e",
    info: "#4facfe",
  };

  const severity = count > 2 ? "error" : count > 1 ? "warning" : "info";
  const color = severityColors[severity];

  return (
    <Box
      sx={{
        display: "inline-block",
        position: "relative",
        borderRadius: "16px",
        padding: "6px 12px",
        background: "rgba(255, 255, 255, 0.2)",
        backdropFilter: "blur(5px)",
        border: `1px solid ${color}`,
        boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
        transition: "all 0.3s ease",
        "&:hover": {
          transform: "translateY(-2px)",
          boxShadow: `0 6px 10px ${color}40`,
        },
      }}
    >
      <Typography
        variant="body1"
        sx={{
          fontWeight: 600,
          color: color,
          fontFamily: "'Courier New', monospace",
        }}
      >
        {hostname}
      </Typography>
      <Box
        sx={{
          position: "absolute",
          top: -8,
          right: -8,
          width: 24,
          height: 24,
          borderRadius: "50%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: color,
          color: "white",
          fontWeight: "bold",
          fontSize: "0.75rem",
        }}
      >
        {count}
      </Box>
    </Box>
  );
};

const FALLBACK_SVG_DATA_URL =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(
    `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='1.5'><rect x='3' y='4' width='18' height='14' rx='2'/><path d='M8 9h8M7 16h10'/></svg>`,
  );

function hashStringToColor(str: string) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = str.charCodeAt(i) + ((h << 5) - h);
  return `hsl(${Math.abs(h) % 360} 55% 50%)`;
}

function normalizeNatureData(
  input: ServerData,
  mode: "total" | "prod" | "hors_prod",
) {
  const arr: { name: string; count: number; icon?: string }[] = [];

  for (const obj of input.server_count_by_nature || []) {
    for (const [name, data] of Object.entries(obj)) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const { icon, total, prod, hors_prod } = data as any as {
        icon?: string;
        total: number;
        prod: number;
        hors_prod: number;
      };

      const count =
        mode === "prod" ? prod : mode === "hors_prod" ? hors_prod : total;

      arr.push({ name, count, icon: icon || undefined });
    }
  }

  arr.sort((a, b) => b.count - a.count);
  return arr;
}

/* -----------------------
 *  Nouvelle carte : ServerCountByNatureCard avec expansion
 *   - Affiche 15 éléments par défaut (5 lignes × 3 colonnes)
 *   - Bouton "Afficher plus" pour voir le reste
 * ------------------------ */

export const ServerCountByNatureCard: React.FC<{
  serverData: ServerData;
  title?: string;
  mode?: "total" | "prod" | "hors_prod";
}> = ({ serverData, title = "Serveurs par nature", mode = "total" }) => {
  const [showAll, setShowAll] = useState(false);
  const items = normalizeNatureData(serverData, mode);
  const total = items.reduce((s, it) => s + it.count, 0) || 1;

  const defaultLimit = 15; // 5 lignes × 3 colonnes
  const visibleItems = showAll ? items : items.slice(0, defaultLimit);
  const hasMore = items.length > defaultLimit;

  const barColor =
    mode === "prod" ? "#ffb3b3" : mode === "hors_prod" ? "#a3d9a5" : "#90caf9"; // couleur par défaut pour total

  return (
    <Card sx={{ mb: 4, backgroundColor: modernTheme.cardBackground }}>
      <CardContent>
        <Typography
          variant="h5"
          gutterBottom
          sx={{ display: "flex", alignItems: "center" }}
        >
          <Activity style={{ marginRight: "8px" }} />
          {title}
        </Typography>

        <Grid container spacing={2}>
          {visibleItems.map((it) => {
            const pct = Math.round((it.count / total) * 100);
            return (
              <Grid item xs={12} sm={6} md={4} key={it.name}>
                <Box
                  sx={{
                    display: "flex",
                    gap: 2,
                    alignItems: "center",
                    p: 1.25,
                    borderRadius: 2,
                    border: `1px solid ${modernTheme.outline}`,
                    background: modernTheme.cardBackground,
                    boxShadow: `0 4px 12px ${modernTheme.shadow}`,
                  }}
                >
                  <Tooltip title={it.name} arrow>
                    <Box
                      sx={{
                        width: 52,
                        height: 52,
                        borderRadius: 1.5,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        flexShrink: 0,
                        background: it.icon
                          ? "transparent"
                          : hashStringToColor(it.name),
                      }}
                    >
                      {it.icon ? (
                        <img
                          src={it.icon}
                          alt={it.name}
                          style={{
                            width: 36,
                            height: 36,
                            objectFit: "contain",
                          }}
                          onError={(e) => {
                            const target = e.currentTarget as HTMLImageElement;
                            if (target.src !== FALLBACK_SVG_DATA_URL)
                              target.src = FALLBACK_SVG_DATA_URL;
                          }}
                        />
                      ) : (
                        <Typography
                          variant="subtitle2"
                          sx={{ color: "white", fontWeight: 700 }}
                        >
                          {it.name
                            .split(" ")
                            .map((p) => p[0])
                            .slice(0, 2)
                            .join("")
                            .toUpperCase()}
                        </Typography>
                      )}
                    </Box>
                  </Tooltip>

                  <Box sx={{ flex: 1 }}>
                    <Box
                      display="flex"
                      justifyContent="space-between"
                      alignItems="baseline"
                    >
                      <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
                        {it.name}
                      </Typography>
                      <Typography variant="h6" sx={{ fontWeight: 800 }}>
                        {it.count}
                      </Typography>
                    </Box>

                    <Box sx={{ mt: 1 }}>
                      <LinearProgress
                        variant="determinate"
                        value={pct}
                        sx={{
                          height: 8,
                          borderRadius: 2,
                          backgroundColor: "#eee",
                          "& .MuiLinearProgress-bar": {
                            backgroundColor: barColor,
                          },
                        }}
                      />
                      <Typography
                        variant="caption"
                        color="text.secondary"
                        sx={{ mt: 0.5, display: "block" }}
                      >
                        {pct}% du total
                      </Typography>
                    </Box>
                  </Box>
                </Box>
              </Grid>
            );
          })}
        </Grid>

        {/* Bouton Afficher plus/moins */}
        {hasMore && (
          <Box
            sx={{
              mt: 3,
              display: "flex",
              justifyContent: "center",
            }}
          >
            <Button
              variant="outlined"
              onClick={() => setShowAll(!showAll)}
              sx={{
                borderColor: modernTheme.primary,
                color: modernTheme.primary,
                "&:hover": {
                  borderColor: modernTheme.primary,
                  backgroundColor: `${modernTheme.primary}10`,
                },
                px: 3,
                py: 1,
                borderRadius: 2,
              }}
            >
              {showAll
                ? `Afficher moins`
                : `Afficher plus (+${items.length - defaultLimit} natures)`}
            </Button>
          </Box>
        )}

        {/* Message informatif quand tout est affiché */}
        {showAll && hasMore && (
          <Box
            sx={{
              mt: 2,
              p: 1.5,
              borderRadius: 1,
              textAlign: "center",
              color: modernTheme.textSecondary,
              backgroundColor: `${modernTheme.primary}08`,
              border: `1px solid ${modernTheme.primary}20`,
            }}
          >
            <Typography variant="body2">
              Affichage de toutes les {items.length} natures de serveurs
            </Typography>
          </Box>
        )}
      </CardContent>
    </Card>
  );
};

/* -----------------------
 *  Fin de la nouvelle carte
 * ------------------------ */

export const ServerCountByNatureCardWithTabs: React.FC<{
  serverData: ServerData;
}> = ({ serverData }) => {
  const [mode, setMode] = useState<"total" | "prod" | "hors_prod">("total");

  // Calculer le nombre de natures (types) différentes pour chaque mode
  const getNatureCounts = () => {
    const totalItems = normalizeNatureData(serverData, "total");
    const prodItems = normalizeNatureData(serverData, "prod");
    const horsProdItems = normalizeNatureData(serverData, "hors_prod");

    // Filtrer les items qui ont un count > 0 pour obtenir le nombre de natures actives
    const totalNatures = totalItems.filter((item) => item.count > 0).length;
    const prodNatures = prodItems.filter((item) => item.count > 0).length;
    const horsProdNatures = horsProdItems.filter(
      (item) => item.count > 0,
    ).length;

    return {
      total: totalNatures,
      prod: prodNatures,
      hors_prod: horsProdNatures,
    };
  };

  const counts = getNatureCounts();

  return (
    <Card sx={{ mb: 4, backgroundColor: modernTheme.cardBackground }}>
      <CardContent>
        <Typography
          variant="h5"
          gutterBottom
          sx={{ display: "flex", alignItems: "center" }}
        >
          <Activity style={{ marginRight: "8px" }} />
          Serveurs par nature
        </Typography>

        <Tabs
          value={mode}
          onChange={(_e, val) => setMode(val)}
          sx={{ mb: 2 }}
          textColor="primary"
          indicatorColor="primary"
        >
          <Tab
            label={
              <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                <span>Total</span>
                <Chip
                  label={counts.total.toLocaleString()}
                  size="small"
                  sx={{
                    backgroundColor: "#90caf9",
                    color: "white",
                    fontWeight: "bold",
                    minWidth: "45px",
                  }}
                />
              </Box>
            }
            value="total"
          />
          <Tab
            label={
              <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                <span>Production</span>
                <Chip
                  label={counts.prod.toLocaleString()}
                  size="small"
                  sx={{
                    backgroundColor: "#ffb3b3",
                    color: "white",
                    fontWeight: "bold",
                    minWidth: "45px",
                  }}
                />
              </Box>
            }
            value="prod"
          />
          <Tab
            label={
              <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                <span>Hors Production</span>
                <Chip
                  label={counts.hors_prod.toLocaleString()}
                  size="small"
                  sx={{
                    backgroundColor: "#a3d9a5",
                    color: "white",
                    fontWeight: "bold",
                    minWidth: "45px",
                  }}
                />
              </Box>
            }
            value="hors_prod"
          />
        </Tabs>

        <ServerCountByNatureCard serverData={serverData} mode={mode} />
      </CardContent>
    </Card>
  );
};

const ServerCockpit: React.FC = () => {
  const [data, setData] = useState<ServerData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showAllApps, setShowAllApps] = useState(false);
  const [appLoading, setAppLoading] = useState(false);
  const [applications, setApplications] = useState<ApplicationData[]>([]);
  const [showAllOpenshiftApps, setShowAllOpenshiftApps] = useState(false);
  const [openshiftLoading, setOpenshiftLoading] = useState(false);
  const [openshiftApplications, setOpenshiftApplications] = useState<OpenshiftAppData[]>([]);

  const [showAllPowerApps, setShowAllPowerApps] = useState(false);
const [powerLoading, setPowerLoading] = useState(false);
const [powerApplications, setPowerApplications] = useState<PowerInfoData[]>([]);

  // Ajoutez cette fonction après formatValue
  const formatOpenshiftValue = (value: string | null, type: 'cpu' | 'ram') => {
    if (value === null) return 'N/A';

    const num = parseFloat(value);

    switch (type) {
      case 'cpu':
        // Convertir millicores en cores
        return `${(num / 1000).toLocaleString()} cores`;
      case 'ram':
        // Convertir Mebibytes en Gibibytes
        return `${(num / 1024).toFixed(1)} GiB`;
      default:
        return value;
    }
  };

  const fetchApplications = async () => {
    setAppLoading(true);
    try {
      const response = await fetch(hardware_info_x86_info(), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ scope: "solutions" }),
      });

      if (!response.ok) {
        throw new Error(`Erreur HTTP: ${response.status}`);
      }

      const appData = await response.json();
      setApplications(appData);
    } catch (err) {
      console.error("Erreur lors de la récupération des applications:", err);
    } finally {
      setAppLoading(false);
    }
  };

  const fetchOpenshiftApplications = async () => {
    setOpenshiftLoading(true);
    try {
      const response = await fetch(hardware_info_openshift_info(), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ scope: "solutions" }),
      });

      if (!response.ok) {
        throw new Error(`Erreur HTTP: ${response.status}`);
      }

      const openshiftData = await response.json();
      const appsFiltered = openshiftData
        .filter((app: OpenshiftAppData) => app.total_cpu_m !== null || app.total_ram_mi !== null);

      // NE PAS TRIER - conserver l'ordre du backend
      setOpenshiftApplications(appsFiltered);
    } catch (err) {
      console.error("Erreur lors de la récupération des applications Openshift:", err);
    } finally {
      setOpenshiftLoading(false);
    }
  };

  // Fonction pour récupérer les données Power
const fetchPowerApplications = async () => {
  setPowerLoading(true);
  try {
    const response = await fetch(hardware_info_power_info(), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ scope: "solutions" }),
    });

    if (!response.ok) {
      throw new Error(`Erreur HTTP: ${response.status}`);
    }

    const powerData = await response.json();
    // Filtrer les applications avec des données valides
    const appsFiltered = powerData.filter((app: PowerInfoData) => 
      app.cpu_limit_total || app.cpu_request_total || app.total_ram
    );
    setPowerApplications(appsFiltered);
  } catch (err) {
    console.error("Erreur lors de la récupération des applications Power:", err);
  } finally {
    setPowerLoading(false);
  }
};

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetchWithAuth(Server_Stats());
      if (!response.ok) {
        throw new Error(`Erreur HTTP: ${response.status}`);
      }
      const apiData = await response.json();
      setData(apiData);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erreur inconnue");
      console.error("Erreur lors de la récupération des données:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    fetchApplications();
    fetchOpenshiftApplications();
    fetchPowerApplications();
  }, []);

  const refreshData = async () => {
    setLoading(true);
    setError(null);

    try {
      const refreshResponse = await fetchWithAuth(Server_StatsRefresh(), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (!refreshResponse.ok) {
        console.warn(
          `Erreur lors du rafraîchissement des stats: ${refreshResponse.status}`,
        );
        return; // Ne pas continuer si l'étape 1 échoue
      }

      const dataResponse = await fetchWithAuth(Server_Stats());
      if (!dataResponse.ok) {
        console.warn(`Erreur HTTP: ${dataResponse.status}`);
        return;
      }

      const apiData = await dataResponse.json();
      setData(apiData);
    } catch (err) {
      // Ne pas remonter l'erreur, juste log et garder l'état actuel
      console.warn(
        "Erreur silencieuse lors de la récupération des données:",
        err,
      );
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        minHeight="100vh"
      >
        <Box textAlign="center">
          <CircularProgress size={60} thickness={4} />
          <Typography variant="h6" sx={{ mt: 3, fontWeight: 500 }}>
            Chargement du cockpit serveurs...
          </Typography>
        </Box>
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error" sx={{ mb: 3 }}>
          Erreur lors du chargement des données: {error}
        </Alert>
        <Tooltip title="Actualiser les données">
          <IconButton
            onClick={refreshData}
            sx={{
              bgcolor: modernTheme.primary,
              color: "white",
              "&:hover": {
                bgcolor: modernTheme.primary,
                transform: "rotate(360deg)",
                transition: "transform 0.5s ease",
              },
            }}
          >
            <RefreshCw />
          </IconButton>
        </Tooltip>
      </Box>
    );
  }

  if (!data) return null;

  // Données pour les graphiques
  const architectureData = [
    {
      label: "x86",
      value: data.architecture_distribution.x86,
      percentage:
        (data.architecture_distribution.x86 /
          (data.architecture_distribution.x86 +
            data.architecture_distribution.power)) *
        100,
      color: "#4facfe",
    },
    {
      label: "Power",
      value: data.architecture_distribution.power,
      percentage:
        (data.architecture_distribution.power /
          (data.architecture_distribution.x86 +
            data.architecture_distribution.power)) *
        100,
      color: "#ff9a9e",
    },
  ];

  const osData = [
    {
      label: "Linux",
      value: data.os_ratio.linux,
      percentage:
        (data.os_ratio.linux / (data.os_ratio.linux + data.os_ratio.windows)) *
        100,
      color: osColors.Linux,
    },
    {
      label: "Windows",
      value: data.os_ratio.windows,
      percentage:
        (data.os_ratio.windows /
          (data.os_ratio.linux + data.os_ratio.windows)) *
        100,
      color: osColors.Windows,
    },
  ];

  const sourcesData = [
    { label: "VMware", value: data.vmware_count, color: colors.entity },
    { label: "Power", value: data.power_count, color: colors.pod },
    { label: "BigFix", value: data.bigfix_count, color: colors.deployment },
    { label: "Inventaire", value: data.inventory_count, color: colors.pole },
  ];

  // Données pour les taux d'isolation
  const isolationData = [
    {
      label: "Inventaire",
      value: data.isolated_servers.inventory,
      max: Math.max(data.inventory_count, 1),
      color: colors.inventoryServer,
    },
    {
      label: "Power",
      value: data.isolated_servers.power,
      max: Math.max(data.power_count, 1),
      color: colors.pod,
    },
    {
      label: "VMware",
      value: data.isolated_servers.vmware,
      max: Math.max(data.vmware_count, 1),
      color: colors.entity,
    },
    {
      label: "BigFix",
      value: data.isolated_servers.bigfix,
      max: Math.max(data.bigfix_count, 1),
      color: colors.deployment,
    },
  ];

  return (
    <Box
      sx={{
        p: { xs: 2, md: 4 },
        backgroundColor: modernTheme.background,
        minHeight: "100vh",
        backgroundImage:
          "radial-gradient(circle at 10% 20%, rgba(200, 200, 255, 0.05) 0%, rgba(200, 255, 200, 0.05) 90%)",
      }}
    >
      {/* Header */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          mb: 3,
        }}
      >
        <Typography
          variant="h3"
          sx={{ fontWeight: "bold", color: modernTheme.primary }}
        >
          <Server style={{ marginRight: "12px", verticalAlign: "middle" }} />
          Cockpit Fiabilisation
        </Typography>
        <Tooltip title="Actualiser les données">
          <IconButton
            onClick={refreshData}
            sx={{
              bgcolor: modernTheme.primary,
              color: "white",
              "&:hover": {
                bgcolor: modernTheme.primary,
                transform: "rotate(360deg)",
                transition: "transform 0.5s ease",
              },
            }}
          >
            <RefreshCw />
          </IconButton>
        </Tooltip>
      </Box>

      <Alert severity="info" sx={{ mb: 3 }}>
        Dernière mise à jour:{" "}
        {new Date(data.calculated_at).toLocaleString("fr-FR")}
      </Alert>

      {/* Vue d'ensemble */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={3}>
          <Card sx={{ backgroundColor: colors.reliableServer, height: "100%" }}>
            <CardContent>
              <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
                <CheckCircle size={24} />
                <Typography variant="h6" sx={{ ml: 1 }}>
                  Serveurs Fiables
                </Typography>
              </Box>
              <Typography variant="h3" sx={{ fontWeight: "bold" }}>
                {data.fiable_servers_count.toLocaleString()}
              </Typography>
              <Typography variant="body1">
                sur{" "}
                {(
                  data.inventory_count +
                  data.isolated_servers.power +
                  data.isolated_servers.vmware
                ).toLocaleString()}{" "}
                serveurs
              </Typography>
              <GaugeChart
                value={data.fiable_servers_count}
                max={
                  data.inventory_count +
                  data.isolated_servers.power +
                  data.isolated_servers.vmware
                }
                label="Serveurs Fiables"
                color={modernTheme.accent}
              />
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={3}>
          <Card sx={{ backgroundColor: colors.namespace, height: "100%" }}>
            <CardContent>
              <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
                <Network size={24} />
                <Typography variant="h6" sx={{ ml: 1 }}>
                  Namespaces Fiables
                </Typography>
              </Box>
              <Typography variant="h3" sx={{ fontWeight: "bold" }}>
                {data.fibale_namespaces_count}
              </Typography>
              <Typography variant="body1">
                sur {Math.max(data.namespaces_count, 1)} namespaces
              </Typography>
              <GaugeChart
                value={data.fibale_namespaces_count}
                max={Math.max(data.namespaces_count, 1)}
                label="Namespaces Fiables"
                color={modernTheme.accent}
              />
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={3}>
          <Card sx={{ backgroundColor: colors.solution, height: "100%" }}>
            <CardContent>
              <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
                <Activity size={24} />
                <Typography variant="h6" sx={{ ml: 1 }}>
                  Applications Fiables
                </Typography>
              </Box>
              <Typography variant="h3" sx={{ fontWeight: "bold" }}>
                {data.fibale_solutions_count}
              </Typography>
              <Typography variant="body1">
                sur {Math.max(data.solutions_count, 1)} solutions
              </Typography>
              <GaugeChart
                value={data.fibale_solutions_count}
                max={Math.max(data.solutions_count, 1)}
                label="Applications Fiables"
                color={modernTheme.accent}
              />
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card
            sx={{ backgroundColor: colors.solution_actives, height: "100%" }}
          >
            <CardContent>
              <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
                <Activity size={24} />
                <Typography variant="h6" sx={{ ml: 1 }}>
                  Applications Actives
                </Typography>
              </Box>
              <Typography variant="h3" sx={{ fontWeight: "bold" }}>
                {data.activated_solutions_count}
              </Typography>
              <Typography variant="body1">
                sur {Math.max(data.solutions_count, 1)} solutions
              </Typography>
              <GaugeChart
                value={data.activated_solutions_count}
                max={Math.max(data.solutions_count, 1)}
                label="Applications Actives"
                color={modernTheme.accent}
              />
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Indicateurs de santé */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={6}>
          <Card sx={{ backgroundColor: modernTheme.cardBackground }}>
            <CardContent>
              <Typography
                variant="h5"
                gutterBottom
                sx={{ display: "flex", alignItems: "center" }}
              >
                <AlertTriangle
                  style={{ marginRight: "8px", color: modernTheme.surfaceVariant }}
                />
                Taux d'Isolation
              </Typography>
              {/* Barre de progression pour le taux d'isolation en inventaire */}
              <Box sx={{ mb: 3 }}>
                <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 1 }}>
                  Taux d'Isolation en Inventaire
                </Typography>
                <LinearProgress
                  variant="determinate"
                  value={
                    Math.min(
                      (data.isolated_servers.inventory /
                        Math.max(data.inventory_count, 1)) * 100,
                      100
                    )
                  }
                  sx={{
                    height: 10,
                    borderRadius: 5,
                    backgroundColor: modernTheme.outline,
                    "& .MuiLinearProgress-bar": {
                      backgroundColor: colors.inventoryServer,
                    },
                  }}
                />
                <Typography
                  variant="caption"
                  color={modernTheme.textSecondary}
                  sx={{ mt: 0.5, display: "block" }}
                >
                  {((data.isolated_servers.inventory /
                    Math.max(data.inventory_count, 1)) * 100).toFixed(1)}% (
                  {data.isolated_servers.inventory.toLocaleString()}/
                  {data.inventory_count.toLocaleString()})
                </Typography>
              </Box>
              <Grid container spacing={2}>
                {isolationData.map((item, index) => (
                  <Grid item xs={6} md={3} key={index}>
                    <Paper
                      sx={{
                        p: 2,
                        textAlign: "center",
                        backgroundColor: item.color,
                        color: "white",
                        transition: "transform 0.3s ease",
                        "&:hover": {
                          transform: "translateY(-5px)",
                        },
                      }}
                    >
                      <Typography variant="h6" sx={{ fontWeight: "bold" }}>
                        {item.value.toLocaleString()}
                      </Typography>
                      <Typography variant="body1">{item.label}</Typography>
                      <Typography variant="body2" sx={{ opacity: 0.8 }}>
                        {((item.value / item.max) * 100).toFixed(1)}%
                      </Typography>
                    </Paper>
                  </Grid>
                ))}
              </Grid>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={6}>
          <Paper
            elevation={0}
            sx={{
              p: 3,
              textAlign: "center",
              backgroundColor: "rgba(255, 255, 255, 0.8)",
              backdropFilter: "blur(10px)",
              border: "1px solid rgba(255, 255, 255, 0.3)",
              borderRadius: "12px",
              boxShadow: "0 4px 20px rgba(0, 0, 0, 0.08)",
              height: "100%",
            }}
          >
            <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
              État des Signatures
            </Typography>
            <DonutChart
              data={[
                {
                  label: "Signés",
                  value: data.signed_servers_count,
                  percentage:
                    (data.signed_servers_count / Math.max(data.inventory_count, 1)) * 100,
                  color: modernTheme.accent,
                },
                {
                  label: "Expirés",
                  value: data.expired_servers_count,
                  percentage:
                    (data.expired_servers_count / Math.max(data.inventory_count, 1)) * 100,
                  color: "#ff9a9e",
                },
                {
                  label: "Non signés",
                  value: data.unsigned_servers_count,
                  percentage:
                    (data.unsigned_servers_count / Math.max(data.inventory_count, 1)) * 100,
                  color: "#ff758c",
                },
              ]}
              size={200}
              centerValue={data.inventory_count.toLocaleString()}
              centerLabel="Total"
            />
          </Paper>
        </Grid>
      </Grid>

      {/* Détail des signatures */}
      <Card sx={{ mb: 4, backgroundColor: modernTheme.cardBackground }}>
        <CardContent>
          <Typography
            variant="h5"
            gutterBottom
            sx={{ display: "flex", alignItems: "center" }}
          >
            <Shield style={{ marginRight: "8px" }} />
            Détail des Signatures
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <Paper
                sx={{
                  p: 2,
                  textAlign: "center",
                  backgroundColor: modernTheme.accent,
                  color: "white",
                  transition: "transform 0.3s ease",
                  "&:hover": {
                    transform: "translateY(-5px)",
                  },
                }}
              >
                <Typography variant="h4" sx={{ fontWeight: "bold" }}>
                  {data.signed_servers_count.toLocaleString()}
                </Typography>
                <Typography variant="body1">Serveurs Signés</Typography>
                <Typography variant="body2" sx={{ opacity: 0.8 }}>
                  {(
                    (data.signed_servers_count / Math.max(data.inventory_count, 1)) *
                    100
                  ).toFixed(1)}
                  %
                </Typography>
              </Paper>
            </Grid>

            <Grid item xs={12} md={4}>
              <Paper
                sx={{
                  p: 2,
                  textAlign: "center",
                  backgroundColor: "#ff9a9e",
                  color: "white",
                  transition: "transform 0.3s ease",
                  "&:hover": {
                    transform: "translateY(-5px)",
                  },
                }}
              >
                <Typography variant="h4" sx={{ fontWeight: "bold" }}>
                  {data.expired_servers_count.toLocaleString()}
                </Typography>
                <Typography variant="body1">Signatures Expirées</Typography>
                <Typography variant="body2" sx={{ opacity: 0.8 }}>
                  {(
                    (data.expired_servers_count / Math.max(data.inventory_count, 1)) *
                    100
                  ).toFixed(1)}
                  %
                </Typography>
              </Paper>
            </Grid>

            <Grid item xs={12} md={4}>
              <Paper
                sx={{
                  p: 2,
                  textAlign: "center",
                  backgroundColor: "#ff758c",
                  color: "white",
                  transition: "transform 0.3s ease",
                  "&:hover": {
                    transform: "translateY(-5px)",
                  },
                }}
              >
                <Typography variant="h4" sx={{ fontWeight: "bold" }}>
                  {data.unsigned_servers_count.toLocaleString()}
                </Typography>
                <Typography variant="body1">Non Signés</Typography>
                <Typography variant="body2" sx={{ opacity: 0.8 }}>
                  {(
                    (data.unsigned_servers_count / Math.max(data.inventory_count, 1)) *
                    100
                  ).toFixed(1)}
                  %
                </Typography>
              </Paper>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Sources de données */}
      <Card sx={{ mb: 4, backgroundColor: modernTheme.cardBackground }}>
        <CardContent>
          <Typography
            variant="h5"
            gutterBottom
            sx={{ display: "flex", alignItems: "center" }}
          >
            <Shield style={{ marginRight: "8px" }} />
            Sources de Données
          </Typography>
          <Grid container spacing={2}>
            {sourcesData.map((source, index) => (
              <Grid item xs={6} md={3} key={index}>
                <Paper
                  sx={{
                    p: 2,
                    textAlign: "center",
                    backgroundColor: source.color,
                    transition: "transform 0.3s ease",
                    "&:hover": {
                      transform: "translateY(-5px)",
                    },
                  }}
                >
                  <Typography variant="h6">
                    {source.value.toLocaleString()}
                  </Typography>
                  <Typography variant="body2">{source.label}</Typography>
                </Paper>
              </Grid>
            ))}
          </Grid>
        </CardContent>
      </Card>

      {/* Top 5 Applications */}
      <Card sx={{ mb: 4, backgroundColor: modernTheme.cardBackground }}>
        <CardContent>
          <Typography
            variant="h5"
            gutterBottom
            sx={{ display: "flex", alignItems: "center" }}
          >
            <Activity style={{ marginRight: "8px" }} />
            Liste des Applications par Consommation
            {appLoading && <CircularProgress size={20} sx={{ ml: 2 }} />}
          </Typography>

          {applications.length > 0 ? (
            <>
              <Grid container spacing={2}>
                {(showAllApps ? applications : applications.slice(0, 5)).map((app, index) => (
                  <Grid item xs={12} key={app.solution_name}>
                    <Paper
                      sx={{
                        p: 2,
                        borderRadius: 2,
                        border: `1px solid ${modernTheme.outline}`,
                        background: modernTheme.cardBackground,
                        boxShadow: `0 2px 8px ${modernTheme.shadow}`,
                        transition: "all 0.3s ease",
                        "&:hover": {
                          transform: "translateY(-2px)",
                          boxShadow: `0 4px 12px ${modernTheme.shadow}`,
                        },
                      }}
                    >
                      <Box display="flex" alignItems="center" justifyContent="space-between">
                        <Box display="flex" alignItems="center" gap={2}>
                          <Box
                            sx={{
                              width: 40,
                              height: 40,
                              borderRadius: 1,
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "center",
                              background: modernTheme.gradients.primary,
                              color: "white",
                              fontWeight: "bold",
                              fontSize: "1.2rem",
                            }}
                          >
                            {index + 1}
                          </Box>
                          <Box>
                            <Typography variant="h6" sx={{ fontWeight: 600 }}>
                              {app.solution_name}
                            </Typography>
                          </Box>
                        </Box>

                        <Box display="flex" gap={4}>
                          <Box textAlign="center">
                            <Chip
                              label="CPU"
                              size="small"
                              sx={{
                                backgroundColor: "#4facfe",
                                color: "white",
                                mb: 0.5,
                              }}
                            />
                            <Typography variant="h6" sx={{ fontWeight: 700 }}>
                              {parseInt(app.total_cpu).toLocaleString()}
                            </Typography>
                            <Typography variant="caption" color={modernTheme.textSecondary}>
                              Cores
                            </Typography>
                          </Box>
                          <Box textAlign="center">
                            <Chip
                              label="RAM"
                              size="small"
                              sx={{
                                backgroundColor: "#43e97b",
                                color: "white",
                                mb: 0.5,
                              }}
                            />
                            <Typography variant="h6" sx={{ fontWeight: 700 }}>
                              {(parseFloat(app.total_ram) / 1024 / 1024).toFixed(1)} TB
                            </Typography>
                            <Typography variant="caption" color={modernTheme.textSecondary}>
                              Mémoire
                            </Typography>
                          </Box>

                          <Box textAlign="center">
                            <Chip
                              label="Stockage"
                              size="small"
                              sx={{
                                backgroundColor: "#f093fb",
                                color: "white",
                                mb: 0.5,
                              }}
                            />
                            <Typography variant="h6" sx={{ fontWeight: 700 }}>
                              {(parseFloat(app.total_disk) / 1024 / 1024 / 1024 / 1024).toFixed(1)} TB
                            </Typography>
                            <Typography variant="caption" color={modernTheme.textSecondary}>
                              Disque
                            </Typography>
                          </Box>
                        </Box>
                      </Box>

                      {/* Barres de progression pour montrer la consommation relative */}
                      <Box sx={{ mt: 2 }}>
                        <Grid container spacing={1}>
                          <Grid item xs={4}>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                              <Box sx={{ width: '100%' }}>
                                <LinearProgress
                                  variant="determinate"
                                  value={Math.min((parseInt(app.total_cpu) / parseInt(applications[0].total_cpu)) * 100, 100)}
                                  sx={{
                                    height: 8,
                                    borderRadius: 2,
                                    backgroundColor: "#4facfe20",
                                    '& .MuiLinearProgress-bar': {
                                      backgroundColor: "#4facfe",
                                    },
                                  }}
                                />
                              </Box>
                            </Box>
                          </Grid>
                          <Grid item xs={4}>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                              <Box sx={{ width: '100%' }}>
                                <LinearProgress
                                  variant="determinate"
                                  value={Math.min((parseFloat(app.total_ram) / parseFloat(applications[0].total_ram)) * 100, 100)}
                                  sx={{
                                    height: 8,
                                    borderRadius: 2,
                                    backgroundColor: "#43e97b20",
                                    '& .MuiLinearProgress-bar': {
                                      backgroundColor: "#43e97b",
                                    },
                                  }}
                                />
                              </Box>
                            </Box>
                          </Grid>
                          <Grid item xs={4}>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                              <Box sx={{ width: '100%' }}>
                                <LinearProgress
                                  variant="determinate"
                                  value={Math.min((parseFloat(app.total_disk) / parseFloat(applications[0].total_disk)) * 100, 100)}
                                  sx={{
                                    height: 8,
                                    borderRadius: 2,
                                    backgroundColor: "#f093fb20",
                                    '& .MuiLinearProgress-bar': {
                                      backgroundColor: "#f093fb",
                                    },
                                  }}
                                />
                              </Box>
                            </Box>
                          </Grid>
                        </Grid>
                      </Box>
                    </Paper>
                  </Grid>
                ))}
              </Grid>

              {/* Bouton Afficher plus/moins */}
              {applications.length > 5 && (
                <Box
                  sx={{
                    mt: 3,
                    display: "flex",
                    justifyContent: "center",
                  }}
                >
                  <Button
                    variant="outlined"
                    onClick={() => setShowAllApps(!showAllApps)}
                    sx={{
                      borderColor: modernTheme.primary,
                      color: modernTheme.primary,
                      "&:hover": {
                        borderColor: modernTheme.primary,
                        backgroundColor: `${modernTheme.primary}10`,
                      },
                      px: 3,
                      py: 1,
                      borderRadius: 2,
                    }}
                  >
                    {showAllApps
                      ? `Afficher moins (Top 5)`
                      : `Afficher plus (+${applications.length - 5} applications)`}
                  </Button>
                </Box>
              )}
            </>
          ) : (
            <Alert severity="info">
              Aucune donnée d'application disponible.
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Applications Power */}
<Card sx={{ mb: 4, backgroundColor: modernTheme.cardBackground }}>
  <CardContent>
    <Typography
      variant="h5"
      gutterBottom
      sx={{ display: "flex", alignItems: "center" }}
    >
      <Server style={{ marginRight: "8px", color: "#caa34b" }} />
      Liste des Applications Power (Limits / Requests)
      {powerLoading && <CircularProgress size={20} sx={{ ml: 2, color: "#caa34b" }} />}
    </Typography>

    {powerApplications.length > 0 ? (
      <>
        <Grid container spacing={2}>
          {(showAllPowerApps ? powerApplications : powerApplications.slice(0, 5)).map((app, index) => {
            // Convertir les valeurs
            const cpuLimit = parseFloat(app.cpu_limit_total || '0');
            const cpuRequest = parseFloat(app.cpu_request_total || '0');
            const ramBytes = parseFloat(app.total_ram || '0');
            const ramGB = ramBytes / 1024 / 1024 / 1024; // Convertir bytes en GB
                      
            return (
              <Grid item xs={12} key={app.solution_name}>
                <Paper
                  sx={{
                    p: 2,
                    borderRadius: 2,
                    border: `1px solid ${modernTheme.outline}`,
                    background: modernTheme.cardBackground,
                    boxShadow: `0 2px 8px ${modernTheme.shadow}`,
                    transition: "all 0.3s ease",
                    "&:hover": {
                      transform: "translateY(-2px)",
                      boxShadow: `0 4px 12px rgba(202, 163, 75, 0.1)`,
                    },
                  }}
                >
                  <Box display="flex" alignItems="center" justifyContent="space-between">
                    <Box display="flex" alignItems="center" gap={2}>
                      <Box
                        sx={{
                          width: 40,
                          height: 40,
                          borderRadius: 1,
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          background: "#fce38a",
                          color: "#a6842e",
                          fontWeight: "bold",
                          fontSize: "1.2rem",
                        }}
                      >
                        {index + 1}
                      </Box>
                      <Box>
                        <Typography variant="h6" sx={{ fontWeight: 600, color: "#1E293B" }}>
                          {app.solution_name}
                        </Typography>
         
                      </Box>
                    </Box>
                  </Box>

                  {/* Section CPU */}
                  <Box sx={{ mt: 2, mb: 3 }}>
                    <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600, color: "#a6842e" }}>
                      CPU Resources
                    </Typography>
                    <Grid container spacing={2}>
                      <Grid item xs={6}>
                        <Paper
                          sx={{
                            p: 1.5,
                            borderRadius: 1,
                            backgroundColor: "rgba(252, 227, 138, 0.1)",
                            border: "1px solid rgba(252, 227, 138, 0.3)",
                          }}
                        >
                          <Typography variant="caption" sx={{ color: "#a6842e", fontWeight: 500 }}>
                            CPU Limits
                          </Typography>
                          <Typography variant="h6" sx={{ fontWeight: 700, color: "#a6842e" }}>
                            {cpuLimit.toLocaleString()}
                          </Typography>
                          <Typography variant="caption" sx={{ color: "#caa34b" }}>
                            
                          </Typography>
                        </Paper>
                      </Grid>
                      <Grid item xs={6}>
                        <Paper
                          sx={{
                            p: 1.5,
                            borderRadius: 1,
                            backgroundColor: "rgba(202, 163, 75, 0.1)",
                            border: "1px solid rgba(202, 163, 75, 0.3)",
                          }}
                        >
                          <Typography variant="caption" sx={{ color: "#caa34b", fontWeight: 500 }}>
                            CPU Requests
                          </Typography>
                          <Typography variant="h6" sx={{ fontWeight: 700, color: "#caa34b" }}>
                            {cpuRequest.toLocaleString()}
                          </Typography>
                          <Typography variant="caption" sx={{ color: "#a6842e" }}>
                            
                          </Typography>
                        </Paper>
                      </Grid>
                    </Grid>

                  </Box>

                  {/* Section RAM */}
                  <Box sx={{ mt: 3 }}>
                    <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600, color: "#a6842e" }}>
                      RAM Resources
                    </Typography>
                    <Paper
                      sx={{
                        p: 1.5,
                        borderRadius: 1,
                        backgroundColor: "rgba(166, 132, 46, 0.05)",
                        border: "1px solid rgba(166, 132, 46, 0.2)",
                      }}
                    >
                      <Typography variant="caption" sx={{ color: "#a6842e", fontWeight: 500 }}>
                        RAM Total
                      </Typography>
                      <Typography variant="h6" sx={{ fontWeight: 700, color: "#a6842e" }}>
                        {ramGB.toFixed(1)} GB
                      </Typography>
                      <Typography variant="caption" sx={{ color: "#caa34b" }}>
                        Mémoire allouée
                      </Typography>
                    </Paper>
                    
                  
                  </Box>
                </Paper>
              </Grid>
            );
          })}
        </Grid>

        {/* Bouton Afficher plus/moins pour Power */}
        {powerApplications.length > 5 && (
          <Box
            sx={{
              mt: 3,
              display: "flex",
              justifyContent: "center",
            }}
          >
            <Button
              variant="outlined"
              onClick={() => setShowAllPowerApps(!showAllPowerApps)}
              sx={{
                borderColor: "#caa34b",
                color: "#a6842e",
                "&:hover": {
                  borderColor: "#a6842e",
                  backgroundColor: "rgba(252, 227, 138, 0.1)",
                },
                px: 3,
                py: 1,
                borderRadius: 2,
                fontWeight: 500,
              }}
            >
              {showAllPowerApps
                ? `Afficher moins (Top 5)`
                : `Afficher plus (+${powerApplications.length - 5} applications)`}
            </Button>
          </Box>
        )}
      </>
    ) : (
      <Alert severity="info" sx={{ backgroundColor: "rgba(252, 227, 138, 0.1)" }}>
        Aucune donnée d'application Power disponible.
      </Alert>
    )}

    {/* Résumé statistique global Power */}
    {powerApplications.length > 0 && (
      <Box sx={{ 
        mt: 3, 
        p: 2, 
        backgroundColor: "rgba(252, 227, 138, 0.05)", 
        borderRadius: 2,
        border: "1px solid rgba(252, 227, 138, 0.2)"
      }}>
        <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, color: "#a6842e" }}>
          Résumé Global Power
        </Typography>
        <Grid container spacing={2}>
          <Grid item xs={6} md={3}>
            <Typography variant="caption" sx={{ color: "#caa34b", fontWeight: 500 }}>
              Applications
            </Typography>
            <Typography variant="h6" sx={{ color: "#a6842e", fontWeight: 700 }}>
              {powerApplications.length}
            </Typography>
          </Grid>
          <Grid item xs={6} md={3}>
            <Typography variant="caption" sx={{ color: "#caa34b", fontWeight: 500 }}>
              CPU Limits Total
            </Typography>
            <Typography variant="h6" sx={{ color: "#a6842e", fontWeight: 700 }}>
              {powerApplications
                .reduce((sum, app) => sum + parseFloat(app.cpu_limit_total || '0'), 0)
                .toLocaleString()} units
            </Typography>
          </Grid>
          <Grid item xs={6} md={3}>
            <Typography variant="caption" sx={{ color: "#caa34b", fontWeight: 500 }}>
              CPU Requests Total
            </Typography>
            <Typography variant="h6" sx={{ color: "#a6842e", fontWeight: 700 }}>
              {powerApplications
                .reduce((sum, app) => sum + parseFloat(app.cpu_request_total || '0'), 0)
                .toLocaleString()} units
            </Typography>
          </Grid>
          <Grid item xs={6} md={3}>
            <Typography variant="caption" sx={{ color: "#caa34b", fontWeight: 500 }}>
              RAM Total
            </Typography>
            <Typography variant="h6" sx={{ color: "#a6842e", fontWeight: 700 }}>
              {(powerApplications
                .reduce((sum, app) => sum + parseFloat(app.total_ram || '0'), 0) 
                / 1024 / 1024 / 1024).toFixed(1)} GB
            </Typography>
          </Grid>
          <Grid item xs={6} md={3}>
            <Typography variant="caption" sx={{ color: "#caa34b", fontWeight: 500 }}>
              Moyenne CPU Usage
            </Typography>
            <Typography variant="h6" sx={{ color: "#a6842e", fontWeight: 700 }}>
              {(() => {
                const validApps = powerApplications.filter(app =>
                  parseFloat(app.cpu_limit_total || '0') > 0
                );
                if (validApps.length === 0) return 'N/A';

                const avg = validApps.reduce((sum, app) => {
                  const limit = parseFloat(app.cpu_limit_total || '0');
                  const request = parseFloat(app.cpu_request_total || '0');
                  return limit > 0 ? sum + (request / limit) * 100 : sum;
                }, 0) / validApps.length;

                return avg.toFixed(1) + '%';
              })()}
            </Typography>
          </Grid>
          <Grid item xs={6} md={3}>
            <Typography variant="caption" sx={{ color: "#caa34b", fontWeight: 500 }}>
              RAM par App (moy)
            </Typography>
            <Typography variant="h6" sx={{ color: "#a6842e", fontWeight: 700 }}>
              {(powerApplications
                .reduce((sum, app) => sum + parseFloat(app.total_ram || '0'), 0) 
                / powerApplications.length
                / 1024 / 1024 / 1024).toFixed(1)} GB
            </Typography>
          </Grid>
        </Grid>
      </Box>
    )}
  </CardContent>
</Card>

      <Card sx={{ mb: 4, backgroundColor: modernTheme.cardBackground }}>
        <CardContent>
          <Typography
            variant="h5"
            gutterBottom
            sx={{ display: "flex", alignItems: "center" }}
          >
            <Box
              component="img"
              src="https://upload.wikimedia.org/wikipedia/commons/3/3a/OpenShift-LogoType.svg"
              alt="OpenShift"
              sx={{ width: 24, height: 24, mr: 1 }}
            />
            Liste des Applications Openshift (Limits / Requests)
            {openshiftLoading && <CircularProgress size={20} sx={{ ml: 2 }} />}
          </Typography>

          {openshiftApplications.length > 0 ? (
            <>
              <Grid container spacing={2}>
                {(showAllOpenshiftApps ? openshiftApplications : openshiftApplications.slice(0, 5)).map((app, index) => {
                  // Convertir les valeurs
                  const cpuLimit = parseFloat(app.total_cpu_m || '0');
                  const cpuRequest = parseFloat(app.total_request_cpu_m || '0');
                  const ramLimit = parseFloat(app.total_ram_mi || '0');
                  const ramRequest = parseFloat(app.total_request_ram_mi || '0');

                  // Calculer les pourcentages d'utilisation POUR L'AFFICHAGE SEULEMENT
                  const cpuUsagePercent = cpuLimit > 0 ? (cpuRequest / cpuLimit) * 100 : 0;
                  const ramUsagePercent = ramLimit > 0 ? (ramRequest / ramLimit) * 100 : 0;
                  return (
                    <Grid item xs={12} key={app.solution_name}>
                      <Paper
                        sx={{
                          p: 2,
                          borderRadius: 2,
                          border: `1px solid ${modernTheme.outline}`,
                          background: modernTheme.cardBackground,
                          boxShadow: `0 2px 8px ${modernTheme.shadow}`,
                          transition: "all 0.3s ease",
                          "&:hover": {
                            transform: "translateY(-2px)",
                            boxShadow: `0 4px 12px ${modernTheme.shadow}`,
                          },
                        }}
                      >
                        <Box display="flex" alignItems="center" justifyContent="space-between">
                          <Box display="flex" alignItems="center" gap={2}>
                            <Box
                              sx={{
                                width: 40,
                                height: 40,
                                borderRadius: 1,
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                background: modernTheme.gradients.secondary,
                                color: "white",
                                fontWeight: "bold",
                                fontSize: "1.2rem",
                              }}
                            >
                              {index + 1}
                            </Box>
                            <Box>
                              <Typography variant="h6" sx={{ fontWeight: 600 }}>
                                {app.solution_name}
                              </Typography>
                              <Typography variant="body2" color={modernTheme.textSecondary}>
                                Limits vs Requests
                              </Typography>
                            </Box>
                          </Box>
                        </Box>

                        {/* Section CPU */}
                        <Box sx={{ mt: 2, mb: 3 }}>
                          <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600 }}>
                            CPU Resources
                          </Typography>
                          <Grid container spacing={2}>
                            <Grid item xs={6}>
                              <Paper
                                sx={{
                                  p: 1.5,
                                  borderRadius: 1,
                                  backgroundColor: "#667eea10",
                                  border: "1px solid #667eea30",
                                }}
                              >
                                <Typography variant="caption" color={modernTheme.textSecondary}>
                                  CPU Limits
                                </Typography>
                                <Typography variant="h6" sx={{ fontWeight: 700, color: "#667eea" }}>
                                  {formatOpenshiftValue(app.total_cpu_m, 'cpu')}
                                </Typography>
                                <Typography variant="caption" color={modernTheme.textSecondary}>
                                  
                                </Typography>
                              </Paper>
                            </Grid>
                            <Grid item xs={6}>
                              <Paper
                                sx={{
                                  p: 1.5,
                                  borderRadius: 1,
                                  backgroundColor: "#4facfe10",
                                  border: "1px solid #4facfe30",
                                }}
                              >
                                <Typography variant="caption" color={modernTheme.textSecondary}>
                                  CPU Requests
                                </Typography>
                                <Typography variant="h6" sx={{ fontWeight: 700, color: "#4facfe" }}>
                                  {formatOpenshiftValue(app.total_request_cpu_m, 'cpu')}
                                </Typography>
                                <Typography variant="caption" color={modernTheme.textSecondary}>
                                  
                                </Typography>
                              </Paper>
                            </Grid>
                          </Grid>

                          {/* Barre de progression CPU */}
                          <Box sx={{ mt: 2 }}>
                            <Box display="flex" justifyContent="space-between" sx={{ mb: 0.5 }}>
                              <Typography variant="caption" color={modernTheme.textSecondary}>
                                Utilisation: {cpuUsagePercent.toFixed(1)}%
                              </Typography>
                            </Box>
                            <LinearProgress
                              variant="determinate"
                              value={Math.min(cpuUsagePercent, 100)}
                              sx={{
                                height: 10,
                                borderRadius: 2,
                                backgroundColor: "#667eea20",
                                '& .MuiLinearProgress-bar': {
                                  backgroundColor: cpuUsagePercent > 80 ? "#ff4444" :
                                    cpuUsagePercent > 60 ? "#ffa726" : "#667eea",
                                  backgroundImage: `linear-gradient(90deg, 
                              #4facfe ${Math.min(cpuUsagePercent, 100)}%, 
                              #667eea ${Math.min(cpuUsagePercent, 100)}%
                            )`,
                                },
                              }}
                            />
                            <Box display="flex" justifyContent="space-between" sx={{ mt: 0.5 }}>
                              <Typography variant="caption" color="#4facfe">
                                Request
                              </Typography>
                              <Typography variant="caption" color="#667eea">
                                Limit
                              </Typography>
                            </Box>
                          </Box>
                        </Box>

                        {/* Section RAM */}
                        <Box sx={{ mt: 3 }}>
                          <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600 }}>
                            RAM Resources
                          </Typography>
                          <Grid container spacing={2}>
                            <Grid item xs={6}>
                              <Paper
                                sx={{
                                  p: 1.5,
                                  borderRadius: 1,
                                  backgroundColor: "#f093fb10",
                                  border: "1px solid #f093fb30",
                                }}
                              >
                                <Typography variant="caption" color={modernTheme.textSecondary}>
                                  RAM Limits
                                </Typography>
                                <Typography variant="h6" sx={{ fontWeight: 700, color: "#f093fb" }}>
                                  {formatOpenshiftValue(app.total_ram_mi, 'ram')}
                                </Typography>
                                <Typography variant="caption" color={modernTheme.textSecondary}>
                                  
                                </Typography>
                              </Paper>
                            </Grid>
                            <Grid item xs={6}>
                              <Paper
                                sx={{
                                  p: 1.5,
                                  borderRadius: 1,
                                  backgroundColor: "#f5576c10",
                                  border: "1px solid #f5576c30",
                                }}
                              >
                                <Typography variant="caption" color={modernTheme.textSecondary}>
                                  RAM Requests
                                </Typography>
                                <Typography variant="h6" sx={{ fontWeight: 700, color: "#f5576c" }}>
                                  {formatOpenshiftValue(app.total_request_ram_mi, 'ram')}
                                </Typography>
                                <Typography variant="caption" color={modernTheme.textSecondary}>
                                  
                                </Typography>
                              </Paper>
                            </Grid>
                          </Grid>

                          {/* Barre de progression RAM */}
                          <Box sx={{ mt: 2 }}>
                            <Box display="flex" justifyContent="space-between" sx={{ mb: 0.5 }}>
                              <Typography variant="caption" color={modernTheme.textSecondary}>
                                Utilisation: {ramUsagePercent.toFixed(1)}%
                              </Typography>
                            </Box>
                            <LinearProgress
                              variant="determinate"
                              value={Math.min(ramUsagePercent, 100)}
                              sx={{
                                height: 10,
                                borderRadius: 2,
                                backgroundColor: "#f093fb20",
                                '& .MuiLinearProgress-bar': {
                                  backgroundColor: ramUsagePercent > 80 ? "#ff4444" :
                                    ramUsagePercent > 60 ? "#ffa726" : "#f093fb",
                                  backgroundImage: `linear-gradient(90deg, 
                              #f5576c ${Math.min(ramUsagePercent, 100)}%, 
                              #f093fb ${Math.min(ramUsagePercent, 100)}%
                            )`,
                                },
                              }}
                            />
                            <Box display="flex" justifyContent="space-between" sx={{ mt: 0.5 }}>
                              <Typography variant="caption" color="#f5576c">
                                Request
                              </Typography>
                              <Typography variant="caption" color="#f093fb">
                                Limit
                              </Typography>
                            </Box>
                          </Box>
                        </Box>

                        {/* Indicateurs de performance */}
                        <Grid container spacing={1} sx={{ mt: 2 }}>
                          <Grid item xs={6}>
                            <Box sx={{
                              p: 1,
                              borderRadius: 1,
                              backgroundColor: cpuUsagePercent > 80 ? "#ff444410" :
                                cpuUsagePercent > 60 ? "#ffa72610" : "#667eea10",
                              border: `1px solid ${cpuUsagePercent > 80 ? "#ff444430" :
                                cpuUsagePercent > 60 ? "#ffa72630" : "#667eea30"}`,
                            }}>
                              <Typography variant="caption" color={modernTheme.textSecondary}>
                                CPU Status
                              </Typography>
                              <Typography
                                variant="body2"
                                sx={{
                                  fontWeight: 600,
                                  color: cpuUsagePercent > 80 ? "#ff4444" :
                                    cpuUsagePercent > 60 ? "#ffa726" : "#667eea"
                                }}
                              >
                                {cpuUsagePercent > 80 ? "CRITIQUE" :
                                  cpuUsagePercent > 60 ? "ATTENTION" : "NORMAL"}
                              </Typography>
                            </Box>
                          </Grid>
                          <Grid item xs={6}>
                            <Box sx={{
                              p: 1,
                              borderRadius: 1,
                              backgroundColor: ramUsagePercent > 80 ? "#ff444410" :
                                ramUsagePercent > 60 ? "#ffa72610" : "#f093fb10",
                              border: `1px solid ${ramUsagePercent > 80 ? "#ff444430" :
                                ramUsagePercent > 60 ? "#ffa72630" : "#f093fb30"}`,
                            }}>
                              <Typography variant="caption" color={modernTheme.textSecondary}>
                                RAM Status
                              </Typography>
                              <Typography
                                variant="body2"
                                sx={{
                                  fontWeight: 600,
                                  color: ramUsagePercent > 80 ? "#ff4444" :
                                    ramUsagePercent > 60 ? "#ffa726" : "#f093fb"
                                }}
                              >
                                {ramUsagePercent > 80 ? "CRITIQUE" :
                                  ramUsagePercent > 60 ? "ATTENTION" : "NORMAL"}
                              </Typography>
                            </Box>
                          </Grid>
                        </Grid>
                      </Paper>
                    </Grid>
                  );
                })}
              </Grid>

              {/* Bouton Afficher plus/moins pour Openshift */}
              {openshiftApplications.length > 5 && (
                <Box
                  sx={{
                    mt: 3,
                    display: "flex",
                    justifyContent: "center",
                  }}
                >
                  <Button
                    variant="outlined"
                    onClick={() => setShowAllOpenshiftApps(!showAllOpenshiftApps)}
                    sx={{
                      borderColor: modernTheme.secondary,
                      color: modernTheme.secondary,
                      "&:hover": {
                        borderColor: modernTheme.secondary,
                        backgroundColor: `${modernTheme.secondary}10`,
                      },
                      px: 3,
                      py: 1,
                      borderRadius: 2,
                    }}
                  >
                    {showAllOpenshiftApps
                      ? `Afficher moins (Top 5)`
                      : `Afficher plus (+${openshiftApplications.length - 5} applications)`}
                  </Button>
                </Box>
              )}
            </>
          ) : (
            <Alert severity="info">
              Aucune donnée d'application Openshift disponible.
            </Alert>
          )}

          {/* Résumé statistique global */}
          {openshiftApplications.length > 0 && (
            <Box sx={{ mt: 3, p: 2, backgroundColor: `${modernTheme.secondary}08`, borderRadius: 2 }}>
              <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
                Résumé Global Openshift
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={6} md={3}>
                  <Typography variant="caption" color={modernTheme.textSecondary}>
                    Applications
                  </Typography>
                  <Typography variant="h6">{openshiftApplications.length}</Typography>
                </Grid>
                <Grid item xs={6} md={3}>
                  <Typography variant="caption" color={modernTheme.textSecondary}>
                    CPU Limits Total
                  </Typography>
                  <Typography variant="h6">
                    {formatOpenshiftValue(
                      openshiftApplications
                        .reduce((sum, app) => sum + parseFloat(app.total_cpu_m || '0'), 0)
                        .toString(),
                      'cpu'
                    )}
                  </Typography>
                </Grid>
                <Grid item xs={6} md={3}>
                  <Typography variant="caption" color={modernTheme.textSecondary}>
                    CPU Requests Total
                  </Typography>
                  <Typography variant="h6">
                    {formatOpenshiftValue(
                      openshiftApplications
                        .reduce((sum, app) => sum + parseFloat(app.total_request_cpu_m || '0'), 0)
                        .toString(),
                      'cpu'
                    )}
                  </Typography>
                </Grid>
                <Grid item xs={6} md={3}>
                  <Typography variant="caption" color={modernTheme.textSecondary}>
                    RAM Limits Total
                  </Typography>
                  <Typography variant="h6">
                    {formatOpenshiftValue(
                      openshiftApplications
                        .reduce((sum, app) => sum + parseFloat(app.total_ram_mi || '0'), 0)
                        .toString(),
                      'ram'
                    )}
                  </Typography>
                </Grid>
                <Grid item xs={6} md={3}>
                  <Typography variant="caption" color={modernTheme.textSecondary}>
                    RAM Requests Total
                  </Typography>
                  <Typography variant="h6">
                    {formatOpenshiftValue(
                      openshiftApplications
                        .reduce((sum, app) => sum + parseFloat(app.total_request_ram_mi || '0'), 0)
                        .toString(),
                      'ram'
                    )}
                  </Typography>
                </Grid>
                <Grid item xs={6} md={3}>
                  <Typography variant="caption" color={modernTheme.textSecondary}>
                    Moyenne CPU Usage
                  </Typography>
                  <Typography variant="h6">
                    {(() => {
                      const validApps = openshiftApplications.filter(app =>
                        parseFloat(app.total_cpu_m || '0') > 0
                      );
                      if (validApps.length === 0) return 'N/A';

                      const avg = validApps.reduce((sum, app) => {
                        const limit = parseFloat(app.total_cpu_m || '0');
                        const request = parseFloat(app.total_request_cpu_m || '0');
                        return limit > 0 ? sum + (request / limit) * 100 : sum;
                      }, 0) / validApps.length;

                      return avg.toFixed(1) + '%';
                    })()}
                  </Typography>
                </Grid>
                <Grid item xs={6} md={3}>
                  <Typography variant="caption" color={modernTheme.textSecondary}>
                    Moyenne RAM Usage
                  </Typography>
                  <Typography variant="h6">
                    {(() => {
                      const validApps = openshiftApplications.filter(app =>
                        parseFloat(app.total_ram_mi || '0') > 0
                      );
                      if (validApps.length === 0) return 'N/A';

                      const avg = validApps.reduce((sum, app) => {
                        const limit = parseFloat(app.total_ram_mi || '0');
                        const request = parseFloat(app.total_request_ram_mi || '0');
                        return limit > 0 ? sum + (request / limit) * 100 : sum;
                      }, 0) / validApps.length;

                      return avg.toFixed(1) + '%';
                    })()}
                  </Typography>
                </Grid>
              </Grid>
            </Box>
          )}
        </CardContent>
      </Card>

      

      {/* Serveurs par nature */}
      <ServerCountByNatureCardWithTabs serverData={data} />

      {/* Architecture et OS */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={6}>
          <Paper
            elevation={0}
            sx={{
              p: 3,
              height: "100%",
              backgroundColor: "rgba(255, 255, 255, 0.8)",
              backdropFilter: "blur(10px)",
              border: "1px solid rgba(255, 255, 255, 0.3)",
              borderRadius: "12px",
              boxShadow: "0 4px 20px rgba(0, 0, 0, 0.08)",
            }}
          >
            <Typography
              variant="h5"
              gutterBottom
              display="flex"
              alignItems="center"
              sx={{ fontWeight: 600 }}
            >
              <PieChart
                style={{ marginRight: 8 }}
                color={modernTheme.primary}
              />
              Distribution Architecture
            </Typography>
            <Divider sx={{ mb: 3 }} />
            <DonutChart
              data={architectureData}
              size={250}
              centerValue={architectureData
                .reduce((a, b) => a + b.value, 0)
                .toLocaleString()}
              centerLabel="Serveurs"
            />
          </Paper>
        </Grid>

        <Grid item xs={12} md={6}>
          <Paper
            elevation={0}
            sx={{
              p: 3,
              height: "100%",
              backgroundColor: "rgba(255, 255, 255, 0.8)",
              backdropFilter: "blur(10px)",
              border: "1px solid rgba(255, 255, 255, 0.3)",
              borderRadius: "12px",
              boxShadow: "0 4px 20px rgba(0, 0, 0, 0.08)",
            }}
          >
            <Typography
              variant="h5"
              gutterBottom
              display="flex"
              alignItems="center"
              sx={{ fontWeight: 600 }}
            >
              <Monitor style={{ marginRight: 8 }} color={modernTheme.primary} />
              Répartition OS (x86)
            </Typography>
            <Divider sx={{ mb: 3 }} />
            <DonutChart
              data={osData}
              size={250}
              centerValue={osData
                .reduce((a, b) => a + b.value, 0)
                .toLocaleString()}
              centerLabel="Systèmes"
            />
          </Paper>
        </Grid>
      </Grid>

      {/* Serveurs isolés */}
      <Card sx={{ mb: 4, backgroundColor: modernTheme.cardBackground }}>
        <CardContent>
          <Typography
            variant="h5"
            gutterBottom
            sx={{ display: "flex", alignItems: "center" }}
          >
            <AlertTriangle
              style={{ marginRight: "8px", color: modernTheme.surfaceVariant }}
            />
            Serveurs Isolés
          </Typography>
          <Grid container spacing={2}>
            {Object.entries(data.isolated_servers).map(([source, count]) => (
              <Grid item xs={6} md={3} key={source}>
                <Paper
                  sx={{
                    p: 2,
                    textAlign: "center",
                    backgroundColor:
                      count > 0 ? modernTheme.surfaceVariant : "#e8f5e8",
                    transition: "transform 0.3s ease",
                    "&:hover": {
                      transform: "translateY(-5px)",
                    },
                  }}
                >
                  <Typography
                    variant="h6"
                    sx={{ color: count > 0 ? "white" : "inherit" }}
                  >
                    {count.toLocaleString()}
                  </Typography>
                  <Typography
                    variant="body2"
                    sx={{
                      color: count > 0 ? "white" : "inherit",
                      textTransform: "capitalize",
                    }}
                  >
                    {source}
                  </Typography>
                </Paper>
              </Grid>
            ))}
          </Grid>
        </CardContent>
      </Card>

      {/* IPs dupliquées */}
      <Card sx={{ mb: 4, backgroundColor: modernTheme.cardBackground }}>
        <CardContent>
          <Typography
            variant="h5"
            gutterBottom
            sx={{ display: "flex", alignItems: "center" }}
          >
            <XCircle
              style={{ marginRight: "8px", color: modernTheme.surfaceVariant }}
            />
            Adresses IP Dupliquées par Environnement
          </Typography>

          {orderedEnvironments.map((env) => {
            const ips = data.duplicate_ips[env];
            if (!ips || Object.keys(ips).length === 0) return null;

            return (
              <Box key={env} sx={{ mb: 3 }}>
                <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
                  <Chip
                    label={env}
                    sx={{
                      backgroundColor: getBadgeColorEnvironment(env),
                      color: "#000",
                      fontWeight: "bold",
                      mr: 2,
                      minWidth: 120,
                      justifyContent: "center",
                    }}
                  />
                  <Typography variant="h6">
                    {Object.keys(ips).length} IP(s) dupliquée(s)
                  </Typography>
                </Box>

                <Box
                  display="flex"
                  flexWrap="wrap"
                  gap={2}
                  sx={{
                    p: 2,
                    backgroundColor: "rgba(244, 67, 54, 0.05)",
                    borderRadius: "8px",
                    border: "1px dashed rgba(244, 67, 54, 0.2)",
                  }}
                >
                  {Object.entries(ips).map(([ip, count]) => (
                    <Tooltip
                      key={ip}
                      title={`${count} occurrence(s) dans ${env}`}
                      arrow
                    >
                      <div>
                        <IpBadge ip={ip} count={count} />
                      </div>
                    </Tooltip>
                  ))}
                </Box>
              </Box>
            );
          })}
        </CardContent>
      </Card>

      {/* Hostnames dupliqués */}
      <Card sx={{ backgroundColor: modernTheme.cardBackground }}>
        <CardContent>
          <Typography
            variant="h5"
            gutterBottom
            sx={{ display: "flex", alignItems: "center" }}
          >
            <XCircle
              style={{ marginRight: "8px", color: modernTheme.surfaceVariant }}
            />
            Hostnames Dupliqués
          </Typography>

          {data.duplicate_hostnames && Object.keys(data.duplicate_hostnames).length > 0 ? (
            <Box
              display="flex"
              flexWrap="wrap"
              gap={2}
              sx={{
                p: 2,
                backgroundColor: "rgba(244, 67, 54, 0.05)",
                borderRadius: "8px",
                border: "1px dashed rgba(244, 67, 54, 0.2)",
              }}
            >
              {Object.entries(data.duplicate_hostnames)
                .sort(([, countA], [, countB]) => countB - countA)
                .map(([hostname, count]) => (
                  <Tooltip
                    key={hostname}
                    title={`${count} occurrence(s) pour l'hostname ${hostname}`}
                    arrow
                  >
                    <div>
                      <HostnameBadge hostname={hostname} count={count} />
                    </div>
                  </Tooltip>
                ))}
            </Box>
          ) : (
            <Alert severity="info">
              Aucun hostname dupliqué détecté.
            </Alert>
          )}
        </CardContent>
      </Card>
    </Box>
  );
};

export default ServerCockpit;