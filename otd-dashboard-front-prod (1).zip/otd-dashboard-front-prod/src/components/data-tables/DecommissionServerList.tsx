import { useState, useEffect, useMemo, ReactNode } from 'react';
import {
  Box, Button, Typography, Paper, Chip, Alert, CircularProgress, Fade, Slide, Zoom, Dialog, DialogTitle, DialogContent, DialogActions, Checkbox, TextField, InputAdornment, ToggleButton, ToggleButtonGroup, Stack, IconButton, Radio, RadioGroup, FormControlLabel, Grid,
} from '@mui/material';
import {
  Timeline, TimelineItem, TimelineSeparator, TimelineConnector, TimelineContent, TimelineDot, TimelineOppositeContent
} from "@mui/lab";
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { DataGrid, GridColDef } from '@mui/x-data-grid';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import CancelIcon from '@mui/icons-material/Cancel';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import VisibilityIcon from '@mui/icons-material/Visibility'; // Eye icon
import CloseIcon from '@mui/icons-material/Close';
import PersonIcon from '@mui/icons-material/Person';
import PowerSettingsNewIcon from '@mui/icons-material/PowerSettingsNew';
import DeleteForeverIcon from '@mui/icons-material/DeleteForever';
import { DECOM_ENDPOINT, Servers_To_Decom } from '@/config/api.config';
import ServerDetailsModal from '@/components/modals/ServerDetailsModal';
import { SiN8N } from 'react-icons/si';

enum DecomPhase {
  INITIATED = "En attente de validation du TAM, demander par",
  VALITED_TAM = "Validée par le TAM uniquement",
  AWAITING_FCT_VALIDATION = "En attente de validation fonctionelle",
  VALITED_FCT = "Validée par le TAM et le Responsable fonctionnel",
  REFUSED_TAM = "Rejetée par le TAM",
  REFUSED_FCT = "Rejetée par le Responsable Fonctionnel",
  SHUTDOWN = "Eteint",
  DECOM = "Décommissioné",
}
declare module '@mui/material/styles' {
  interface Components {
    MuiDataGrid?: {
      styleOverrides?: {
        cell?: React.CSSProperties;
        columnHeader?: React.CSSProperties;
      };
    };
  }
}

// === TYPES ===
interface Admin {
  email: string;
  roles: string[];
  "full name": string;
}
interface CircuitData {
  id: number;
  created_at: string;
  decom_request: number;
  initiated_by_ops: Record<string, string>;
  tam_validation: Record<string, string>;
  function_validation: Record<string, string>;
  phase: string;
  shutdown_at: string | null;
  deleted_at: string | null;
  updated_at: string;
}

interface ServerSpecs {
  vmware_name: any;
  HMC_SOURCE: any;
  cpu: {
    request: ReactNode;
    limit: ReactNode;
    count: number;
    hot_add_enabled: boolean;
    cores_per_socket: number;
    hot_remove_enabled: boolean;
  };
  disks: Array<{
    id: string;
    type: string;
    label: string;
    capacity: number;
  }>;
  memory: {
    size_MiB: number;
    hot_add_enabled: boolean;
    hot_add_limit_MiB: number;
    hot_add_increment_size_MiB: number;
  };
  storage: number;
  vmware_id: string;
  vmware_source: string;
}
interface ServerToDecom {
  shutdown_at: string | null | undefined;
  natures_inventory: never[];
  phase: string | undefined;
  updated_by: any;
  created_at: any;
  solutions: any;
  updated_at: any;
  created_by: any;
  entities: any;
  poles: any;
  domains: any;
  signed: any;
  nature_detail: any;
  os_detail: any;
  id: number;
  hostname: string;
  ip_addresses: string[];
  os_type: string;
  base_server_id?: number;
  uname: string | null;
  environments: string[];
  admins: Admin[];
  is_validated: boolean;
  awaiting_functional_validation: boolean;
  circuit_data?: CircuitData | null;
  specs?: ServerSpecs;
}
type FilterType = 'all' | 'tam' | 'functional' | 'validated' | 'pending';

// === THÈME ===
const modernTheme = createTheme({
  palette: {
    primary: { main: '#6366F1' },
    success: { main: '#10B981' },
    error: { main: '#EF4444' },
    warning: { main: '#F59E0B' },
    background: { default: '#F8FAFC', paper: '#FFFFFF' },
  },
  shape: { borderRadius: 6 },
  components: {
    MuiButton: { styleOverrides: { root: { textTransform: 'none', fontWeight: 600, borderRadius: 12 } } },
    MuiDialog: { styleOverrides: { paper: { borderRadius: 20 } } },
    MuiDataGrid: {
      styleOverrides: {
        cell: { display: 'flex', justifyContent: 'flex-start', alignItems: 'center', paddingLeft: 2 },
        columnHeader: { justifyContent: 'flex-start', paddingLeft: 2 },
      },
    },
  },
});

const getPastelColorOS = (
  value: string,
): { bgColor: string; textColor: string } => {
  switch (value.toLowerCase()) {
    case "windows":
      return { bgColor: "#93C5FD", textColor: "#1E40AF" }; // bleu pastel
    case "linux":
      return { bgColor: "#a8e6b1", textColor: "#166534" }; // vert pastel
    case "macos":
      return { bgColor: "#F9A8D4", textColor: "#831843" }; // rose pastel
    case "aix":
      return { bgColor: "#fce38a", textColor: "#1E40AF" }; // jaune pastel
    default:
      return { bgColor: "#7fb2e6", textColor: "#000000" };
  }
};


const getCurrentUserEmail = (): string | null => {
  const token = localStorage.getItem("access_token");
  if (!token) return null;
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    return payload.email || payload.sub || null;
  } catch { return null; }
};

// === FONCTION POUR DÉTERMINER LA PHASE SUIVANTE ===
const getNextPhase = (server: ServerToDecom): string => {
  const phase = server.phase || server.circuit_data?.phase || "";

  // Si déjà éteint ou décommissionné, on affiche la phase actuelle
  if (phase === DecomPhase.SHUTDOWN || phase === DecomPhase.DECOM) {
    return phase;
  }

  // Si rejeté, on affiche rejeté
  if (phase === DecomPhase.REFUSED_TAM || phase === DecomPhase.REFUSED_FCT) {
    return "Demande rejetée";
  }

  // Déterminer la phase suivante en fonction de la phase actuelle
  switch (phase) {
    case DecomPhase.INITIATED:
    case "":
    case "En attente":
      // Nouvelle demande → en attente de validation TAM
      return "En attente de validation par le TAM";

    case DecomPhase.VALITED_TAM:
      return server.awaiting_functional_validation
        ? "En attente de validation fonctionnelle"
        : "En attente d'arrêt du serveur";

    case DecomPhase.AWAITING_FCT_VALIDATION:
      return "En attente de validation fonctionnelle";

    case DecomPhase.VALITED_FCT:
      return "En attente d'arrêt du serveur";

    default:
      // Par défaut, considérer que c'est une nouvelle demande
      return "En attente de validation par le TAM";
  }
};

const getPhaseStatus = (phase: string | undefined, server: ServerToDecom): {
  canTAMAct: boolean;
  canFCTAct: boolean;
  checkboxDisabled: boolean;
  showTAMButton: boolean;
  showFCTButton: boolean;
  shouldShowFCTValidation: boolean; // Nouveau
} => {
  const userEmail = getCurrentUserEmail();
  if (!userEmail || !server) {
    return {
      canTAMAct: false,
      canFCTAct: false,
      checkboxDisabled: true,
      showTAMButton: false,
      showFCTButton: false,
      shouldShowFCTValidation: false
    };
  }

  // Vérifier les rôles
  const isTAM = server.admins.some(a =>
    a.email.toLowerCase() === userEmail.toLowerCase() &&
    a.roles.map(r => r.toLowerCase()).includes("tam")
  );

  const isFCT = server.admins.some(a =>
    a.email.toLowerCase() === userEmail.toLowerCase() &&
    a.roles.map(r => r.toLowerCase()).includes("functional_admin")
  );

  const basePhase = phase || '';

  // PHASES DÉTAILLÉES
  switch (basePhase) {
    case DecomPhase.INITIATED:
    case "":
    case "En attente":
      return {
        canTAMAct: isTAM,
        canFCTAct: false,
        checkboxDisabled: !isTAM,
        showTAMButton: isTAM,
        showFCTButton: false,
        shouldShowFCTValidation: false // ← IMPORTANT
      };

    case DecomPhase.VALITED_TAM:
      // Le TAM a validé, on attend la validation FCT
      return {
        canTAMAct: false, // TAM ne peut plus agir
        canFCTAct: isFCT,
        checkboxDisabled: !isFCT,
        showTAMButton: false,
        showFCTButton: isFCT,
        shouldShowFCTValidation: true // ← On montre la validation FCT
      };

    case DecomPhase.AWAITING_FCT_VALIDATION:
      return {
        canTAMAct: false,
        canFCTAct: isFCT,
        checkboxDisabled: !isFCT,
        showTAMButton: false,
        showFCTButton: isFCT,
        shouldShowFCTValidation: true
      };

    case DecomPhase.VALITED_FCT:
    case DecomPhase.REFUSED_TAM:
    case DecomPhase.REFUSED_FCT:
    case DecomPhase.SHUTDOWN:
    case DecomPhase.DECOM:
      return {
        canTAMAct: false,
        canFCTAct: false,
        checkboxDisabled: true,
        showTAMButton: false,
        showFCTButton: false,
        shouldShowFCTValidation: false

      };

    default:
      // Par défaut, si la phase n'est pas reconnue, permettre au TAM d'agir
      return {
        canTAMAct: isTAM,
        canFCTAct: false,
        checkboxDisabled: !isTAM,
        showTAMButton: isTAM,
        showFCTButton: false,
        shouldShowFCTValidation: false

      };
  }
};
const transformServerToRowData = (server: ServerToDecom): any => {
  // === Fonction de dédoublonnage (par email OU nom) ===
  const dedupAdmins = (admins: any[]): any[] => {
    const seen = new Set<string>();
    return admins.filter(admin => {
      const key = admin.email?.trim() || admin.name?.trim() || `${Math.random()}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  };

  // === Tous les admins, même vides ===
  const allAdmins = (server.admins || []).map(a => ({
    email: (a.email || "").trim(),
    name: (a["full name"] || "à définir").trim(),
    roles: a.roles || [],
  }));

  // === Répartition par rôle + dédoublonnage ===
  const funcAdmins = dedupAdmins(
    allAdmins
      .filter(a => a.roles.some((r: string) => r.toLowerCase().includes("functional_admin")))
      .map(a => ({ name: a.name, email: a.email }))
  );

  const techAdmins = dedupAdmins(
    allAdmins
      .filter(a => a.roles.some((r: string) => r.toLowerCase().includes("technical_admin")))
      .map(a => ({ name: a.name, email: a.email }))
  );

  const tamAdmins = dedupAdmins(
    allAdmins
      .filter(a => a.roles.some((r: string) => r.toLowerCase().includes("tam")))
      .map(a => ({ name: a.name, email: a.email }))
  );

  return {
    Hostname: server.hostname,
    "Type OS": server.os_type,
    os_detail: server.os_detail,
    Uname: server.uname,
    "Adresses IP": server.ip_addresses,
    Environnements: server.environments || [],
    "Nature du serveur dans L'inventaire": server.natures_inventory || [],
    "Nature du serveur dans BigFix": server.nature_detail ? [server.nature_detail] : [],
    "Solutions dans Bigfix": server.solutions || [],
    "Solutions dans l'inventaire": server.solutions || [],
    Fiabilité: server.is_validated ? "Fiable" : "Non fiable",

    // === Admins sans doublons ===
    "Admin Fonctionnel": funcAdmins,
    "Admin Technique": techAdmins,
    TAM: tamAdmins,

    Domaine: server.domains || [],
    Pôle: server.poles || [],
    Entities: server.entities || [],
  };
};

// === TIMELINE ANIMÉE ===
const DecomTimeline = ({ server }: { server: ServerToDecom | null }) => {
  if (!server || !server.circuit_data) {
    return (
      <Box sx={{ p: 6, textAlign: 'center', color: '#9CA3AF' }}>
        <Typography variant="h6">Aucune donnée disponible</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
          Le workflow n'a pas encore été initié pour ce serveur
        </Typography>
      </Box>
    );
  }

  const c = server.circuit_data;
  const opsDone = !!c.initiated_by_ops && Object.keys(c.initiated_by_ops).length > 0;
  const tamDone = !!c.tam_validation && Object.keys(c.tam_validation).length > 0;
  const fctDone = !!c.function_validation && Object.keys(c.function_validation).length > 0;
  const shutdownDone = !!c.shutdown_at;
  const decomDone = !!c.deleted_at;
  const hasFct = server.awaiting_functional_validation === true;
  const isRejectedByTAM = c.phase.includes("Rejetée") && tamDone && !fctDone;
  const isRejectedByFCT = c.phase.includes("Rejetée") && fctDone;

  // === Fonction pour extraire et dédupliquer les admins par rôle ===
  const getAdminsByRole = (roleKeyword: string): Admin[] => {
    const seen = new Set<string>();
    return server.admins
      .filter(a =>
        a.email &&
        a.roles.some(r => r.toLowerCase().includes(roleKeyword))
      )
      .filter(a => {
        const key = a.email.toLowerCase();
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      });
  };

  // === Définir le tableau steps ===
  const steps = [
    {
      label: 'Initié par OPS',
      subtitle: 'Demande créée',
      icon: <PersonIcon />,
      done: opsDone,
      date: opsDone ? Object.values(c.initiated_by_ops)[0] : undefined,
      by: opsDone ? Object.keys(c.initiated_by_ops)[0].split('@')[0] : undefined,
      color: '#6366F1',
      bgColor: '#EEF2FF',
      pendingAdmins: [] as Admin[],
    },
    {
      label: tamDone && !isRejectedByTAM ? 'Validé par TAM' : 'Validation TAM',
      subtitle: isRejectedByTAM ? 'Demande refusée' : 'Validation technique',
      icon: isRejectedByTAM ? <CancelIcon /> : <CheckCircleIcon />,
      done: tamDone,
      date: tamDone ? Object.values(c.tam_validation)[0] : undefined,
      by: tamDone ? Object.keys(c.tam_validation)[0].split('@')[0] : undefined,
      color: isRejectedByTAM ? '#EF4444' : '#10B981',
      bgColor: isRejectedByTAM ? '#FEE2E2' : '#D1FAE5',
      pendingAdmins: !tamDone ? getAdminsByRole('tam') : [],
    },
  ];

  // Ajouter validation fonctionnelle si nécessaire
  if (hasFct && !isRejectedByTAM) {
    steps.push({
      label: fctDone && !isRejectedByFCT ? 'Validé par FCT' : 'Validation FCT',
      subtitle: isRejectedByFCT ? 'Demande refusée' : 'Validation fonctionnelle',
      icon: isRejectedByFCT ? <CancelIcon /> : fctDone ? <CheckCircleIcon /> : <PersonIcon />,
      done: fctDone,
      date: fctDone ? Object.values(c.function_validation)[0] : undefined,
      by: fctDone ? Object.keys(c.function_validation)[0].split('@')[0] : undefined,
      color: isRejectedByFCT ? '#EF4444' : fctDone ? '#10B981' : '#F59E0B',
      bgColor: isRejectedByFCT ? '#FEE2E2' : fctDone ? '#D1FAE5' : '#FEF3C7',
      pendingAdmins: !fctDone ? getAdminsByRole('functional_admin') : [],
    });
  }

  // Ajouter étapes finales uniquement si non rejeté
  if (!isRejectedByTAM && !isRejectedByFCT) {
    steps.push(
      {
        label: 'Arrêt du serveur',
        subtitle: 'Mise hors service',
        icon: <PowerSettingsNewIcon />,
        done: shutdownDone,
        date: shutdownDone ? c.shutdown_at ?? undefined : undefined,
        by: undefined,
        color: '#8B5CF6',
        bgColor: '#F3E8FF',
        pendingAdmins: [] as Admin[],
      },
      {
        label: 'Décommissionné',
        subtitle: 'Suppression définitive',
        icon: <DeleteForeverIcon />,
        done: decomDone,
        date: decomDone ? c.deleted_at ?? undefined : undefined,
        by: undefined,
        color: '#EC4899',
        bgColor: '#FCE7F3',
        pendingAdmins: [] as Admin[],
      }
    );
  }

  return (
    <Box sx={{ height: 'auto', overflowY: 'auto', px: 2 }}>
      {/* === TITRE AVEC INFORMATIONS SIMPLES À CÔTÉ === */}
      <Box sx={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'flex-start',
        mb: 4,
        p: 3,
        bgcolor: '#F8FAFC',
        borderRadius: 2,
        border: '1px solid #E5E7EB'
      }}>
        {/* Titre à gauche */}
        <Box>
          <Typography variant="h5" fontWeight={700} color="primary" gutterBottom>
            Détails du Workflow
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Suivi du processus pour ce serveur
          </Typography>
        </Box>

        {/* Informations du serveur à droite */}
        <Box sx={{ textAlign: 'right' }}>
          <Typography variant="h6" fontWeight={600} gutterBottom>
            {server.hostname}
          </Typography>
          
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
            {/* OS */}
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 1 }}>
              <Typography variant="body2" color="text.secondary">OS:</Typography>
              <Chip
                label={server.os_type}
                size="small"
                sx={{
                  bgcolor: getPastelColorOS(server.os_type).bgColor,
                  color: getPastelColorOS(server.os_type).textColor,
                  fontWeight: 500,
                }}
              />
            </Box>
            
            {/* IP */}
            <Box>
              <Typography variant="body2" color="text.secondary">
                IP: {server.ip_addresses.join(', ')}
              </Typography>
            </Box>
            
            {/* Environnement */}
            <Box>
              <Typography variant="body2" color="text.secondary">
                Env: {server.environments?.join(', ') || 'Non défini'}
              </Typography>
            </Box>
          </Box>
        </Box>
      </Box>

      {/* === TIMELINE === */}
      <Timeline
        position="alternate"
        sx={{
          m: 0,
          p: 0,
          '& .MuiTimelineConnector-root': {
            backgroundColor: '#E5E7EB',
          },
        }}
      >
        {steps.map((step: any, index: number) => (
          <Zoom in timeout={300 + index * 150} key={index}>
            <TimelineItem>
              <TimelineOppositeContent
                color="text.secondary"
                sx={{
                  flex: 0.3,
                  py: 2,
                }}
              >
                <Fade in={step.done} timeout={600}>
                  <Box>
                    {step.done && step.date && (
                      <>
                        <Typography
                          variant="body2"
                          fontWeight={600}
                          sx={{ color: step.color }}
                        >
                          {new Date(step.date).toLocaleDateString('fr-FR', {
                            day: '2-digit',
                            month: 'short',
                            year: 'numeric'
                          })}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {new Date(step.date).toLocaleTimeString('fr-FR', {
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </Typography>
                      </>
                    )}
                  </Box>
                </Fade>
              </TimelineOppositeContent>
              <TimelineSeparator>
                {index > 0 && (
                  <TimelineConnector
                    sx={{
                      bgcolor: step.done ? steps[index - 1].color : '#E5E7EB',
                      width: 3,
                    }}
                  />
                )}

                <Slide direction="up" in timeout={400 + index * 150}>
                  <TimelineDot
                    sx={{
                      bgcolor: step.done ? step.color : '#E5E7EB',
                      color: 'white',
                      width: 48,
                      height: 48,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      boxShadow: step.done ? `0 0 0 4px ${step.color}20` : 'none',
                      transition: 'all 0.4s ease',
                      border: step.done ? `3px solid ${step.color}` : '3px solid #E5E7EB',
                    }}
                  >
                    {step.icon}
                  </TimelineDot>
                </Slide>
                {index < steps.length - 1 && (
                  <TimelineConnector
                    sx={{
                      bgcolor: steps[index + 1].done ? step.color : '#E5E7EB',
                      width: 3,
                      minHeight: 40,
                    }}
                  />
                )}
              </TimelineSeparator>
              <TimelineContent sx={{ py: 2, px: 2 }}>
                <Fade in timeout={500 + index * 200}>
                  <Paper
                    elevation={step.done ? 3 : 1}
                    sx={{
                      p: 2.5,
                      borderRadius: 2,
                      bgcolor: step.done ? step.bgColor : '#F9FAFB',
                      border: `2px solid ${step.done ? step.color : '#E5E7EB'}`,
                      transition: 'all 0.3s ease',
                      '&:hover': {
                        transform: step.done ? 'translateY(-2px)' : 'none',
                        boxShadow: step.done ? 4 : 1,
                      },
                    }}
                  >
                    <Typography
                      variant="h6"
                      fontWeight={700}
                      sx={{
                        color: step.done ? step.color : 'text.disabled',
                        fontSize: '1rem',
                        mb: 0.5,
                      }}
                    >
                      {step.label}
                    </Typography>
                    <Typography
                      variant="body2"
                      color="text.secondary"
                      sx={{ mb: step.done && step.by ? 1 : 0 }}
                    >
                      {step.subtitle}
                    </Typography>
                    {step.done && step.by && (
                      <Box
                        sx={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: 0.5,
                          mt: 1,
                          pt: 1,
                          borderTop: '1px solid',
                          borderColor: 'divider',
                        }}
                      >
                        <PersonIcon fontSize="small" sx={{ color: step.color }} />
                        <Typography
                          variant="body2"
                          fontWeight={500}
                          sx={{ color: step.color }}
                        >
                          {step.by}
                        </Typography>
                      </Box>
                    )}
                    {!step.done && (
                      <Chip
                        label="En attente"
                        size="small"
                        sx={{
                          mt: 1,
                          fontWeight: 600,
                          bgcolor: '#F3F4F6',
                          color: '#6B7280',
                        }}
                      />
                    )}

                    {!step.done &&
                      (step.label.includes('Validation TAM') || step.label.includes('Validation FCT')) &&
                      step.pendingAdmins.length > 0 && (
                        <Box
                          sx={{
                            mt: 2,
                            p: 2,
                            bgcolor: '#FFF8E1',
                            borderRadius: 2,
                            border: '1px dashed #FFB300',
                          }}
                        >
                          <Typography variant="body2" fontWeight={600} color="#D97706" gutterBottom>
                            Peuvent valider :
                          </Typography>
                          <Stack spacing={0.5}>
                            {step.pendingAdmins.map((admin: Admin, i: number) => (
                              <Box key={i} sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                                <PersonIcon fontSize="small" sx={{ color: '#D97706' }} />
                                <Typography variant="body2">
                                  <strong>{admin["full name"] || 'Inconnu'}</strong>{' '}
                                  <a
                                    href={`mailto:${admin.email}`}
                                    style={{ color: '#6366F1', textDecoration: 'none' }}
                                    onClick={(e) => e.stopPropagation()}
                                  >
                                    {admin.email}
                                  </a>
                                </Typography>
                              </Box>
                            ))}
                          </Stack>
                        </Box>
                      )}
                  </Paper>
                </Fade>
              </TimelineContent>
            </TimelineItem>
          </Zoom>
        ))}
      </Timeline>
    </Box>
  );
};



// === ENDPOINTS ===
const TAM_ENDPOINT = `${DECOM_ENDPOINT()}/decom/manage/tam/`;
const FCT_ENDPOINT = `${DECOM_ENDPOINT()}/decom/manage/functional_lead/`;
const loadCircuitData = async (id: number): Promise<CircuitData | null> => {
  try {
    const token = localStorage.getItem("access_token");
    if (!token) return null;
    const response = await fetch(
      `${DECOM_ENDPOINT()}/decom-circuit/${id}`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
    if (!response.ok) return null;
    return await response.json();
  } catch { return null; }
};

// === COMPOSANT PRINCIPAL ===
export default function DecommissionServerList() {
  const [servers, setServers] = useState<ServerToDecom[]>([]);
  const [filteredServers, setFilteredServers] = useState<ServerToDecom[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => setError(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [error]);
  const [selectedServers, setSelectedServers] = useState<number[]>([]);
  const [validationDialogOpen, setValidationDialogOpen] = useState(false);
  const [functionalDialogOpen, setFunctionalDialogOpen] = useState(false);
  const [detailsModalOpen, setDetailsModalOpen] = useState(false);
  const [timelineModalOpen, setTimelineModalOpen] = useState(false);
  const [selectedServer, setSelectedServer] = useState<ServerToDecom | null>(null);
  const [validationLoading, setValidationLoading] = useState(false);
  const [functionalLoading, setFunctionalLoading] = useState(false);
  const [validationResult, setValidationResult] = useState<{ success: boolean; message: string } | null>(null);
  const [, setFunctionalResult] = useState<{ [key: number]: { status: string } }>({});
  const [tamActions, setTamActions] = useState<{ [key: number]: 'accept' | 'refuse' }>({});
  const [fctActions, setFctActions] = useState<{ [key: number]: 'accept' | 'refuse' }>({});

  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState<FilterType>('all');

  const [, setApiResponses] = useState<{ [key: number]: any[] }>({});
  const [functionalNeeded, setFunctionalNeeded] = useState<{ [key: number]: boolean }>({});
  const [confirmHostnames, setConfirmHostnames] = useState<{ [key: number]: string }>({});

  const [ipSuggestions, setIpSuggestions] = useState<{
    [key: number]: {
      id_source: any; id: number; ip: string
    }[]
  }>({});
  const [selectedIpEntry, setSelectedIpEntry] = useState<{ [key: number]: { id: number; id_source: number | undefined } }>({});
  const [validationErrors, setValidationErrors] = useState<{ [key: number]: string }>({});

  const checkServerValidity = async (serverId: number, _hostname: string, _ipList: string[]) => {
    const server = servers.find(s => s.id === serverId);

    if (!server) {
      setValidationErrors(p => ({ ...p, [serverId]: 'Serveur non trouvé' }));
      return 'not-found';
    }

    // Vérifier si les specs sont présentes
    if (!server.specs) {
      setValidationErrors(p => ({
        ...p,
        [serverId]: '⚠️ Aucune donnée technique disponible'
      }));
      return 'no-specs';
    }

    // Vérifier les données minimales - ADAPTÉ POUR AIX ET AUTRES OS
    const isAIX = server.os_type.toLowerCase() === 'aix';

    if (isAIX) {
      // Validation spécifique pour AIX
      const hasValidAIXSpecs = server.specs.vmware_id ||
        server.specs.HMC_SOURCE ||
        server.specs.vmware_source;

      if (!hasValidAIXSpecs) {
        setValidationErrors(p => ({
          ...p,
          [serverId]: '⚠️ Données techniques AIX incomplètes'
        }));
        return 'incomplete-specs';
      }
    } else {
      // Validation pour autres OS
      const hasValidSpecs = (server.specs.cpu && server.specs.cpu.count) &&
        (server.specs.memory && server.specs.memory.size_MiB) &&
        server.specs.vmware_id &&
        server.specs.vmware_source;

      if (!hasValidSpecs) {
        setValidationErrors(p => ({
          ...p,
          [serverId]: '⚠️ Données techniques incomplètes'
        }));
        return 'incomplete-specs';
      }
    }

    // Tout est OK
    setValidationErrors(p => ({ ...p, [serverId]: '' }));
    return 'valid';
  };

  // Fonction UNIQUEMENT pour afficher dans le filtre "À moi (TAM)"
  const shouldShowInTAMFilter = (server: ServerToDecom): boolean => {
    const userEmail = getCurrentUserEmail();
    if (!userEmail) return false;

    return server.admins.some(a =>
      a.email.toLowerCase() === userEmail.toLowerCase() &&
      a.roles.map(r => r.toLowerCase()).includes("tam")
    );
    // Pas de vérification isAIX ici → les AIX apparaîtront
  };

  // Fonction UNIQUEMENT pour afficher dans le filtre "À moi (FCT)"
  const shouldShowInFCTFilter = (server: ServerToDecom): boolean => {
    const userEmail = getCurrentUserEmail();
    if (!userEmail) return false;

    return server.admins.some(a =>
      a.email.toLowerCase() === userEmail.toLowerCase() &&
      a.roles.map(r => r.toLowerCase()).includes("functional_admin")
    );
    // Pas de vérification isAIX ici → les AIX apparaîtront
  };


  const canUserManageAsTAM = (server: ServerToDecom): boolean => {
    const userEmail = getCurrentUserEmail();
    if (!userEmail) return false;

    // Vérifier si l'utilisateur est TAM pour ce serveur
    const isTAM = server.admins.some(a =>
      a.email.toLowerCase() === userEmail.toLowerCase() &&
      a.roles.map(r => r.toLowerCase()).includes("tam")
    );

    if (!isTAM) return false;

    const phase = server.phase || server.circuit_data?.phase;
    const { canTAMAct } = getPhaseStatus(phase, server);

    return canTAMAct;
  };


  const canUserManageAsFunctional = (server: ServerToDecom): boolean => {
    const phase = server.phase || server.circuit_data?.phase;
    const { canFCTAct } = getPhaseStatus(phase, server);
    return canFCTAct;
  };

  const [] = useState(false);


  const fetchServersToDecom = async () => {
    try {
      setLoading(true);
      setError(null);
      const token = localStorage.getItem("access_token");
      const response = await fetch(Servers_To_Decom(), {
        headers: { "Content-Type": "application/json", ...(token && { Authorization: `Bearer ${token}` }) },
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data: ServerToDecom[] = await response.json();

      // On ne charge PLUS circuit_data ici
      setServers(data);
      setFilteredServers(data);
    } catch (err) {
      setError("Impossible de charger les serveurs");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (validationDialogOpen && selectedServers.length > 0) {
      const checkAll = async () => {
        setIpSuggestions({});
        setSelectedIpEntry({});
        setValidationErrors({});

        for (const id of selectedServers) {
          const server = servers.find(s => s.id === id);
          if (server && canUserManageAsTAM(server)) {
            await checkServerValidity(id, server.hostname, server.ip_addresses);
          }
        }
      };
      checkAll();
    }
  }, [validationDialogOpen, selectedServers, servers]);

  useEffect(() => { fetchServersToDecom(); }, []);

  // === FILTRE GLOBAL AVEC RECHERCHE DANS TOUS LES CHAMPS ===
  useEffect(() => {
    let filtered = [...servers];

    // 1. Appliquer le filtre par rôle
    switch (filter) {
      case 'tam':
        // Utilisez la fonction POUR LA VUE (inclut les AIX)
        filtered = filtered.filter(shouldShowInTAMFilter);
        break;
      case 'functional':
        // Utilisez la fonction POUR LA VUE (inclut les AIX)
        filtered = filtered.filter(shouldShowInFCTFilter);
        break;
      case 'validated':
        filtered = filtered.filter(s => s.is_validated);
        break;
      case 'pending':
        filtered = filtered.filter(s => !s.is_validated);
        break;
      default:
        // 'all' - pas de filtre supplémentaire
        break;
    }

    // 2. Appliquer la recherche
    if (searchTerm.trim()) {
      const query = searchTerm.toLowerCase().trim();
      filtered = filtered.filter(server => {
        // Vérifier tous les champs (reste identique)
        if (server.hostname.toLowerCase().includes(query)) return true;
        if (server.ip_addresses.some(ip => ip.toLowerCase().includes(query))) return true;
        if (server.os_type.toLowerCase().includes(query)) return true;
        if (server.environments.some(env => env.toLowerCase().includes(query))) return true;

        // Vérifier la phase
        const phase = server.phase || server.circuit_data?.phase || '';
        if (phase.toLowerCase().includes(query)) return true;

        // Vérifier les admins
        const adminMatch = server.admins.some(admin =>
          (admin["full name"] ?? "").toLowerCase().includes(query) ||
          admin.email.toLowerCase().includes(query)
        );
        return adminMatch;
      });
    }


    setSelectedServers([]);
    setFilteredServers(filtered);
  }, [servers, filter, searchTerm]);

  useEffect(() => {
    if (functionalDialogOpen && selectedServers.length > 0) {
      const checkAll = async () => {
        setApiResponses({});
        for (const id of selectedServers) {
          const server = servers.find(s => s.id === id);
          if (server && canUserManageAsFunctional(server)) {
            await checkServerValidity(id, server.hostname, server.ip_addresses);
          }
        }
      };
      checkAll();
    }
  }, [functionalDialogOpen, selectedServers, servers]);



  const handleTAMValidation = async () => {
    try {
      setValidationLoading(true);
      const token = localStorage.getItem("access_token");

      const payload = {
        operations: selectedServers.map(id => {
          const server = servers.find(s => s.id === id)!;

          return {
            id_demande: id,
            validé_par_le_tam: tamActions[id] === 'accept',
            validation_fonctionnelle_necessaire: tamActions[id] === 'accept' && (functionalNeeded[id] === true),
            ip_addresses: server.ip_addresses,
            id_source: server.base_server_id || null,
            // Ajouter un champ spécifique pour AIX si nécessaire
            is_aix: server.os_type.toUpperCase() === "AIX", // Pour information seulement
          };
        }),
      };

      const res = await fetch(TAM_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify(payload),
      });

      if (!res.ok) throw new Error("Échec");

      setValidationResult({ success: true, message: "Validation TAM envoyée" });
      setTimeout(() => {
        fetchServersToDecom();
        resetTAMState();
      }, 1500);
    } catch {
      setValidationResult({ success: false, message: "Erreur" });
    } finally {
      setValidationLoading(false);
    }
  };

  const resetTAMState = () => {
    setSelectedServers([]);
    setTamActions({});
    setFunctionalNeeded({});
    setConfirmHostnames({});
    setValidationDialogOpen(false);
    setValidationResult(null);
  };

  const handleFCTValidation = async () => {
    try {
      setFunctionalLoading(true);
      const token = localStorage.getItem("access_token");

      const payload = {
        operations: selectedServers.map(id => {
          const server = servers.find(s => s.id === id)!;

          return {
            id_demande: id,
            ip: server.ip_addresses,
            hostname: server.hostname,
            id_source: server.base_server_id || null, // Utiliser base_server_id des specs
            validé_par_admin_fonctionnel: fctActions[id] === 'accept'
          };
        }),
      };

      const res = await fetch(FCT_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify(payload),
      });

      if (!res.ok) throw new Error("Échec");

      setTimeout(() => {
        fetchServersToDecom();
        resetFCTState();
      }, 1500);
    } catch {
      setFunctionalResult({ [-1]: { status: "Erreur de validation FCT" } });
    } finally {
      setFunctionalLoading(false);
    }
  };

  const resetFCTState = () => {
    setSelectedServers([]);
    setFctActions({});
    setFunctionalDialogOpen(false);
    setFunctionalResult({});
  };

  const handleServerSelection = (id: number, checked: boolean, isFunctional = false) => {
    if (checked) {
      setSelectedServers(p => [...p, id]);
      if (!isFunctional) setTamActions(p => ({ ...p, [id]: 'accept' }));
      else setFctActions(p => ({ ...p, [id]: 'accept' }));
    } else {
      setSelectedServers(p => p.filter(x => x !== id));
      setTamActions(p => { const np = { ...p }; delete np[id]; return np; });
      setFctActions(p => { const np = { ...p }; delete np[id]; return np; });
      setFunctionalNeeded(p => { const np = { ...p }; delete np[id]; return np; });
      setConfirmHostnames(p => { const np = { ...p }; delete np[id]; return np; });
    }
  };

  const allConfirmed = selectedServers.every(id => {
    if (tamActions[id] === 'refuse') return true;

    const s = servers.find(x => x.id === id);
    const needsIp = ipSuggestions[id]?.length > 0;
    const ipOk = !needsIp || !!selectedIpEntry[id];
    const hostnameConfirmed = confirmHostnames[id]?.toLowerCase() === s?.hostname.toLowerCase();

    return ipOk && hostnameConfirmed;
  });

  const openDetails = (server: ServerToDecom) => {
    setSelectedServer(server);
    setDetailsModalOpen(true);
  };

  const openTimeline = async (server: ServerToDecom) => {
    setDetailsModalOpen(false); // ← fermer details
    setSelectedServer({ ...server, circuit_data: null });
    setTimelineModalOpen(true);
    const circuit = await loadCircuitData(server.id);
    setSelectedServer(prev => prev ? { ...prev, circuit_data: circuit } : null);
  };

  const columns: GridColDef[] = useMemo(() => [
    {
      field: 'selection',
      headerName: '',
      width: 60,
      sortable: false,
      renderCell: (params: any) => {
        const s = params.row;
        const phase = s.phase || s.circuit_data?.phase;
        const { checkboxDisabled } = getPhaseStatus(phase, s);
        const canTAM = canUserManageAsTAM(s);
        const canFCT = canUserManageAsFunctional(s);

        return (
          <Box sx={{ display: 'flex', justifyContent: 'center' }}>
            <Checkbox
              checked={selectedServers.includes(s.id)}
              onChange={e => handleServerSelection(s.id, e.target.checked, canFCT)}
              disabled={checkboxDisabled || (!canTAM && !canFCT)}
              size="small"
            />
          </Box>
        );
      },
    },
    {
      field: 'actions',
      headerName: 'Actions',
      width: 140,
      sortable: false,
      renderCell: (params: any) => (
        <Box sx={{ display: 'flex', justifyContent: 'center', gap: 1 }}>
          <IconButton size="small" onClick={() => openDetails(params.row)} color="primary">
            <VisibilityIcon fontSize="small" />
          </IconButton>
          <IconButton size="small" onClick={() => openTimeline(params.row)} color="secondary">
            <SiN8N />
          </IconButton>
        </Box>
      ),
    },
    {
      field: 'hostname',
      headerName: 'Hostname',
      width: 280,
      renderCell: (params: any) => {
        const server = params.row as ServerToDecom;
        const hostname = server.hostname || '';
        const uname = server.uname || null;
        const isAix = server.os_type.toLowerCase() === 'aix';

        return (
          <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', lineHeight: 1.3 }}>
            <Typography fontWeight={600} fontSize="0.95rem">
              {hostname}
            </Typography>
            {isAix && uname && (
              <Typography
                variant="caption"
                color="text.secondary"
                fontSize="0.75rem"
                sx={{ mt: -0.5 }}
              >
                uname: <strong>{uname}</strong>
              </Typography>
            )}
          </Box>
        );
      },
    },
    { field: 'ip_addresses', headerName: 'IP', width: 220, renderCell: (p: any) => <Box sx={{ display: 'flex', justifyContent: 'center', gap: 0.5, flexWrap: 'wrap' }}>{p.value.map((ip: string) => <Chip key={ip} label={ip} size="small" variant="outlined" />)}</Box> },
    {
      field: 'os_type',
      headerName: 'OS',
      width: 120,
      renderCell: (params: any) => {
        const os = params.value || '';
        const isAix = os.toUpperCase() === "AIX";
        const { bgColor, textColor } = getPastelColorOS(os);

        return (
          <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 1 }}>
            <Chip
              label={os}
              size="small"
              sx={{
                backgroundColor: bgColor,
                color: textColor,
                fontWeight: 600,
                fontSize: '0.75rem',
                '& .MuiChip-label': {
                  padding: '0 8px',
                },
                border: isAix ? '2px solid #FFB300' : 'none',
              }}
            />
          </Box>
        );
      },
    },
    { field: 'environments', headerName: 'Env', width: 140, renderCell: (p: any) => <Box sx={{ display: 'flex', justifyContent: 'center', gap: 0.5, flexWrap: 'wrap' }}>{p.value.map((e: string) => <Chip key={e} label={e} size="small" variant="outlined" />)}</Box> },
    {
      field: 'phase',
      headerName: 'Phase',
      width: 380,
      renderCell: (p: any) => {
        const server = p.row as ServerToDecom;

        // Récupérer la phase suivante
        const nextPhase = getNextPhase(server);

        // Phase actuelle (pour le logique conditionnelle)
        const currentPhase = server.phase || server.circuit_data?.phase || "";

        // Date d'arrêt : d'abord à la racine, sinon dans circuit_data
        const shutdownAt = server.shutdown_at || server.circuit_data?.shutdown_at;
        const shutdownDateStr = shutdownAt
          ? new Date(shutdownAt).toLocaleDateString('fr-FR', {
            day: '2-digit',
            month: 'short',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
          })
          : null;

        // === CAS SPÉCIAL : Serveur déjà éteint → affichage dédié avec date ===
        if (currentPhase === DecomPhase.SHUTDOWN && shutdownDateStr) {
          return (
            <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', py: 1 }}>
              <Chip
                label="Éteint"
                size="small"
                sx={{
                  bgcolor: '#FEE2E2',
                  color: '#991B1B',
                  border: '1px solid #FCA5A5',
                  fontWeight: 700,
                  fontSize: '0.875rem',
                  mb: 0.5
                }}
              />
              <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.75rem' }}>
                Le {shutdownDateStr}
              </Typography>
            </Box>
          );
        }

        // === CAS SPÉCIAL : Décommissionné ===
        if (currentPhase === DecomPhase.DECOM) {
          return (
            <Box sx={{ textAlign: 'center' }}>
              <Chip
                label="Décommissionné"
                size="small"
                sx={{
                  bgcolor: '#FCE7F3',
                  color: '#EC4899',   
                  border: '1px solid #EC4899',
                  fontWeight: 700,
                  minWidth: 140
                }}
              />
            </Box>
          );
        }

        // === CAS SPÉCIAL : Rejeté ===
        if (currentPhase === DecomPhase.REFUSED_TAM || currentPhase === DecomPhase.REFUSED_FCT) {
          const rejectedBy = currentPhase === DecomPhase.REFUSED_TAM ? "TAM" : "Responsable fonctionnel";
          return (
            <Box sx={{ textAlign: 'center' }}>
              <Chip
                label={`Rejeté par ${rejectedBy}`}
                size="small"
                sx={{
                  bgcolor: '#F3F4F6',
                  color: '#4B5563',
                  border: '1px solid #D1D5DB',
                  fontWeight: 600,
                  minWidth: 140
                }}
              />
            </Box>
          );
        }

        // === PHASE SUIVANTE NORMALE ===
        const getPhaseColor = (phase: string) => {
          if (phase.includes("validation par le TAM"))
            // BLEU pour "En attente de validation par le TAM"
            return { bg: '#E0E7FF', text: '#4338CA', border: '#A5B4FC' };
          if (phase.includes("validation fonctionnelle"))
            return { bg: '#FEF3C7', text: '#92400E', border: '#FCD34D' };
          if (phase.includes("arrêt du serveur"))
            return { bg: '#E0E7FF', text: '#4338CA', border: '#A5B4FC' };
          if (phase === "Éteint")
            return { bg: '#FEE2E2', text: '#991B1B', border: '#FCA5A5' };
          if (phase === "Décommissionné")
            return { bg: '#DCFCE7', text: '#166534', border: '#86EFAC' };
          return { bg: '#E0E7FF', text: '#4338CA', border: '#A5B4FC' };
        };

        const { bg, text, border } = getPhaseColor(nextPhase);

        return (
          <Box sx={{ textAlign: 'center' }}>
            <Chip
              label={nextPhase}
              size="small"
              sx={{
                bgcolor: bg,
                color: text,
                border: `1px solid ${border}`,
                fontWeight: 600,
                minWidth: 180
              }}
            />
          </Box>
        );
      },
    },
    {
      field: 'countdown',
      headerName: 'Compteur',
      width: 200,
      align: 'center',
      headerAlign: 'center',
      sortable: true,
      // Cette fonction retourne une valeur numérique pour le tri
      valueGetter: (_, row) => {
        const server = row as ServerToDecom;
        const shutdownAt = server.shutdown_at || server.circuit_data?.shutdown_at;
        
        if (!shutdownAt) return Infinity; // Pas encore éteint → en bas
        
        const shutdownDate = new Date(shutdownAt);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        shutdownDate.setHours(0, 0, 0, 0);
        
        const diffTime = today.getTime() - shutdownDate.getTime();
        return Math.floor(diffTime / (1000 * 60 * 60 * 24));
      },
      renderCell: (params: any) => {
        const server = params.row as ServerToDecom;
        const shutdownAt = server.shutdown_at || server.circuit_data?.shutdown_at;
    
        // Pas de date d'arrêt → rien à afficher
        if (!shutdownAt) {
          return <Typography variant="caption" color="text.secondary">-</Typography>;
        }
    
        const shutdownDate = new Date(shutdownAt);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        shutdownDate.setHours(0, 0, 0, 0);
    
        const diffTime = today.getTime() - shutdownDate.getTime();
        const daysSinceShutdown = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
        // Formatage de la date
        const formatted = shutdownDate.toLocaleDateString('fr-FR', {
          day: '2-digit',
          month: 'short',
          year: 'numeric'
        });
    
        // Cas 1 : Éteint depuis 30 jours ou plus → "Dépassé"
        if (daysSinceShutdown >= 30) {
          return (
            <Box sx={{ textAlign: 'center', lineHeight: 1.4 }}>
              <Chip
                label="Dépassé"
                size="small"
                color="error"
                sx={{
                  bgcolor: '#FECACA',
                  color: '#991B1B',
                  fontWeight: 700,
                  fontSize: '0.8rem'
                }}
              />
              <Typography variant="caption" color="error" sx={{ display: 'block', mt: 0.5, fontSize: '0.75rem' }}>
                {formatted}
              </Typography>
            </Box>
          );
        }
    
        // Cas 2 : Éteint depuis moins de 30 jours → "Éteint il y a X jours"
        if (daysSinceShutdown > 0) {
          const label = daysSinceShutdown === 1
            ? "Éteint hier"
            : `Éteint il y a ${daysSinceShutdown} jours`;
    
          return (
            <Box sx={{ textAlign: 'center' }}>
              <Chip
                label={daysSinceShutdown === 1 ? "Hier" : `${daysSinceShutdown}j`}
                size="small"
                sx={{
                  bgcolor: '#FEE2E2',
                  color: '#991B1B',
                  fontWeight: 700,
                  minWidth: 48
                }}
              />
              <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.75rem', mt: 0.5 }}>
                {label}
              </Typography>
              <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.7rem' }}>
                {formatted}
              </Typography>
            </Box>
          );
        }
    
        // Cas 3 : Éteint aujourd'hui
        if (daysSinceShutdown === 0) {
          return (
            <Box sx={{ textAlign: 'center' }}>
              <Chip
                label="Aujourd'hui"
                size="small"
                color="error"
                sx={{
                  bgcolor: '#FECACA',
                  fontWeight: 800,
                  minWidth: 70
                }}
              />
              <Typography variant="caption" color="error" sx={{ fontSize: '0.75rem', mt: 0.5 }}>
                Éteint aujourd'hui
              </Typography>
            </Box>
          );
        }
    
        // Si jamais dans le futur (ne devrait pas arriver ici)
        return <Typography variant="caption" color="text.secondary">-</Typography>;
      },
    }
  ], [selectedServers, servers]);

  if (loading) {
    return (
      <ThemeProvider theme={modernTheme}>
        <Box sx={{ display: 'flex', justifyContent: 'center', my: 8 }}>
          <CircularProgress />
        </Box>
      </ThemeProvider>
    );
  }

  return (
    <ThemeProvider theme={modernTheme}>
      <Fade in timeout={600}>
        <Box sx={{ p: 3, maxWidth: 16000, mx: 'auto' }}>
          <Paper sx={{ p: 3, mb: 3, borderRadius: 3, background: 'linear-gradient(135deg, #6366F1 0%, #8B5CF6 100%)', color: 'white' }}>
            <Box display="flex" justifyContent="space-between" alignItems="center">
              <Box>
                <Typography variant="h4" sx={{ fontWeight: 700, mb: 1 }}>
                  Serveurs à Décommissionner
                </Typography>

                <Typography variant="body2" sx={{ opacity: 0.9 }}>
                  {filteredServers.length} serveur(s) • {selectedServers.length} sélectionné(s)
                </Typography>
              </Box>
              <Stack direction="row" spacing={1}>
                {selectedServers.some(id => {
                  const s = servers.find(x => x.id === id)!;
                  const phase = s.phase || s.circuit_data?.phase;
                  const { showTAMButton } = getPhaseStatus(phase, s);
                  return showTAMButton;
                }) && (
                    <Button variant="contained" onClick={() => setValidationDialogOpen(true)}>
                      TAM ({selectedServers.filter(id => {
                        const s = servers.find(x => x.id === id)!;
                        const phase = s.phase || s.circuit_data?.phase;
                        const { showTAMButton } = getPhaseStatus(phase, s);
                        return showTAMButton;
                      }).length})
                    </Button>
                  )}
                {selectedServers.some(id => {
                  const s = servers.find(x => x.id === id)!;
                  const phase = s.phase || s.circuit_data?.phase;
                  const { showFCTButton, shouldShowFCTValidation } = getPhaseStatus(phase, s);
                  // IMPORTANT: Ne montrer que si shouldShowFCTValidation est true
                  return showFCTButton && shouldShowFCTValidation;
                }) && (
                    <Button variant="contained" color="warning" onClick={() => setFunctionalDialogOpen(true)}>
                      FCT ({selectedServers.filter(id => {
                        const s = servers.find(x => x.id === id)!;
                        const phase = s.phase || s.circuit_data?.phase;
                        const { showFCTButton, shouldShowFCTValidation } = getPhaseStatus(phase, s);
                        return showFCTButton && shouldShowFCTValidation;
                      }).length})
                    </Button>
                  )}
              </Stack>
            </Box>
          </Paper>

          <Paper sx={{ p: 2, mb: 3, borderRadius: 3 }}>
            <Stack direction={{ xs: 'column', md: 'row' }} spacing={2} alignItems="center">
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <FilterListIcon sx={{ mr: 1, color: '#6366F1' }} />
                <ToggleButtonGroup value={filter} exclusive onChange={(_, v) => v && setFilter(v)}>
                  <ToggleButton value="all">Tous</ToggleButton>
                  <ToggleButton value="tam">À moi (TAM)</ToggleButton>
                  <ToggleButton value="functional">À moi (FCT)</ToggleButton>
                </ToggleButtonGroup>
              </Box>
              <TextField
                placeholder="Recherche globale ..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon />
                    </InputAdornment>
                  ),
                }}
                sx={{ minWidth: 400 }} // un peu plus large pour le texte
              />
            </Stack>
          </Paper>

          {error && <Alert severity="error" sx={{ mb: 3 }}>{error}</Alert>}
          {validationResult && (
            <Alert severity={validationResult.success ? "success" : "error"} onClose={() => setValidationResult(null)} sx={{ mb: 3 }}>
              {validationResult.message}
            </Alert>
          )}

          <Paper sx={{ borderRadius: 3, overflow: 'hidden' }}>
            <DataGrid
              rows={filteredServers}
              columns={columns}
              getRowId={r => r.id}
              pageSizeOptions={[10, 25, 50]}
              initialState={{ pagination: { paginationModel: { pageSize: 25 } } }}
              onPaginationModelChange={() => {
                setSelectedServers([]);
              }}
              sx={{
                minHeight: 600,
                '& .MuiDataGrid-cell': {
                  justifyContent: 'flex-start',
                  paddingLeft: 2,
                },
                '& .MuiDataGrid-columnHeader': {
                  justifyContent: 'flex-start',
                  paddingLeft: 2,
                },
              }}
            />
          </Paper>

          {/* === MODAL TAM – AVEC LISTES === */}
          <Dialog open={validationDialogOpen} onClose={() => setValidationDialogOpen(false)} maxWidth="md" fullWidth>
            <DialogTitle sx={{ background: 'linear-gradient(135deg, #6366F1 0%, #8B5CF6 100%)', color: 'white', py: 3 }}>
              <Typography variant="h6" fontWeight={700}>Validation TAM</Typography>
              <IconButton onClick={() => setValidationDialogOpen(false)} sx={{ position: 'absolute', right: 16, top: 16, color: 'white' }}>
                <CloseIcon />
              </IconButton>
            </DialogTitle>
            <DialogContent dividers sx={{ p: 3 }}>
              <Stack spacing={3}>
                {selectedServers.filter(id => canUserManageAsTAM(servers.find(s => s.id === id)!)).map(id => {
                  const s = servers.find(x => x.id === id)!;
                  const errorMsg = validationErrors[id];
                  const suggestions = ipSuggestions[id] || [];
                  const hasSuggestions = suggestions.length > 0;

                  return (
                    <Paper key={id} elevation={3} sx={{ p: 3, borderRadius: 3, border: '1px solid #E5E7EB', mb: 3 }}>
                      <Typography fontWeight={600} gutterBottom textAlign="center">
                        {s.hostname}
                      </Typography>

                      <Box sx={{ mb: 1, textAlign: 'center' }}>
                        <Typography variant="caption" color="text.secondary">
                          IP déclarée : {s.ip_addresses.join(', ') || 'Aucune'}
                        </Typography>
                      </Box>

                      {errorMsg && (
                        <Alert severity={hasSuggestions ? "warning" : "error"} sx={{ mb: 2 }}>
                          {errorMsg}
                        </Alert>
                      )}

                      {/* === AFFICHAGE DES SPECS === */}
                      {s.specs ? (
                        <Box sx={{ mt: 2, mb: 3 }}>
                          <Typography variant="subtitle2" fontWeight={600} gutterBottom>
                            Spécifications techniques {s.os_type.toLowerCase() === 'aix' && '(AIX)'}
                          </Typography>
                          <Paper
                            variant="outlined"
                            sx={{
                              p: 2,
                              mb: 2,
                              bgcolor: s.os_type.toLowerCase() === 'aix' ? '#FFF8E1' : '#ECFDF5',
                              border: s.os_type.toLowerCase() === 'aix' ? '1px solid #F59E0B' : '1px solid #10B981',
                            }}
                          >
                            {s.os_type.toLowerCase() === 'aix' ? (
                              // Format AIX spécifique selon les données reçues
                              <Grid container spacing={1} sx={{ fontSize: '0.875rem' }}>
                                {s.specs.cpu && typeof s.specs.cpu === 'object' ? (
                                  <Grid item xs={6}>
                                    <strong>CPU:</strong>
                                    <Box sx={{ mt: 0.5 }}>
                                      {s.specs.cpu.limit && (
                                        <div><strong>Limit:</strong> {s.specs.cpu.limit}</div>
                                      )}
                                      {s.specs.cpu.request && (
                                        <div><strong>Request:</strong> {s.specs.cpu.request}</div>
                                      )}
                                    </Box>
                                  </Grid>
                                ) : s.specs.cpu ? (
                                  <Grid item xs={6}>
                                    <strong>CPU:</strong> {s.specs.cpu} {typeof s.specs.cpu === 'number' ? 'cœurs' : ''}
                                  </Grid>
                                ) : null}

                                {s.specs.HMC_SOURCE && (
                                  <Grid item xs={6}><strong>Source HMC:</strong> {s.specs.HMC_SOURCE}</Grid>
                                )}

                                {s.specs.vmware_source && (
                                  <Grid item xs={6}><strong>Source VMware:</strong> {s.specs.vmware_source}</Grid>
                                )}

                                {s.specs.vmware_id && (
                                  <Grid item xs={6}><strong>VMware ID:</strong> {s.specs.vmware_id}</Grid>
                                )}

                                {s.specs.vmware_name && (
                                  <Grid item xs={6}><strong>Nom VMware:</strong> {s.specs.vmware_name}</Grid>
                                )}
                              </Grid>
                            ) : (
                              // Format standard pour les autres OS
                              <Grid container spacing={1} sx={{ fontSize: '0.875rem' }}>
                                {s.specs.cpu && typeof s.specs.cpu === 'object' && s.specs.cpu.count && (
                                  <Grid item xs={6}><strong>CPU:</strong> {s.specs.cpu.count} cœurs</Grid>
                                )}

                                {s.specs.cpu && typeof s.specs.cpu === 'object' && s.specs.cpu.cores_per_socket && (
                                  <Grid item xs={6}><strong>Cœurs/socket:</strong> {s.specs.cpu.cores_per_socket}</Grid>
                                )}

                                {s.specs.memory && typeof s.specs.memory === 'object' && s.specs.memory.size_MiB && (
                                  <Grid item xs={6}>
                                    <strong>Mémoire:</strong> {Math.round(s.specs.memory.size_MiB / 1024)} Go
                                  </Grid>
                                )}

                                {s.specs.storage && (
                                  <Grid item xs={6}><strong>Stockage:</strong> {Math.round(s.specs.storage / (1024 ** 3))} Go</Grid>
                                )}

                                {s.specs.vmware_id && (
                                  <Grid item xs={6}><strong>VMware ID:</strong> {s.specs.vmware_id}</Grid>
                                )}

                                {s.specs.vmware_source && (
                                  <Grid item xs={6}><strong>Source VMware:</strong> {s.specs.vmware_source}</Grid>
                                )}

                                {s.specs.cpu && typeof s.specs.cpu === 'object' && (
                                  <Grid item xs={6}>
                                    <strong>Hot Add CPU:</strong> {s.specs.cpu.hot_add_enabled ? "✅ Activé" : "❌ Désactivé"}
                                  </Grid>
                                )}

                                {s.specs.memory && typeof s.specs.memory === 'object' && (
                                  <Grid item xs={6}>
                                    <strong>Hot Add Mémoire:</strong> {s.specs.memory.hot_add_enabled ? "✅ Activé" : "❌ Désactivé"}
                                  </Grid>
                                )}

                                {s.specs.disks && s.specs.disks.length > 0 && (
                                  <Grid item xs={12}>
                                    <strong>Disques:</strong>
                                    <Box sx={{ mt: 1, display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                                      {s.specs.disks.map((disk: any, idx: number) => (
                                        <Chip
                                          key={idx}
                                          label={`${disk.label}: ${Math.round(disk.capacity / (1024 ** 3))} GB`}
                                          size="small"
                                          variant="outlined"
                                        />
                                      ))}
                                    </Box>
                                  </Grid>
                                )}
                              </Grid>
                            )}
                          </Paper>
                        </Box>
                      ) : (
                        <Alert severity="warning" sx={{ mt: 2, mb: 2 }}>
                          Aucune donnée technique disponible pour ce serveur
                        </Alert>
                      )}

                      {/* === SÉLECTION D'IP SI NÉCESSAIRE === */}
                      {hasSuggestions && (
                        <TextField
                          select
                          fullWidth
                          label="Choisir l'IP correcte"
                          value={selectedIpEntry[id]?.id || ''}
                          onChange={e => {
                            const selectedId = Number(e.target.value);
                            const suggestion = suggestions.find(s => s.id === selectedId);
                            if (suggestion) {
                              setSelectedIpEntry(p => ({
                                ...p,
                                [id]: { id: suggestion.id, id_source: suggestion.id_source }
                              }));
                            }
                          }}
                          size="small"
                          SelectProps={{ native: true }}
                          sx={{ mb: 2 }}
                        >
                          <option value="">-- Sélectionner une IP --</option>
                          {suggestions.map(sugg => (
                            <option key={sugg.id} value={sugg.id}>
                              {sugg.ip} (ID BigFix: {sugg.id_source})
                            </option>
                          ))}
                        </TextField>
                      )}

                      {/* === BOUTONS ACCEPTER / REFUSER === */}
                      <RadioGroup
                        value={tamActions[id] || 'accept'}
                        onChange={e => setTamActions(p => ({ ...p, [id]: e.target.value as 'accept' | 'refuse' }))}
                        sx={{ justifyContent: 'center', display: 'flex', flexDirection: 'row', mt: 2 }}
                      >
                        <FormControlLabel
                          value="accept"
                          control={<Radio color="success" />}
                          label={<Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}><CheckCircleIcon color="success" /> Accepter</Box>}
                        />
                        <FormControlLabel
                          value="refuse"
                          control={<Radio color="error" />}
                          label={<Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}><CancelIcon color="error" /> Refuser</Box>}
                        />
                      </RadioGroup>

                      {tamActions[id] === 'accept' && (
                        <>
                          {/* Confirmation hostname */}
                          <TextField
                            fullWidth
                            label={`Confirmez le hostname "${s.hostname}"`}
                            placeholder={s.hostname}
                            value={confirmHostnames[id] || ''}
                            onChange={e => setConfirmHostnames(p => ({ ...p, [id]: e.target.value }))}
                            size="small"
                            sx={{ mt: 2 }}
                            error={confirmHostnames[id] !== undefined && confirmHostnames[id].toLowerCase() !== s.hostname.toLowerCase()}
                            helperText={confirmHostnames[id] !== undefined && confirmHostnames[id].toLowerCase() !== s.hostname.toLowerCase() ? "Hostname incorrect" : ""}
                          />

                          {/* Validation FCT nécessaire */}
                          <Box sx={{ mt: 2, display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 1 }}>
                            <Checkbox
                              checked={functionalNeeded[id] || false}
                              onChange={e => setFunctionalNeeded(p => ({ ...p, [id]: e.target.checked }))}
                            />
                            <Typography variant="body2">
                              Validation par l'admin fonctionnel nécessaire
                            </Typography>
                          </Box>
                        </>
                      )}
                    </Paper>
                  );
                })}
              </Stack>
            </DialogContent>
            <DialogActions sx={{ p: 3, bgcolor: '#F8FAFC', justifyContent: 'center' }}>
              <Button onClick={handleTAMValidation} variant="contained" disabled={!allConfirmed || validationLoading}>
                {validationLoading ? 'Envoi...' : 'Confirmer'}
              </Button>
            </DialogActions>
          </Dialog>

          {/* === MODAL FCT === */}
          <Dialog open={functionalDialogOpen} onClose={() => setFunctionalDialogOpen(false)} maxWidth="md" fullWidth>
            <DialogTitle sx={{ bgcolor: '#F59E0B', color: 'white', py: 3 }}>
              <Typography variant="h6" fontWeight={700}>Validation Fonctionnelle</Typography>
              <IconButton onClick={() => setFunctionalDialogOpen(false)} sx={{ position: 'absolute', right: 16, top: 16, color: 'white' }}>
                <CloseIcon />
              </IconButton>
            </DialogTitle>
            <DialogContent dividers sx={{ p: 3 }}>
              <Stack spacing={3}>
                {selectedServers.filter(id => canUserManageAsFunctional(servers.find(s => s.id === id)!)).map(id => {
                  const s = servers.find(x => x.id === id)!;

                  return (
                    <Paper key={id} elevation={3} sx={{ p: 3, borderRadius: 3, border: '1px solid #E5E7EB' }}>
                      <Typography fontWeight={600} gutterBottom textAlign="center">
                        {s.hostname}
                      </Typography>

                      <Box sx={{ mb: 1, textAlign: 'center' }}>
                        <Typography variant="caption" color="text.secondary">
                          IP : {s.ip_addresses.join(', ')}
                        </Typography>
                      </Box>

                      {/* === AFFICHAGE DES SPECS === */}
                      {s.specs && (
                        <Box sx={{ mt: 2, mb: 3 }}>
                          <Typography variant="subtitle2" fontWeight={600} gutterBottom>
                            Spécifications techniques
                          </Typography>
                          <Paper
                            variant="outlined"
                            sx={{
                              p: 2,
                              mb: 2,
                              bgcolor: '#ECFDF5',
                              border: '1px solid #10B981',
                            }}
                          >
                            <Grid container spacing={1} sx={{ fontSize: '0.875rem' }}>
                              <Grid item xs={6}><strong>CPU:</strong> {s.specs.cpu.count} cœurs</Grid>
                              <Grid item xs={6}><strong>Cœurs/socket:</strong> {s.specs.cpu.cores_per_socket}</Grid>
                              <Grid item xs={6}><strong>Mémoire:</strong> {Math.round(s.specs.memory.size_MiB / 1024)} Go</Grid>
                              <Grid item xs={6}><strong>Stockage:</strong> {Math.round(s.specs.storage / (1024 ** 3))} Go</Grid>
                              <Grid item xs={6}><strong>VMware ID:</strong> {s.specs.vmware_id}</Grid>
                              <Grid item xs={6}><strong>Source VMware:</strong> {s.specs.vmware_source}</Grid>
                            </Grid>
                          </Paper>
                        </Box>
                      )}

                      <RadioGroup
                        value={fctActions[id] || 'accept'}
                        onChange={e => setFctActions(p => ({ ...p, [id]: e.target.value as 'accept' | 'refuse' }))}
                        sx={{ justifyContent: 'center', display: 'flex', flexDirection: 'row', mt: 2 }}
                      >
                        <FormControlLabel value="accept" control={<Radio color="success" />} label="Accepter" />
                        <FormControlLabel value="refuse" control={<Radio color="error" />} label="Refuser" />
                      </RadioGroup>
                    </Paper>
                  );
                })}
              </Stack>
            </DialogContent>
            <DialogActions sx={{ p: 3, bgcolor: '#F8FAFC', justifyContent: 'center' }}>
              <Button onClick={handleFCTValidation} variant="contained" color="warning" disabled={functionalLoading}>
                {functionalLoading ? 'Envoi...' : 'Confirmer'}
              </Button>
            </DialogActions>
          </Dialog>

          {/* === TIMELINE MODAL === */}
          <Dialog open={timelineModalOpen} onClose={() => setTimelineModalOpen(false)} maxWidth="md" fullWidth>
            <DialogTitle sx={{ background: 'linear-gradient(135deg, #6366F1 0%, #8B5CF6 100%)', color: 'white', py: 3 }}>
              <Typography variant="h6" fontWeight={700}>Workflow de décommissionnement</Typography>
              <IconButton onClick={() => setTimelineModalOpen(false)} sx={{ position: 'absolute', right: 16, top: 16, color: 'white' }}>
                <CloseIcon />
              </IconButton>
            </DialogTitle>
            <DialogContent sx={{ p: 3, bgcolor: '#F8FAFC' }}>
              <DecomTimeline server={selectedServer} />
            </DialogContent>
          </Dialog>

          {selectedServer && (
            <ServerDetailsModal
              open={detailsModalOpen}
              onClose={() => setDetailsModalOpen(false)}
              serverData={selectedServer}
              rowData={transformServerToRowData(selectedServer)}
            />
          )}
        </Box>
      </Fade>
    </ThemeProvider>
  );
}