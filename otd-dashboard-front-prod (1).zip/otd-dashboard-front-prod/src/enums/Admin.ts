// src/types/enums/Admin.ts

export enum Admin {
  Entity = "entités",
  Pôle = "pôles",
  Domaine = "domaines",
  Solution = "solutions",
  Rôle = "rôles",
  Person = "personnes",
  DomainNameExterne = "Nom domaine externe",
}
