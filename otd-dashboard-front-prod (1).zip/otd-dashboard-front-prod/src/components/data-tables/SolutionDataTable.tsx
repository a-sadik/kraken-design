import { useEffect, useMemo, useState } from "react";
import { Box, Button, Typography, Switch } from "@mui/material";
import {
  useMaterialReactTable,
  MRT_ColumnDef,
  MRT_GlobalFilterTextField,
  MRT_ShowHideColumnsButton,
  MRT_ToggleFiltersButton,
  MRT_TableContainer,
  MRT_TablePagination,
} from "material-react-table";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import AdminPanelSettingsIcon from "@mui/icons-material/AdminPanelSettings";
import { useNavigate } from "react-router-dom";

import WidgetMainContainer from "../containers/WidgetMainContainer";
import { getAllSolutions } from "@/services/SolutionService";
import { SolutionDetailResponseDTO } from "@/types/dto/response/solution/SolutionDetailResponseDTO";
import { solutionResToView } from "@/mappers/SolutionMapper";
import SolutionView from "@/types/view/SolutionView";
import { getCssVariableValue } from "@/utils/getDynamicColor";
import CustomLoading from "../basics/CustomLoading";
import CustomBadge from "../basics/CustomBadge";
import CustomTooltip from "../basics/CustomToolTip";

export default function SolutionDataTable() {
  const [solutions, setSolutions] = useState<SolutionView[]>([]);
  const [loading, setLoading] = useState(false);
  const [isProduction, setIsProduction] = useState(false);
  const [isHorsProduction, setIsHorsProduction] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const data: SolutionDetailResponseDTO[] = await getAllSolutions();
        setSolutions(solutionResToView(data));
      } catch (error) {
        console.error("Erreur lors de la récupération des données:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const filteredSolutions = useMemo(() => {
    return solutions.filter((sol) => {
      if (isProduction) return sol["Type"] === "Production";
      if (isHorsProduction) return sol["Type"] !== "Production";
      return true;
    });
  }, [solutions, isProduction, isHorsProduction]);

  const columns = useMemo<MRT_ColumnDef<SolutionView>[]>(() => {
    if (solutions.length === 0) return [];

    return Object.keys(solutions[0])
      .filter(
        (key) =>
          !["id", "solution_id", "server_id", "os_id", "os"].includes(key),
      )
      .map((key) => ({
        accessorKey: key,
        header: key.toUpperCase(),
        Cell: ({ cell }) => {
          const value = cell.getValue<any>();
          if (value === null || value === undefined || value === "-") {
            return (
              <Typography fontSize="1rem" fontWeight="">
                -
              </Typography>
            );
          }

          if (typeof value === "object" && !Array.isArray(value)) {
            return (
              <CustomTooltip title={JSON.stringify(value, null, 2)}>
                <Typography fontSize="0.9" fontWeight="">
                  {Object.values(value).join(", ")}
                </Typography>
              </CustomTooltip>
            );
          }

          if (Array.isArray(value)) {
            return (
              <Box display="flex" gap={1} flexWrap="wrap">
                {value.map((item, idx) => (
                  <CustomBadge key={idx} text={item} />
                ))}
              </Box>
            );
          }

          return (
            <CustomTooltip title={value}>
              <Typography fontSize="0.9" fontWeight="">
                {value}
              </Typography>
            </CustomTooltip>
          );
        },
      }));
  }, [solutions]);

  const table = useMaterialReactTable({
    columns,
    data: filteredSolutions,
    state: { isLoading: loading },
    initialState: { showGlobalFilter: true },
    enableColumnOrdering: true,
    enableColumnFilters: true,
    enableDensityToggle: true,
  });

  const primaryColor = getCssVariableValue("--primary-color");
  const theme = createTheme({
    palette: {
      primary: { main: primaryColor },
    },
  });

  if (loading) return <CustomLoading />;

  return (
    <ThemeProvider theme={theme}>
      <Box>
        <Box
          display="flex"
          justifyContent="space-between"
          alignItems="center"
          mb={3}
        >
          <Typography
            variant="h4"
            fontWeight="bold"
            className="data-table-title"
          >
            Liste des solutions
          </Typography>
          <Button
            variant="contained"
            color="primary"
            startIcon={<AdminPanelSettingsIcon />}
            onClick={() => navigate("/auditadmin/admin")}
          >
            <Typography className="text-button-add" variant="h6">
              Admin
            </Typography>
          </Button>
        </Box>

        <WidgetMainContainer sx={{ borderColor: "--primary-color" }}>
          <Box
            sx={{
              display: "flex",
              flexWrap: "wrap",
              gap: 2,
              alignItems: "center",
              justifyContent: "space-between",
              mb: 2,
            }}
          >
            <Box display="flex" alignItems="center" gap={1}>
              <MRT_ShowHideColumnsButton
                table={table}
                sx={{ color: primaryColor }}
              />
              <Typography variant="body2" sx={{ color: primaryColor }}>
                Colonnes
              </Typography>
            </Box>
            <Box display="flex" alignItems="center" gap={1}>
              <MRT_ToggleFiltersButton
                table={table}
                sx={{ color: primaryColor }}
              />
              <Typography variant="body2" sx={{ color: primaryColor }}>
                Filtres
              </Typography>
            </Box>
            <Box display="flex" alignItems="center" gap={1}>
              <Switch
                size="small"
                color="primary"
                checked={isProduction}
                onChange={(e) => {
                  setIsProduction(e.target.checked);
                  setIsHorsProduction(false);
                }}
              />
              <Typography variant="body2" sx={{ color: primaryColor }}>
                Production
              </Typography>
            </Box>
            <Box display="flex" alignItems="center" gap={1}>
              <Switch
                size="small"
                color="primary"
                checked={isHorsProduction}
                onChange={(e) => {
                  setIsHorsProduction(e.target.checked);
                  setIsProduction(false);
                }}
              />
              <Typography variant="body2" sx={{ color: primaryColor }}>
                Hors Production
              </Typography>
            </Box>
            <MRT_GlobalFilterTextField table={table} />
          </Box>

          <MRT_TableContainer table={table} />
          <Box display="flex" justifyContent="flex-end" mt={2}>
            <MRT_TablePagination table={table} />
          </Box>
        </WidgetMainContainer>
      </Box>
    </ThemeProvider>
  );
}
