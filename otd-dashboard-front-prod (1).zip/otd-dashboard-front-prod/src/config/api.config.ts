export const API_CONFIG = {
  RELIABILITY_URL: `${import.meta.env.VITE_PREFIX_RELIABILITY_PATH}:${
    import.meta.env.VITE_RELIABILITY_SERVER_PORT
  }`,
  RELIABILITY_API_VERSION: import.meta.env.VITE_SUFFIX_RELIABILITY_PATH,

  DATA_URL: `${import.meta.env.VITE_PREFIX_DATA_PATH}:${
    import.meta.env.VITE_DATA_SERVER_PORT
  }`,
  DATA_API_VERSION: import.meta.env.VITE_SUFFIX_DATA_PATH,
  N8N_URL:import.meta.env.VITE_BIGFIX_API_URL
};

export const getCoreROOTApiUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}`;
};

export const getServersApiUrl = (endpoint: string): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/servers/${endpoint}`;
};

export const getFieldsApiUrl = (endpoint: string): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/options/${endpoint}`;
};

export const patchUpdateSolutionServerApiUrl = (): string => {
  return `${API_CONFIG.DATA_URL}/${API_CONFIG.DATA_API_VERSION}/solutions-servers/`;
};

export const postRefreshReliabilityApiUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/refresh/`;
};

export const getSignatureListApiUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/servers/signature-status/`;
};

export const postDeploySignatureApiUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/deploy_signature/`;
};

export const getTopologyRootApiUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/openshift-tree/entities/`;
};

export const getAitaStatsUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/openshift-tree/entities/45/poles/`;
};

export const getAitaStatsNamespacesUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/openshift-tree/solutions`;
};
export const getAitaStatsentiteUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/metrics/aita/`;
};

export const postDeployMultipleSignatureApiUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/deploy_signatures/`;
};

export const postExportSignatureApiUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/export_signatures/`;
};

export const getSolutionsApiUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/openshift-tree/solutions/`;
};

export const getAdminSolutionsApiUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/admin/solutions/`;
};

export const getAllTopology = (type: string): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/openshift-tree/${type}`;
};

export const getNamespacesApiUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/namespaces/`;
};

export const getPodsbyNamespacesApiUrl = (namespaceId: number): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/namespace/${namespaceId}/pods`;
};

export const postAffechtNamespacesToSolutionsApiUrl = (
  namespaceId: number,
): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/namespace/${namespaceId}/affect/`;
};
export const postMachinesUrl = (): string => {
  return `${API_CONFIG.DATA_URL}/${API_CONFIG.DATA_API_VERSION}/machines`;
};

export const getMachinesUrl = (): string => {
  return `${API_CONFIG.DATA_URL}/${API_CONFIG.DATA_API_VERSION}/machines`;
};

export const getKrakenCORE_BaseUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}`;
};

export const getAdminCRUD_BaseUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/admin`;
};
export const Post_Correct_IP = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/servers/correct`;
};
export const getNatures_BaseUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/servers/natures`;
};
export const getMyViewApiUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/my-view/`;
};
export const getMyView_Documents_ApiUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/my-view/dat/versions/`;
};
export const getConflit_Ip = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/servers/ip_conflict/`;
};
export const getSolutions_Inventory = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/admin/solutions`;
};
export const getNatures_Inventory = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/servers/natures`;
};
export const export_AllServers = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/servers/export`;
};
export const export_IsolatedServers = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/servers/isolated/optimized/`;
};
export const Servers_To_Decom = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/servers/servers-to-decom/`;
};
export const Post_Decom = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/servers/decom/`;
};
export const Post_Manage_Decom = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/servers/decom/manage/tam/`;
};
export const export_InventoryServers = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/servers/inventorize/`;
};
export const Server_Stats = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/metrics/`;
};
export const DECOM_ENDPOINT = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/servers`;
};
export const Server_StatsRefresh = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/refresh-stats/`;
};

export const getServerById = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/servers/details`;
};

export const GetAudit_BaseURL = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/auditing/`;
};

export const DeleteServerApiURL = (server_id: number): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/admin/servers/${server_id}`;
};

export const getTeams_BaseUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/certificates/team/`;
};

export const CRONJOBS_BaseUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/scheduler/jobs/`;
};
export const Communications_URL = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/communication/announcements/`;
};

export const Documentation_App_URL = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/documentation/mdx-content/`;
};

export const getReleaseNotesApiUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/release/release-notes/`;
};



export const goToPathServer = (): string => {
  return `${API_CONFIG.DATA_URL}/signature-serveurs/`;
};

export const postBigFixDataApiUrl = () => `${API_CONFIG.N8N_URL}/webhook/bigfix-info/`;
export const postDecomApiUrl = () =>`${API_CONFIG.N8N_URL}/webhook/info-before-decom`;

export const hardware_info_power_info = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/power_info`;
};

export const hardware_info_x86_info = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/x86_info`;
};

export const hardware_info_openshift_info = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/openshift_info`;
};


// export const hardware_info_x86_info = () =>`${API_CONFIG.N8N_URL}/webhook/hardware_info`;
// export const hardware_info_openshift_info = () =>`${API_CONFIG.N8N_URL}/webhook/caas_info`;