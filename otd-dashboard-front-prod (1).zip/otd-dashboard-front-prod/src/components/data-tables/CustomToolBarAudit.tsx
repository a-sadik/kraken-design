// src/components/data-tables/CustomToolBarAudit.tsx

import { FC, useState } from "react";
import {
  GridToolbarContainer,
  GridToolbarColumnsButton,
  GridToolbarFilterButton,
  GridToolbarExport,
  GridToolbarQuickFilter,
  GridToolbarProps,
} from "@mui/x-data-grid";
import {
  Button,
  Menu,
  MenuItem,
  Checkbox,
  FormControlLabel,
  Box,
} from "@mui/material";
import FilterListIcon from "@mui/icons-material/FilterList";

// Interface for the component props extending GridToolbarProps
interface CustomToolBarAuditProps extends GridToolbarProps {
  // Operation status filters
  isSuccessOperation?: boolean;
  setIsSuccessOperation?: React.Dispatch<React.SetStateAction<boolean>>;
  isFailedOperation?: boolean;
  setIsFailedOperation?: React.Dispatch<React.SetStateAction<boolean>>;

  // Action type filters
  isCreateAction?: boolean;
  setIsCreateAction?: React.Dispatch<React.SetStateAction<boolean>>;
  isUpdateAction?: boolean;
  setIsUpdateAction?: React.Dispatch<React.SetStateAction<boolean>>;
  isDeleteAction?: boolean;
  setIsDeleteAction?: React.Dispatch<React.SetStateAction<boolean>>;
  isSignInAction?: boolean;
  setIsSignInAction?: React.Dispatch<React.SetStateAction<boolean>>;
  isSignOutAction?: boolean;
  setIsSignOutAction?: React.Dispatch<React.SetStateAction<boolean>>;
}

const CustomToolBarAudit: FC<CustomToolBarAuditProps> = ({
  // Operation status filters
  isSuccessOperation = true,
  setIsSuccessOperation,
  isFailedOperation = true,
  setIsFailedOperation,

  // Action type filters
  isCreateAction = true,
  setIsCreateAction,
  isUpdateAction = true,
  setIsUpdateAction,
  isDeleteAction = true,
  setIsDeleteAction,
  isSignInAction = true,
  setIsSignInAction,
  isSignOutAction = true,
  setIsSignOutAction,

  ...gridToolbarProps
}) => {
  // État pour gérer les menus déroulants
  const [statusAnchorEl, setStatusAnchorEl] = useState<null | HTMLElement>(
    null,
  );
  const [actionAnchorEl, setActionAnchorEl] = useState<null | HTMLElement>(
    null,
  );

  // Gestionnaires pour ouvrir/fermer les menus
  const handleStatusMenuOpen = (event: React.MouseEvent<HTMLElement>) => {
    setStatusAnchorEl(event.currentTarget);
  };

  const handleActionMenuOpen = (event: React.MouseEvent<HTMLElement>) => {
    setActionAnchorEl(event.currentTarget);
  };

  const handleStatusMenuClose = () => {
    setStatusAnchorEl(null);
  };

  const handleActionMenuClose = () => {
    setActionAnchorEl(null);
  };

  // Calculer le nombre de filtres actifs pour chaque catégorie
  const activeStatusFilters = [
    isSuccessOperation && setIsSuccessOperation,
    isFailedOperation && setIsFailedOperation,
  ].filter(Boolean).length;

  const activeActionFilters = [
    isCreateAction && setIsCreateAction,
    isUpdateAction && setIsUpdateAction,
    isDeleteAction && setIsDeleteAction,
    isSignInAction && setIsSignInAction,
    isSignOutAction && setIsSignOutAction,
  ].filter(Boolean).length;

  return (
    <GridToolbarContainer
      sx={{
        display: "flex",
        flexDirection: "row",
        justifyContent: "space-between",
        flexWrap: "wrap",
        gap: 1,
      }}
      {...gridToolbarProps}
    >
      <GridToolbarColumnsButton />
      <GridToolbarFilterButton />
      <GridToolbarExport />

      {/* Bouton de filtrage par Statut */}
      {(typeof setIsSuccessOperation === "function" ||
        typeof setIsFailedOperation === "function") && (
        <Box>
          <Button
            variant="outlined"
            startIcon={<FilterListIcon />}
            onClick={handleStatusMenuOpen}
            color="primary"
            size="small"
          >
            Statut {activeStatusFilters > 0 && `(${activeStatusFilters})`}
          </Button>
          <Menu
            anchorEl={statusAnchorEl}
            open={Boolean(statusAnchorEl)}
            onClose={handleStatusMenuClose}
          >
            {typeof isSuccessOperation === "boolean" &&
              typeof setIsSuccessOperation === "function" && (
                <MenuItem dense>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={isSuccessOperation}
                        onChange={() =>
                          setIsSuccessOperation(!isSuccessOperation)
                        }
                        color="success"
                      />
                    }
                    label="Réussie"
                  />
                </MenuItem>
              )}
            {typeof isFailedOperation === "boolean" &&
              typeof setIsFailedOperation === "function" && (
                <MenuItem dense>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={isFailedOperation}
                        onChange={() =>
                          setIsFailedOperation(!isFailedOperation)
                        }
                        color="error"
                      />
                    }
                    label="Échoué"
                  />
                </MenuItem>
              )}
          </Menu>
        </Box>
      )}

      {/* Bouton de filtrage par Type d'Action */}
      {(typeof setIsCreateAction === "function" ||
        typeof setIsUpdateAction === "function" ||
        typeof setIsDeleteAction === "function" ||
        typeof setIsSignInAction === "function" ||
        typeof setIsSignOutAction === "function") && (
        <Box>
          <Button
            variant="outlined"
            startIcon={<FilterListIcon />}
            onClick={handleActionMenuOpen}
            color="primary"
            size="small"
          >
            Action {activeActionFilters > 0 && `(${activeActionFilters})`}
          </Button>
          <Menu
            anchorEl={actionAnchorEl}
            open={Boolean(actionAnchorEl)}
            onClose={handleActionMenuClose}
          >
            {typeof isCreateAction === "boolean" &&
              typeof setIsCreateAction === "function" && (
                <MenuItem dense>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={isCreateAction}
                        onChange={() => setIsCreateAction(!isCreateAction)}
                      />
                    }
                    label="Création"
                  />
                </MenuItem>
              )}
            {typeof isUpdateAction === "boolean" &&
              typeof setIsUpdateAction === "function" && (
                <MenuItem dense>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={isUpdateAction}
                        onChange={() => setIsUpdateAction(!isUpdateAction)}
                      />
                    }
                    label="Modifier"
                  />
                </MenuItem>
              )}
            {typeof isDeleteAction === "boolean" &&
              typeof setIsDeleteAction === "function" && (
                <MenuItem dense>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={isDeleteAction}
                        onChange={() => setIsDeleteAction(!isDeleteAction)}
                      />
                    }
                    label="Suppression"
                  />
                </MenuItem>
              )}
            {typeof isSignInAction === "boolean" &&
              typeof setIsSignInAction === "function" && (
                <MenuItem dense>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={isSignInAction}
                        onChange={() => setIsSignInAction(!isSignInAction)}
                      />
                    }
                    label="Connecter"
                  />
                </MenuItem>
              )}
            {typeof isSignOutAction === "boolean" &&
              typeof setIsSignOutAction === "function" && (
                <MenuItem dense>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={isSignOutAction}
                        onChange={() => setIsSignOutAction(!isSignOutAction)}
                      />
                    }
                    label="Déconnecter"
                  />
                </MenuItem>
              )}
          </Menu>
        </Box>
      )}

      <GridToolbarQuickFilter sx={{ width: "25rem" }} />
    </GridToolbarContainer>
  );
};

export default CustomToolBarAudit;
