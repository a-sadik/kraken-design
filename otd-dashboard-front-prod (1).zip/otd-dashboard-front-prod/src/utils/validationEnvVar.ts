// src/utils/validationEnvVar.ts

// Fonction pour vérifier si une variable est invalide
export function isInvalid(value: string) {
  return value === undefined || value === null || value === "";
}
