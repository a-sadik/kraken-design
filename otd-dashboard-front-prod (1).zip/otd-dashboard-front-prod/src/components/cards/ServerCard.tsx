import type React from "react";
import { Card, CardContent, Typography, Box, Chip } from "@mui/material";
import type {
  Vmware,
  Power,
  Bigfix,
  Inventory,
  Solution,
} from "@/services/isolatedService";

// Define a union type for all possible server data structures
type ServerData = Vmware | Power | Bigfix | Inventory;

interface ServerCardProps {
  server: ServerData;
  isSelected: boolean;
  // onSelect is only for selectable servers (Vmware, Power, Bigfix)
  onSelect: (server: Vmware | Power | Bigfix) => void;
  isSelectable: boolean; // Indicates if the card can be selected
}

// Color mappings for environments and OS types
const environmentColors: Record<string, string> = {
  production: "#ffb3b3", // Light Red
  preproduction: "#ffd699", // Light Orange
  integration: "#b3e6ff", // Light Blue
  recette: "#c6b3ff", // Light Purple
  development: "#a8e6b1", // Light Green
  formation: "#ffe6cc",
};

const osColors: Record<string, string> = {
  windows: "#99caff", // Light Blue
  linux: "#a8e6b1", // Light Green
  macos: "#f3aebd", // Light Pink
  aix: "#fce38a", // Medium Blue
  other: "#7fb2e6", // Light Yellow
};

const ServerCard: React.FC<ServerCardProps> = ({
  server,
  isSelected,
  onSelect,
  isSelectable,
}) => {
  const handleCardClick = () => {
    if (isSelectable) {
      // Cast to the union type that can be selected
      onSelect(server as Vmware | Power | Bigfix);
    }
  };

  // Helper function to render solution chips
  const renderSolutions = (solutions: Solution[]) => (
    <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5, mt: 1 }}>
      {solutions.map((sol, index) => (
        <Chip
          key={index}
          label={sol.solution_name}
          size="small"
          variant="outlined"
        />
      ))}
    </Box>
  );

  return (
    <Card
      variant="outlined"
      sx={{
        cursor: isSelectable ? "pointer" : "default", // Change cursor if selectable
        borderColor: isSelected ? "primary.main" : "divider", // Highlight if selected
        borderWidth: isSelected ? 2 : 1,
        transition: "border-color 0.2s ease-in-out",
        "&:hover": {
          borderColor: isSelectable ? "primary.light" : "divider", // Hover effect
        },
        height: "100%", // Ensures consistent height in a grid layout
        display: "flex",
        flexDirection: "column",
      }}
      onClick={handleCardClick}
    >
      <CardContent sx={{ flexGrow: 1 }}>
        <Typography variant="h6" component="div" sx={{ mb: 1 }}>
          {server.hostname}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Source:{" "}
          {server.source.charAt(0).toUpperCase() + server.source.slice(1)}
        </Typography>

        {/* Display OS Type with custom color */}
        <Box sx={{ mt: 1 }}>
          <Typography variant="subtitle2">OS Type:</Typography>
          <Chip
            label={server.os_type}
            size="small"
            sx={{
              backgroundColor:
                osColors[server.os_type.toLowerCase()] || osColors.other,
              color: (theme) =>
                theme.palette.getContrastText(
                  osColors[server.os_type.toLowerCase()] || osColors.other,
                ),
            }}
          />
        </Box>

        {/* Display IP Addresses */}
        {server.ip_addresses && server.ip_addresses.length > 0 && (
          <Box sx={{ mt: 1 }}>
            <Typography variant="subtitle2">IP Addresses:</Typography>
            <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
              {server.ip_addresses.map((ip, index) => (
                <Chip key={index} label={ip} size="small" />
              ))}
            </Box>
          </Box>
        )}

        {/* Display OS Detail (if available) */}
        {"os_detail" in server && server.os_detail && (
          <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
            OS Detail: {server.os_detail}
          </Typography>
        )}

        {/* Display Nature Detail (if available) */}
        {"nature_detail" in server && server.nature_detail && (
          <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
            Nature Detail: {server.nature_detail}
          </Typography>
        )}

        {/* Display Server Nature (if available) */}
        {"server_nature" in server &&
          server.server_nature &&
          server.server_nature.length > 0 && (
            <Box sx={{ mt: 1 }}>
              <Typography variant="subtitle2">Server Nature:</Typography>
              <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
                {server.server_nature.map((nature, index) => (
                  <Chip
                    key={index}
                    label={nature}
                    size="small"
                    variant="outlined"
                  />
                ))}
              </Box>
            </Box>
          )}

        {/* Display Environments (if available) with custom colors */}
        {"environments" in server &&
          server.environments &&
          server.environments.length > 0 && (
            <Box sx={{ mt: 1 }}>
              <Typography variant="subtitle2">Environments:</Typography>
              <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
                {server.environments.map((env, index) => (
                  <Chip
                    key={index}
                    label={env}
                    size="small"
                    sx={{
                      backgroundColor:
                        environmentColors[env.toLowerCase()] ||
                        environmentColors.other,
                      color: (theme) =>
                        theme.palette.getContrastText(
                          environmentColors[env.toLowerCase()] ||
                            environmentColors.other,
                        ),
                    }}
                  />
                ))}
              </Box>
            </Box>
          )}

        {/* Display Associated Solutions (if available) */}
        {"solutions" in server &&
          server.solutions &&
          server.solutions.length > 0 && (
            <Box sx={{ mt: 1 }}>
              <Typography variant="subtitle2">Associated Solutions:</Typography>
              {renderSolutions(server.solutions)}
            </Box>
          )}

        {/* Display creation and update timestamps */}
        <Typography variant="caption" display="block" sx={{ mt: 1 }}>
          Created: {new Date(server.created_at).toLocaleString()} by{" "}
          {server.created_by}
        </Typography>
        <Typography variant="caption" display="block">
          Updated: {new Date(server.updated_at).toLocaleString()} by{" "}
          {server.updated_by}
        </Typography>
      </CardContent>
    </Card>
  );
};

export default ServerCard;
