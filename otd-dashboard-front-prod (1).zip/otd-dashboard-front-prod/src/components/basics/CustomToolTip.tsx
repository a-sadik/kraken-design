// src/components/basics/CustomTooltip.tsx

import { ReactElement, FC } from "react";
import Tooltip from "@mui/material/Tooltip";
import Typography from "@mui/material/Typography";

import { TooltipProps } from "@mui/material/Tooltip";



interface CustomTooltipProps extends Omit<TooltipProps, "title"> {
  title: React.ReactNode;
  children: ReactElement;
  fontSize?: string;
}


const CustomTooltip: FC<CustomTooltipProps> = ({
  title,
  children,
  fontSize = "1rem",
}) => {
  if (title === "" || title === null) return <> {children} </>;
  return (
    <Tooltip
      title={
        <Typography variant="body2" sx={{ fontSize, color: "white" }}>
          {title}
        </Typography>
      }
      arrow
      sx={{
        "& .MuiTooltip-tooltip": {
          bgcolor: "var(--layout-background-color)",
          color: "white",
        },
      }}
    >
      {children}
    </Tooltip>
  );
};

export default CustomTooltip;
