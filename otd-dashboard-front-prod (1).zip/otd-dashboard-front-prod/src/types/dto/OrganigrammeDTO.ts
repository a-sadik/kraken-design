// src/types/dto/OrganigrammeDTO.ts

export interface OrganigrammeResponseDTO {
  name: string;
  title?: string;
}
