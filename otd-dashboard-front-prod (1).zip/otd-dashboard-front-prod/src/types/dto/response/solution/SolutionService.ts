import {
  getNatures_Inventory,
  getSolutions_Inventory,
} from "@/config/api.config";
import fetchWithAuth from "@/middleware/fetch-auth";
import type { SolutionDetailResponseDTO } from "@/types/dto/response/solution/SolutionDetailResponseDTO";

export async function getAllSolutions(): Promise<SolutionDetailResponseDTO[]> {
  try {
    const response = await fetchWithAuth(getSolutions_Inventory());
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data = await response.json();
    if (!Array.isArray(data)) {
      console.error("API did not return an array for solutions:", data);
      return [];
    }
    return data;
  } catch (error) {
    console.error("Error fetching solutions:", error);
    // Re-throw to allow calling component to handle
    throw error;
  }
}

export async function getServerNatures(): Promise<string[]> {
  try {
    const response = await fetchWithAuth(getNatures_Inventory());
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data = await response.json();
    if (
      !Array.isArray(data) ||
      !data.every((item) => typeof item === "string")
    ) {
      console.error(
        "API did not return an array of strings for server natures:",
        data,
      );
      return [];
    }
    return data;
  } catch (error) {
    console.error("Error fetching server natures:", error);
    // Re-throw to allow calling component to handle
    throw error;
  }
}
