import { useState, useEffect, useCallback } from "react";
import {
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Paper,
  TableContainer,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  IconButton,
  CircularProgress,
  Snackbar,
  Alert,
  Box,
  Stack,
} from "@mui/material";
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
} from "@mui/icons-material";
import { getNatures_BaseUrl } from "@/config/api.config";
import { useSnackbar } from "@/hooks/useSnackbar"; // Import the new hook
import fetchWithAuth from "@/middleware/fetch-auth";
import { keycloak } from "@/auth/keycloakConnectAdapter";

const API_BASE_URL = getNatures_BaseUrl();

interface ServerNature {
  name: string;
}

export function ServerNaturesCRUD() {
  const [natures, setNatures] = useState<ServerNature[]>([]);
  const [currentNature, setCurrentNature] = useState<ServerNature | null>(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const { snackbar, showSnackbar, handleCloseSnackbar } = useSnackbar();
  const [originalNatureName, setOriginalNatureName] = useState<string | null>(
    null,
  );

  const fetchNatures = useCallback(async () => {
    try {
      setLoading(true);
      const response = await fetchWithAuth(`${API_BASE_URL}/`);
      const data: string[] = await response.json();
      setNatures(data.map((name) => ({ name })));
    } catch (error) {
      showSnackbar(
        "Erreur lors du chargement des natures de serveurs",
        "error",
      );
      console.error(error);
    } finally {
      setLoading(false);
    }
  }, [showSnackbar]);

  useEffect(() => {
    fetchNatures();
  }, [fetchNatures]);

  const handleCreate = () => {
    setCurrentNature({ name: "" });
    setIsEditing(false);
    setOpenDialog(true);
  };

  const handleEdit = (nature: ServerNature) => {
    setCurrentNature(nature);
    setOriginalNatureName(nature.name);
    setIsEditing(true);
    setOpenDialog(true);
  };

  const handleDelete = async (name: string) => {
    if (window.confirm(`Confirmer la suppression de la nature "${name}" ?`)) {
      try {
        await fetchWithAuth(`${API_BASE_URL}/${name}/`, { method: "DELETE" });
        setNatures(natures.filter((n) => n.name !== name));
        showSnackbar("Nature de serveur supprimée avec succès", "success");
      } catch (error) {
        showSnackbar("Erreur lors de la suppression", "error");
      }
    }
  };

  const handleSubmit = async () => {
    if (!currentNature?.name) {
      showSnackbar("Le nom de la nature ne peut pas être vide", "error");
      return;
    }

    try {
      let url: string;
      let method: string;
      let body: string | undefined;

      if (isEditing) {
        // For PATCH, the URL includes the OLD name, and body has the NEW name
        url = `${API_BASE_URL}/${originalNatureName}`;
        method = "PATCH";
        body = JSON.stringify({ new_name: currentNature!.name }); // Assuming currentNature.name is the new name
      } else {
        // For POST, body has the NEW name
        url = `${API_BASE_URL}/`;
        method = "POST";
        body = JSON.stringify({ new_nature: currentNature!.name });
      }

      const response = await fetchWithAuth(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      // Re-fetch all natures to ensure consistency after modification
      await fetchNatures();
      showSnackbar(
        `Nature de serveur ${isEditing ? "modifiée" : "ajoutée"} avec succès`,
        "success",
      );
      setOpenDialog(false);
    } catch (error) {
      showSnackbar("Erreur lors de l'opération", "error");
      console.error(error);
    }
  };

  return (
    <Paper sx={{ p: 4, borderRadius: 2, boxShadow: 3 }}>
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          mb: 3,
        }}
      >
        <Typography
          variant="h5"
          component="h2"
          sx={{ fontWeight: "bold", color: "text.primary" }}
        >
          Gestion des Natures de Serveurs
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={handleCreate}
          disabled={!keycloak.hasRoles("admin_role")}
          sx={{
            bgcolor: "primary.main",
            "&:hover": { bgcolor: "primary.dark" },
            borderRadius: 1,
            px: 3,
            py: 1.2,
          }}
        >
          Ajouter une Nature
        </Button>
      </Box>

      {loading ? (
        <Box sx={{ display: "flex", justifyContent: "center", py: 4 }}>
          <CircularProgress />
        </Box>
      ) : (
        <TableContainer
          component={Paper}
          sx={{ borderRadius: 2, boxShadow: 1 }}
        >
          <Table sx={{ minWidth: 600 }}>
            <TableHead sx={{ bgcolor: "grey.100" }}>
              <TableRow>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Nom de la Nature
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Actions
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {natures.map((nature) => (
                <TableRow
                  key={nature.name}
                  sx={{ "&:nth-of-type(odd)": { bgcolor: "action.hover" } }}
                >
                  <TableCell>{nature.name}</TableCell>
                  <TableCell>
                    <Stack direction="row" spacing={0.5}>
                      <IconButton
                        color="primary"
                        size="small"
                        disabled={!keycloak.hasRoles("admin_role")}
                        onClick={() => handleEdit(nature)}
                      >
                        <EditIcon sx={{ fontSize: 20 }} />
                      </IconButton>
                      <IconButton
                        color="error"
                        size="small"
                        disabled={!keycloak.hasRoles("admin_role")}
                        onClick={() => handleDelete(nature.name)}
                      >
                        <DeleteIcon sx={{ fontSize: 20 }} />
                      </IconButton>
                    </Stack>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {/* Dialog d'édition/création */}
      <Dialog
        open={openDialog}
        onClose={() => setOpenDialog(false)}
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle
          sx={{ bgcolor: "primary.main", color: "white", py: 2, px: 3 }}
        >
          <Typography variant="h6" component="span" sx={{ fontWeight: "bold" }}>
            {isEditing
              ? "Modifier la nature de serveur"
              : "Créer une nouvelle nature de serveur"}
          </Typography>
        </DialogTitle>
        <DialogContent dividers sx={{ p: 3 }}>
          {currentNature && (
            <TextField
              label="Nom de la nature"
              fullWidth
              value={currentNature.name}
              onChange={(e) => {
                const newValue = e.target.value;
                if (
                  newValue.includes("/") ||
                  newValue.includes("&") ||
                  newValue.includes("?")
                ) {
                  showSnackbar(
                    "Les caractères '/', '?' et '&' sont interdits dans le nom",
                    "error",
                  );
                  return;
                }
                setCurrentNature({ ...currentNature, name: newValue });
              }}
              required
              variant="outlined"
              size="small"
            />
          )}
        </DialogContent>
        <DialogActions sx={{ p: 2, borderTop: "1px solid #eee" }}>
          <Button
            onClick={() => setOpenDialog(false)}
            variant="outlined"
            sx={{ borderRadius: 1 }}
          >
            Annuler
          </Button>
          <Button
            variant="contained"
            onClick={handleSubmit}
            disabled={!currentNature?.name}
            sx={{
              bgcolor: "primary.main",
              "&:hover": { bgcolor: "primary.dark" },
              borderRadius: 1,
            }}
          >
            {isEditing ? "Modifier" : "Créer"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar de notification */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          sx={{ width: "100%", boxShadow: 3 }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Paper>
  );
}
