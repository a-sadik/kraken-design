// import React, { ReactElement, ReactNode } from 'react';
// import { Box, Typography, Tabs, Tab, Alert, alpha, Chip,  Divider, Grid, Paper, Skeleton, Stack } from '@mui/material';
// // import { SolutionList } from '@/types/TopologyTypes';
// import { Person, Apps, Business } from '@mui/icons-material';
// import { FiServer } from 'react-icons/fi';
// import { LuRocket } from 'react-icons/lu';
// import { MdAdminPanelSettings, MdOutlineAdminPanelSettings } from 'react-icons/md';
// import { TbBuildingBank } from 'react-icons/tb';
// import { VscSymbolNamespace } from 'react-icons/vsc';
// import { darkColors, pastelTheme } from '../basics/ThemeButton';
// import { colors } from './utils/colors';
// import type {
//   EntitiesList,
//   SolutionList,
//   NamespacesList,
//   DeploymentsList,
//   Childserver,
//   ServerList,
//   PodsList,
//   BreadcrumbItem,
// } from "@/types/TopologyTypes"
// interface SolutionDetailViewProps {
//   solution: any;
// }

// const SolutionDetailView = ({ solution }: { solution: SolutionList }) => {
//     const tabKey = `solution-${solution.solution_id}-view`
//     const tabValue = solutionViewTab.get(tabKey) || 0

//     // Nouveau composant pour les sections d'information
//     const InfoSection = ({ title, icon, children }: { title: string; icon: ReactElement; children: ReactNode }) => (
//       <Box sx={{ mb: 3 }}>
//         <Paper
//           elevation={0}
//           sx={{
//             p: 2,
//             background: alpha(colors.solution, 0.1),
//             border: `1px solid ${alpha(colors.solution, 0.3)}`,
//             borderRadius: 2,
//           }}
//         >
//           <Typography variant="subtitle2" sx={{ fontWeight: 700, color: darkColors.solution, mb: 1, display: 'flex', alignItems: 'center', gap: 1 }}>
//             {icon} {title}
//           </Typography>
//           {children}
//         </Paper>
//       </Box>
//     )

//     // Organisation améliorée des informations
//     const renderOrganizationInfo = () => {
//         function renderEnvironmentChips(list_environnements: string[]): React.ReactNode {
//             throw new Error('Function not implemented.');
//         }

//       return (
//         <>
//           <InfoSection title="Responsables" icon={<MdAdminPanelSettings />}>
//             <Grid container spacing={2}>
//               {solution.person && (
//                 <Grid item xs={12} md={6}>
//                   <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
//                     <Person fontSize="small" />
//                     <Typography variant="body2">
//                       <strong>TAM:</strong> {solution.person}
//                     </Typography>
//                   </Box>
//                 </Grid>
//               )}
//               {solution.count_technical_admins > 0 && (
//                 <Grid item xs={12} md={6}>
//                   <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
//                     <MdAdminPanelSettings size={18} />
//                     <Typography variant="body2">
//                       <strong>Admins Techniques:</strong> {solution.count_technical_admins}
//                     </Typography>
//                   </Box>
//                 </Grid>
//               )}
//               {solution.count_functional_admins > 0 && (
//                 <Grid item xs={12} md={6}>
//                   <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
//                     <MdOutlineAdminPanelSettings size={18} />
//                     <Typography variant="body2">
//                       <strong>Admins Fonctionnels:</strong> {solution.count_functional_admins}
//                     </Typography>
//                   </Box>
//                 </Grid>
//               )}
//             </Grid>
//           </InfoSection>

//           <InfoSection title="Caractéristiques" icon={<Apps />}>
//             <Grid container spacing={2}>
//               <Grid item xs={12} md={6}>
//                 <Typography variant="body2">
//                   <strong>Type:</strong> {solution.solution_type}
//                 </Typography>
//               </Grid>
//               <Grid item xs={12} md={6}>
//                 <Typography variant="body2">
//                   <strong>PSI:</strong> {solution.psi}
//                 </Typography>
//               </Grid>
//               <Grid item xs={12} md={6}>
//                 <Typography variant="body2">
//                   <strong>Rôle:</strong> {solution.solution_role}
//                 </Typography>
//               </Grid>
//               {solution.list_environnements && (
//                 <Grid item xs={12} md={6}>
//                   <Typography variant="body2" sx={{ mb: 0.5 }}>
//                     <strong>Environnements:</strong>
//                   </Typography>
//                   {renderEnvironmentChips(solution.list_environnements)}
//                 </Grid>
//               )}
//             </Grid>
//           </InfoSection>
//         </>
//       )
//     }

//     function setSolutionViewTab(arg0: (prev: any) => Map<unknown, unknown>): void {
//         throw new Error('Function not implemented.');
//     }

//     function renderNamespaceTabs(arg0: any, solution_id: number): React.ReactNode {
//         throw new Error('Function not implemented.');
//     }

//     function renderServerEnvironmentTabs(solution: SolutionList): React.ReactNode {
//         throw new Error('Function not implemented.');
//     }

//     return (
//       <Box sx={{ mt: 3 }}>
//         <Paper
//           elevation={0}
//           sx={{
//             p: 3,
//             background: pastelTheme.cardBackground,
//             border: `1px solid ${pastelTheme.outline}`,
//             borderRadius: 3,
//             boxShadow: `0 8px 24px ${pastelTheme.shadow}`,
//           }}
//         >
//           {/* En-tête améliorée */}
//           <Box sx={{
//             display: 'flex',
//             alignItems: 'center',
//             gap: 3,
//             mb: 3,
//             flexDirection: { xs: 'column', sm: 'row' },
//             textAlign: { xs: 'center', sm: 'left' }
//           }}>
//             <Box
//               sx={{
//                 p: 3,
//                 borderRadius: "50%",
//                 backgroundColor: alpha(colors.solution, 0.2),
//                 color: darkColors.solution,
//                 flexShrink: 0,
//                 display: "flex",
//                 alignItems: "center",
//                 justifyContent: "center",
//               }}
//             >
//               <Apps sx={{ fontSize: 40 }} />
//             </Box>
//             <Box>
//               <Typography variant="h4" sx={{ fontWeight: 800, color: darkColors.solution, mb: 1 }}>
//                 {solution.solution_name}
//               </Typography>
//               <Stack
//                 direction="row"
//                 spacing={2}
//                 divider={<Divider orientation="vertical" flexItem />}
//                 sx={{ justifyContent: { xs: 'center', sm: 'flex-start' } }}
//               >
//                 <Chip
//                   label={solution.solution_type}
//                   size="small"
//                   sx={{
//                     fontWeight: 700,
//                     backgroundColor: alpha(colors.solution, 0.2),
//                     color: darkColors.solution
//                   }}
//                 />
//                 <Chip
//                   label={solution.psi}
//                   size="small"
//                   sx={{
//                     fontWeight: 700,
//                     backgroundColor: alpha(colors.solution, 0.2),
//                     color: darkColors.solution
//                   }}
//                 />
//                 <Chip
//                   label={solution.solution_role}
//                   size="small"
//                   sx={{
//                     fontWeight: 700,
//                     backgroundColor: alpha(colors.solution, 0.2),
//                     color: darkColors.solution
//                   }}
//                 />
//               </Stack>
//             </Box>
//           </Box>

//           {/* Informations d'organisation */}
//           {renderOrganizationInfo()}

//           {/* Onglets améliorés */}
//           <Tabs
//             value={tabValue}
//             onChange={(_, newValue) => setSolutionViewTab((prev) => new Map(prev).set(tabKey, newValue))}
//             sx={{
//               mb: 3,
//               "& .MuiTab-root": {
//                 fontSize: "14px",
//                 fontWeight: 700,
//                 textTransform: "none",
//                 minHeight: 48,
//                 borderRadius: 2,
//                 mx: 1,
//                 "&.Mui-selected": {
//                   backgroundColor: darkColors.solution,
//                   color: "white",
//                 },
//               },
//             }}
//             variant="scrollable"
//             scrollButtons="auto"
//           >
//             <Tab
//               icon={<FiServer />}
//               iconPosition="start"
//               label="Serveurs"
//               sx={{
//                 color: colors.server,
//                 '&.Mui-selected': {
//                   backgroundColor: colors.server,
//                   color: 'white'
//                 }
//               }}
//             />
//             <Tab
//               icon={<VscSymbolNamespace />}
//               iconPosition="start"
//               label="Namespaces"
//               sx={{
//                 color: colors.namespace,
//                 '&.Mui-selected': {
//                   backgroundColor: colors.namespace,
//                   color: 'white'
//                 }
//               }}
//             />
//             <Tab
//               icon={<LuRocket />}  // Vous pouvez choisir une autre icône plus appropriée
//               iconPosition="start"
//               label="Infos MAJ"
//               sx={{
//                 color: colors.deployment,
//                 '&.Mui-selected': {
//                   backgroundColor: colors.deployment,
//                   color: 'white'
//                 }
//               }}
//             />
//           </Tabs>

//           {/* Contenu des onglets */}
//           <Box sx={{ mt: 2 }}>
//             {tabValue === 1 ? (
//               //contenue namespaces
//               <Box>
//                 <Typography variant="h6" sx={{
//                   mb: 2,
//                   display: "flex",
//                   alignItems: "center",
//                   gap: 1,
//                   fontWeight: 700,
//                   color: colors.namespace
//                 }}>
//                   <VscSymbolNamespace />
//                   {/* ({solution.count_servers || 0}) */}
//                   Namespaces OpenShift ({solution.count_namespaces || 0})
//                 </Typography>
//                 {solution.child_namespace ? (
//                   loading.has(`solution-${solution.solution_id}-namespaces`) ? (
//                     <Skeleton variant="rectangular" height={300} sx={{ borderRadius: 2 }} />
//                   ) : (
//                     renderNamespaceTabs(
//                       loadedData.get(`solution-${solution.solution_id}-namespaces`) || [],
//                       solution.solution_id,
//                     )
//                   )
//                 ) : (
//                   <Alert severity="info" sx={{ borderRadius: 2 }}>
//                     Aucun namespace configuré pour cette solution
//                   </Alert>
//                 )}
//               </Box>
//             ) : tabValue === 2 ? (
//               // Nouveau contenu pour Infos MAJ
//               <Box>
//                 <Typography variant="h6" sx={{
//                   mb: 2,
//                   display: "flex",
//                   alignItems: "center",
//                   gap: 1,
//                   fontWeight: 700,
//                   color: colors.deployment
//                 }}>
//                   <LuRocket />
//                   Informations de Mise à Jour
//                 </Typography>

//                 <Paper sx={{
//                   p: 3,
//                   borderRadius: 3,
//                   backgroundColor: alpha(colors.deployment, 0.05),
//                   borderLeft: `4px solid ${colors.deployment}`
//                 }}>
//                   <Grid container spacing={3}>

//                     {/* Demandes Utilisateurs */}
//                     <Grid item xs={12} sm={6} md={3}>
//                       <Box sx={{
//                         p: 2,
//                         backgroundColor: alpha(colors.solution, 0.1),
//                         borderRadius: 2,
//                         borderLeft: `4px solid ${colors.solution}`
//                       }}>
//                         <Typography variant="subtitle2" sx={{
//                           fontWeight: 700,
//                           color: colors.solution,
//                           display: 'flex',
//                           alignItems: 'center',
//                           gap: 1
//                         }}>
//                           <Apps /> Demandes Utilisateurs
//                         </Typography>
//                         <Typography variant="h4" sx={{ mt: 1, fontWeight: 800 }}>
//                           {solution.count_request || 0}
//                         </Typography>
//                       </Box>
//                     </Grid>

//                     {/* CAB */}
//                     <Grid item xs={12} sm={6} md={3}>
//                       <Box sx={{
//                         p: 2,
//                         backgroundColor: alpha(colors.entity, 0.1),
//                         borderRadius: 2,
//                         borderLeft: `4px solid ${colors.entity}`
//                       }}>
//                         <Typography variant="subtitle2" sx={{
//                           fontWeight: 700,
//                           color: colors.entity,
//                           display: 'flex',
//                           alignItems: 'center',
//                           gap: 1
//                         }}>
//                           <Business /> CAB
//                         </Typography>
//                         <Typography variant="h4" sx={{ mt: 1, fontWeight: 800 }}>
//                           {solution.count_cab || 0}
//                         </Typography>
//                       </Box>
//                     </Grid>

//                     {/* ECAB */}
//                     <Grid item xs={12} sm={6} md={3}>
//                       <Box sx={{
//                         p: 2,
//                         backgroundColor: alpha(colors.domain, 0.1),
//                         borderRadius: 2,
//                         borderLeft: `4px solid ${colors.domain}`
//                       }}>
//                         <Typography variant="subtitle2" sx={{
//                           fontWeight: 700,
//                           color: colors.domain,
//                           display: 'flex',
//                           alignItems: 'center',
//                           gap: 1
//                         }}>
//                           <TbBuildingBank /> ECAB
//                         </Typography>
//                         <Typography variant="h4" sx={{ mt: 1, fontWeight: 800 }}>
//                           {solution.count_ecab || 0}
//                         </Typography>
//                       </Box>
//                     </Grid>
//                   </Grid>

//                   {/* Vous pouvez ajouter ici des informations supplémentaires ou des graphiques */}
//                   <Box sx={{ mt: 3 }}>
//                     <Typography variant="body2" sx={{ fontStyle: 'italic' }}>
//                       Dernière mise à jour: {solution.updated_at ? new Date(solution.updated_at).toLocaleString() : 'Inconnue'}
//                     </Typography>
//                   </Box>
//                 </Paper>
//               </Box>
//             ) : (

//               <Box>
//                 <Typography variant="h6" sx={{
//                   mb: 2,
//                   display: "flex",
//                   alignItems: "center",
//                   gap: 1,
//                   fontWeight: 700,
//                   color: colors.server
//                 }}>
//                   <FiServer />
//                   Serveurs ({solution.count_servers || 0})
//                 </Typography>
//                 {solution.child_servers && solution.child_servers.length > 0 ? (
//                   renderServerEnvironmentTabs(solution)
//                 ) : (
//                   <Alert severity="info" sx={{ borderRadius: 2 }}>
//                     Aucun serveur configuré pour cette solution
//                   </Alert>
//                 )}
//               </Box>
//             )}
//           </Box>
//         </Paper>
//       </Box>
//     )
//   }

// export default SolutionDetailView;
