// src/services/project-amounts/BDIProjectAmountsService.ts

// import files
import { ProjectAmountsResponseDTO } from "@/types/dto/response/ProjectAmountsResponseDTO";
import mockData from "@/data/project-amounts/bdi.json";

export const getBDIProjectAmounts = async (): Promise<
  ProjectAmountsResponseDTO[]
> => {
  try {
    // Simuler un appel réseau avec un délai
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(mockData as ProjectAmountsResponseDTO[]);
      }, 3000);
    });
  } catch (error) {
    console.error("Error fetching BDI project money data:", error);
    throw error;
  }
};
