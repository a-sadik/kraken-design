// src/components/data-tables/PersonDataTable.tsx

import { useEffect, useMemo, useState } from "react";
import { Box, Typography, Button, Chip } from "@mui/material";
import {
  useMaterialReactTable,
  MRT_ColumnDef,
  MRT_GlobalFilterTextField,
  MRT_ShowHideColumnsButton,
  MRT_TableContainer,
  MRT_TablePagination,
  MRT_ToggleFiltersButton,
} from "material-react-table";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import { getAllPersons } from "@/services/admin/PersonService";
import { PersonShortResponseDTO } from "@/types/dto/PersonDTO";
import { getCssVariableValue } from "@/utils/getDynamicColor";
import { useNavigate } from "react-router-dom";
import WidgetMainContainer from "@/components/containers/WidgetMainContainer";

import AdminPanelSettingsIcon from "@mui/icons-material/AdminPanelSettings";

const PersonDataTable = () => {
  const [data, setData] = useState<PersonShortResponseDTO[]>([]);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchPersons = async () => {
      setLoading(true);
      try {
        const response = await getAllPersons();
        setData(response);
      } catch (error) {
        console.error("Erreur de chargement des personnes :", error);
      } finally {
        setLoading(false);
      }
    };

    fetchPersons();
  }, []);

  const columns = useMemo<MRT_ColumnDef<PersonShortResponseDTO>[]>(
    () => [
      {
        accessorKey: "firstname",
        header: "Nom",
        Cell: ({ cell }) => (
          <Typography fontWeight="" fontSize="1rem">
            {cell.getValue<string>()}
          </Typography>
        ),
      },
      {
        accessorKey: "email",
        header: "Email",
        Cell: ({ cell }) => (
          <Typography fontWeight="" fontSize="1rem">
            {cell.getValue<string>() || "-"}
          </Typography>
        ),
      },
      {
        accessorKey: "role",
        header: "Rôle",
        Cell: ({ row }) =>
          row.original.role ? (
            <Chip
              label={row.original.role}
              color="success"
              variant="outlined"
            />
          ) : (
            <Chip label="Aucun rôle" color="warning" variant="outlined" />
          ),
      },
      // {
      //   accessorKey: 'postes',
      //   header: 'Posts',
      //   Cell: ({ row }) => {
      //     const posts = row.original.postes;
      //     return posts && posts.length > 0 ? (
      //       <Box display="flex" gap={1} flexWrap="wrap">
      //         {posts.map((post, index) => (
      //           <Chip
      //             key={index}
      //             label={post}
      //             color={index % 2 === 0 ? 'primary' : 'secondary'}
      //             variant="filled"
      //           />
      //         ))}
      //       </Box>
      //     ) : (
      //       <Chip label="Aucun poste" color="error" variant="outlined" />
      //     );
      //   },
      // },
      {
        accessorKey: "postes",
        header: "Posts",
        Cell: ({ row }) => {
          let posts: string[] = [];

          try {
            const raw = row.original.posts;
            if (typeof raw === "string") {
              // ✅ parse deux fois
              const firstParse = JSON.parse(raw); // encore string
              posts = JSON.parse(firstParse); // tableau final
            } else if (Array.isArray(raw)) {
              posts = raw;
            }
          } catch (err) {
            console.warn("⚠️ Parsing posts failed:", err);
          }

          const getChipColor = (
            post: string,
          ):
            | "primary"
            | "secondary"
            | "success"
            | "info"
            | "error"
            | "default" => {
            const lower = post.toLowerCase();
            if (lower.includes("manager")) return "info";
            if (lower.includes("projet")) return "secondary";
            if (lower.includes("développeur")) return "success";
            return "default";
          };

          return posts.length > 0 ? (
            <Box display="flex" gap={1} flexWrap="wrap">
              {posts.map((post, index) => (
                <Chip
                  key={index}
                  label={post}
                  color={getChipColor(post)}
                  variant="filled"
                />
              ))}
            </Box>
          ) : (
            <Chip label="Aucun poste" color="error" variant="outlined" />
          );
        },
      },
    ],
    [],
  );

  const table = useMaterialReactTable({
    columns,
    data,
    state: { isLoading: loading },
    initialState: { showGlobalFilter: true },
    enableColumnOrdering: true,
    enableColumnFilters: true,
    enableDensityToggle: true,
  });

  const primaryColor = getCssVariableValue("--primary-color");

  const theme = createTheme({
    palette: {
      primary: { main: primaryColor },
    },
  });

  return (
    <ThemeProvider theme={theme}>
      <Box>
        {/* Header */}
        <Box
          display="flex"
          justifyContent="space-between"
          alignItems="center"
          mb={3}
        >
          <Typography
            variant="h4"
            fontWeight="bold"
            className="data-table-title"
          >
            Liste des personnes
          </Typography>
          <Box display="flex" gap={2}>
            <Button
              variant="contained"
              color="primary"
              startIcon={<AdminPanelSettingsIcon />}
              onClick={() => navigate("/auditadmin/admin")}
              className="button-add"
            >
              <Typography className="text-button-add" variant="h6">
                Admin
              </Typography>
            </Button>
          </Box>
        </Box>

        {/* Table + Outils */}
        <WidgetMainContainer sx={{ borderColor: "--primary-color" }}>
          <Box
            sx={{
              display: "flex",
              backgroundColor: "inherit",
              borderRadius: "4px",
              flexDirection: "row",
              gap: "16px",
              color: "primary",
              justifyContent: "space-between",
              alignItems: "center",
              "@media max-width: 768px": { flexDirection: "column" },
            }}
          >
            <Box display="flex" alignItems="center" gap={1}>
              <MRT_ShowHideColumnsButton
                table={table}
                sx={{ color: primaryColor }}
              />
              <Typography variant="body2" sx={{ color: primaryColor }}>
                Colonnes
              </Typography>
            </Box>
            <Box display="flex" alignItems="center" gap={1}>
              <MRT_ToggleFiltersButton
                table={table}
                sx={{ color: primaryColor }}
              />
              <Typography variant="body2" sx={{ color: primaryColor }}>
                Filtres
              </Typography>
            </Box>

            <MRT_GlobalFilterTextField table={table} />
          </Box>

          <MRT_TableContainer table={table} />
          <Box display="flex" justifyContent="flex-end" mt={2}>
            <MRT_TablePagination table={table} />
          </Box>
        </WidgetMainContainer>
      </Box>
    </ThemeProvider>
  );
};

export default PersonDataTable;
