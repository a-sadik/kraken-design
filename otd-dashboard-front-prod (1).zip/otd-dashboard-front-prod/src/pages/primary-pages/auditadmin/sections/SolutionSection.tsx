// export default SolutionSection;

import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";

import {
  Box,
  Grid,
  Stack,
  Typography,
  IconButton,
  Collapse,
  TextField,
  Button,
  Snackbar,
  Alert as MuiAlert,
  useMediaQuery,
} from "@mui/material";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";

import WidgetMainContainer from "@/components/containers/WidgetMainContainer";
import { MaterialReactTable, MRT_ColumnDef } from "material-react-table";

import SearchIcon from "@mui/icons-material/Search";

import { getAllSolutions } from "@/services/SolutionService";
import { CreateSolutionModal } from "@/components/modals/CreateSolutionModal";
import { EditSolutionModal } from "@/components/modals/EditSolutionModal";

const PAGE_SIZE = 5;

interface SolItem {
  solution_id: number;
  solution_name: string;
}

const SolutionSection: React.FC = () => {
  const [solutions, setSolutions] = useState<SolItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [collapseOpen, setCollapseOpen] = useState(true);
  const [globalFilter, setGlobalFilter] = useState("");
  const [snack, setSnack] = useState({
    open: false,
    msg: "",
    severity: "success" as "success" | "error",
  });

  const [editOpen, setEditOpen] = useState(false);
  const [selected, setSelected] = useState<SolItem | null>(null);

  const [addOpen, setAddOpen] = useState(false);

  const isXs = useMediaQuery("(max-width:480px)");

  const navigate = useNavigate();

  useEffect(() => {
    setLoading(true);
    fetchSolutions();
  }, []);

  const fetchSolutions = () => {
    setLoading(true);
    getAllSolutions()
      .then((res) => {
        if (Array.isArray(res)) {
          const mapped = res.map((sol) => ({
            solution_id: sol.solution_id,
            solution_name: sol.solution_name,
          }));
          setSolutions(mapped);
        }
      })
      .catch(() =>
        setSnack({
          open: true,
          msg: "Erreur de chargement",
          severity: "error",
        }),
      )
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    if (globalFilter.trim() && !collapseOpen) {
      setCollapseOpen(true);
    }
  }, [globalFilter]);

  const data = useMemo(() => {
    if (!globalFilter) return solutions;
    return solutions.filter((sol) =>
      sol.solution_name.toLowerCase().includes(globalFilter.toLowerCase()),
    );
  }, [solutions, globalFilter]);

  const columns = useMemo<MRT_ColumnDef<SolItem>[]>(
    () => [
      {
        header: "Solution",
        accessorKey: "solution_name",
        Cell: ({ row }) => (
          <Typography
            sx={{
              // cursor: 'pointer',
              fontWeight: 500,
              color: "primary.main",
              // '&:hover': { textDecoration: 'underline' },
            }}
          >
            {row.original.solution_name}
          </Typography>
        ),
      },
      {
        header: "Actions",
        id: "actions",
        enableSorting: false,
        enableColumnFilter: false,
        muiTableHeadCellProps: { sx: { textAlign: "right" } },
        muiTableBodyCellProps: { sx: { textAlign: "right" } },
        Cell: ({ row }) => (
          <Stack direction="row" justifyContent="flex-end" spacing={1}>
            <Button
              size="small"
              variant="contained"
              color="info"
              onClick={() => {
                setSelected(row.original);
                setEditOpen(true);
              }}
            >
              Modifier
            </Button>
          </Stack>
        ),
      },
    ],
    [],
  );

  return (
    <Grid container spacing={3} sx={{ mb: 3 }}>
      <Grid item xs={12}>
        <WidgetMainContainer>
          <Stack
            direction="row"
            justifyContent="space-between"
            alignItems="center"
            flexWrap="wrap"
          >
            <Stack direction="row" alignItems="center" spacing={1}>
              <Typography
                variant="h6"
                fontWeight="bold"
                sx={{
                  cursor: "pointer",
                  color: "primary.main",
                  "&:hover": { textDecoration: "underline" },
                }}
                onClick={() => navigate("/admin/solution")}
              >
                Solutions
              </Typography>
              <IconButton onClick={() => setAddOpen(true)}>
                <AddCircleOutlineIcon color="primary" />
              </IconButton>
            </Stack>
            <Stack
              direction="row"
              spacing={1}
              alignItems="center"
              flexWrap="wrap"
            >
              {isXs ? (
                <IconButton>
                  <SearchIcon />
                </IconButton>
              ) : (
                <Box sx={{ width: { xs: "120px", sm: "230px" } }}>
                  <TextField
                    size="small"
                    fullWidth
                    placeholder="Rechercher…"
                    value={globalFilter}
                    onChange={(e) => setGlobalFilter(e.target.value)}
                  />
                  {!collapseOpen && globalFilter && (
                    <Typography variant="caption" color="textSecondary">
                      Résultats filtrés — ouvrez la section pour les voir.
                    </Typography>
                  )}
                </Box>
              )}

              <IconButton onClick={() => setCollapseOpen((o) => !o)}>
                {collapseOpen ? <ExpandLessIcon /> : <ExpandMoreIcon />}
              </IconButton>
            </Stack>
          </Stack>

          <Collapse in={collapseOpen}>
            <MaterialReactTable
              columns={columns}
              data={data}
              state={{ isLoading: loading, showProgressBars: loading }}
              enableColumnActions={false}
              enableDensityToggle={false}
              enableHiding={false}
              enableFullScreenToggle={false}
              enableToolbarInternalActions={false}
              enableGlobalFilter={false}
              initialState={{
                pagination: { pageIndex: 0, pageSize: PAGE_SIZE },
              }}
              muiTablePaperProps={{
                elevation: 0,
                sx: { boxShadow: "none", border: "none" },
              }}
              muiTableContainerProps={{
                sx: {
                  border: "none",
                  "& .MuiTableRow-root, & .MuiTableCell-root": {
                    borderBottom: "none",
                  },
                },
              }}
              muiTableHeadProps={{ sx: { display: "none" } }}
              muiTableBodyProps={{ sx: { paddingTop: 0 } }}
            />
          </Collapse>
        </WidgetMainContainer>
      </Grid>

      <CreateSolutionModal
        open={addOpen}
        onClose={() => {
          setAddOpen(false);
          fetchSolutions();
        }}
      />

      {selected && (
        <EditSolutionModal
          open={editOpen}
          onClose={() => setEditOpen(false)}
          solutionId={selected.solution_id}
          currentName={selected.solution_name}
          onSuccess={fetchSolutions}
        />
      )}

      <Snackbar
        open={snack.open}
        autoHideDuration={3000}
        onClose={() => setSnack((s) => ({ ...s, open: false }))}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <MuiAlert severity={snack.severity} variant="filled">
          {snack.msg}
        </MuiAlert>
      </Snackbar>
    </Grid>
  );
};

export default SolutionSection;
