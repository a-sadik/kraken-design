import { useState, useEffect } from "react";
import { Modal, Card, CardContent, Typography, Box, Button, Stack, IconButton, Divider } from "@mui/material";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import NavigateBeforeIcon from "@mui/icons-material/NavigateBefore";
import CloseIcon from "@mui/icons-material/Close";
import CampaignIcon from "@mui/icons-material/Campaign";
import { keycloak } from "@/auth/keycloakConnectAdapter";
import { Communications_URL } from "@/config/api.config";

// Interfaces pour les annonces
interface Priority {
  id: number;
  name: string;
}

interface Status {
  id: number;
  name: string;
}

interface Announcement {
  id: number;
  title: string;
  message: string;
  author: string;
  published_at: string;
  expires_at: string | null;
  priority: Priority;
  status: Status;
  priority_id: number;
  status_id: number;
  tags: string[];
  draft: boolean;
}

// Couleurs Attijariwafa Bank solides
const attijariColors = {
  orange: '#FF6B00',     // Orange principal
  red: '#E30613',        // Rouge
  dark: '#000000',       // Noir
  light: '#FFFFFF',      // Blanc
  white: '#FFFFFF',
  gray: '#6C757D',       // Gris moyen
  lightGray: '#F5F5F5'   // Gris clair
};

// Hook personnalisé pour les annonces
const useAnnouncements = () => {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchAnnouncements = async () => {
      try {
        setLoading(true);
        const response = await fetch(Communications_URL(),
          {
            method: "GET",
            headers: {
              "accept": "application/json",
              "X-CSRFTOKEN": "s5KOCOBSgVNM6VUvI3p3zRwRGmtVZDIv"
            }
          }
        );

        if (response.ok) {
          const data: Announcement[] = await response.json();
          const activeAnnouncements = data.filter((announcement: Announcement) => {
            const now = new Date();
            const expiresAt = announcement.expires_at ? new Date(announcement.expires_at) : null;
            return !announcement.draft && (!expiresAt || expiresAt > now);
          });

          // TRIER LES ANNONCES PAR PRIORITÉ (Haute > Moyenne > Basse)
          const sortedAnnouncements = activeAnnouncements.sort((a, b) => {
            // Map pour les poids de priorité
            const priorityWeights = new Map<number, number>([
              [3, 1], // Haute = poids 1
              [1, 2], // Moyenne = poids 2
              [2, 3]  // Basse = poids 3
            ]);

            const priorityA = priorityWeights.get(a.priority.id) || 4;
            const priorityB = priorityWeights.get(b.priority.id) || 4;

            return priorityA - priorityB;
          });

          setAnnouncements(sortedAnnouncements);
        } else {
          setError('Erreur lors du chargement des annonces');
        }
      } catch (err) {
        setError('Erreur de connexion');
      } finally {
        setLoading(false);
      }
    };

    fetchAnnouncements();
  }, []);

  return { announcements, loading, error };
};

// Composant Popup d'annonces
const AnnouncementPopup = ({ announcements, onClose }: { announcements: Announcement[], onClose: () => void }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  // Fonction pour obtenir la couleur selon la priorité
  const getPriorityColor = (priorityId: number) => {
    switch (priorityId) {
      case 3: // Haute
        return '#E30613'; // Rouge Attijari
      case 1: // Moyenne
        return '#FF6B00'; // Orange Attijari
      case 2: // Basse
        return '#6C757D'; // Gris
      default:
        return '#6C757D';
    }
  };

  // Fonction pour obtenir la couleur de fond selon la priorité
  const getPriorityBgColor = (priorityId: number) => {
    switch (priorityId) {
      case 3: // Haute
        return 'rgba(227, 6, 19, 0.08)'; // Rouge très clair
      case 1: // Moyenne
        return 'rgba(255, 107, 0, 0.08)'; // Orange très clair
      case 2: // Basse
        return 'rgba(108, 117, 125, 0.08)'; // Gris très clair
      default:
        return 'rgba(108, 117, 125, 0.08)';
    }
  };

  // Fonction pour obtenir le texte de priorité
  const getPriorityText = (priorityName: string) => {
    switch (priorityName) {
      case 'Haute':
        return 'Annonce importante';
      case 'Moyenne':
        return 'Annonce moyenne';
      case 'Basse':
        return 'Annonce informative';
      default:
        return 'Annonce';
    }
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % announcements.length);
  };

  const handlePrevious = () => {
    setCurrentIndex((prev) => (prev - 1 + announcements.length) % announcements.length);
  };

  const currentAnnouncement = announcements[currentIndex];
  const currentPriorityColor = getPriorityColor(currentAnnouncement.priority.id);
  const currentPriorityBgColor = getPriorityBgColor(currentAnnouncement.priority.id);
  const currentPriorityText = getPriorityText(currentAnnouncement.priority.name);

  return (
    <Modal
      open={true}
      onClose={onClose}
      aria-labelledby="announcement-modal"
      sx={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backdropFilter: 'blur(4px)',
        backgroundColor: 'rgba(0, 0, 0, 0.6)'
      }}
    >
      <Card
        sx={{
          maxWidth: 500,
          width: '95%',
          maxHeight: '85vh',
          overflow: 'hidden',
          borderRadius: 2,
          boxShadow: '0 10px 40px rgba(0, 0, 0, 0.2)',
          border: `2px solid ${currentPriorityColor}`
        }}
      >
        {/* En-tête avec couleur dynamique selon la priorité */}
        <Box
          sx={{
            backgroundColor: currentPriorityColor,
            color: attijariColors.white,
            py: 2,
            px: 3,
            position: 'relative'
          }}
        >
          <Stack direction="row" alignItems="center" spacing={2}>
            <CampaignIcon sx={{ fontSize: 28 }} />
            <Box flex={1}>
              <Typography variant="h6" sx={{ fontWeight: 600, fontSize: '1.1rem' }}>
                Communication Attijariwafa Bank
              </Typography>
              <Typography variant="body2" sx={{ opacity: 0.9, fontSize: '0.85rem' }}>
                {currentPriorityText}
              </Typography>
            </Box>
            <IconButton
              onClick={onClose}
              sx={{
                color: attijariColors.white,
                '&:hover': {
                  backgroundColor: 'rgba(255, 255, 255, 0.2)'
                }
              }}
            >
              <CloseIcon />
            </IconButton>
          </Stack>
        </Box>

        <CardContent sx={{ p: 0, backgroundColor: attijariColors.light }}>
          {/* Contenu principal */}
          <Box sx={{ px: 3, py: 2 }}>
            <Stack direction="row" justifyContent="space-between" alignItems="flex-start" spacing={2}>
              <Typography
                variant="h5"
                sx={{
                  fontWeight: 600,
                  color: attijariColors.dark,
                  mb: 2,
                  lineHeight: 1.3,
                  flex: 1
                }}
              >
                {currentAnnouncement.title}
              </Typography>

              {/* Badge de priorité */}
              <Box
                sx={{
                  backgroundColor: currentPriorityBgColor,
                  color: currentPriorityColor,
                  px: 2,
                  py: 0.5,
                  borderRadius: 1,
                  border: `1px solid ${currentPriorityColor}`,
                  fontSize: '0.75rem',
                  fontWeight: 600,
                  whiteSpace: 'nowrap'
                }}
              >
                Priorité {currentAnnouncement.priority.name}
              </Box>
            </Stack>

            <Box
              sx={{
                backgroundColor: currentPriorityBgColor,
                borderRadius: 1,
                p: 2.5,
                border: `1px solid ${currentPriorityColor}`
              }}
            >
              <Typography
                variant="body1"
                sx={{
                  lineHeight: 1.6,
                  color: attijariColors.dark,
                  fontSize: '0.95rem'
                }}
              >
                {currentAnnouncement.message}
              </Typography>
            </Box>
          </Box>

          <Divider />

          {/* Métadonnées */}
          <Box sx={{ px: 3, py: 2, backgroundColor: attijariColors.light }}>
            <Stack spacing={1.5}>
              <Stack direction="row" spacing={3}>
                <Box>
                  <Typography variant="caption" sx={{ color: attijariColors.gray, fontWeight: 600, display: 'block' }}>
                    Auteur
                  </Typography>
                  <Typography variant="body2" sx={{ color: attijariColors.dark, fontWeight: 500 }}>
                    {currentAnnouncement.author}
                  </Typography>
                </Box>
                <Box>
                  <Typography variant="caption" sx={{ color: attijariColors.gray, fontWeight: 600, display: 'block' }}>
                    Publication
                  </Typography>
                  <Typography variant="body2" sx={{ color: attijariColors.dark, fontWeight: 500 }}>
                    {new Date(currentAnnouncement.published_at).toLocaleDateString('fr-FR', {
                      day: '2-digit',
                      month: '2-digit',
                      year: 'numeric'
                    })}
                  </Typography>
                </Box>
              </Stack>

              {/* {currentAnnouncement.expires_at && (
                <Box>
                  <Typography variant="caption" sx={{ color: currentPriorityColor, fontWeight: 600, display: 'block' }}>
                    Expire le
                  </Typography>
                  <Typography variant="body2" sx={{ color: currentPriorityColor, fontWeight: 500 }}>
                    {new Date(currentAnnouncement.expires_at).toLocaleDateString('fr-FR', {
                      day: '2-digit',
                      month: '2-digit',
                      year: 'numeric'
                    })}
                  </Typography>
                </Box>
              )} */}
            </Stack>
          </Box>

          {/* Pied de page avec navigation */}
          <Box
            sx={{
              backgroundColor: attijariColors.lightGray,
              px: 3,
              py: 2,
              borderTop: `1px solid #E0E0E0`
            }}
          >
            <Stack direction="row" justifyContent="space-between" alignItems="center">
              {/* Navigation */}
              {announcements.length > 1 && (
                <Stack direction="row" alignItems="center" spacing={1}>
                  <IconButton
                    size="small"
                    onClick={handlePrevious}
                    sx={{
                      border: `1px solid ${currentPriorityColor}`,
                      borderRadius: 1,
                      width: 32,
                      height: 32,
                      color: currentPriorityColor
                    }}
                  >
                    <NavigateBeforeIcon sx={{ fontSize: 18 }} />
                  </IconButton>

                  <Typography variant="body2" sx={{ color: attijariColors.gray, minWidth: 60, textAlign: 'center' }}>
                    {currentIndex + 1} / {announcements.length}
                  </Typography>

                  <IconButton
                    size="small"
                    onClick={handleNext}
                    sx={{
                      border: `1px solid ${currentPriorityColor}`,
                      borderRadius: 1,
                      width: 32,
                      height: 32,
                      color: currentPriorityColor
                    }}
                  >
                    <NavigateNextIcon sx={{ fontSize: 18 }} />
                  </IconButton>
                </Stack>
              )}

              {/* Espace flexible pour pousser le bouton à droite */}
              <Box flex={1} />

              {/* Bouton de fermeture */}
              <Button
                variant="contained"
                onClick={onClose}
                sx={{
                  backgroundColor: currentPriorityColor,
                  color: attijariColors.white,
                  borderRadius: 1,
                  px: 3,
                  py: 1,
                  fontWeight: 600,
                  textTransform: 'none',
                  fontSize: '0.9rem',
                  border: `1px solid ${currentPriorityColor}`,
                  '&:hover': {
                    backgroundColor: currentPriorityColor,
                    filter: 'brightness(0.9)'
                  }
                }}
              >
                J'ai compris
              </Button>
            </Stack>
          </Box>
        </CardContent>
      </Card>
    </Modal>
  );
};

// Composant principal qui gère l'affichage global
const GlobalAnnouncements = () => {
  const { announcements } = useAnnouncements();
  const [showPopup, setShowPopup] = useState(false);

  useEffect(() => {
    // Vérifier si l'utilisateur est authentifié et n'a pas encore vu les annonces
    if (keycloak.isAuthenticated()) {
      const announcementsShown = sessionStorage.getItem('announcementsShown');

      // Afficher le popup seulement si il y a des annonces et qu'elles n'ont pas été vues
      if (announcements.length > 0 && announcementsShown !== 'true') {
        setShowPopup(true);
        sessionStorage.setItem('announcementsShown', 'true');
      }
    }
  }, [announcements, keycloak.isAuthenticated()]);

  if (!showPopup) return null;

  return (
    <AnnouncementPopup
      announcements={announcements}
      onClose={() => setShowPopup(false)}
    />
  );
};

export default GlobalAnnouncements;