// src/types/view/CertificateView.ts

export default interface CertificateView {
  audit?: boolean;
  created_at?: string;
  type?: string;
  exp_date?: string;

  id: number;
  "Réf de ticket iTop": string;
  id_itop_ticket: string; // not visible at ui just for create link to itop platform
  Référence: string;
  "Interne/Externe": string;
  "Statut de la demande": string[];
  "Common Name": string;
  "Statut de ticket": string;
  Demandeur: string;
  Validateur: string;
  "Date d'expiration": string;
  "Date de création": string;
  Solution: string;
  Dns: string[];
  is_renewed: boolean; // not visible at ui just for create visibilty button
}
