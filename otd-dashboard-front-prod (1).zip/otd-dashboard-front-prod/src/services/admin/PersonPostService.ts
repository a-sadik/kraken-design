import { AxiosError } from "axios";

import {
  AssignPostsRequestDTO,
  // PersonPostShortResponseDTO,
} from "@/types/dto/PersonPostDTO";

import { PostShortResponseDTO } from "@/types/dto/PostDTO";
import apiClient from "../apiClientHttp";
import { ErrorResponse } from "@/exceptions/ErrorResponse";

const Path = "/person-post";

export const assignPostsToPerson = async (
  personId: number,
  dto: AssignPostsRequestDTO,
): Promise<{ message: string; posts: PostShortResponseDTO[] }> => {
  try {
    const { data } = await apiClient.dataApiClient.post<{
      message: string;
      posts: PostShortResponseDTO[];
    }>(`${Path}/persons/${personId}`, dto);

    return data; // { message: '...', posts:[...] }
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;
    console.error("Error assigning posts:", err.response?.data.message);
    throw err;
  }
};

export const getPostsOfPerson = async (
  personId: number,
): Promise<PostShortResponseDTO[]> => {
  try {
    const { data } = await apiClient.dataApiClient.get<PostShortResponseDTO[]>(
      `${Path}/persons/${personId}/posts`,
    );
    return data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;
    console.error("Error fetching person posts:", err.response?.data.message);
    throw err;
  }
};

export const deletePersonPost = async (personPostId: number): Promise<void> => {
  try {
    await apiClient.dataApiClient.delete<void>(`${Path}/${personPostId}`);
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;
    console.error(
      "Error deleting person-post row:",
      err.response?.data.message,
    );
    throw err;
  }
};
