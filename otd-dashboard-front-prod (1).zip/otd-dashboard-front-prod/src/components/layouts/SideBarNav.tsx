// src/components/layouts/Sidebar.tsx

import { Link, useLocation } from "react-router-dom";
import routes, { PageTitle } from "../../routes";
import { keycloak } from "@/auth/keycloakConnectAdapter";

export default function Sidebar() {
  const location = useLocation();

  const buttonPage = (route: any, index: number) =>
    route.showInNave && (
      <li className="menu--item" key={index}>
        <Link
          to={route.path}
          className={location.pathname === route.path ? "active" : ""}
        >
          {route.icon}
          <span className="menu--item__text">{route.title}</span>
        </Link>
      </li>
    );

  return (
    <aside className="nav-container" style={{ width: "7rem" }}>
      <nav className="main-nav">
        <ul className="nav text-center">
          {keycloak.hasRoles("kraken_role") &&
            routes.map((route, index) => {
              // 🟦 1. Rôle self_service_certificate_role
              if (
                keycloak.hasRoles("self_service_certificate_role") &&
                (route.title === PageTitle.SELF_SERVICE ||
                  route.title === PageTitle.CERTIFICATES)
              ) {
                return buttonPage(route, index);
              }

              // 🟩 2. Rôle admin
              if (keycloak.hasRoles("admin_role")) {
                return buttonPage(route, index);
              }

              // 🟨 3. Rôle vision 360
              if (
                keycloak.hasRoles("vision_360_read_only_role") &&
                route.title === "Vision 360"
              ) {
                return buttonPage(route, index);
              }

              // 🟧 4. Rôle tam
              if (
                keycloak.hasRoles("tam_role") &&
                route.title === "Référentiel Apps"
              ) {
                return buttonPage(route, index);
              }

              // 🟪 5. Rôle read_only
              if (
                keycloak.hasRoles("read_only_role") &&
                (route.title === PageTitle.Cockpit ||
                  route.title === PageTitle.Cockpit_certif ||
                  route.title === PageTitle.SERVERS_SIGNATURE ||
                  route.title === PageTitle.Cockpits ||
                  // route.title === "Vision 360" ||
                  route.title === PageTitle.CERTIFICATES ||
                  route.title === PageTitle.MY_VIEW)
              ) {
                return buttonPage(route, index);
              }

              // 🔵 6. Rôle ops ou tam
              if (
                (keycloak.hasRoles("ops_role") ||
                  keycloak.hasRoles("tam_role")) &&
                (route.title === PageTitle.Cockpit ||
                  route.title === PageTitle.SELF_SERVICE ||
                  route.title === PageTitle.CERTIFICATES ||
                  // route.title === "Vision 360" ||
                  route.title === PageTitle.SERVERS_SIGNATURE ||
                  route.title === PageTitle.MY_VIEW) ||
                route.title === PageTitle.CAB
              ) {
                return buttonPage(route, index);
              }

              // 🟤 7. Rôle dev
              if (
                keycloak.hasRoles("dev_role") &&
                route.title === PageTitle.SERVERS_SIGNATURE
              ) {
                return buttonPage(route, index);
              }

              // 🔴 8. Rôle security
              if (
                keycloak.hasRoles("security_role") &&
                (route.title === PageTitle.Cockpit ||
                  route.title === PageTitle.SELF_SERVICE ||
                  route.title === PageTitle.CERTIFICATES)
              ) {
                return buttonPage(route, index);
              }

              // 🔴 9. Rôle release
              if (
                keycloak.hasRoles("self_service_release_role") &&
                (route.title === PageTitle.SELF_SERVICE)
              ) {
                return buttonPage(route, index);
              }

              // 🟫 10. Rôle my_view
              if (
                keycloak.hasRoles("my_view_role") &&
                (route.title === PageTitle.MY_VIEW)
              ) {
                return buttonPage(route, index);
              }

              return null;
            })}
        </ul>
      </nav>
    </aside>
  );
}
