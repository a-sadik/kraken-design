import { useEffect, useState } from "react";
import {
  Box,
  Typography,
  Divider,
  Link,
  Tooltip,
  Chip,
  Paper,
} from "@mui/material";

import {
  Timeline,
  TimelineItem,
  TimelineSeparator,
  TimelineConnector,
  TimelineContent,
  TimelineDot,
  TimelineOppositeContent,
} from "@mui/lab";

// import files
import MyModal from "./MyModal";
import { getFormatedDate } from "@/utils";
import { isInvalid } from "../../utils/validationEnvVar";

// import icons
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import PauseCircleFilledIcon from "@mui/icons-material/PauseCircleFilled";
import ErrorIcon from "@mui/icons-material/Error";
import ScheduleIcon from "@mui/icons-material/Schedule";
import AssignmentIcon from "@mui/icons-material/Assignment";
import DescriptionIcon from "@mui/icons-material/Description";
import PersonIcon from "@mui/icons-material/Person";
import EditIcon from "@mui/icons-material/Edit";
import EventNoteIcon from "@mui/icons-material/EventNote";
import WarningIcon from "@mui/icons-material/Warning";

import { AuditDetailDTO } from "@/types/dto/AuditDTO";
import { getCertificateById } from "@/services/CertificateService";
import { CertificateDetailResponseDTO } from "@/types/dto/response/CertificateResponseDTO";

const V_ITOP_TICKET_ID_URL = import.meta.env.VITE_ITOP_TICKET_ID_URL;

const requiredEnvVars = [
  { key: "ITOP_TICKET_ID_URL", value: V_ITOP_TICKET_ID_URL },
];

requiredEnvVars.forEach(({ key, value }) => {
  if (isInvalid(value)) {
    console.error(
      `Environment variable of iTop '${key}' is missing or invalid.`,
    );
    process.exit(1);
  }
});

interface DisplayCertificateModalProps {
  open: boolean;
  onClose: () => void;
  title: string;
  data: AuditDetailDTO[];
}

interface TimelineItemData {
  date: string;
  title: string;
  subtitle: string;
  content: string;
  icon: React.ReactNode;
  color: string;
  backgroundColor: string;
}

const DisplayCertificateModal = ({
  open,
  onClose,
  title,
  data,
}: DisplayCertificateModalProps) => {
  const [certificateById, setCertificateById] =
    useState<CertificateDetailResponseDTO | null>(null);
  const [timelineItems, setTimelineItems] = useState<TimelineItemData[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [certificateInfo, setCertificateInfo] = useState<any>(null);
  const [expirationDate, setExpirationDate] = useState<string | null>(null);

  const handleDisplayCertificateButton = async () => {
    try {
      setLoading(true);
      if (data && data.length > 0) {
        const certId = data[0]?.item_ids[0] || 0;
        const result = await getCertificateById(certId);
        setCertificateById(result);

        // Get the latest state from the audit data
        const latestAudit = data[data.length - 1];
        const certInfo = {
          ...latestAudit?.new_value,
          common_name:
            latestAudit?.new_value?.common_name ||
            data[0]?.new_value?.common_name,
          dns: latestAudit?.new_value?.dns || data[0]?.new_value?.dns,
          solution:
            latestAudit?.new_value?.solution || data[0]?.new_value?.solution,
          certificate_type:
            latestAudit?.new_value?.certificate_type ||
            data[0]?.new_value?.certificate_type,
          config_file:
            latestAudit?.new_value?.config_file ||
            data[0]?.new_value?.config_file,
          certificate_request_ref:
            latestAudit?.new_value?.certificate_request_ref ||
            data[0]?.new_value?.certificate_request_ref,
          certificate_target: result?.certificate_target,
        };

        setCertificateInfo(certInfo);

        // Extract expiration date
        // if (latestAudit?.new_value?.exp_date) {
        //   setExpirationDate(latestAudit.new_value.exp_date);
        // }
        if (certificateById?.exp_date) {
          setExpirationDate(certificateById.exp_date);
        }

        buildTimelineItems(result, data);
      }
    } catch (error) {
      console.error("Failed to fetch certificate data by ID:", error);
    } finally {
      setLoading(false);
    }
  };

  const buildTimelineItems = (
    certificate: CertificateDetailResponseDTO | null,
    auditData: AuditDetailDTO[],
  ) => {
    if (!certificate || !auditData || auditData.length === 0) return;

    const items: TimelineItemData[] = [];

    // Sort audit entries by operation_at date
    const sortedAuditData = [...auditData].sort(
      (a, b) =>
        new Date(a.operation_at).getTime() - new Date(b.operation_at).getTime(),
    );

    // First entry - initial creation
    const initialAudit = sortedAuditData[0];
    if (initialAudit.action_type === "Création") {
      items.push({
        date: getFormatedDate(initialAudit.operation_at),
        title: "Demande de certificat",
        subtitle: `Par ${initialAudit.agent.firstname} ${initialAudit.agent.lastname}`,
        content: initialAudit.action_description,
        icon: <PersonIcon />,
        color: "primary",
        backgroundColor: "#e3f2fd", // Light blue
      });

      // iTop ticket creation - add this right after creation
      if (certificate?.itop_ticket_ref) {
        items.push({
          date: getFormatedDate(initialAudit.operation_at),
          title: "Création du ticket iTop",
          subtitle: certificate.itop_ticket_ref,
          content: `Ticket de référence: ${certificate.itop_ticket_ref}`,
          icon: <AssignmentIcon />,
          color: "warning",
          backgroundColor: "#fff8e1", // Light amber
        });
      }

      // Certificate request reference
      const certRef = initialAudit?.new_value?.certificate_request_ref;
      if (certRef) {
        items.push({
          date: getFormatedDate(initialAudit.operation_at),
          title: "Référence du certificat",
          subtitle: certRef,
          content: `Cible: ${certificate?.certificate_target || "Non définie"}`,
          icon: <DescriptionIcon />,
          color: "info",
          backgroundColor: "#e8f5e9", // Light green
        });
      }
    }

    // Process each audit entry for status changes
    for (let i = 0; i < sortedAuditData.length; i++) {
      const audit = sortedAuditData[i];

      // Skip the first entry if it's creation - we already handled it
      if (i === 0 && audit.action_type === "Création") continue;

      // Handle status changes
      if (
        audit.action_type === "Modifier" &&
        audit.new_value &&
        (audit.new_value.ticket_state || audit.new_value.certificate_state)
      ) {
        const getStatusIcon = () => {
          const ticketState = audit.new_value.ticket_state;
          if (ticketState === "Rejeter") return <ErrorIcon />;
          if (ticketState === "Fermer") return <CheckCircleIcon />;
          if (ticketState === "En attente") return <PauseCircleFilledIcon />;
          return <EditIcon />;
        };

        const getStatusColor = () => {
          const ticketState = audit.new_value.ticket_state;
          if (ticketState === "Rejeter") return "error";
          if (ticketState === "Fermer") return "success";
          if (ticketState === "En attente") return "warning";
          return "info";
        };

        const getCardColor = () => {
          const ticketState = audit.new_value.ticket_state;
          if (ticketState === "Rejeter") return "#ffebee"; // Light red
          if (ticketState === "Fermer") return "#e8f5e9"; // Light green
          if (ticketState === "En attente") return "#fff8e1"; // Light amber
          return "#f5f5f5"; // Light grey
        };

        let cardTitle = "Mise à jour du statut";
        let cardDetailedText = audit.action_description;

        if (audit.new_value.ticket_state === "En attente") {
          cardTitle = "Mise en attente";
        } else if (audit.new_value.ticket_state === "Fermer") {
          cardTitle = "Validation du certificat";
        } else if (audit.new_value.ticket_state === "Rejeter") {
          cardTitle = "Rejet du certificat";
        }

        items.push({
          date: getFormatedDate(audit.operation_at),
          title: cardTitle,
          subtitle: `Par ${audit.agent.firstname} ${audit.agent.lastname}`,
          content: audit.new_value.action_comment
            ? `${cardDetailedText}\nCommentaire: ${audit.new_value.action_comment}`
            : cardDetailedText,
          icon: getStatusIcon(),
          color: getStatusColor(),
          backgroundColor: getCardColor(),
        });
      }
    }

    setTimelineItems(items);
  };

  useEffect(() => {
    if (data && data.length > 0) {
      handleDisplayCertificateButton();
    }
  }, [data]);

  // Status styles for badges
  const requestStatusStyles = {
    etapeEnCours: {
      backgroundColor: "#fff", // Jaune
      color: "#F5B62E",
      border: "1px solid #ffc107",
    },
    etapeTerminee: {
      backgroundColor: "#fff", // Vert
      color: "#6bcd3a",
      border: "1px solid #6bcd3a",
    },
    etapeRejeter: {
      backgroundColor: "#fff", // Vert
      color: "#cc3300",
      border: "1px solid #cc3300",
    },
    etapeAvenir: {
      backgroundColor: "#f8f9fa", // Gris clair
      color: "#6c757d",
      border: "1px solid #dee2e6",
    },
  };

  const getStatusChipStyle = (state: string | undefined) => {
    if (!state) return requestStatusStyles.etapeAvenir;
    switch (state) {
      case "Activer":
        return requestStatusStyles.etapeTerminee;
      case "En cours":
        return requestStatusStyles.etapeEnCours;
      case "Mettre en attente":
        return requestStatusStyles.etapeEnCours;
      case "En cours de signature":
        return requestStatusStyles.etapeEnCours;
      case "Rejeter":
        return requestStatusStyles.etapeRejeter;
      default:
        return requestStatusStyles.etapeAvenir;
    }
  };

  // Calculate days until expiration
  const getDaysUntilExpiration = () => {
    if (!expirationDate) return null;
    const expDate = new Date(expirationDate);
    const today = new Date();
    const diffTime = expDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  // Get expiration status color
  const getExpirationStatusColor = () => {
    const daysLeft = getDaysUntilExpiration();
    if (daysLeft === null) return "default";
    if (daysLeft <= 0) return "error";
    if (daysLeft <= 30) return "warning";
    return "success";
  };

  // Render the expiration date component
  const renderExpirationDate = () => {
    if (!expirationDate) return null;

    const daysLeft = getDaysUntilExpiration();
    const statusColor = getExpirationStatusColor();

    return (
      <Box
        sx={{
          display: "flex",
          flexDirection: { xs: "column", sm: "row" },
          alignItems: "center",
          justifyContent: "center",
          gap: 2,
          p: 2,
          borderRadius: 1,
          bgcolor:
            statusColor === "error"
              ? "#ffebee"
              : statusColor === "warning"
                ? "#fff8e1"
                : "#e8f5e9",
          border: 1,
          borderColor:
            statusColor === "error"
              ? "#ffcdd2"
              : statusColor === "warning"
                ? "#ffe082"
                : "#c8e6c9",
          my: 2,
        }}
      >
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <ScheduleIcon color="warning" />
          <Typography variant="subtitle1" fontWeight="bold">
            Date d'expiration: {getFormatedDate(expirationDate)}
          </Typography>
        </Box>

        {daysLeft !== null && (
          <Chip
            label={
              daysLeft <= 0
                ? "Certificat expiré"
                : `${daysLeft} jour${daysLeft > 1 ? "s" : ""} restant${daysLeft > 1 ? "s" : ""}`
            }
            color={statusColor}
            icon={daysLeft <= 30 ? <WarningIcon /> : undefined}
          />
        )}
      </Box>
    );
  };

  return (
    <MyModal
      mainColor="--certifcate-main-color"
      open={open}
      onClose={onClose}
      title={title}
      data={data || {}}
    >
      {data && data.length > 0 && certificateInfo ? (
        <Box sx={{ width: "100%", maxWidth: "800px" }}>
          {/* Header */}
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              mb: 2,
            }}
          >
            <Typography variant="h6">Informations du certificat</Typography>
          </Box>

          {/* Informations Générales avec statut */}
          <Box sx={{ mb: 3, display: "flex", flexDirection: "column", gap: 2 }}>
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "flex-start",
              }}
            >
              <Typography variant="h6">État du certificat</Typography>
              <Chip
                label={
                  certificateInfo.certificate_state || "En cours de traitement"
                }
                sx={{
                  fontWeight: "bold",
                  ...getStatusChipStyle(certificateInfo.certificate_state),
                }}
              />
            </Box>

            <Box
              sx={{
                display: "grid",
                gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
                gap: 2,
              }}
            >
              <Box>
                <Typography variant="subtitle2" color="textSecondary">
                  Solution
                </Typography>
                <Typography variant="body1">
                  {certificateById?.solution.solution_name || "N/A"}
                </Typography>
              </Box>

              <Box>
                <Typography variant="subtitle2" color="textSecondary">
                  Type
                </Typography>
                <Typography variant="body1">
                  {certificateInfo.certificate_type || "N/A"}
                </Typography>
              </Box>

              <Box>
                <Typography variant="subtitle2" color="textSecondary">
                  Common Name
                </Typography>
                <Typography variant="body1">
                  {certificateInfo.common_name || "N/A"}
                </Typography>
              </Box>

              <Box>
                <Typography variant="subtitle2" color="textSecondary">
                  Référence
                </Typography>
                <Typography variant="body1">
                  {certificateInfo.certificate_request_ref || "N/A"}
                </Typography>
              </Box>

              <Box>
                <Typography variant="subtitle2" color="textSecondary">
                  Cible
                </Typography>
                <Typography variant="body1">
                  {certificateInfo.certificate_target || "N/A"}
                </Typography>
              </Box>
            </Box>

            {/* DNS Section */}
            {certificateInfo.dns && certificateInfo.dns.length > 0 && (
              <Box>
                <Typography variant="subtitle2" color="textSecondary">
                  DNS
                </Typography>
                <Box sx={{ pl: 2, mt: 1 }}>
                  {certificateInfo.dns.map((dns: string, index: number) => (
                    <Typography key={index} variant="body2" sx={{ mb: 0.5 }}>
                      {index + 1}. {dns}
                    </Typography>
                  ))}
                </Box>
              </Box>
            )}
          </Box>

          <Divider sx={{ my: 2 }} />

          {/* Expiration Date Display - en haut */}
          {expirationDate && renderExpirationDate()}

          {/* Timeline */}
          <Typography
            variant="h6"
            sx={{ mb: 2, display: "flex", alignItems: "center", gap: 1 }}
          >
            <EventNoteIcon /> Historique du certificat
          </Typography>

          <Box sx={{ height: "450px", width: "100%", overflow: "auto" }}>
            {loading ? (
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  height: "100%",
                }}
              >
                <Typography>Chargement des données...</Typography>
              </Box>
            ) : timelineItems.length > 0 ? (
              <Timeline
                position="alternate"
                sx={{
                  padding: 0,
                  [`& .MuiTimelineConnector-root`]: {
                    backgroundColor: "#bdbdbd",
                  },
                }}
              >
                {timelineItems.map((item, index) => (
                  <TimelineItem key={index}>
                    <TimelineOppositeContent color="text.secondary">
                      <Typography
                        variant="body2"
                        sx={{
                          fontWeight: "medium",
                        }}
                      >
                        {item.date}
                      </Typography>
                    </TimelineOppositeContent>

                    <TimelineSeparator>
                      <TimelineDot color={item.color as any}>
                        {item.icon}
                      </TimelineDot>
                      {index < timelineItems.length - 1 && (
                        <TimelineConnector />
                      )}
                    </TimelineSeparator>

                    <TimelineContent>
                      <Paper
                        elevation={1}
                        sx={{
                          p: 2,
                          backgroundColor: item.backgroundColor,
                          mb: 3,
                        }}
                      >
                        <Typography
                          variant="h6"
                          sx={{
                            color: "#0073e6",
                          }}
                        >
                          {item.title}
                        </Typography>
                        <Typography
                          variant="subtitle1"
                          sx={{
                            fontWeight: "medium",
                          }}
                        >
                          {item.subtitle}
                        </Typography>
                        <Typography
                          variant="body2"
                          sx={{
                            mt: 1,
                            color: "text.secondary",
                          }}
                        >
                          {item.content}
                        </Typography>
                      </Paper>
                    </TimelineContent>
                  </TimelineItem>
                ))}
              </Timeline>
            ) : (
              <Typography>Aucun historique disponible</Typography>
            )}
          </Box>

          {/* iTop Ticket Link */}
          {certificateById?.itop_ticket_ref && (
            <Box sx={{ textAlign: "center", mt: 3 }}>
              <Tooltip title="Ouvrir le ticket iTop">
                <Link
                  color="primary"
                  href={`${V_ITOP_TICKET_ID_URL}=${certificateById?.itop_ticket_num}`}
                  underline="always"
                  rel="noopener"
                  target="_blank"
                  sx={{ display: "inline-flex", alignItems: "center", gap: 1 }}
                >
                  <AssignmentIcon fontSize="small" />
                  <Typography variant="subtitle1">
                    {certificateById?.itop_ticket_ref}
                  </Typography>
                </Link>
              </Tooltip>
            </Box>
          )}

          {/* Configuration File Details */}
          {certificateInfo.config_file &&
            Object.keys(certificateInfo.config_file).length > 0 && (
              <>
                <Divider sx={{ my: 3 }} />
                <Typography variant="h6" sx={{ mb: 2 }}>
                  Détails de configuration
                </Typography>
                <Box
                  sx={{
                    display: "grid",
                    gridTemplateColumns:
                      "repeat(auto-fill, minmax(180px, 1fr))",
                    gap: 2,
                    bgcolor: "#f9f9f9",
                    p: 2,
                    borderRadius: 1,
                  }}
                >
                  {Object.entries(certificateInfo.config_file).map(
                    ([key, value]) => (
                      <Box key={key} sx={{ mb: 1 }}>
                        <Typography
                          variant="subtitle2"
                          sx={{ fontWeight: "bold", color: "primary.main" }}
                        >
                          {key}
                        </Typography>
                        <Typography variant="body2" color="textSecondary">
                          {value as string}
                        </Typography>
                      </Box>
                    ),
                  )}
                </Box>
              </>
            )}
        </Box>
      ) : (
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            p: 4,
          }}
        >
          <Typography>Aucune donnée disponible</Typography>
        </Box>
      )}
    </MyModal>
  );
};

export default DisplayCertificateModal;
