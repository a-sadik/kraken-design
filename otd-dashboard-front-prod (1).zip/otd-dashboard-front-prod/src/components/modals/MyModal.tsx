// src/components/modals/MyModal.tsx

import React from "react";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  IconButton,
  Typography,
  Divider,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";

// Import files
import { getCssVariableValue } from "@/utils/getDynamicColor";

interface MyModalProps {
  open: boolean;
  onClose: () => void;
  title: string;
  mainColor?: string;
  data?: Record<string, any>;
  children: React.ReactNode; // Accepter les enfants comme un formulaire dynamique
}

const MyModal: React.FC<MyModalProps> = ({
  open,
  onClose,
  title,
  mainColor = "--primary-color",
  children,
}) => {
  const customTheme = createTheme({
    palette: {
      primary: { main: getCssVariableValue(mainColor) },
    },
  });

  return (
    <Dialog
      open={open}
      onClose={onClose}
      sx={{
        "& .MuiPaper-root": {
          overflowY: "visible", // Désactive le scrolling dans le modal
        },
      }}
    >
      <DialogTitle
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          position: "relative",
          background: `var(${mainColor})`,
          padding: "16px",
        }}
      >
        <Typography
          sx={{
            fontWeight: "bold",
            fontSize: { xs: "1.5rem", sm: "2rem", md: "2.5rem", lg: "1.5rem" },
            mx: "3rem",
            width: "100%",
          }}
        >
          {title}
        </Typography>
        <IconButton
          aria-label="close"
          onClick={onClose}
          sx={{ position: "absolute", right: 8, top: 8, padding: 0 }}
        >
          <CloseIcon />
        </IconButton>
      </DialogTitle>

      <Divider />

      <DialogContent>
        <ThemeProvider theme={customTheme}>
          {children} {/* Affichez ici le composant dynamique passé en enfant */}
        </ThemeProvider>
      </DialogContent>
    </Dialog>
  );
};

export default MyModal;
