import React, { useState, useEffect, useCallback } from "react";
import MDEditor from '@uiw/react-md-editor';
// import '@toast-ui/editor/dist/toastui-editor.css';
// import '@uiw/react-md-editor/markdown-editor.css';
// import '@uiw/react-markdown-preview/markdown.css';
import {
  Box,
  Typography,
  Paper,
  Container,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Alert,
  CircularProgress,
  Tooltip,
  Stack,
  Card,
  CardContent,
  InputAdornment,
  LinearProgress,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from "@mui/material";
import {
  Add,
  Edit,
  Delete,
  Visibility,
  Search,
  Description,
  CloudUpload,
} from "@mui/icons-material";
import { alpha } from "@mui/material/styles";
import ReactMarkdown from 'react-markdown';
import { Documentation_App_URL, getSolutionsApiUrl } from "@/config/api.config";

// Thème et couleurs
const colors = {
  solution: "#b3e6ff",
  server: "#99caff",
  namespace: "#a8e6b1",
  deployment: "#f3aebd",
  domain: "#d4c4fb",
  entity: "#ffd8a6",
};

const theme = {
  primary: "#1976d2",
  secondary: "#dc004e",
  background: "#f5f5f5",
  textPrimary: "#333333",
  textSecondary: "#666666",
  border: "#e0e0e0",
  success: "#2e7d32",
  error: "#d32f2f",
  warning: "#ed6c02",
};

interface DocumentationMDX {
  id: number;
  solution: string;
  content: string;
  created_at: string;
  updated_at: string;
}

interface Solution {
  id: number;
  solution_name: string;
  solution_role?: string;
  domain?: string;
}

const AdminDocumentationPage: React.FC = () => {
  // États
  const [documents, setDocuments] = useState<DocumentationMDX[]>([]);
  const [solutions, setSolutions] = useState<Solution[]>([]);
  const [loading, setLoading] = useState(false);
  const [solutionsLoading, setSolutionsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedDocument, setSelectedDocument] = useState<DocumentationMDX | null>(null);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [currentDocument, setCurrentDocument] = useState<DocumentationMDX | null>(null);
  const [editSolution, setEditSolution] = useState("");
  const [editContent, setEditContent] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [saveLoading, setSaveLoading] = useState(false);


  // URL de base de l'API
  const getDocumentationApiUrl = () => {
    return Documentation_App_URL();
  };

  // Composant de rendu Markdown
  const MarkdownRenderer = ({ content }: { content: string }) => {
    return (
      <ReactMarkdown
        components={{
          code: ({ children }) => (
            <Box
              component="code"
              sx={{
                backgroundColor: alpha(theme.primary, 0.1),
                padding: '2px 6px',
                borderRadius: 1,
                fontSize: '0.875rem',
                fontFamily: 'Monaco, Consolas, "Courier New", monospace',
                display: 'inline-block',
                margin: '0 2px',
              }}
            >
              {children}
            </Box>
          ),
          h1: ({ children }) => (
            <Typography variant="h4" sx={{ mt: 3, mb: 2, fontWeight: 700, color: theme.primary }}>
              {children}
            </Typography>
          ),
          h2: ({ children }) => (
            <Typography variant="h5" sx={{ mt: 2, mb: 1, fontWeight: 700 }}>
              {children}
            </Typography>
          ),
          h3: ({ children }) => (
            <Typography variant="h6" sx={{ mt: 2, mb: 1, fontWeight: 600 }}>
              {children}
            </Typography>
          ),
          p: ({ children }) => (
            <Typography variant="body1" sx={{ mb: 1, lineHeight: 1.6 }}>
              {children}
            </Typography>
          ),
          ul: ({ children }) => (
            <Box component="ul" sx={{ pl: 2, mb: 2 }}>
              {children}
            </Box>
          ),
          ol: ({ children }) => (
            <Box component="ol" sx={{ pl: 2, mb: 2 }}>
              {children}
            </Box>
          ),
          li: ({ children }) => (
            <Typography component="li" variant="body1" sx={{ mb: 0.5 }}>
              {children}
            </Typography>
          ),
          blockquote: ({ children }) => (
            <Box
              sx={{
                borderLeft: `4px solid ${theme.primary}`,
                pl: 2,
                ml: 0,
                my: 2,
                backgroundColor: alpha(theme.primary, 0.05),
                py: 1,
                borderRadius: '0 8px 8px 0',
              }}
            >
              {children}
            </Box>
          ),
          a: ({ href, children }) => (
            <Typography
              component="a"
              href={href}
              target="_blank"
              rel="noopener noreferrer"
              sx={{
                color: theme.primary,
                textDecoration: 'none',
                '&:hover': {
                  textDecoration: 'underline',
                },
              }}
            >
              {children}
            </Typography>
          ),
        }}
      >
        {content}
      </ReactMarkdown>
    );
  };

  // Fonction pour charger les solutions
  const fetchSolutions = useCallback(async () => {
    setSolutionsLoading(true);
    console.log("🚀 Début du chargement des solutions...");

    try {
      const token = localStorage.getItem("bearerToken") ||
        localStorage.getItem("access_token") ||
        localStorage.getItem("token");

      if (!token) {
        console.error("❌ Aucun token trouvé");
        throw new Error("Aucun token d'authentification trouvé");
      }

      console.log("🔗 URL appelée:", getSolutionsApiUrl());

      const response = await fetch(getSolutionsApiUrl(), {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      console.log("📡 Statut de la réponse:", response.status);

      if (!response.ok) {
        throw new Error(`Erreur ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      console.log("📦 Données brutes reçues:", data);

      // Traitement des données
      let solutionsData: Solution[] = [];

      if (data.applications && Array.isArray(data.applications)) {
        console.log("✅ Structure 'applications' détectée");
        solutionsData = data.applications.map((app: any) => ({
          id: app.id,
          solution_name: app.solution_name,
          solution_role: app.solution_role,
          domain: app.domain,
        }));
      } else if (Array.isArray(data)) {
        console.log("✅ Structure tableau direct détectée");
        solutionsData = data.map((app: any) => ({
          id: app.id,
          solution_name: app.solution_name,
          solution_role: app.solution_role,
          domain: app.domain,
        }));
      } else {
        console.warn("⚠️ Structure inattendue, exploration...", data);
        // Explorer les clés de l'objet
        Object.keys(data).forEach(key => {
          console.log(`🔍 Clé '${key}':`, data[key]);
          if (Array.isArray(data[key])) {
            console.log(`✅ Tableau trouvé dans la clé '${key}'`);
            solutionsData = data[key].map((app: any) => ({
              id: app.id,
              solution_name: app.solution_name,
              solution_role: app.solution_role,
              domain: app.domain,
            }));
          }
        });
      }

      console.log("🎯 Solutions extraites:", solutionsData);
      setSolutions(solutionsData);

    } catch (err) {
      console.error("💥 Erreur complète:", err);
      setError("Erreur lors du chargement des solutions: " + (err as Error).message);
    } finally {
      setSolutionsLoading(false);
      console.log("🏁 Chargement des solutions terminé");
    }
  }, []);

  // Fonctions CRUD pour les documents
  const fetchDocuments = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const token = localStorage.getItem("bearerToken") ||
        localStorage.getItem("access_token") ||
        localStorage.getItem("token");

      if (!token) {
        throw new Error("Aucun token d'authentification trouvé");
      }

      const response = await fetch(getDocumentationApiUrl(), {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`Erreur ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      setDocuments(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error("Erreur lors du chargement des documents:", err);
      setError("Erreur lors du chargement des documents: " + (err as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  const createDocument = async (solution: string, content: string) => {
    setSaveLoading(true);
    try {
      const token = localStorage.getItem("bearerToken") ||
        localStorage.getItem("access_token") ||
        localStorage.getItem("token");

      if (!token) {
        throw new Error("Aucun token d'authentification trouvé");
      }

      const response = await fetch(getDocumentationApiUrl(), {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          solution: solution,
          content: content,
        }),
      });

      if (!response.ok) {
        throw new Error(`Erreur ${response.status}: ${response.statusText}`);
      }

      const newDocument = await response.json();
      return newDocument;
    } catch (err) {
      console.error("Erreur lors de la création du document:", err);
      throw err;
    } finally {
      setSaveLoading(false);
    }
  };

  const updateDocument = async (id: number, solution: string, content: string) => {
    setSaveLoading(true);
    try {
      const token = localStorage.getItem("bearerToken") ||
        localStorage.getItem("access_token") ||
        localStorage.getItem("token");

      if (!token) {
        throw new Error("Aucun token d'authentification trouvé");
      }

      const response = await fetch(`${getDocumentationApiUrl()}${id}/`, {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          solution: solution,
          content: content,
        }),
      });

      if (!response.ok) {
        throw new Error(`Erreur ${response.status}: ${response.statusText}`);
      }

      const updatedDocument = await response.json();
      return updatedDocument;
    } catch (err) {
      console.error("Erreur lors de la mise à jour du document:", err);
      throw err;
    } finally {
      setSaveLoading(false);
    }
  };

  const deleteDocument = async (id: number) => {
    try {
      const token = localStorage.getItem("bearerToken") ||
        localStorage.getItem("access_token") ||
        localStorage.getItem("token");

      if (!token) {
        throw new Error("Aucun token d'authentification trouvé");
      }

      const response = await fetch(`${getDocumentationApiUrl()}${id}/`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error(`Erreur ${response.status}: ${response.statusText}`);
      }

      return true;
    } catch (err) {
      console.error("Erreur lors de la suppression du document:", err);
      throw err;
    }
  };

  // Handlers
  const handleCreateDocument = () => {
    setEditSolution("");
    setEditContent("");
    setIsEditing(false);
    setCurrentDocument(null);
    setEditDialogOpen(true);
  };

  const handleEditDocument = (doc: DocumentationMDX) => {
    setCurrentDocument(doc);
    setEditSolution(doc.solution);
    setEditContent(doc.content);
    setIsEditing(true);
    setEditDialogOpen(true);
  };

  const handleViewDocument = (doc: DocumentationMDX) => {
    setSelectedDocument(doc);
    setViewDialogOpen(true);
  };

  const handleDeleteDocument = (doc: DocumentationMDX) => {
    setCurrentDocument(doc);
    setDeleteDialogOpen(true);
  };

  const handleSaveDocument = async () => {
    try {
      if (isEditing && currentDocument) {
        const updatedDoc = await updateDocument(currentDocument.id, editSolution, editContent);
        setDocuments(prev => prev.map(doc =>
          doc.id === currentDocument.id ? updatedDoc : doc
        ));
      } else {
        const newDoc = await createDocument(editSolution, editContent);
        setDocuments(prev => [...prev, newDoc]);
      }

      setEditDialogOpen(false);
      setCurrentDocument(null);
      setEditContent("");
      setEditSolution("");
      setError(null);
    } catch (err) {
      setError("Erreur lors de la sauvegarde du document: " + (err as Error).message);
    }
  };

  const handleConfirmDelete = async () => {
    if (!currentDocument) return;

    try {
      await deleteDocument(currentDocument.id);
      setDocuments(prev => prev.filter(doc => doc.id !== currentDocument.id));
      setDeleteDialogOpen(false);
      setCurrentDocument(null);
      setError(null);
    } catch (err) {
      setError("Erreur lors de la suppression du document: " + (err as Error).message);
    }
  };

  // Fonction pour extraire l'acronyme du nom de solution
  const getSolutionAcronym = (solutionName: string): string => {
    const match = solutionName.match(/\(([^)]+)\)/);
    return match ? match[1] : '';
  };

  // Fonction pour obtenir le nom sans acronyme
  const getSolutionNameWithoutAcronym = (solutionName: string): string => {
    return solutionName.replace(/\s*\([^)]*\)\s*$/, '').trim();
  };

  // Filtrage des documents
  const filteredDocuments = documents.filter(doc =>
    doc.solution.toLowerCase().includes(searchTerm.toLowerCase()) ||
    doc.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Chargement initial
  useEffect(() => {
    fetchSolutions();
    fetchDocuments();
  }, [fetchSolutions, fetchDocuments]);

  return (
    <Box sx={{ minHeight: "100vh", backgroundColor: theme.background, py: 4 }}>
      <Container maxWidth="xl">
        {/* En-tête */}
        <Box sx={{ mb: 4 }}>
          <Typography variant="h3" sx={{ fontWeight: 800, color: theme.primary, mb: 2 }}>
            📋 Administration Documentation
          </Typography>
          <Typography variant="h6" sx={{ color: theme.textSecondary }}>
            Gestion complète de la documentation MDX
          </Typography>
        </Box>

        {/* Cartes de statistiques */}
        <Stack direction={{ xs: "column", sm: "row" }} spacing={2} sx={{ mb: 4 }}>
          <Card sx={{ flex: 1, backgroundColor: alpha(theme.primary, 0.1) }}>
            <CardContent>
              <Typography variant="h4" sx={{ fontWeight: 800, color: theme.primary }}>
                {documents.length}
              </Typography>
              <Typography variant="body2" sx={{ color: theme.textSecondary, fontWeight: 600 }}>
                Documents Total
              </Typography>
            </CardContent>
          </Card>
          <Card sx={{ flex: 1, backgroundColor: alpha(theme.success, 0.1) }}>
            <CardContent>
              <Typography variant="h4" sx={{ fontWeight: 800, color: theme.success }}>
                {new Set(documents.map(d => d.solution)).size}
              </Typography>
              <Typography variant="body2" sx={{ color: theme.textSecondary, fontWeight: 600 }}>
                Solutions avec documentation
              </Typography>
            </CardContent>
          </Card>
          <Card sx={{ flex: 1, backgroundColor: alpha(colors.namespace, 0.1) }}>
            <CardContent>
              <Typography variant="h4" sx={{ fontWeight: 800, color: colors.namespace }}>
                {solutions.length}
              </Typography>
              <Typography variant="body2" sx={{ color: theme.textSecondary, fontWeight: 600 }}>
                Solutions Disponibles
              </Typography>
            </CardContent>
          </Card>
        </Stack>

        {/* Barre de recherche et actions */}
        <Paper sx={{ p: 3, mb: 3 }}>
          <Box sx={{ display: 'flex', gap: 2, alignItems: 'center', flexWrap: 'wrap' }}>
            <TextField
              placeholder="Rechercher par solution ou contenu..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              sx={{ flex: 1, minWidth: 300 }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <Search />
                  </InputAdornment>
                ),
              }}
            />
            <Button
              variant="contained"
              startIcon={<Add />}
              onClick={handleCreateDocument}
              sx={{
                backgroundColor: theme.primary,
                '&:hover': {
                  backgroundColor: alpha(theme.primary, 0.8),
                },
              }}
            >
              Nouveau Document
            </Button>
          </Box>
        </Paper>

        {/* Messages d'erreur */}
        {error && (
          <Alert severity="error" sx={{ mb: 3 }}>
            {error}
          </Alert>
        )}

        {/* Tableau des documents */}
        <Paper sx={{ overflow: 'hidden' }}>
          {loading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
              <CircularProgress />
            </Box>
          ) : filteredDocuments.length === 0 ? (
            <Box sx={{ textAlign: 'center', p: 4 }}>
              <Description sx={{ fontSize: 64, color: theme.textSecondary, mb: 2, opacity: 0.5 }} />
              <Typography variant="h6" sx={{ mb: 1, color: theme.textSecondary }}>
                {documents.length === 0 ? 'Aucun document' : 'Aucun résultat'}
              </Typography>
              <Typography variant="body2" sx={{ mb: 2, color: theme.textSecondary }}>
                {documents.length === 0
                  ? 'Commencez par créer votre premier document.'
                  : 'Aucun document ne correspond à votre recherche.'
                }
              </Typography>
              {documents.length === 0 && (
                <Button
                  variant="contained"
                  startIcon={<Add />}
                  onClick={handleCreateDocument}
                >
                  Créer un document
                </Button>
              )}
            </Box>
          ) : (
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow sx={{ backgroundColor: alpha(theme.primary, 0.1) }}>
                    <TableCell sx={{ fontWeight: 700 }}>Solution</TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>Aperçu du contenu</TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>Créé le</TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>Mis à jour le</TableCell>
                    <TableCell sx={{ fontWeight: 700, width: 140 }}>Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {filteredDocuments.map((doc) => (
                    <TableRow
                      key={doc.id}
                      sx={{
                        '&:hover': {
                          backgroundColor: alpha(theme.primary, 0.05),
                        }
                      }}
                    >
                      <TableCell>
                        <Box>
                          <Chip
                            label={
                              getSolutionAcronym(doc.solution)
                                ? `${getSolutionNameWithoutAcronym(doc.solution)} (${getSolutionAcronym(doc.solution)})`
                                : getSolutionNameWithoutAcronym(doc.solution)
                            }
                            size="small"
                            sx={{
                              backgroundColor: alpha(theme.primary, 0.2),
                              color: theme.primary,
                              fontWeight: 600,
                              mb: 0.5
                            }}
                          />
                        </Box>
                      </TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1 }}>
                          <Box sx={{ flex: 1 }}>
                            <Typography
                              variant="body2"
                              sx={{
                                maxWidth: 350,
                                display: '-webkit-box',
                                WebkitLineClamp: 3,
                                WebkitBoxOrient: 'vertical',
                                overflow: 'hidden',
                                cursor: 'pointer',
                                '&:hover': { color: theme.primary }
                              }}
                              onClick={() => handleViewDocument(doc)}
                            >
                              {/* Afficher le texte sans balises Markdown */}
                              {doc.content
                                .replace(/#{1,6}\s+/g, '') // Supprime les titres
                                .replace(/\*\*(.*?)\*\*/g, '$1') // Supprime le gras
                                .replace(/\*(.*?)\*/g, '$1') // Supprime l'italique
                                .replace(/`(.*?)`/g, '$1') // Supprime le code inline
                                .substring(0, 200)}
                              {doc.content.length > 200 ? '...' : ''}
                            </Typography>
                            <Typography variant="caption" color="text.secondary">
                              {doc.content.split('\n').length} lignes •
                              {Math.ceil(doc.content.length / 1000)}k caractères
                            </Typography>
                          </Box>
                        </Box>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2">
                          {new Date(doc.created_at).toLocaleDateString('fr-FR')}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {new Date(doc.created_at).toLocaleTimeString('fr-FR')}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2">
                          {new Date(doc.updated_at).toLocaleDateString('fr-FR')}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {new Date(doc.updated_at).toLocaleTimeString('fr-FR')}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', gap: 0.5 }}>
                          <Tooltip title="Voir">
                            <IconButton
                              size="small"
                              onClick={() => handleViewDocument(doc)}
                              sx={{ color: theme.primary }}
                            >
                              <Visibility />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Modifier">
                            <IconButton
                              size="small"
                              onClick={() => handleEditDocument(doc)}
                              sx={{ color: theme.warning }}
                            >
                              <Edit />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Supprimer">
                            <IconButton
                              size="small"
                              onClick={() => handleDeleteDocument(doc)}
                              sx={{ color: theme.error }}
                            >
                              <Delete />
                            </IconButton>
                          </Tooltip>
                        </Box>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </Paper>

        {/* Dialog de visualisation */}
        <Dialog
          open={viewDialogOpen}
          onClose={() => setViewDialogOpen(false)}
          maxWidth="md"
          fullWidth
          scroll="paper"
        >
          <DialogTitle>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Description sx={{ color: theme.primary }} />
              <Typography variant="h6">
                {selectedDocument && getSolutionNameWithoutAcronym(selectedDocument.solution)}
                {selectedDocument && getSolutionAcronym(selectedDocument.solution) && (
                  <Typography component="span" variant="body2" color="text.secondary" sx={{ ml: 1 }}>
                    ({getSolutionAcronym(selectedDocument.solution)})
                  </Typography>
                )}
              </Typography>
            </Box>
            <Typography variant="caption" color="text.secondary">
              ID: {selectedDocument?.id} •
              Créé le: {selectedDocument && new Date(selectedDocument.created_at).toLocaleString('fr-FR')}
              {selectedDocument?.created_at !== selectedDocument?.updated_at &&
                ` • Modifié le: ${selectedDocument && new Date(selectedDocument.updated_at).toLocaleString('fr-FR')}`
              }
            </Typography>
          </DialogTitle>
          <DialogContent dividers>
            {selectedDocument && (
              <Box sx={{ p: 1 }}>
                <MarkdownRenderer content={selectedDocument.content} />
              </Box>
            )}
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setViewDialogOpen(false)}>
              Fermer
            </Button>
          </DialogActions>
        </Dialog>

        {/* Dialog d'édition/création */}
        {/* Dialog d'édition/création */}
        <Dialog
          open={editDialogOpen}
          onClose={() => setEditDialogOpen(false)}
          maxWidth="md"
          fullWidth
        >
          <DialogTitle>
            {isEditing ? 'Modifier le document' : 'Nouveau document'}
          </DialogTitle>
          <DialogContent>
            <Box sx={{ mt: 2 }}>
              <FormControl fullWidth margin="normal">
                <InputLabel>Solution</InputLabel>
                <Select
                  value={editSolution}
                  label="Solution"
                  onChange={(e) => setEditSolution(e.target.value)}
                  disabled={solutionsLoading}
                >
                  {solutionsLoading ? (
                    <MenuItem disabled>
                      <CircularProgress size={20} sx={{ mr: 1 }} />
                      Chargement des solutions...
                    </MenuItem>
                  ) : (
                    solutions.map((solution) => (
                      <MenuItem key={solution.id} value={solution.solution_name}>
                        {/* AFFICHAGE SIMPLIFIÉ : seulement le nom avec acronyme */}
                        <Typography variant="body1">
                          {solution.solution_name}
                        </Typography>
                      </MenuItem>
                    ))
                  )}
                </Select>
              </FormControl>

              <Box sx={{ mt: 2 }}>
                <Typography variant="subtitle2" sx={{ mb: 1, color: theme.textSecondary }}>
                  Éditeur Markdown - Supporte les styles, tableaux, code, images, etc.
                </Typography>
                <Box sx={{ border: `1px solid ${theme.border}`, borderRadius: 1 }}>
                  <MDEditor
                    value={editContent}
                    onChange={(value) => setEditContent(value || '')}
                    height={400}
                    preview="live"
                    visibleDragbar={true}
                    textareaProps={{
                      placeholder: 'Écrivez votre documentation en Markdown...\n\nUtilisez # pour les titres\n**gras** pour le texte important\n*italique* pour l\'emphase\n- pour les listes\n``` pour le code\n| pour les tableaux',
                    }}
                  />
                </Box>

                {/* Guide rapide Markdown */}
                <Paper sx={{ mt: 2, p: 2, backgroundColor: alpha(theme.primary, 0.05) }}>
                  <Typography variant="caption" fontWeight="bold" display="block" sx={{ mb: 1 }}>
                    📝 Guide rapide Markdown :
                  </Typography>
                  <Stack direction="row" spacing={3} flexWrap="wrap">
                    <Typography variant="caption" sx={{ display: 'flex', alignItems: 'center', mr: 2 }}>
                      <Chip label="#" size="small" sx={{ mr: 0.5 }} /> Titre
                    </Typography>
                    <Typography variant="caption" sx={{ display: 'flex', alignItems: 'center', mr: 2 }}>
                      <Chip label="**" size="small" sx={{ mr: 0.5 }} /> <strong>Gras</strong>
                    </Typography>
                    <Typography variant="caption" sx={{ display: 'flex', alignItems: 'center', mr: 2 }}>
                      <Chip label="*" size="small" sx={{ mr: 0.5 }} /> <em>Italique</em>
                    </Typography>
                    <Typography variant="caption" sx={{ display: 'flex', alignItems: 'center', mr: 2 }}>
                      <Chip label="```" size="small" sx={{ mr: 0.5 }} /> Code
                    </Typography>
                    <Typography variant="caption" sx={{ display: 'flex', alignItems: 'center', mr: 2 }}>
                      <Chip label="-" size="small" sx={{ mr: 0.5 }} /> Liste
                    </Typography>
                    <Typography variant="caption" sx={{ display: 'flex', alignItems: 'center', mr: 2 }}>
                      <Chip label="|" size="small" sx={{ mr: 0.5 }} /> Tableau
                    </Typography>
                    <Typography variant="caption" sx={{ display: 'flex', alignItems: 'center' }}>
                      <Chip label="![alt](url)" size="small" sx={{ mr: 0.5 }} /> Image
                    </Typography>
                  </Stack>
                </Paper>
              </Box>
            </Box>
            {saveLoading && (
              <LinearProgress sx={{ mt: 2 }} />
            )}
          </DialogContent>
          <DialogActions>
            <Button
              onClick={() => setEditDialogOpen(false)}
              disabled={saveLoading}
            >
              Annuler
            </Button>
            <Button
              onClick={handleSaveDocument}
              variant="contained"
              disabled={!editSolution || !editContent || saveLoading}
              startIcon={saveLoading ? <CircularProgress size={16} /> : <CloudUpload />}
            >
              {saveLoading ? 'Sauvegarde...' : (isEditing ? 'Modifier' : 'Créer')}
            </Button>
          </DialogActions>
        </Dialog>

        {/* Dialog de confirmation de suppression */}
        <Dialog
          open={deleteDialogOpen}
          onClose={() => setDeleteDialogOpen(false)}
        >
          <DialogTitle>
            Confirmer la suppression
          </DialogTitle>
          <DialogContent>
            <Typography>
              Êtes-vous sûr de vouloir supprimer le document "{currentDocument && getSolutionNameWithoutAcronym(currentDocument.solution)}" ?
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
              Cette action est irréversible.
            </Typography>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setDeleteDialogOpen(false)}>
              Annuler
            </Button>
            <Button
              onClick={handleConfirmDelete}
              variant="contained"
              color="error"
              startIcon={<Delete />}
            >
              Supprimer
            </Button>
          </DialogActions>
        </Dialog>
      </Container>
    </Box>
  );
};

export default AdminDocumentationPage;