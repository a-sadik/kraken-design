// src/pages/SelfServicePage.tsx
import React from "react";
import { useNavigate } from "react-router-dom";
import { Button, Grid2, Grid, Box, Typography } from "@mui/material";
// import files
import { keycloak } from "../../auth/keycloakConnectAdapter";
// import icons
import { SiKeycloak, SiRedhatopenshift } from "react-icons/si";
import { PiCertificateLight } from "react-icons/pi";
import { FiZap } from "react-icons/fi";
// Import des nouvelles icônes
import { SiApachekafka } from "react-icons/si";
import { SiElasticsearch } from "react-icons/si";
import { SiDynatrace } from "react-icons/si";
import { FaServer } from "react-icons/fa";
import { FaShieldAlt } from "react-icons/fa";
import { FaNetworkWired } from "react-icons/fa";
import { FaBucket } from "react-icons/fa6";
import { GrNotes } from "react-icons/gr";
// import { SiAmazons3 } from "react-icons/si";
// import { HiOutlineServerStack } from "react-icons/hi2";
// import { MdSettingsBackupRestore } from "react-icons/md";

import AxwayLogoUrl from "../../../public/logos/sources/axway_logo.png";
import { CiSettings } from "react-icons/ci";

const SelfServicePage: React.FC = () => {
  const navigate = useNavigate();

  const goToPage = (path: string) => {
    navigate(path);
  };

  const selfServiceItems = [
    // Certificat management
    ...(keycloak.hasRoles(["security_role", "tam_role", "ops_role", "self_service_certificate_role"])
      ? [
        {
          label: "certificat",
          icon: <PiCertificateLight size={60} />,
          path: "/certifcats",
          onClick: () => goToPage("/certifcats"),
          type: "certificat",
        },
      ]
      : []),

    // Release note
    ...(keycloak.hasRoles(['admin_role', 'self_service_release_role', 'ops_role']) ? [{
      label: "Release Note",
      icon: <GrNotes size={60} />,
      path: "/Release-Note",
      onClick: () => goToPage("/AdminReleaseNotesPage"),
      type: "certificat"
    }] : []),

    ...(keycloak.hasRoles(["admin_role"])
      // ...(keycloak.hasRoles([ "admin_role", "tam_role", "ops_role", ])
      ? [
        {
          label: "Backup",
          icon: <FiZap size={60} />,
          path: "/Backup",
          onClick: () => goToPage("/Backup"),
          type: "other",
        },
      ]
      : []),



    // VM management
    ...(keycloak.hasRoles('admin_role') ? [{
      label: "VM",
      icon: <FaServer size={60} />,
      path: "/self-service/machine",
      onClick: () => goToPage("/self-service/machine"),
      type: "other"
    }] : []),


    // OpenShift management
    ...(keycloak.hasRoles("admin_role")
      ? [
        {
          label: "namespace sur Openshift",
          icon: <SiRedhatopenshift size={60} />,
          path: "",
          onClick: () => { },
          type: "other",
        },
      ]
      : []),

    // Flux sécurité
    ...(keycloak.hasRoles('admin_role') ? [{
      label: "Flux sécurité",
      icon: <FaShieldAlt size={60} />,
      path: "",
      onClick: () => { },
      type: "other"
    }] : []),

    // Kafka
    ...(keycloak.hasRoles('admin_role') ? [{
      label: "Kafka",
      icon: <SiApachekafka size={60} />,
      path: "",
      onClick: () => { },
      type: "other"
    }] : []),

    // Keycloak
    ...(keycloak.hasRoles('admin_role') ? [{
      label: "Keycloak",
      icon: <SiKeycloak size={60} />,
      path: "",
      onClick: () => { },
      type: "other"
    }] : []),

    // DNS
    ...(keycloak.hasRoles('admin_role') ? [{
      label: "DNS",
      icon: <FaNetworkWired size={60} />,
      path: "",
      onClick: () => { },
      type: "other"
    }] : []),

    // Elastic search
    ...(keycloak.hasRoles('admin_role') ? [{
      label: "Elastic search",
      icon: <SiElasticsearch size={60} />,
      path: "",
      onClick: () => { },
      type: "other"
    }] : []),

    // Dynatrace
    ...(keycloak.hasRoles('admin_role') ? [{
      label: "Dynatrace",
      icon: <SiDynatrace size={60} />,
      path: "",
      onClick: () => { },
      type: "other"
    }] : []),

    // S3
    ...(keycloak.hasRoles('admin_role') ? [{
      label: "S3",
      icon: <FaBucket size={60} />,
      path: "",
      onClick: () => { },
      type: "other"
    }] : []),




    // cft axway
...(keycloak.hasRoles('admin_role') ? [{
  label: "cft axway",
  icon: (
    <img
      src={AxwayLogoUrl}
      alt="Axway"
      style={{
        width: 60,          // largeur fixe
        height: 'auto',      // conserve le ratio
        filter: 'brightness(0) invert(1)', // effet gris
        display: 'block'
      }}
    />
  ),
  path: "",
  // onClick: () => window.open(),
  type: "other"
}] : []),



    // autosys automation
    ...(keycloak.hasRoles('admin_role') ? [{
      label: "autosys automation",
      icon: <CiSettings  size={60} />,
      path: "",
      onClick: () => { },
      type: "other"
    }] : []),

    // Sauvegarde (existant - commenté)
    // ...(keycloak.hasRoles('admin_role') ? [{
    //   label: "Sauvegarde",
    //   icon: <MdSettingsBackupRestore size={60} />,
    //   path: "",
    //   onClick: () => {},
    //   type: "other"
    // }] : []),

    // Stockage S3 (existant - commenté)
    //   ...(keycloak.hasRoles('admin_role') ? [{
    //     label: "Stockage S3",
    //     icon: <SiAmazons3 size={60} />,
    //     path: "",
    //     onClick: () => {},
    //     type: "other"
    //   }] : [])
  ];

  return (
    <Grid2
      container
      spacing={2}
      sx={{
        width: "70%",
        marginX: "auto",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      {selfServiceItems.map(({ label, icon, onClick, type }, index) => (
        <Grid
          key={index}
          item
          xs={4}
          component="div"
          sx={{ display: "flex", justifyContent: "center" }}
        >
          <Button
            className={`btn-self-service ${type === "certificat" ? "certificat" : "other"}`}
            color={type === "certificat" ? "primary" : "inherit"}
            variant="contained"
            size="large"
            onClick={onClick}
            sx={{
              minWidth: "120px",
              height: "140px",
              margin: 1,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              textTransform: "uppercase",
              ...(type !== "certificat" && {
                backgroundColor: "",
                color: "#ffffff",
                "&:hover": {
                  backgroundColor: "#757575", // Couleur grise plus foncée au survol
                },
              }),
            }}
          >
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
              }}
            >
              {icon}
              <Typography
                variant="body2"
                sx={{ mt: 1, fontWeight: "bold", fontSize: "16px" }}
              >
                {label}
              </Typography>
            </Box>
          </Button>
        </Grid>
      ))}
    </Grid2>
  );
};

export default SelfServicePage;