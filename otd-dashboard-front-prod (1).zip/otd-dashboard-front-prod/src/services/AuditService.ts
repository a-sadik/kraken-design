// src/services/AuditService.ts
import axios, { AxiosError } from "axios";

import apiClientHttp from "./apiClientHttp";
import { ErrorResponse } from "react-router-dom";
import { AuditDetailDTO, AuditShortDTO } from "@/types/dto/AuditDTO";

import { AuditView } from "@/types/view/AuditView";
import { auditResToView } from "@/mappers/AuditMapper";

export const getAudits = async () => {
  const response = await axios.get("/api/audits");
  return response.data;
};

const path = "/audits";

// Function to recieve one audit certificate by id
export const getAuditCertificateById = async (
  id: number,
): Promise<AuditDetailDTO[] | null> => {
  try {
    const response = await apiClientHttp.dataApiClient.get<
      AuditDetailDTO[] | null
    >(`${path}/certificate/${id}`);
    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error("Error fetching certificate data by id:", err.response?.data);
    throw error;
  }
};

// Function to receive all audits
export const getAllAudits = async (): Promise<AuditView[]> => {
  try {
    const response =
      await apiClientHttp.dataApiClient.get<AuditShortDTO[]>(`/audits`);

    const mappedData: AuditView[] = auditResToView(response.data);

    return mappedData;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;
    throw err;
  }
};
