import React, { useEffect, useState } from "react";
import {
  Box,
  Button,
  CircularProgress,
  TextField,
  Autocomplete,
} from "@mui/material";
import axios from "axios";
import MyModal from "@/components/modals/MyModal";
import { getAllTypeSolutions } from "@/services/SolutionService";

interface Item {
  solution_id: number;
  solution_type: string;
}

interface Props {
  open: boolean;
  onClose: () => void;
  onSave: () => void;
}

export const ModifierTypeSolutionModal: React.FC<Props> = ({
  open,
  onClose,
  onSave,
}) => {
  const [items, setItems] = useState<Item[]>([]);
  const [selected, setSelected] = useState<Item | null>(null);
  const [newName, setNewName] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open) {
      setLoading(true);
      getAllTypeSolutions()
        .then((data) => setItems(data))
        .finally(() => setLoading(false));
      setSelected(null);
      setNewName("");
    }
  }, [open]);

  const handleSave = () => {
    if (!selected || !newName.trim()) return;

    axios
      .put(`/api/solution/type/${selected.solution_id}`, { name: newName })
      .then(() => {
        onSave();
        onClose();
      });
  };

  return (
    <MyModal open={open} onClose={onClose} title="Modifier un Type">
      <Box sx={{ minWidth: 500, px: 2, pt: 1 }}>
        {loading ? (
          <Box textAlign="center" my={2}>
            <CircularProgress />
          </Box>
        ) : (
          <>
            <Autocomplete
              options={items}
              getOptionLabel={(o) => o.solution_type}
              value={selected}
              onChange={(_, value) => {
                setSelected(value);
                setNewName(value?.solution_type || "");
              }}
              renderInput={(params) => (
                <TextField {...params} label="Sélectionner un Type" fullWidth />
              )}
            />

            <TextField
              fullWidth
              label="Nouveau nom du Type"
              sx={{ mt: 2 }}
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              disabled={!selected}
            />
          </>
        )}

        <Box textAlign="right" mt={3}>
          <Button onClick={onClose} variant="outlined" sx={{ mr: 1 }}>
            Annuler
          </Button>
          <Button
            onClick={handleSave}
            variant="contained"
            disabled={!selected || !newName.trim()}
            sx={{
              backgroundColor: "#1976d2",
              color: "#fff",
              fontWeight: "bold",
              "&:hover": {
                backgroundColor: "#125ea9",
              },
            }}
          >
            Modifier
          </Button>
        </Box>
      </Box>
    </MyModal>
  );
};
