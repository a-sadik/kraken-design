// src/types/dto/PostDTO.ts

export interface PostRequestDTO {
  post_name: string;
}

export interface PostShortResponseDTO {
  post_id: number;
  post_name: string;
}

export interface PostDetailResponseDTO {
  post_id: number;
  post_name: string;
}
