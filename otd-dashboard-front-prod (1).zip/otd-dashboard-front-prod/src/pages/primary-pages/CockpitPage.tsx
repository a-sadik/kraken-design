// src/pages/CockpitPage.tsx
import {
  Box,
  Card,
  Typography,
  Grid,
  Avatar,
  MenuItem,
  Select,
  InputLabel,
  FormControl,
  Alert,
  CircularProgress,
  Tooltip,
  Chip,
  Paper,
  Button,
} from "@mui/material";
import { BarChart, PieChart, ScatterChart } from "@mui/x-charts";
import { DataGrid, GridColDef, GridRenderCellParams } from "@mui/x-data-grid";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider, DatePicker } from "@mui/x-date-pickers";
import {
  CheckCircle,
  Error,
  BubbleChart,
  Warning,
  Schedule,
  Security,
  NewReleases,
  ExpandLess,
  ExpandMore,
} from "@mui/icons-material";
import { useState, useEffect } from "react";
import dayjs, { Dayjs } from "dayjs";
import { motion } from "framer-motion";
import {
  getCertificatesStatistics,
  getFilteredCertificatesStatistics,
  CertificateStats,
  ExpirationTimelineItem,
  ChartData,
} from "@/services/CertificateStatisticsService";
import {
  service_unavailable,
  service_data,
  service_failure,
} from "@/utils/customMessages";
import { AxiosError } from "axios";
import { getFormatedDate } from "@/utils";

const stateColors: { [key: string]: string } = {
  Activer: "#A8E6A1", // Vert pastel
  "En cours de signature": "#FFE5B3", // Orange pastel
  Rejeter: "#FFB3B3", // Rouge pastel
  Expiré: "#E6B3FF", // Violet pastel
  "Mettre en attente": "#B3E0FF", // Bleu pastel;
  Autre: "#B3FFE6",
};

interface CertificateForDisplay {
  certificate_id: string;
  common_name: string | null;
  certificate_type: string | null;
  certificate_state: string | null;
  exp_date: string | null;
  created_at: string | null;
  applicant: string | null;
}

interface BubbleData {
  x: number; // Jours jusqu'à expiration
  y: number; // Position Y arbitraire pour éviter le chevauchement
  size: number; // Nombre de certificats expirant ce jour
  id: string;
  date: string;
  certificates: ExpirationTimelineItem[];
  color: string;
}

export default function CockpitPage() {
  const [stats, setStats] = useState<CertificateStats>({
    total: 0,
    createdToday: 0,
    expiringSoon: 0,
    expiring30Days: 0,
    expired: 0,
    byType: {},
    byState: {},
    expirationTimeline: [],
  });

  const [chartData, setChartData] = useState<ChartData>({
    typeChart: [],
    stateChart: [],
  });

  const [certificates, setCertificates] = useState<CertificateForDisplay[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [errorServiceMsg, setErrorServiceMsg] = useState<string | null>(null);
  const [errorOperationMsg, setErrorOperationMsg] = useState<string | null>(null);
  const [startDate, setStartDate] = useState<Dayjs | null>(dayjs("2025-01-01"));
  const [endDate, setEndDate] = useState<Dayjs | null>(dayjs("2030-01-01"));
  const [typeFilter, setTypeFilter] = useState<string>("All");
  const [stateFilter, setStateFilter] = useState<string>("All");
  const [, setIsRefreshing] = useState<boolean>(false);
  const [uniqueTypes, setUniqueTypes] = useState<string[]>([]);
  const [uniqueStates, setUniqueStates] = useState<string[]>([]);
  const [bubbleData, setBubbleData] = useState<BubbleData[]>([]);
  const [showBubbleChart, setShowBubbleChart] = useState(true);
  const [expandedDates, setExpandedDates] = useState<Set<string>>(new Set());
  const [allCertificates, setAllCertificates] = useState<CertificateForDisplay[]>([]);

  // Fonction pour calculer les certificats qui expirent bientôt (moins d'1 mois)
  const calculateExpiringSoon = (certificatesList: CertificateForDisplay[]): number => {
    const today = dayjs();
    return certificatesList.filter((cert: CertificateForDisplay) => {
      if (!cert.exp_date) return false;

      const expDate = dayjs(cert.exp_date);
      const daysUntilExp = expDate.diff(today, 'day');

      // Certificats qui expirent dans moins d'1 mois (entre aujourd'hui et 30 jours)
      return daysUntilExp >= 0 && daysUntilExp <= 30;
    }).length;
  };

  // Fonction pour calculer les certificats expirés
  const calculateExpired = (certificatesList: CertificateForDisplay[]): number => {
    const today = dayjs();

    return certificatesList.filter((cert: CertificateForDisplay) => {
      if (!cert.exp_date) return false;

      const expDate = dayjs(cert.exp_date);
      return expDate.isBefore(today, 'day');
    }).length;
  };

  // Fonction pour calculer les certificats créés aujourd'hui
  const calculateCreatedToday = (certificatesList: CertificateForDisplay[]): number => {
    const today = dayjs().startOf('day');

    return certificatesList.filter((cert: CertificateForDisplay) => {
      if (!cert.created_at) return false;

      const createdDate = dayjs(cert.created_at).startOf('day');
      return createdDate.isSame(today, 'day');
    }).length;
  };

  // Fonction pour gérer l'expansion/réduction
  const toggleDateExpansion = (date: string) => {
    const newExpanded = new Set(expandedDates);
    if (newExpanded.has(date)) {
      newExpanded.delete(date);
    } else {
      newExpanded.add(date);
    }
    setExpandedDates(newExpanded);
  };

  // Fonction pour récupérer les statistiques depuis l'API
  const fetchStatistics = async () => {
    setLoading(true);
    setIsRefreshing(true);
    setErrorOperationMsg(null);
    setErrorServiceMsg(null);
    try {
      const data = await getCertificatesStatistics();

      // Récupérer tous les certificats depuis l'endpoint filtré avec la plage par défaut
      const allCertificatesData = await getFilteredCertificatesStatistics({
        startDate: "2025-01-01", // Utilise la plage par défaut
        endDate: "2030-01-01"
      });

      // Stocker tous les certificats pour les calculs
      const allCerts = allCertificatesData.certificates || [];
      setAllCertificates(allCerts);

      // Calculer toutes les statistiques localement
      const expiringSoonCount = calculateExpiringSoon(allCerts);
      const expiredCount = calculateExpired(allCerts);
      const createdTodayCount = calculateCreatedToday(allCerts);

      setStats({
        ...data.statistics,
        total: allCerts.length || 0,
        expiringSoon: expiringSoonCount,
        expired: expiredCount,
        createdToday: createdTodayCount
      });

      setChartData(data.charts);

      // Extraire les types et états uniques pour les filtres
      const types = Object.keys(data.statistics.byType);
      const states = Object.keys(data.statistics.byState);
      setUniqueTypes(types);
      setUniqueStates(states);

      // PRÉPARER LES DONNÉES POUR LE DIAGRAMME EN BULLES AVEC TOUS LES CERTIFICATS
      prepareBubbleData(allCerts);
      setErrorServiceMsg(null);
    } catch (err) {
      const error = err as AxiosError;
      console.error("Erreur lors de la récupération des statistiques :", err);
      if (error.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    } finally {
      setLoading(false);
      setTimeout(() => setIsRefreshing(false), 500);
    }
  };

  // Fonction pour récupérer les statistiques filtrées
  const fetchFilteredStatistics = async () => {
    setLoading(true);
    setErrorOperationMsg(null);
    setErrorServiceMsg(null);
    try {
      const filters = {
        startDate: startDate?.format("YYYY-MM-DD"),
        endDate: endDate?.format("YYYY-MM-DD"),
        certificateType: typeFilter !== "All" ? typeFilter : undefined,
        certificateState: stateFilter !== "All" ? stateFilter : undefined,
      };

      const data = await getFilteredCertificatesStatistics(filters);

      // Stocker les certificats filtrés
      const filteredCertificates = data.certificates || [];
      setCertificates(filteredCertificates);

      // Calculer les statistiques localement pour les données filtrées
      const expiredCount = calculateExpired(filteredCertificates);
      const createdTodayCount = calculateCreatedToday(filteredCertificates);

      // IMPORTANT: expiringSoon est toujours calculé depuis tous les certificats (allCertificates)
      const expiringSoonCount = calculateExpiringSoon(allCertificates);

      setStats({
        ...data.statistics,
        total: filteredCertificates.length || 0,
        expiringSoon: expiringSoonCount, // Toujours depuis tous les certificats, ignore les filtres
        expired: expiredCount,
        createdToday: createdTodayCount
      });

      setChartData(data.charts);

      // PRÉPARER LES DONNÉES POUR LE DIAGRAMME EN BULLES AVEC LES CERTIFICATS FILTRÉS
      prepareBubbleData(filteredCertificates);
      setErrorServiceMsg(null);
    } catch (err) {
      const error = err as AxiosError;
      console.error(
        "Erreur lors de la récupération des statistiques filtrées :",
        err,
      );
      if (error.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    } finally {
      setLoading(false);
    }
  };


  // Fonction pour préparer les données du diagramme en bulles
  const prepareBubbleData = (certificatesToUse: CertificateForDisplay[]) => {
    if (certificatesToUse.length === 0) {
      setBubbleData([]);
      return;
    }

    // Grouper UNIQUEMENT par date d'expiration (format YYYY-MM-DD)
    const groupedByDate = certificatesToUse.reduce(
      (acc, cert) => {
        const expDate = cert.exp_date;
        if (expDate) {
          // Utiliser uniquement la date (sans l'heure) comme clé de groupement
          const dateKey = dayjs(expDate).format("YYYY-MM-DD");
          if (!acc[dateKey]) {
            acc[dateKey] = [];
          }
          // Convertir CertificateForDisplay en ExpirationTimelineItem
          acc[dateKey].push({
            organization: "organization",
            issuer: "issuer",
            certificate_id: cert.certificate_id,
            common_name: cert.common_name || "",
            certificate_type: cert.certificate_type || "",
            exp_date: cert.exp_date || "",
            applicant: cert.applicant || "",
            status: "active",
            daysUntilExpiration: getDaysUntilExpiration(cert.exp_date) || 0,
          });
        }
        return acc;
      },
      {} as Record<string, ExpirationTimelineItem[]>,
    );

    // Trouver le min et max pour normaliser les tailles
    const certCounts = Object.values(groupedByDate).map(
      (certs) => certs.length,
    );
    const minCount = certCounts.length > 0 ? Math.min(...certCounts) : 0;
    const maxCount = certCounts.length > 0 ? Math.max(...certCounts) : 0;

    // Créer les données pour les bulles - une bulle par date unique
    const bubbles: BubbleData[] = Object.entries(groupedByDate).map(
      ([dateKey, certs], index) => {
        const daysUntilExp = getDaysUntilExpiration(dateKey) || 0;
        const certCount = certs.length;

        // COULEURS PASTEL
        let color = "#A8E6A1"; // Vert pastel
        if (daysUntilExp < 0) {
          color = "#FFB3B3"; // Rouge pastel
        } else if (daysUntilExp <= 7) {
          color = "#FFD4A3"; // Orange pastel
        } else if (daysUntilExp <= 30) {
          color = "#FFE5B3"; // Orange clair pastel
        } else if (daysUntilExp <= 90) {
          color = "#FFF5B7"; // Jaune pastel
        } else if (daysUntilExp <= 180) {
          color = "#B3E0FF"; // Bleu clair pastel
        } else if (daysUntilExp <= 365) {
          color = "#A3D5FF"; // Bleu pastel
        }

        // NOUVEAU CALCUL : Taille vraiment proportionnelle
        let bubbleSize;
        if (maxCount === minCount) {
          bubbleSize = 15; // Taille fixe si tous ont le même nombre
        } else {
          // Normalisation entre 8 et 50 pour avoir une vraie différence
          const normalized = (certCount - minCount) / (maxCount - minCount);
          bubbleSize = 8 + normalized * 42; // De 8 à 50
        }

        return {
          x: daysUntilExp,
          y: (index % 5) + 1,
          size: Math.round(bubbleSize),
          id: `bubble-${dateKey}-${index}`,
          date: dateKey,
          certificates: certs,
          color,
        };
      },
    );

    setBubbleData(bubbles);
  };

  useEffect(() => {
    fetchStatistics();
  }, []);

  // Appliquer les filtres quand ils changent
  useEffect(() => {
    if (startDate || endDate || typeFilter !== "All" || stateFilter !== "All") {
      fetchFilteredStatistics();
    } else {
      // Si aucun filtre n'est appliqué, récupérer les stats générales
      fetchStatistics();
    }
  }, [startDate, endDate, typeFilter, stateFilter]);

  // Calculer les jours jusqu'à l'expiration
  const getDaysUntilExpiration = (
    dateString: string | null | undefined,
  ): number | null => {
    if (!dateString) return null;
    const expDate = dayjs(dateString);
    const today = dayjs();
    return expDate.diff(today, "day");
  };

  // Formater les dates
  const formatDate = (dateString: string | null | undefined): string => {
    if (!dateString) return "-";
    try {
      return dayjs(dateString).format("DD/MM/YYYY");
    } catch (error) {
      console.error("Erreur de formatage de date:", error);
      return "-";
    }
  };

  // Configuration des colonnes pour le DataGrid
  const columns: GridColDef[] = [
    {
      field: "common_name",
      headerName: "Nom Commun",
      flex: 1,
      minWidth: 200,
    },
    {
      field: "certificate_type",
      headerName: "Type",
      flex: 0.8,
      minWidth: 120,
    },
    {
      field: "certificate_state",
      headerName: "État",
      flex: 0.8,
      minWidth: 120,
      renderCell: (params) => (
        <Chip
          label={params.value}
          color={params.value === "ACTIVE" ? "success" : "default"}
          size="small"
        />
      ),
    },
    {
      field: "exp_date",
      headerName: "Expiration",
      flex: 1,
      minWidth: 120,
      renderCell: (
        params: GridRenderCellParams<
          CertificateForDisplay,
          string | null | undefined
        >,
      ) => {
        const daysUntilExp = getDaysUntilExpiration(params.value || undefined);
        const isExpired = daysUntilExp !== null && daysUntilExp < 0;
        const isExpiringSoon =
          daysUntilExp !== null && daysUntilExp <= 7 && daysUntilExp >= 0;
        return (
          <Box display="flex" alignItems="center">
            <Typography variant="body2">
              {getFormatedDate(params?.value || "")}
            </Typography>
            {isExpired && <Error color="error" sx={{ ml: 1, fontSize: 16 }} />}
            {isExpiringSoon && (
              <Warning color="warning" sx={{ ml: 1, fontSize: 16 }} />
            )}
          </Box>
        );
      },
    },
    {
      field: "created_at",
      headerName: "Création",
      flex: 1,
      minWidth: 120,
      renderCell: (
        params: GridRenderCellParams<
          CertificateForDisplay,
          string | null | undefined
        >,
      ) => {
        const daysSinceCreation = getDaysUntilExpiration(
          params.value || undefined,
        );
        const isRecentlyCreated =
          daysSinceCreation !== null &&
          daysSinceCreation >= -7 &&
          daysSinceCreation <= 0;
        return (
          <Box display="flex" alignItems="center">
            <Typography variant="body2">
              {getFormatedDate(params?.value || "")}
            </Typography>
            {isRecentlyCreated && (
              <NewReleases color="primary" sx={{ ml: 1, fontSize: 16 }} />
            )}
          </Box>
        );
      },
    },
    {
      field: "applicant",
      headerName: "Demandeur",
      flex: 1,
      minWidth: 150,
    },
  ];

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <Box p={3}>
        {/* En-tête */}
        <Box
          display="flex"
          justifyContent="space-between"
          alignItems="center"
          mb={3}
        >
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <Typography variant="h4" gutterBottom>
              Dashboard des Certificats
            </Typography>
            <Typography variant="subtitle1" color="text.secondary">
              Gestion et suivi des certificats SSL/TLS
            </Typography>
          </motion.div>
        </Box>

        {/* Messages d'erreur */}
        {errorServiceMsg && (
          <Alert severity="error" sx={{ mb: 3 }}>
            {errorServiceMsg}
          </Alert>
        )}
        {errorOperationMsg && (
          <Alert severity="error" sx={{ mb: 3 }}>
            {errorOperationMsg}
          </Alert>
        )}

        {/* Filtres */}
        <Paper sx={{ p: 2, mb: 3 }}>
          <Typography variant="h6" gutterBottom>
            Filtres
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12} md={3}>
              <DatePicker
                label="Date de début"
                value={startDate}
                onChange={setStartDate}
                slotProps={{ textField: { fullWidth: true, size: "small" } }}
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <DatePicker
                label="Date de fin"
                value={endDate}
                onChange={setEndDate}
                slotProps={{ textField: { fullWidth: true, size: "small" } }}
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <FormControl fullWidth size="small">
                <InputLabel>Type de certificat</InputLabel>
                <Select
                  value={typeFilter}
                  label="Type de certificat"
                  onChange={(e) => setTypeFilter(e.target.value)}
                >
                  <MenuItem value="All">Tous les types</MenuItem>
                  {uniqueTypes.map((type) => (
                    <MenuItem key={type} value={type}>
                      {type}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={3}>
              <FormControl fullWidth size="small">
                <InputLabel>État</InputLabel>
                <Select
                  value={stateFilter}
                  label="État"
                  onChange={(e) => setStateFilter(e.target.value)}
                >
                  <MenuItem value="All">Tous les états</MenuItem>
                  {uniqueStates.map((state) => (
                    <MenuItem key={state} value={state}>
                      {state}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
          </Grid>
        </Paper>

        {loading ? (
          <Box display="flex" justifyContent="center" my={4}>
            <CircularProgress size={60} />
          </Box>
        ) : (
          <>
            {/* KPIs */}
            <Grid container spacing={3} mb={4}>
              <Grid item xs={12} sm={6} md={3}>
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                >
                  <Card sx={{ p: 2, height: "100%" }}>
                    <Box display="flex" alignItems="center">
                      <Avatar sx={{ bgcolor: "primary.main", mr: 2 }}>
                        <Security />
                      </Avatar>
                      <Box>
                        <Typography variant="h6" color="primary">
                          {stats.total}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          Total Certificats
                        </Typography>
                      </Box>
                    </Box>
                  </Card>
                </motion.div>
              </Grid>
              <Grid item xs={12} sm={6} md={3}>
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.1 }}
                >
                  <Card sx={{ p: 2, height: "100%" }}>
                    <Box display="flex" alignItems="center">
                      <Avatar sx={{ bgcolor: "success.main", mr: 2 }}>
                        <CheckCircle />
                      </Avatar>
                      <Box>
                        <Typography variant="h6" color="success.main">
                          {stats.createdToday}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          Créés aujourd'hui
                        </Typography>
                      </Box>
                    </Box>
                  </Card>
                </motion.div>
              </Grid>
              <Grid item xs={12} sm={6} md={3}>
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.2 }}
                >
                  <Card sx={{ p: 2, height: "100%" }}>
                    <Box display="flex" alignItems="center">
                      <Avatar sx={{ bgcolor: "warning.main", mr: 2 }}>
                        <Schedule />
                      </Avatar>
                      <Box>
                        <Typography variant="h6" color="warning.main">
                          {stats.expiringSoon}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          Expirent bientôt (≤ 1 mois)
                        </Typography>
                      </Box>
                    </Box>
                  </Card>
                </motion.div>
              </Grid>
              <Grid item xs={12} sm={6} md={3}>
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.3 }}
                >
                  <Card sx={{ p: 2, height: "100%" }}>
                    <Box display="flex" alignItems="center">
                      <Avatar sx={{ bgcolor: "error.main", mr: 2 }}>
                        <Error />
                      </Avatar>
                      <Box>
                        <Typography variant="h6" color="error.main">
                          {stats.expired}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          Expirés
                        </Typography>
                      </Box>
                    </Box>
                  </Card>
                </motion.div>
              </Grid>
            </Grid>

            {/* Bouton pour masquer/afficher le diagramme en bulles */}
            <Box mb={2}>
              <Tooltip
                title={
                  showBubbleChart
                    ? "Masquer le graphique des expirations"
                    : "Afficher le graphique des expirations"
                }
              >
                <Button
                  onClick={() => setShowBubbleChart(!showBubbleChart)}
                  color="primary"
                  startIcon={<BubbleChart />}
                  sx={{ fontSize: "1.2rem", padding: "10px 20px" }}
                >
                  {showBubbleChart
                    ? "Masquer le diagramme"
                    : "Afficher le diagramme"}
                </Button>
              </Tooltip>
            </Box>

            {/* Diagramme en bulles des expirations - Maintenant visible par défaut */}
            {showBubbleChart && (
              <Card sx={{ p: 3, mb: 4 }}>
                <Box display="flex" alignItems="center" mb={2}>
                  <BubbleChart sx={{ mr: 1, color: "primary.main" }} />
                  <Typography variant="h6">
                    Visualisation des Expirations par Date
                  </Typography>
                </Box>

                {bubbleData.length > 0 ? (
                  <Box>
                    <Box mb={2}>
                      <Typography
                        variant="body2"
                        color="text.secondary"
                        gutterBottom
                      >
                        Légende: Plus la bulle est grande, plus il y a de
                        certificats expirant à cette date. Tous les certificats
                        sont affichés.
                      </Typography>
                      <Box display="flex" gap={1} flexWrap="wrap">
                        <Chip
                          size="small"
                          label="Expiré"
                          sx={{ backgroundColor: "#FFB3B3", color: "#8B0000" }}
                        />
                        <Chip
                          size="small"
                          label="≤ 7 jours"
                          sx={{ backgroundColor: "#FFD4A3", color: "#8B4513" }}
                        />
                        <Chip
                          size="small"
                          label="≤ 30 jours"
                          sx={{ backgroundColor: "#FFE5B3", color: "#8B6914" }}
                        />
                        <Chip
                          size="small"
                          label="≤ 3 mois"
                          sx={{ backgroundColor: "#FFF5B7", color: "#8B8000" }}
                        />
                        <Chip
                          size="small"
                          label="≤ 6 mois"
                          sx={{ backgroundColor: "#B3E0FF", color: "#00008B" }}
                        />
                        <Chip
                          size="small"
                          label="≤ 1 an"
                          sx={{ backgroundColor: "#A3D5FF", color: "#000080" }}
                        />
                        <Chip
                          size="small"
                          label="> 1 an"
                          sx={{ backgroundColor: "#A8E6A1", color: "#006400" }}
                        />
                      </Box>
                    </Box>

                    <ScatterChart
                      height={400}
                      series={bubbleData.map((bubble, _seriesIndex) => ({
                        data: [
                          {
                            x: bubble.x,
                            y: bubble.y,
                            id: bubble.id,
                          },
                        ],
                        label: `${formatDate(bubble.date)} (${bubble.certificates.length})`,
                        color: bubble.color,
                        markerSize: bubble.size, // Utilise directement la taille calculée
                        valueFormatter: (_value) => {
                          const certNames = bubble.certificates
                            .slice(0, 2)
                            .map((c) => c.common_name)
                            .join(", ");
                          const moreText =
                            bubble.certificates.length > 2
                              ? ` et ${bubble.certificates.length - 2} autre(s)...`
                              : "";
                          const daysText =
                            bubble.x < 0
                              ? `Expiré il y a ${Math.abs(bubble.x)} jours`
                              : `Expire dans ${bubble.x} jours`;
                          return `📅 ${formatDate(bubble.date)}\n${daysText}\n📊 ${bubble.certificates.length} certificat(s)\n🔒 ${certNames}${moreText}`;
                        },
                      }))}
                      xAxis={[
                        {
                          label: "Jours jusqu'à expiration",
                          min: Math.min(...bubbleData.map((b) => b.x)) - 10,
                          max: Math.max(...bubbleData.map((b) => b.x)) + 10,
                        },
                      ]}
                      yAxis={[
                        {
                          label: "",
                          min: 0,
                          max: 6,
                          tickLabelStyle: { fontSize: 0 },
                          tickSize: 0,
                        },
                      ]}
                    />

                    <Box mt={2}>
                      <Typography variant="subtitle2" gutterBottom>
                        Certificats groupés par date d'expiration :
                      </Typography>
                      <Grid container spacing={1}>
                        {bubbleData.map((dateGroup, index) => (
                          <Grid item xs={12} sm={6} md={4} key={index}>
                            <Paper
                              sx={{
                                p: 2,
                                bgcolor: dateGroup.color + "20",
                                border: `2px solid ${dateGroup.color}50`,
                                cursor: "pointer",
                                "&:hover": {
                                  bgcolor: dateGroup.color + "30",
                                },
                              }}
                              onClick={() =>
                                toggleDateExpansion(dateGroup.date)
                              }
                            >
                              {/* En-tête du groupe */}
                              <Box
                                display="flex"
                                alignItems="center"
                                justifyContent="space-between"
                                mb={1}
                              >
                                <Box>
                                  <Typography
                                    variant="subtitle2"
                                    fontWeight="bold"
                                  >
                                    📅 {formatDate(dateGroup.date)}
                                  </Typography>
                                  <Typography
                                    variant="body2"
                                    color="primary"
                                    fontWeight="medium"
                                  >
                                    {dateGroup.certificates.length}{" "}
                                    certificat(s)
                                  </Typography>
                                </Box>
                                <Box textAlign="center">
                                  <Typography
                                    variant="caption"
                                    display="block"
                                    color="text.secondary"
                                  >
                                    {dateGroup.x < 0
                                      ? `Expiré il y a ${Math.abs(dateGroup.x)} jours`
                                      : `Expire dans ${dateGroup.x} jours`}
                                  </Typography>
                                  {expandedDates.has(dateGroup.date) ? (
                                    <ExpandLess color="primary" />
                                  ) : (
                                    <ExpandMore color="primary" />
                                  )}
                                </Box>
                              </Box>

                              {/* Liste des certificats développée */}
                              {expandedDates.has(dateGroup.date) && (
                                <Box
                                  mt={2}
                                  pt={2}
                                  borderTop={`1px solid ${dateGroup.color}50`}
                                  sx={{ maxHeight: 300, overflowY: "auto" }}
                                >
                                  {dateGroup.certificates.map(
                                    (cert, certIndex) => (
                                      <Box
                                        key={cert.certificate_id || certIndex}
                                        mb={1.5}
                                        p={1}
                                        sx={{
                                          bgcolor: "background.paper",
                                          borderRadius: 1,
                                          border: "1px solid",
                                          borderColor: "divider",
                                        }}
                                      >
                                        <Typography
                                          variant="body2"
                                          fontWeight="medium"
                                          gutterBottom
                                        >
                                          🔒{" "}
                                          {cert.common_name ||
                                            "Nom non spécifié"}
                                        </Typography>
                                        <Typography
                                          variant="caption"
                                          display="block"
                                          color="text.secondary"
                                        >
                                          <strong>Type:</strong>{" "}
                                          {cert.certificate_type || "N/A"}
                                        </Typography>
                                        <Typography
                                          variant="caption"
                                          display="block"
                                          color="text.secondary"
                                        >
                                          <strong>Demandeur:</strong>{" "}
                                          {cert.applicant || "N/A"}
                                        </Typography>
                                        <Typography
                                          variant="caption"
                                          display="block"
                                          color="text.secondary"
                                        >
                                          <strong>ID:</strong>{" "}
                                          {cert.certificate_id}
                                        </Typography>
                                      </Box>
                                    ),
                                  )}
                                </Box>
                              )}
                            </Paper>
                          </Grid>
                        ))}
                      </Grid>
                    </Box>
                  </Box>
                ) : (
                  <Box
                    display="flex"
                    justifyContent="center"
                    alignItems="center"
                    height={300}
                  >
                    <Typography color="text.secondary">
                      Aucune donnée disponible pour le diagramme en bulles.
                    </Typography>
                  </Box>
                )}
              </Card>
            )}

            {/* Alertes */}
            {(stats.expiringSoon > 0 || stats.expired > 0) && (
              <Box mb={3}>
                {stats.expired > 0 && (
                  <Alert severity="error" sx={{ mb: 1 }}>
                    {stats.expired} certificat(s) ont expiré !
                  </Alert>
                )}
                {stats.expiringSoon > 0 && (
                  <Alert severity="warning">
                    {stats.expiringSoon} certificat(s) expirent dans le mois !
                  </Alert>
                )}
              </Box>
            )}

            {/* Graphiques */}
            <Grid container spacing={3} mt={1} mb={4}>
              <Grid item xs={12} md={6}>
                <Card sx={{ p: 2, height: 400 }}>
                  <Typography variant="h6" gutterBottom>
                    Certificats par type
                  </Typography>
                  {chartData.typeChart.length > 0 ? (
                    <BarChart
                      height={320}
                      xAxis={[
                        {
                          id: "type",
                          data: chartData.typeChart.map((d) => d.type),
                          scaleType: "band",
                        },
                      ]}
                      series={[
                        {
                          data: chartData.typeChart.map((d) => d.count),
                          label: "Nombre de certificats",
                          color: "#A3D5FF",
                        },
                      ]}
                    />
                  ) : (
                    <Box
                      display="flex"
                      justifyContent="center"
                      alignItems="center"
                      height={320}
                    >
                      <Typography color="text.secondary">
                        Aucune donnée disponible
                      </Typography>
                    </Box>
                  )}
                </Card>
              </Grid>
              <Grid item xs={12} md={6}>
                <Card sx={{ p: 2, height: 400 }}>
                  <Typography variant="h6" gutterBottom>
                    Répartition par état
                  </Typography>
                  {chartData.stateChart.length > 0 ? (
                    <PieChart
                      height={320}
                      series={[
                        {
                          data: chartData.stateChart.map((item) => ({
                            ...item,
                            color: stateColors[item.label] || "#CCCCCC", // Couleur par défaut si non définie
                          })),
                        },
                      ]}
                    />
                  ) : (
                    <Box
                      display="flex"
                      justifyContent="center"
                      alignItems="center"
                      height={320}
                    >
                      <Typography color="text.secondary">
                        Aucune donnée disponible
                      </Typography>
                    </Box>
                  )}
                </Card>
              </Grid>
            </Grid>

            {/* Tableau des certificats - Affiché seulement si on a des données filtrées */}
            {certificates.length > 0 && (
              <Card sx={{ p: 2 }}>
                <Typography variant="h6" gutterBottom>
                  Liste des certificats ({certificates.length})
                </Typography>
                <DataGrid
                  rows={certificates}
                  columns={columns}
                  getRowId={(row) => row.certificate_id}
                  autoHeight
                  pageSizeOptions={[5, 10, 25, 50]}
                  initialState={{
                    pagination: { paginationModel: { pageSize: 10, page: 0 } },
                  }}
                  sx={{
                    border: "none",
                    "& .MuiDataGrid-columnHeaderTitle": {
                      fontWeight: "bold",
                    },
                    "& .MuiDataGrid-row:hover": {
                      backgroundColor: "action.hover",
                    },
                  }}
                />
              </Card>
            )}
          </>
        )}
      </Box>
    </LocalizationProvider>
  );
}