// src/types/view/HostView.ts

import DataView from "./DataView";

export interface HostView {
  source: string;
  number?: number;
  data?: DataView[];
  primaryColor: string;
  secondaryColor: string;
}
