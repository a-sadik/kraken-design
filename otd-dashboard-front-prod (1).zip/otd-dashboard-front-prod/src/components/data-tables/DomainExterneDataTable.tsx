// src/components/data-tables/DomainExterneDataTable.tsx

import { useMemo, useState, useCallback } from "react";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import {
  Box,
  Button,
  Tooltip,
  Switch,
  Typography,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  IconButton,
} from "@mui/material";
import {
  MRT_GlobalFilterTextField,
  MRT_ShowHideColumnsButton,
  MRT_TableContainer,
  MRT_TablePagination,
  MRT_ToggleDensePaddingButton,
  MRT_ToggleFiltersButton,
  useMaterialReactTable,
  type MRT_ColumnDef,
} from "material-react-table";

// Imports d'icônes
import KeyboardIcon from "@mui/icons-material/Keyboard";
import VisibilityIcon from "@mui/icons-material/Visibility";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import { CiExport } from "react-icons/ci";

// Imports de styles et containers personnalisés
import WidgetMainContainer from "@/components/containers/WidgetMainContainer";
import { getCssVariableValue } from "@/utils/getDynamicColor";
import "@/styles/reliability-data-table.css";
import "@/styles/colors.css";

// import ficher
import AddForm from "@/components/forms/AddForm";
import { Admin } from "@/enums/Admin";

// Type de données pour l'entité
type DomainExterneData = {
  action: string;
  nom: string;
  manager: string;
  DateDeCreation: string;
};

// Données initiales
const initialEntities: DomainExterneData[] = [
  {
    action: "Said",
    nom: "Said",
    manager: "East Daphne",
    DateDeCreation: "20/02/2025",
  },
  {
    action: "samir",
    nom: "samir",
    manager: "East Daphne",
    DateDeCreation: "05/03/2025",
  },
  {
    action: "hamid",
    nom: "hamid",
    manager: "East Daphne",
    DateDeCreation: "25/03/2025",
  },
  {
    action: "brahim",
    nom: "brahim",
    manager: "East Daphne",
    DateDeCreation: "27/03/2025",
  },
  {
    action: "test1",
    nom: "Mohammed",
    manager: "East Daphne",
    DateDeCreation: "10/03/2025",
  },
];

const DomainExterneDataTable = () => {
  // États pour les entités
  const [entities, setEntities] =
    useState<DomainExterneData[]>(initialEntities);

  // États pour les différentes boîtes de dialogue
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedDomainExterne, setSelectedDomainExterne] =
    useState<DomainExterneData | null>(null);
  const [openViewDialog, setOpenViewDialog] = useState(false);

  const [openEditDialog, setOpenEditDialog] = useState(false);
  const [editedDomainExterne, setEditedDomainExterne] =
    useState<DomainExterneData | null>(null);

  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [entityToDelete, setDomainExterneToDelete] =
    useState<DomainExterneData | null>(null);

  // const showHideButtonRef = useRef(null);

  // Gestion de l'ouverture du formulaire d'ajout
  const handleOpenAddDomainExterne = useCallback(() => {
    setIsAddModalOpen(true);
  }, []);

  // Gestion de la soumission du formulaire d'ajout
  const handleSubmitAddDomainExterne = (newDomainExterne: {
    nom: string;
    manager: string;
  }) => {
    const today = new Date();
    const formattedDate = today.toLocaleDateString(); // Format local ou adapter selon vos besoins
    const newDomainExterneData: DomainExterneData = {
      action: newDomainExterne.nom,
      nom: newDomainExterne.nom,
      manager: newDomainExterne.manager,
      DateDeCreation: formattedDate,
    };
    setEntities((prev) => [...prev, newDomainExterneData]);
    setIsAddModalOpen(false);
  };

  // Gestion des actions du tableau
  const handleView = (entity: DomainExterneData) => {
    setSelectedDomainExterne(entity);
    setOpenViewDialog(true);
  };

  const handleEdit = (entity: DomainExterneData) => {
    setEditedDomainExterne(entity);
    setOpenEditDialog(true);
  };

  const handleSaveEdit = () => {
    if (editedDomainExterne) {
      console.log("Données modifiées :", editedDomainExterne);
      // Mettre à jour l'entité dans le state
      setEntities((prev) =>
        prev.map((item) =>
          item.nom === editedDomainExterne.nom ? editedDomainExterne : item,
        ),
      );
      setOpenEditDialog(false);
    }
  };

  const handleDelete = (entity: DomainExterneData) => {
    setDomainExterneToDelete(entity);
    setOpenDeleteDialog(true);
  };

  const handleConfirmDelete = () => {
    if (entityToDelete) {
      console.log("Entité supprimée :", entityToDelete);
      setEntities((prev) =>
        prev.filter((item) => item.nom !== entityToDelete.nom),
      );
      setOpenDeleteDialog(false);
    }
  };

  // Définition des colonnes du tableau
  const columns = useMemo<MRT_ColumnDef<DomainExterneData>[]>(
    () => [
      {
        accessorKey: "action",
        header: "Action",
        size: 150,
        Cell: ({ row }) => (
          <Box display="flex" gap={1}>
            <Tooltip title="Voir">
              <IconButton
                onClick={() => handleView(row.original)}
                sx={{
                  backgroundColor: "#FBC02D",
                  color: "#333",
                  "&:hover": { backgroundColor: "#F9A825" },
                  borderRadius: "50px",
                  width: "30px",
                  height: "30px",
                }}
              >
                <VisibilityIcon />
              </IconButton>
            </Tooltip>
            <Tooltip title="Modifier">
              <IconButton
                onClick={() => handleEdit(row.original)}
                sx={{
                  backgroundColor: "#FBC02D",
                  color: "#333",
                  "&:hover": { backgroundColor: "#F9A825" },
                  borderRadius: "50px",
                  width: "30px",
                  height: "30px",
                }}
              >
                <EditIcon />
              </IconButton>
            </Tooltip>
            <Tooltip title="Supprimer">
              <IconButton
                onClick={() => handleDelete(row.original)}
                sx={{
                  backgroundColor: "#FBC02D",
                  color: "#333",
                  "&:hover": { backgroundColor: "#F9A825" },
                  borderRadius: "50px",
                  width: "30px",
                  height: "30px",
                }}
              >
                <DeleteIcon />
              </IconButton>
            </Tooltip>
          </Box>
        ),
      },
      {
        accessorKey: "nom",
        header: "Nom",
        size: 150,
      },
      {
        accessorKey: "manager",
        header: "Manager",
        size: 150,
      },
      {
        accessorKey: "DateDeCreation",
        header: "Date de Création",
        size: 150,
      },
    ],
    [],
  );

  // Configuration du tableau avec material-react-table
  const table = useMaterialReactTable({
    columns,
    data: entities,
    initialState: { showGlobalFilter: true },
    muiSearchTextFieldProps: {
      sx: {
        "& .MuiOutlinedInput-root": {
          border: "none",
          boxShadow: "none",
          borderBottom: "1px solid gray",
          borderRadius: "0px",
        },
        "& .MuiOutlinedInput-notchedOutline": {
          display: "none",
        },
      },
    },
  });

  const primaryColor = getCssVariableValue("--primary-color");

  const customTheme = createTheme({
    palette: {
      primary: { main: primaryColor },
    },
  });

  return (
    <ThemeProvider theme={customTheme}>
      <Box
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        mb={3}
      >
        <Typography className="data-table-title">
          {`Liste des ${Admin.DomainNameExterne}`}
        </Typography>
        <Box display="flex" gap={2}>
          <Button
            variant="contained"
            color="primary"
            startIcon={<KeyboardIcon />}
            onClick={handleOpenAddDomainExterne}
            className="button-add"
          >
            <Typography className="text-button-add">Ajouter</Typography>
          </Button>
        </Box>
      </Box>

      <WidgetMainContainer sx={{ borderColor: "--primary-color" }}>
        {/* Barre d'outils externe */}
        <Box
          sx={{
            display: "flex",
            backgroundColor: "inherit",
            borderRadius: "4px",
            flexDirection: "row",
            gap: "16px",
            color: "primary",
            justifyContent: "space-between",
            alignItems: "center",
            "@media max-width: 768px": { flexDirection: "column" },
          }}
        >
          <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
            <MRT_ShowHideColumnsButton
              table={table}
              sx={{ color: primaryColor, padding: "2px" }}
            />
            <Typography variant="body2" sx={{ color: primaryColor }}>
              Colonnes
            </Typography>
          </Box>
          <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
            <MRT_ToggleFiltersButton
              table={table}
              sx={{ color: primaryColor, padding: "0px" }}
            />
            <Typography variant="body2" sx={{ color: primaryColor }}>
              Filtres
            </Typography>
          </Box>
          <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
            <CiExport
              style={{
                color: primaryColor,
                padding: "0px",
                fontSize: "16px",
                strokeWidth: 1,
              }}
            />
            <Typography variant="body2" sx={{ color: primaryColor }}>
              Export
            </Typography>
          </Box>
          <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
            <MRT_ToggleDensePaddingButton
              table={table}
              sx={{ color: primaryColor, padding: "0px" }}
            />
            <Typography variant="body2" sx={{ color: primaryColor }}>
              Test
            </Typography>
          </Box>
          {/* Switches Optionnels */}
          <Tooltip title="Activation/Désactivation">
            <Switch size="small" color="primary" />
          </Tooltip>
          <Tooltip title="Activation/Désactivation">
            <Switch size="small" color="primary" />
          </Tooltip>
          <Tooltip title="Activation/Désactivation">
            <Switch size="small" color="primary" />
          </Tooltip>
          <MRT_GlobalFilterTextField table={table} />
        </Box>
        <MRT_TableContainer table={table} />
        <Box sx={{ display: "flex", justifyContent: "flex-end" }}>
          <MRT_TablePagination table={table} />
        </Box>
      </WidgetMainContainer>

      {/* --- DIALOGS --- */}

      {/* Détails de l'entité */}
      <Dialog
        open={openViewDialog}
        onClose={() => setOpenViewDialog(false)}
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle>Détails de l'entité</DialogTitle>
        <DialogContent>
          {selectedDomainExterne && (
            <Box>
              <Typography>
                <strong>Nom:</strong> {selectedDomainExterne.nom}
              </Typography>
              <Typography>
                <strong>Manager:</strong> {selectedDomainExterne.manager}
              </Typography>
              <Typography>
                <strong>Date de création:</strong>{" "}
                {selectedDomainExterne.DateDeCreation}
              </Typography>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenViewDialog(false)} color="primary">
            Fermer
          </Button>
        </DialogActions>
      </Dialog>

      {/* Modifier l'entité */}
      <Dialog
        open={openEditDialog}
        onClose={() => setOpenEditDialog(false)}
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle>Modifier l'entité</DialogTitle>
        <DialogContent>
          {editedDomainExterne && (
            <Box display="flex" flexDirection="column" gap={2} mt={2}>
              <TextField
                label="Nom"
                fullWidth
                value={editedDomainExterne.nom}
                onChange={(e) =>
                  setEditedDomainExterne({
                    ...editedDomainExterne,
                    nom: e.target.value,
                  })
                }
              />
              <TextField
                label="Manager"
                fullWidth
                value={editedDomainExterne.manager}
                onChange={(e) =>
                  setEditedDomainExterne({
                    ...editedDomainExterne,
                    manager: e.target.value,
                  })
                }
              />
              <TextField
                label="Date de création"
                fullWidth
                type="date"
                value={editedDomainExterne.DateDeCreation}
                onChange={(e) =>
                  setEditedDomainExterne({
                    ...editedDomainExterne,
                    DateDeCreation: e.target.value,
                  })
                }
                InputLabelProps={{ shrink: true }}
              />
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenEditDialog(false)} color="secondary">
            Annuler
          </Button>
          <Button onClick={handleSaveEdit} color="primary" variant="contained">
            Enregistrer
          </Button>
        </DialogActions>
      </Dialog>

      {/* Suppression de l'entité */}
      <Dialog
        open={openDeleteDialog}
        onClose={() => setOpenDeleteDialog(false)}
        fullWidth
        maxWidth="xs"
      >
        <DialogTitle>Confirmation</DialogTitle>
        <DialogContent>
          <Typography>
            Êtes-vous sûr de vouloir supprimer l'entité{" "}
            <strong>{entityToDelete?.nom}</strong> ?
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenDeleteDialog(false)} color="secondary">
            Annuler
          </Button>
          <Button
            onClick={handleConfirmDelete}
            color="error"
            variant="contained"
          >
            Supprimer
          </Button>
        </DialogActions>
      </Dialog>

      {/* --- Formulaire d'ajout d'entité --- */}
      <AddForm
        open={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onSubmit={handleSubmitAddDomainExterne}
        adminType="Nom domaine externe"
      />
    </ThemeProvider>
  );
};

export default DomainExterneDataTable;
