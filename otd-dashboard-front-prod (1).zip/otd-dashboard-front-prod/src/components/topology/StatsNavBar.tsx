// import React, { useState } from 'react';
// import { Box, Grid, Typography, Chip, alpha, IconButton, List, ListItem, ListItemText, Paper, Stack } from '@mui/material';
// import { AccountTree, Apps, Person, Visibility, VisibilityOff } from '@mui/icons-material';
// import { FiServer } from 'react-icons/fi';
// import { VscSymbolNamespace } from 'react-icons/vsc';
// import { LuRocket } from 'react-icons/lu';
// import { PiCubeBold } from 'react-icons/pi';
// import { colors } from './utils/colors';

// import { MdAdminPanelSettings, MdOutlineAdminPanelSettings } from 'react-icons/md';
// import { TbBuildingBank } from 'react-icons/tb';
// import { darkColors, pastelTheme } from '../basics/ThemeButton';

// interface StatsNavBarProps {
//     navigation: any;
// }

// const StatsNavBar: React.FC<StatsNavBarProps> = ({ navigation }) => {

//     const currentStats = navigation.currentItem || {}
//     const currentLevelColor = getLevelColor(navigation.currentLevel)
//     const [isVisible, setIsVisible] = useState(true)
//     const [showAdmins, setShowAdmins] = useState(false);
//     const currentNavigationLevel = navigation.currentLevel

//     // Colonne 1 : Organisation
//     const orgStats = []

//     if (currentStats.count_poles !== undefined)
//         orgStats.push({ label: "Pôles", value: currentStats.count_poles, icon: <AccountTree /> })
//     if (currentStats.count_domains !== undefined)
//         orgStats.push({ label: "Domaines", value: currentStats.count_domains, icon: <TbBuildingBank /> })
//     if (currentStats.count_solutions !== undefined)
//         orgStats.push({ label: "Solutions", value: currentStats.count_solutions, icon: <Apps /> })

//     // Colonne 2 : Infrastructure
//     const infraStats = []
//     if (currentStats.count_servers !== undefined)
//         infraStats.push({ label: "Serveurs", value: currentStats.count_servers, icon: <FiServer /> })
//     if (currentStats.count_namespaces !== undefined)
//         infraStats.push({ label: "Namespaces", value: currentStats.count_namespaces, icon: <VscSymbolNamespace /> })
//     if (currentStats.count_deployments !== undefined)
//         infraStats.push({ label: "Déploiements", value: currentStats.count_deployments, icon: <LuRocket /> })
//     if (currentStats.count_pods !== undefined)
//         infraStats.push({ label: "Pods", value: currentStats.count_pods, icon: <PiCubeBold /> })

//     // Colonne 3 : Administration
//     const adminStats = []
//     if (currentStats.count_technical_admins !== undefined)
//         adminStats.push({ label: "Admins Tech", value: currentStats.count_technical_admins, icon: <MdAdminPanelSettings /> })
//     if (currentStats.count_functional_admins !== undefined)
//         adminStats.push({ label: "Admins Fonc", value: currentStats.count_functional_admins, icon: <MdOutlineAdminPanelSettings /> })
//     if (currentStats.count_tams !== undefined)
//         adminStats.push({ label: "TAMs", value: currentStats.count_tams, icon: <Person /> })

//     if (orgStats.length === 0 && infraStats.length === 0 && adminStats.length === 0) return null

//     return (
//         <>

//             {/* Bouton de contrôle */}
//             <Box sx={{ position: 'fixed', right: 16, top: 70, zIndex: 1100, display: 'flex', gap: 1 }}>
//                 <IconButton
//                     onClick={() => setShowAdmins(!showAdmins)}
//                     sx={{
//                         backgroundColor: colors.solution,
//                         color: 'white',
//                         '&:hover': {
//                             backgroundColor: darkColors.solution,
//                         }
//                     }}
//                 >
//                     <MdAdminPanelSettings />
//                 </IconButton>
//                 <IconButton
//                     onClick={() => setIsVisible(!isVisible)}
//                     sx={{
//                         backgroundColor: currentLevelColor,
//                         color: 'white',
//                         '&:hover': {
//                             backgroundColor: darkColors[currentNavigationLevel as keyof typeof darkColors],
//                         }
//                     }}
//                 >
//                     {isVisible ? <VisibilityOff /> : <Visibility />}
//                 </IconButton>
//             </Box>

//             {/* Barre de stats */}

//             {isVisible && (
//                 <Box sx={{ position: 'relative', zIndex: 1000, mb: 3 }}>
//                     <Grid container spacing={3}>

//                         {/* Colonne Organisation */}
//                         <Grid item xs={12} md={4}>
//                             <Box sx={{
//                                 p: 2,
//                                 height: '100%',
//                                 borderLeft: `4px solid ${colors.entity}`,
//                                 bgcolor: alpha(colors.entity, 0.05)
//                             }}>
//                                 <Typography variant="subtitle2" sx={{
//                                     fontWeight: 700,
//                                     mb: 1,
//                                     color: colors.entity,
//                                     display: 'flex',
//                                     alignItems: 'center',
//                                     gap: 1
//                                 }}>
//                                     <AccountTree /> Organisation
//                                 </Typography>

//                                 {/* Affichage du responsable */}
//                                 {currentStats.person && (
//                                     <Box sx={{ mb: 2 }}>
//                                         <Typography variant="body2">
//                                             <strong>TAM:</strong> {currentStats.person}
//                                         </Typography>
//                                     </Box>
//                                 )}

//                                 <Stack spacing={1}>
//                                     {orgStats.map((stat, index) => (
//                                         <Box key={`org-${index}`} sx={{ display: "flex", alignItems: "center", gap: 1 }}>
//                                             {React.cloneElement(stat.icon, { sx: { fontSize: 18, color: colors.entity } })}
//                                             <Typography variant="body2" sx={{ flexGrow: 1 }}>{stat.label}</Typography>
//                                             <Chip
//                                                 label={stat.value}
//                                                 size="small"
//                                                 sx={{
//                                                     backgroundColor: stat.value === 0 ? alpha(colors.entity, 0.3) : colors.entity,
//                                                     color: "white",
//                                                     fontWeight: 700,
//                                                 }}
//                                             />
//                                         </Box>
//                                     ))}
//                                 </Stack>
//                             </Box>
//                         </Grid>

//                         {/* Colonne Infrastructure */}
//                         <Grid item xs={12} md={4}>
//                             <Box sx={{
//                                 p: 2,
//                                 height: '100%',
//                                 borderLeft: `4px solid ${colors.server}`,
//                                 bgcolor: alpha(colors.server, 0.05)
//                             }}>
//                                 <Typography variant="subtitle2" sx={{
//                                     fontWeight: 700,
//                                     mb: 1,
//                                     color: colors.server,
//                                     display: 'flex',
//                                     alignItems: 'center',
//                                     gap: 1
//                                 }}>
//                                     <FiServer /> Infrastructure
//                                 </Typography>
//                                 <Stack spacing={1}>
//                                     {infraStats.map((stat, index) => (
//                                         <Box key={`infra-${index}`} sx={{ display: "flex", alignItems: "center", gap: 1 }}>
//                                             {React.cloneElement(stat.icon, { sx: { fontSize: 18, color: colors.server } })}
//                                             <Typography variant="body2" sx={{ flexGrow: 1 }}>{stat.label}</Typography>
//                                             <Chip
//                                                 label={stat.value}
//                                                 size="small"
//                                                 sx={{
//                                                     backgroundColor: stat.value === 0 ? alpha(colors.server, 0.3) : colors.server,
//                                                     color: "white",
//                                                     fontWeight: 700,
//                                                 }}
//                                             />
//                                         </Box>
//                                     ))}
//                                 </Stack>
//                             </Box>
//                         </Grid>

//                         {/* Colonne Administration */}
//                         <Grid item xs={12} md={4}>
//                             <Box sx={{
//                                 p: 2,
//                                 height: '100%',
//                                 borderLeft: `4px solid ${colors.solution}`,
//                                 bgcolor: alpha(colors.solution, 0.05)
//                             }}>
//                                 <Typography variant="subtitle2" sx={{
//                                     fontWeight: 700,
//                                     mb: 1,
//                                     color: colors.solution,
//                                     display: 'flex',
//                                     alignItems: 'center',
//                                     gap: 1
//                                 }}>
//                                     <MdAdminPanelSettings /> Administration
//                                 </Typography>
//                                 <Stack spacing={1}>
//                                     {adminStats.map((stat, index) => (
//                                         <Box key={`admin-${index}`} sx={{ display: "flex", alignItems: "center", gap: 1 }}>
//                                             {React.cloneElement(stat.icon, { sx: { fontSize: 18, color: colors.solution } })}
//                                             <Typography variant="body2" sx={{ flexGrow: 1 }}>{stat.label}</Typography>
//                                             <Chip
//                                                 label={stat.value}
//                                                 size="small"
//                                                 sx={{
//                                                     backgroundColor: stat.value === 0 ? alpha(colors.solution, 0.3) : colors.solution,
//                                                     color: "white",
//                                                     fontWeight: 700,
//                                                 }}
//                                                 onClick={() => stat.value > 0 && setShowAdmins(!showAdmins)}
//                                             />
//                                         </Box>
//                                     ))}
//                                 </Stack>
//                             </Box>
//                         </Grid>
//                     </Grid>
//                 </Box>
//             )}

//             {/* Modal pour afficher la liste des administrateurs */}
//             {showAdmins && currentStats.list_admins && (
//                 <Paper sx={{
//                     position: 'fixed',
//                     top: '50%',
//                     left: '50%',
//                     transform: 'translate(-50%, -50%)',
//                     zIndex: 1200,
//                     width: '80%',
//                     maxWidth: 800,
//                     maxHeight: '80vh',
//                     overflow: 'auto',
//                     p: 3,
//                     boxShadow: 24,
//                     borderRadius: 3,
//                     backgroundColor: pastelTheme.cardBackground
//                 }}>
//                     <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
//                         <Typography variant="h6" sx={{ color: colors.solution }}>
//                             Liste des Administrateurs
//                         </Typography>
//                         <IconButton onClick={() => setShowAdmins(false)}>
//                             <VisibilityOff />
//                         </IconButton>
//                     </Box>

//                     <Grid container spacing={2}>
//                         {/* Admins Techniques */}
//                         <Grid item xs={12} md={4}>
//                             <Paper sx={{ p: 2, borderLeft: `4px solid ${colors.solution}` }}>
//                                 <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1, color: colors.solution }}>
//                                     Admins Techniques ({currentStats.count_technical_admins || 0})
//                                 </Typography>
//                                 <List dense>
//                                     {currentStats.list_admins.technical_admins?.map((admin: any, index: number) => {
//                                         const emailPrefix = admin.email.split('@')[0];
//                                         const displayName = admin.name ? admin.name.replace(/@.*$/, '') : emailPrefix;
//                                         return (
//                                             <ListItem key={`tech-${index}`} sx={{ py: 0.5 }}>
//                                                 <ListItemText
//                                                     primary={displayName}
//                                                     secondary={admin.email}
//                                                     primaryTypographyProps={{ fontSize: 14, fontWeight: 600 }}
//                                                     secondaryTypographyProps={{ fontSize: 12 }}
//                                                 />
//                                             </ListItem>
//                                         );
//                                     })}
//                                 </List>
//                             </Paper>
//                         </Grid>

//                         {/* Admins Fonctionnels */}
//                         <Grid item xs={12} md={4}>
//                             <Paper sx={{ p: 2, borderLeft: `4px solid ${colors.solution}` }}>
//                                 <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1, color: colors.solution }}>
//                                     Admins Fonctionnels ({currentStats.count_functional_admins || 0})
//                                 </Typography>
//                                 <List dense>
//                                     {currentStats.list_admins.functional_admins?.map((admin: any, index: number) => {
//                                         const emailPrefix = admin.email.split('@')[0];
//                                         const displayName = admin.name ? admin.name.replace(/@.*$/, '') : emailPrefix;
//                                         return (
//                                             <ListItem key={`func-${index}`} sx={{ py: 0.5 }}>
//                                                 <ListItemText
//                                                     primary={displayName}
//                                                     secondary={admin.email}
//                                                     primaryTypographyProps={{ fontSize: 14, fontWeight: 600 }}
//                                                     secondaryTypographyProps={{ fontSize: 12 }}
//                                                 />
//                                             </ListItem>
//                                         );
//                                     })}
//                                 </List>
//                             </Paper>
//                         </Grid>

//                         {/* TAMs */}
//                         <Grid item xs={12} md={4}>
//                             <Paper sx={{ p: 2, borderLeft: `4px solid ${colors.solution}` }}>
//                                 <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1, color: colors.solution }}>
//                                     TAMs ({currentStats.count_tams || 0})
//                                 </Typography>
//                                 {currentStats.person ? (
//                                     <List dense>
//                                         <ListItem sx={{ py: 0.5 }}>
//                                             <ListItemText
//                                                 primary={currentStats.person.split('@')[0]}
//                                                 secondary={currentStats.person}
//                                                 primaryTypographyProps={{ fontSize: 14, fontWeight: 600 }}
//                                                 secondaryTypographyProps={{ fontSize: 12 }}
//                                             />
//                                         </ListItem>
//                                     </List>
//                                 ) : (
//                                     <Typography variant="body2" sx={{ fontSize: 12 }}>
//                                         Aucun TAM défini
//                                     </Typography>
//                                 )}
//                             </Paper>
//                         </Grid>
//                     </Grid>
//                 </Paper>
//             )}
//         </>
//     );
// };

// export default StatsNavBar;
