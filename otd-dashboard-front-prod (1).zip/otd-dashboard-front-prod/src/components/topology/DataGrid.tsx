// import React from 'react';
// import { Box, CircularProgress, Grid, Skeleton, Slide, Typography } from '@mui/material';
// import ItemCard from './ItemCard';
// import { SolutionList } from '@/types/TopologyTypes';
// import SolutionDetailView from './SolutionDetalisView';

// interface DataGridProps {
//   currentData: any[];
//   dataLoaded: boolean;
//   loading: Set<string>;
//   navigation: any;
//   navigateToChild: (item: any, level: string) => void;
// }

// const DataGrid: React.FC<DataGridProps> = ({ currentData, dataLoaded, loading, navigation, navigateToChild }) => {

//   if (!dataLoaded) {
//     return (
//       <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
//         <CircularProgress />
//       </Box>
//     );
//   }

//   if (loading.has("entities") && currentData.length === 0) {
//     return (
//       <Grid container spacing={3}>
//         {[1, 2, 3, 4, 5, 6].map((i) => (
//           <Grid item xs={12} sm={6} md={4} key={i}>
//             <Skeleton variant="rectangular" height={200} sx={{ borderRadius: 4 }} />
//           </Grid>
//         ))}
//       </Grid>
//     )
//   }

//   if (currentData.length === 0) {
//     return (
//       <Box sx={{ textAlign: "center", py: 8 }}>
//         <Typography variant="h6" color="text.secondary">
//           Aucune donnée disponible pour ce niveau
//         </Typography>
//       </Box>
//     )
//   }

//   // Vue spéciale pour les solutions
//   if (navigation.currentLevel === "solution" && currentData.length === 1) {
//     return <SolutionDetailView solution={currentData[0] as SolutionList} />
//   }

//   return (
//     <Slide direction="up" in timeout={400}>
//       <Grid container spacing={3}>
//         {currentData.map((item, index) => (
//           <Grid item xs={12} sm={6} md={4} lg={3} key={item.id || index}>
//             <ItemCard
//               item={item}
//               level={navigation.currentLevel}
//               onNavigate={() => navigateToChild(item, navigation.currentLevel)}
//             />
//           </Grid>
//         ))}
//       </Grid>
//     </Slide>
//   )
// }

// export default DataGrid;
