import type React from "react";
import { useState } from "react";
import NamespaceDataTable from "@/components/data-tables/NamespaceDataTable";
import ServerDataTable from "@/components/data-tables/ServerDataTable";
import { Tabs, Tab, Box } from "@mui/material";
import IsolatedServerPage from "./IsolatedServerPage";
import IpConflictPage from "@/components/data-tables/IpConflitPage";
import DecommissionServerList from "@/components/data-tables/DecommissionServerList";

const SignatureNamespacesPage: React.FC = () => {
  const [openModal, setOpenModal] = useState(false);
  const [activeTab, setActiveTab] = useState(0);

  const handleTabChange = (_event: React.SyntheticEvent, newValue: number) => {
    setActiveTab(newValue);
  };

  return (
    <Box sx={{ width: "100%" }}>
      <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
        <Tabs value={activeTab} onChange={handleTabChange}>
          <Tab label="Serveurs" />
          <Tab label="Namespaces" />
          <Tab label="Serveurs isolés" />
          <Tab label="Conflit IP" />
          <Tab label="Demande de Décommissionnement" />
        </Tabs>
      </Box>

      {activeTab === 0 && (
        <ServerDataTable openModal={openModal} setOpenModal={setOpenModal} />
      )}
      {activeTab === 1 && (
        <NamespaceDataTable openModal={openModal} setOpenModal={setOpenModal} />
      )}
      {activeTab === 2 && (
        <IsolatedServerPage
        />
      )}
      {activeTab === 3 && (
        <IpConflictPage />
      )}
      {activeTab === 4 && (
        <DecommissionServerList />
      )}
    </Box>
  );
};

export default SignatureNamespacesPage;