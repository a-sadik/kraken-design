export interface ServerRequestDTO {
  hostname: string;
  ip_addresses: string[];
  server_nature: string[] | null;
  nature_detail: string | null;
  os_type: string | null;
  uname?: string | null;
  environments: string[] | null;
  solution_ids: number[];
  solutions_inventory?: string[] | null;
  natures_inventory?: string | null | undefined;
  operation_by: string;
}
