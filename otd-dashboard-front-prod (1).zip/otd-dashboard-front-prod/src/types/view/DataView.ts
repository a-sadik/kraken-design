// src/types/view/DataView.ts

export default interface DataView {
  Hostname: string;
  "Adresses IP": string[];
  OS: string | null;
  Solutions: string | null;
  Environnements: string[] | null;
  Domaine: string | null;
  Pôle: string | null;
  Entity: string | null;
  TAM: string | null;
  "Admins techniques": string[] | string | null;
  "Admins fonctionnels": string[] | string | null;
  "Nature de serveur": string[] | null;
  Popularité: string | null;
  Rôle: string | null;
  "Type de solution": string | null;
  // 'Version de la solution déployée': string | null;
  PCI: string | null;
}
