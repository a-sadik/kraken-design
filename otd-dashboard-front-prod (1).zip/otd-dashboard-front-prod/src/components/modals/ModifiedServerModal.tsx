//src/components/modals/ModifiedServerModal.tsx

import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  Box,
  Grid,
  Card,
  CardContent,
  TextField,
  Autocomplete,
  MenuItem,
  Alert,
  Avatar,
  IconButton,
  Slide,
  useTheme,
  useMediaQuery,
  Chip,
  CircularProgress,
} from "@mui/material";
import {
  Close as CloseIcon,
  Computer as ComputerIcon,
  Save as SaveIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
} from "@mui/icons-material";
import type { TransitionProps } from "@mui/material/transitions";
import { useForm, Controller, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z as zod } from "zod";

// Imports des types et services (à adapter selon votre structure)
import type { SolutionDetailResponseDTO } from "@/types/dto/response/solution/SolutionDetailResponseDTO";
import { OperatingSystemType } from "@/enums/OperatingSystemType";
import { ServerNature } from "@/enums/ServerNature";
import { Environnement } from "@/enums/Environnement";
// import { getAllSolutions } from "@/services/SolutionService" // Cette ligne reste commentée
import {
  getNatures_Inventory,
  getSolutions_Inventory,
} from "@/config/api.config";
import fetchWithAuth from "@/middleware/fetch-auth";
import { keycloak } from "@/auth/keycloakConnectAdapter";

// Transition personnalisée
const Transition = React.forwardRef(function Transition(
  props: TransitionProps & {
    children: React.ReactElement;
  },
  ref: React.Ref<unknown>,
) {
  return <Slide direction="up" ref={ref} {...props} />;
});

const getFormSchema = (_isDeleteMode: boolean, _isDeployMode: boolean) =>
  zod.object({
    hostname: zod.string().optional(),
    ip_addresses: zod
      .array(
        zod
          .string()
          .regex(
            /^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/,
            "Adresse IP invalide",
          ),
      )
      .optional(),
    os_type: zod.string().optional(),
    uname: zod.string().optional(),
    server_nature: zod.array(zod.string()).optional(),
    nature_detail: zod.string().optional(),
    solutions: zod
      .array(
        zod
          .object({
            id: zod.number(),
            solution_name: zod.string(),
            solution_role: zod.string(),
            psi: zod.string().nullable(),
            solution_popularity: zod.string().nullable(),
            solution_type: zod.string().nullable(),
            domain: zod.string().nullable(),
            pole: zod.string().nullable(),
            entity: zod.string().nullable(),
            tams: zod.array(zod.string()),
            technical_admins: zod.array(zod.string()),
            functional_admins: zod.array(zod.string()),
            declarted_on_bigfix: zod.boolean(),
            declarted_on_itop: zod.boolean(),
            fiable: zod.boolean(),
          })
          .optional(),
      )
      .optional(),
    solutions_inventory: zod
      .array(zod.string())
      .refine((val) => val.length > 0, {
        message: "Au moins une solution d'inventaire est requise",
      }),
    natures_inventory: zod.array(zod.string()).refine((val) => val.length > 0, {
      message: "Au moins une nature d'inventaire est requise",
    }),
    environments: zod.array(zod.string()).refine((val) => val.length > 0, {
      message: "Au moins un environnement est requis",
    }),
    login: zod.string().optional(),
    password: zod.string().optional(),
    sudo_password: zod.string().optional(),
  });

export type ServerFormData = zod.infer<ReturnType<typeof getFormSchema>>;

// Fonctions utilitaires pour les couleurs
const getOSColor = (os: string) => {
  switch (os.toLowerCase()) {
    case "windows":
      return { bgColor: "#99caff", textColor: "#1E40AF" };
    case "linux":
      return { bgColor: "#a8e6b1", textColor: "#166534" };
    case "macos":
      return { bgColor: "#f3aebd", textColor: "#831843" };
    case "aix":
      return { bgColor: "#fce38a", textColor: "#1E40AF" };
    default:
      return { bgColor: "#7fb2e6", textColor: "#92400E" };
  }
};

const getEnvColor = (env: string) => {
  switch (env.toLowerCase()) {
    case "production":
    case "prod":
      return "#ffb3b3";
    case "préproduction":
    case "préprod":
      return "#ffd699";
    case "intégration":
      return "#b3e6ff";
    case "recette":
      return "#c6b3ff";
    case "développement":
    case "dev":
      return "#b3ffcc";
    case "formation":
      return "#ffe6cc";
    case "technique":
      return "#a9c0d9";
    case "poc":
      return "#ffccf2";
    case "tnr":
      return "#f4bfff";
    default:
      return "#d9d9d9";
  }
};

// Fonction utilitaire pour gérer les valeurs de l'arborescence de manière robuste
const getHierarchyValue = (value: any): string => {
  if (typeof value === "string" && value.trim() !== "") {
    return value;
  }
  if (typeof value === "object" && value !== null) {
    // Tente de trouver une propriété 'name' ou 'value'
    if (typeof value.name === "string" && value.name.trim() !== "")
      return value.name;
    if (typeof value.value === "string" && value.value.trim() !== "")
      return value.value;

    // Si aucune des propriétés standard n'est trouvée, itère sur toutes les propriétés de l'objet
    // pour trouver la première chaîne non vide.
    for (const key in value) {
      if (Object.prototype.hasOwnProperty.call(value, key)) {
        const propValue = value[key];
        if (typeof propValue === "string" && propValue.trim() !== "") {
          return propValue; // Retourne la première chaîne non vide trouvée
        }
      }
    }

    // Si l'objet ne contient aucune chaîne de caractères utile,
    // tente de le convertir en chaîne, mais évite le générique "[object Object]"
    const stringified = String(value);
    if (stringified.trim() !== "" && stringified !== "[object Object]") {
      return stringified;
    }
  }
  // Retourne "N/A" si la valeur est null, undefined, une chaîne vide,
  // ou un objet qui se convertit en "[object Object]" sans valeur utile.
  return "N/A";
};

interface ModifiedServerModalProps {
  open: boolean;
  onClose: () => void;
  initialData?: any;
  onSubmit: (data: ServerFormData) => void;
  isEditMode?: boolean;
  isViewMode?: boolean;
  isDeleteMode?: boolean;
  isDeployMode?: boolean;
  errorMessage?: string | null;
  modalType?: string;
  isAddMode?: boolean;
}

const ModifiedServerModal: React.FC<ModifiedServerModalProps> = ({
  open,
  onClose,
  initialData,
  onSubmit,
  isEditMode = false,
  isViewMode = false,
  isDeleteMode = false,
  isDeployMode = false,
  isAddMode = false,
  errorMessage,
}) => {
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down("md"));

  const [allSolutionsData] = useState<SolutionDetailResponseDTO[]>([]);
  const [loadingAllSolutions] = useState<boolean>(false);

  const [solutionsInventoryOptions, setSolutionsInventoryOptions] = useState<
    string[]
  >([]);
  const [loadingInventorySolutions, setLoadingInventorySolutions] =
    useState<boolean>(false);

  const [inventorySolutionsMap, setInventorySolutionsMap] = useState<
    Map<string, SolutionDetailResponseDTO>
  >(new Map());

  const [naturesInventoryOptions, setNaturesInventoryOptions] = useState<
    string[]
  >([]);
  const [loadingNaturesInventory, setLoadingNaturesInventory] =
    useState<boolean>(false);

  // Configuration du formulaire
  const formSchema = getFormSchema(isDeleteMode, isDeployMode);
  const {
    control,
    register,
    handleSubmit,
    formState: { errors, isValid },
    getValues,
    setValue,
    watch,
  } = useForm<ServerFormData>({
    resolver: zodResolver(formSchema),
    mode: "all",
    defaultValues: initialData || {
      hostname: "",
      ip_addresses: [],
      os_type: "",
      uname: "",
      server_nature: [],
      nature_detail: "",
      solutions: [],
      environments: [],
      solutions_inventory: [],
      natures_inventory: [],
    },
  });

  const watchedOsType = watch("os_type");
  // Vérifier si le type d'OS est AIX

  const isAixOs = watchedOsType === "AIX";

  const watchedInventorySolutionNames = useWatch({
    control,
    name: "solutions_inventory",
  });

  const watchedSolutionsInventory = useWatch({
    control,
    name: "solutions_inventory",
  });
  const watchedNaturesInventory = useWatch({
    control,
    name: "natures_inventory",
  });
  const watchedEnvironments = useWatch({
    control,
    name: "environments",
  });

  const [
    selectedInventorySolutionsDetails,
    setSelectedInventorySolutionsDetails,
  ] = useState<SolutionDetailResponseDTO[]>([]);

  const osTypeList = Object.values(OperatingSystemType);
  const solutionNatureList = Object.values(ServerNature);
  const environmentsList = Object.values(Environnement);

  useEffect(() => {
    if (initialData && !isAddMode) {
      Object.keys(initialData).forEach((key) => {
        setValue(key as keyof ServerFormData, initialData[key]);
      });
    } else {
      setValue("hostname", "");
      setValue("ip_addresses", []);
      setValue("uname", "");
      setValue("server_nature", []);
      setValue("nature_detail", "");
      setValue("solutions", []);
      setValue("environments", []);
      setValue("solutions_inventory", []);
      setValue("natures_inventory", []);
    }
  }, [initialData, setValue, isAddMode]);


  const fetchSolutionsInventoryNames = async () => {
    setLoadingInventorySolutions(true);
    console.log("Fetching inventory solution names and details...");
    try {
      const response = await fetchWithAuth(getSolutions_Inventory());
      const data: SolutionDetailResponseDTO[] = await response.json();

      const names = data.map((s) => s.solution_name);
      setSolutionsInventoryOptions(names);

      const newMap = new Map<string, SolutionDetailResponseDTO>();
      data.forEach((sol) => {
        newMap.set(sol.solution_name, sol);
      });
      setInventorySolutionsMap(newMap);

      console.log("Fetched solution names for inventory dropdown:", names);
      console.log("Populated inventory solutions map with details:", newMap);
    } catch (error) {
      console.error(
        "Erreur lors du chargement des noms et détails de solutions d'inventaire :",
        error,
      );
      setSolutionsInventoryOptions([]);
      setInventorySolutionsMap(new Map());
    } finally {
      setLoadingInventorySolutions(false);
    }
  };

  const fetchNaturesInventoryNames = async () => {
    setLoadingNaturesInventory(true);
    console.log("Fetching inventory nature names...");
    try {
      const response = await fetchWithAuth(getNatures_Inventory());
      const data: string[] = await response.json();
      setNaturesInventoryOptions(data);
      console.log("Fetched nature names for inventory dropdown:", data);
    } catch (error) {
      console.error(
        "Erreur lors du chargement des noms de natures d'inventaire :",
        error,
      );
    } finally {
      setLoadingNaturesInventory(false);
    }
  };

  // --- Effets pour charger les données à l'ouverture du modal ---
  useEffect(() => {
    if (open) {
      fetchSolutionsInventoryNames();
      fetchNaturesInventoryNames();
    }
  }, [open]);

  // Effect pour dériver les détails des solutions d'inventaire sélectionnées
  useEffect(() => {

    const filteredSolutions: SolutionDetailResponseDTO[] = [];
    watchedInventorySolutionNames?.forEach((name) => {
      const solutionDetail = inventorySolutionsMap.get(name);
      if (solutionDetail) {
        filteredSolutions.push(solutionDetail);
      }
    });
    setSelectedInventorySolutionsDetails(filteredSolutions);

    filteredSolutions.forEach((_sol, _index) => {

    });
  }, [watchedInventorySolutionNames, inventorySolutionsMap]);

  // Fonction pour restreindre la saisie des IP
  const handleInputRestriction = (e: React.ChangeEvent<HTMLInputElement>) => {
    const validChars = /^[0-9.]*$/;
    if (!validChars.test(e.target.value)) {
      e.target.value = e.target.value.replace(/[^0-9.]/g, "");
    }
  };

  // Fonction pour obtenir l'icône selon le mode
  const getModalIcon = () => {
    if (isDeleteMode) return <DeleteIcon />;
    if (isDeployMode) return <EditIcon />;
    if (isEditMode) return <EditIcon />;
    return <ComputerIcon />;
  };

  // Fonction pour obtenir le titre
  const getModalTitle = () => {
    if (isDeleteMode) return "Suppression du serveur";
    if (isDeployMode) return "Déploiement de signature";
    if (isEditMode) return "Modification du serveur";
    if (isViewMode) return "Détails du serveur";
    return "Ajout d'un serveur";
  };

  // Composant pour les sections de formulaire (adapté au style de ServerDetailsModal)
  const FormSection = ({
    title,
    children,
  }: {
    title: string;
    children: React.ReactNode;
  }) => (
    <Card
      variant="outlined"
      sx={{
        mb: 1,
        backgroundColor: "#f9fbfd",
        borderColor: "#e0e0e0",
        borderRadius: 0.3,
      }}
    >
      <CardContent sx={{ pb: "16px !important" }}>
        <Typography
          variant="h6"
          component="h3"
          sx={{
            color: "#1976d2",
            fontSize: "1.1rem", // Consistent font size
            fontWeight: 600,
            mb: 1.2, // Consistent margin-bottom
            display: "flex",
            alignItems: "center",
            gap: 1,
          }}
        >
          {title}
        </Typography>
        {children}
      </CardContent>
    </Card>
  );

  // Composant pour les champs de formulaire
  const FormField = ({
    label,
    required = false,
    children,
  }: {
    label: string;
    required?: boolean;
    children: React.ReactNode;
  }) => (
    <Box sx={{ mb: 2 }}>
      <Typography
        variant="body2"
        sx={{
          fontWeight: 600,
          color: "#555",
          mb: 1,
          fontSize: "0.9rem", // Standardized font size for labels
        }}
      >
        {label}
        {required && <span style={{ color: "#d32f2f", marginLeft: 4 }}>*</span>}
      </Typography>
      {children}
    </Box>
  );

  return (
    <Dialog
      open={open}
      onClose={onClose}
      TransitionComponent={Transition}
      keepMounted
      fullScreen={fullScreen}
      maxWidth="lg"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: fullScreen ? 0 : 1, // Consistent with ServerDetailsModal
          maxHeight: "90vh",
        },
      }}
    >
      {/* En-tête avec gradient (style ServerDetailsModal) */}
      <DialogTitle
        sx={{
          background: "linear-gradient(135deg, #1976d2 0%, #0d47a1 100%)",
          color: "white",
          p: 2.5,
          display: "flex",
          alignItems: "center",
          gap: 2,
          position: "relative",
          marginBottom: 2, // Consistent with ServerDetailsModal
        }}
      >
        <Avatar
          sx={{
            bgcolor: "white",
            color: "#1976d2",
            width: 50,
            height: 50,
          }}
        >
          {getModalIcon()}
        </Avatar>

        <Box sx={{ flex: 1 }}>
          <Typography
            variant="h5"
            component="h2"
            sx={{ fontWeight: 600, mb: 0.5 }}
          >
            {getModalTitle()}
          </Typography>
          <Typography variant="body1" sx={{ opacity: 0.9, fontWeight: 400 }}>
            {initialData?.hostname || "Nouveau serveur"}
          </Typography>
        </Box>

        <IconButton
          onClick={onClose}
          sx={{
            color: "white",
            position: "absolute",
            right: 8,
            top: 8,
            "&:hover": {
              backgroundColor: "rgba(255, 255, 255, 0.1)",
            },
          }}
        >
          <CloseIcon />
        </IconButton>
      </DialogTitle>

      {/* Contenu du formulaire */}
      <DialogContent sx={{ p: 2.5, overflow: "auto" }}>
        <form onSubmit={handleSubmit(onSubmit)}>
          {isDeleteMode ? (
            <FormSection title="Confirmation de suppression">
              <Box textAlign="center" py={4}>
                <Typography variant="h6" color="error" sx={{ mb: 2 }}>
                  Êtes-vous sûr de vouloir supprimer ce serveur ?
                </Typography>
                <Typography variant="body1" color="text.secondary">
                  Cette action est irréversible.
                </Typography>
              </Box>
            </FormSection>
          ) : isDeployMode ? (
            <FormSection title="Informations de connexion">
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <FormField label="Login" required>
                    <TextField
                      {...register("login")}
                      error={!!errors.login}
                      helperText={errors.login?.message}
                      fullWidth
                      disabled={isViewMode}
                      placeholder="Entrez le login"
                      sx={{
                        "& .MuiOutlinedInput-root": {
                          borderRadius: 0.3,
                          backgroundColor: isViewMode ? "#f5f5f5" : "white",
                        },
                      }}
                    />
                  </FormField>
                </Grid>
                <Grid item xs={12} md={6}>
                  <FormField label="Mot de passe" required>
                    <TextField
                      {...register("password")}
                      error={!!errors.password}
                      helperText={errors.password?.message}
                      fullWidth
                      type="password"
                      disabled={isViewMode}
                      placeholder="Entrez le mot de passe"
                      sx={{
                        "& .MuiOutlinedInput-root": {
                          borderRadius: 0.3,
                          backgroundColor: isViewMode ? "#f5f5f5" : "white",
                        },
                      }}
                    />
                  </FormField>
                </Grid>
                <Grid item xs={12} md={6}>
                  <FormField label="Mot de passe sudo">
                    <TextField
                      {...register("sudo_password")}
                      error={!!errors.sudo_password}
                      helperText={
                        errors.sudo_password?.message ||
                        "Optionnel - si vide, le mot de passe principal sera utilisé"
                      }
                      fullWidth
                      type="password"
                      disabled={isViewMode}
                      placeholder="Entrez le mot de passe sudo"
                      sx={{
                        "& .MuiOutlinedInput-root": {
                          borderRadius: 0.3,
                          backgroundColor: isViewMode ? "#f5f5f5" : "white",
                        },
                      }}
                    />
                  </FormField>
                </Grid>
              </Grid>
            </FormSection>
          ) : (
            <Grid container spacing={2}>
              {/* Colonne de gauche */}
              <Grid item xs={12} md={6}>
                {/* Section Informations principales */}
                <FormSection title="Informations principales">
                  <Grid container spacing={2}>
                    <Grid item xs={12} md={12}>
                      <FormField label="Hostname" required>
                        <TextField
                          {...register("hostname")}
                          error={!!errors.hostname}
                          helperText={errors.hostname?.message}
                          fullWidth
                          disabled={isViewMode}
                          placeholder="Nom du serveur"
                          sx={{
                            "& .MuiOutlinedInput-root": {
                              borderRadius: 0.3,
                              backgroundColor: isViewMode ? "#f5f5f5" : "white",
                            },
                          }}
                        />
                      </FormField>
                    </Grid>

                    <Grid item xs={12} md={12}>
                      <FormField label="Type d'OS" required>
                        <Controller
                          name="os_type"
                          control={control}
                          render={({ field }) => (
                            <TextField
                              {...field}
                              select
                              fullWidth
                              disabled={isViewMode}
                              error={!!errors.os_type}
                              helperText={errors.os_type?.message}
                              sx={{
                                "& .MuiOutlinedInput-root": {
                                  borderRadius: 0.3,
                                  backgroundColor: isViewMode
                                    ? "#f5f5f5"
                                    : "white",
                                },
                              }}
                            >
                              <MenuItem value="" disabled>
                                <em>Choisir le type d'OS</em>
                              </MenuItem>
                              {osTypeList.map((option) => {
                                const colors = getOSColor(option);
                                return (
                                  <MenuItem key={option} value={option}>
                                    <Chip
                                      label={option}
                                      size="small"
                                      sx={{
                                        backgroundColor: colors.bgColor,
                                        color: colors.textColor,
                                        fontWeight: 500,
                                        fontSize: "0.875rem",
                                        height: "24px",
                                        "& .MuiChip-label": {
                                          px: 1,
                                        },
                                      }}
                                    />
                                  </MenuItem>
                                );
                              })}
                            </TextField>
                          )}
                        />
                      </FormField>
                    </Grid>

                    {/* AJOUTER LE CHAMP UNAME CONDITIONNEL */}
                    {isAixOs && (
                      <Grid item xs={12} md={12}>
                        <FormField label="Uname (AIX)" required>
                          <Controller
                            name="uname"
                            control={control}
                            render={({ field }) => (
                              <TextField
                                {...field}
                                error={!!errors.uname}
                                helperText={
                                  errors.uname?.message ||
                                  "Champ spécifique pour AIX"
                                }
                                fullWidth
                                disabled={isViewMode}
                                placeholder="Valeur uname pour AIX"
                                sx={{
                                  "& .MuiOutlinedInput-root": {
                                    borderRadius: 0.3,
                                    backgroundColor: isViewMode
                                      ? "#f5f5f5"
                                      : "white",
                                  },
                                }}
                              />
                            )}
                          />
                        </FormField>
                      </Grid>
                    )}

                    <Grid item xs={12}>
                      <FormField label="Adresses IP (v4)" required>
                        <Controller
                          name="ip_addresses"
                          control={control}
                          render={({ field }) => (
                            <Autocomplete
                              {...field}
                              multiple
                              freeSolo
                              options={[]}
                              disabled={isViewMode}
                              value={field.value || []}
                              onChange={(_, value) =>
                                field.onChange(value || [])
                              }
                              renderInput={(params) => (
                                <TextField
                                  {...params}
                                  error={!!errors.ip_addresses}
                                  helperText={errors.ip_addresses?.message}
                                  placeholder="Ajouter des adresses IP"
                                  onInput={handleInputRestriction}
                                  sx={{
                                    "& .MuiOutlinedInput-root": {
                                      borderRadius: 0.3,
                                      backgroundColor: isViewMode
                                        ? "#f5f5f5"
                                        : "white",
                                    },
                                  }}
                                />
                              )}
                              renderTags={(value, getTagProps) =>
                                value.map((option, index) => (
                                  <Chip
                                    label={option}
                                    {...getTagProps({ index })}
                                    size="small"
                                    sx={{
                                      backgroundColor: "#e3f2fd",
                                      color: "#1976d2",
                                      fontWeight: 500,
                                      fontSize: "0.875rem",
                                      height: "24px",
                                      "& .MuiChip-label": {
                                        px: 1,
                                      },
                                    }}
                                  />
                                ))
                              }
                            />
                          )}
                        />
                      </FormField>
                    </Grid>
                  </Grid>
                </FormSection>

                {/* Section Détail de la nature (seule) */}
                <FormSection title="Détail de la nature">
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <FormField label="Détail de la nature">
                        <TextField
                          {...register("nature_detail")}
                          disabled={isViewMode}
                          error={!!errors.nature_detail}
                          helperText={errors.nature_detail?.message}
                          fullWidth
                          multiline
                          rows={2}
                          placeholder="Décrivez en détail la nature du serveur"
                          sx={{
                            "& .MuiOutlinedInput-root": {
                              borderRadius: 0.3,
                              backgroundColor: isViewMode ? "#f5f5f5" : "white",
                            },
                          }}
                        />
                      </FormField>
                    </Grid>
                  </Grid>
                </FormSection>

                {/* Section Environnement (seule) */}
                <FormSection title="Environnement">
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <FormField label="Environnement(s)" required>
                        <Controller
                          name="environments"
                          control={control}
                          render={({ field }) => (
                            <Autocomplete
                              {...field}
                              multiple
                              options={environmentsList || []}
                              getOptionLabel={(option) => option}
                              disabled={isViewMode}
                              onChange={(_, value) =>
                                field.onChange(value || [])
                              }
                              renderOption={(props, option) => (
                                <li {...props}>
                                  <Chip
                                    label={option}
                                    size="small"
                                    sx={{
                                      backgroundColor: getEnvColor(option),
                                      color: "#000",
                                      fontWeight: 500,
                                      fontSize: "0.875rem", // Consistent chip font size
                                      height: "24px", // Consistent chip height
                                      "& .MuiChip-label": {
                                        px: 1, // Consistent chip padding
                                      },
                                    }}
                                  />
                                </li>
                              )}
                              renderTags={(value, getTagProps) =>
                                value.map((option, index) => (
                                  <Chip
                                    label={option}
                                    {...getTagProps({ index })}
                                    size="small"
                                    sx={{
                                      backgroundColor: getEnvColor(option),
                                      color: "#000",
                                      fontWeight: 500,
                                      fontSize: "0.875rem", // Consistent chip font size
                                      height: "24px", // Consistent chip height
                                      "& .MuiChip-label": {
                                        px: 1, // Consistent chip padding
                                      },
                                    }}
                                  />
                                ))
                              }
                              renderInput={(params) => (
                                <TextField
                                  {...params}
                                  placeholder="Sélectionner les environnements"
                                  error={!!errors.environments}
                                  helperText={errors.environments?.message}
                                  sx={{
                                    "& .MuiOutlinedInput-root": {
                                      borderRadius: 0.3,
                                      backgroundColor: isViewMode
                                        ? "#f5f5f5"
                                        : "white",
                                    },
                                  }}
                                />
                              )}
                            />
                          )}
                        />
                      </FormField>
                    </Grid>
                  </Grid>
                </FormSection>
              </Grid>

              {/* Colonne de droite */}
              <Grid item xs={12} md={6}>
                {/* Section Nature de serveur et Inventaire */}
                <FormSection title="Nature(s) de serveur">
                  <Grid container spacing={2}>
                    {!isAddMode && (
                      <Grid item xs={12} md={12}>
                        <FormField
                          label="Nature(s) de serveur dans BigFix" >
                          <Controller
                            name="server_nature"
                            control={control}
                            render={({ field }) => (
                              <Autocomplete
                                {...field}
                                multiple
                                options={solutionNatureList}
                                getOptionLabel={(option) => option}
                                disabled={isViewMode || isEditMode}
                                onChange={(_, value) =>
                                  field.onChange(value || [])
                                }
                                renderInput={(params) => (
                                  <TextField
                                    {...params}
                                    placeholder="Sélectionner les natures de serveur"
                                    error={!!errors.server_nature}
                                    helperText={errors.server_nature?.message}
                                    sx={{
                                      "& .MuiOutlinedInput-root": {
                                        borderRadius: 0.3,
                                        backgroundColor:
                                          isViewMode || isEditMode
                                            ? "#f5f5f5"
                                            : "white",
                                      },
                                    }}
                                  />
                                )}
                                renderTags={(value, getTagProps) =>
                                  value.map((option, index) => (
                                    <Chip
                                      label={option}
                                      {...getTagProps({ index })}
                                      size="small"
                                      sx={{
                                        backgroundColor: "#fff3e0",
                                        color: "#f57c00",
                                        fontWeight: 500,
                                        fontSize: "0.875rem", // Consistent chip font size
                                        height: "24px", // Consistent chip height
                                        "& .MuiChip-label": {
                                          px: 1, // Consistent chip padding
                                        },
                                      }}
                                    />
                                  ))
                                }
                              />
                            )}
                          />
                        </FormField>
                      </Grid>
                    )}
                    <Grid item xs={12} md={12}>
                      <FormField
                        label="Nature(s) de serveur dans l'inventaire"
                        required
                      >
                        <Controller
                          name="natures_inventory"
                          control={control}
                          render={({ field }) => (
                            <Autocomplete
                              {...field}
                              multiple
                              key={JSON.stringify(naturesInventoryOptions)}
                              options={naturesInventoryOptions}
                              getOptionLabel={(option) => option}
                              disabled={isViewMode}
                              onChange={(_, value) =>
                                field.onChange(value || [])
                              }
                              loading={loadingNaturesInventory}
                              renderInput={(params) => (
                                <TextField
                                  {...params}
                                  placeholder="Nature(s) de serveur dans l'inventaire"
                                  error={!!errors.natures_inventory}
                                  helperText={errors.natures_inventory?.message}
                                  InputProps={{
                                    ...params.InputProps,
                                    endAdornment: (
                                      <>
                                        {loadingNaturesInventory && (
                                          <CircularProgress
                                            color="inherit"
                                            size={20}
                                          />
                                        )}
                                        {params.InputProps.endAdornment}
                                      </>
                                    ),
                                  }}
                                  sx={{
                                    "& .MuiOutlinedInput-root": {
                                      borderRadius: 0.3,
                                      backgroundColor: isViewMode
                                        ? "#f5f5f5"
                                        : "white",
                                    },
                                  }}
                                />
                              )}
                              renderTags={(value, getTagProps) =>
                                value.map((option, index) => (
                                  <Chip
                                    label={option}
                                    {...getTagProps({ index })}
                                    size="small"
                                    sx={{
                                      backgroundColor: "#fff8e1",
                                      color: "#f57c00",
                                      fontWeight: 500,
                                      fontSize: "0.875rem", // Consistent chip font size
                                      height: "24px", // Consistent chip height
                                      "& .MuiChip-label": {
                                        px: 1, // Consistent chip padding
                                      },
                                    }}
                                  />
                                ))
                              }
                            />
                          )}
                        />
                      </FormField>
                    </Grid>
                  </Grid>
                </FormSection>

                {/* Section Solutions et Inventaire */}
                <FormSection title="Solutions">
                  {!isAddMode && (
                    <Grid item xs={12} md={12}>
                      <FormField label="Solution(s) dans BigFix" >
                        <Controller
                          name="solutions"
                          control={control}
                          render={({ field }) => (
                            <Autocomplete
                              {...field}
                              multiple
                              options={allSolutionsData || []}
                              value={
                                (field.value as unknown as SolutionDetailResponseDTO[]) ||
                                []
                              }
                              getOptionLabel={(option) =>
                                `${option.solution_name} (${option.solution_popularity || "N/A"})`
                              }
                              disabled={isViewMode || isEditMode}
                              loading={loadingAllSolutions}
                              onChange={(_, value) =>
                                field.onChange(value || [])
                              }
                              isOptionEqualToValue={(option, value) =>
                                option.id === value.id
                              }
                              renderInput={(params) => (
                                <TextField
                                  {...params}
                                  placeholder="Sélectionner les solutions"
                                  error={!!errors.solutions}
                                  helperText={errors.solutions?.message}
                                  InputProps={{
                                    ...params.InputProps,
                                    endAdornment: (
                                      <>
                                        {loadingAllSolutions && (
                                          <CircularProgress size={20} />
                                        )}
                                        {params.InputProps.endAdornment}
                                      </>
                                    ),
                                  }}
                                  sx={{
                                    "& .MuiOutlinedInput-root": {
                                      borderRadius: 0.3,
                                      backgroundColor:
                                        isViewMode || isEditMode
                                          ? "#f5f5f5"
                                          : "white",
                                    },
                                  }}
                                />
                              )}
                              renderTags={(value, getTagProps) =>
                                value.map((option, index) => (
                                  <Chip
                                    label={option.solution_name}
                                    {...getTagProps({ index })}
                                    size="small"
                                    sx={{
                                      backgroundColor: "#f3e5f5",
                                      color: "#6a1b9a",
                                      fontWeight: 500,
                                      fontSize: "0.875rem", // Consistent chip font size
                                      height: "24px", // Consistent chip height
                                      "& .MuiChip-label": {
                                        px: 1, // Consistent chip padding
                                      },
                                    }}
                                  />
                                ))
                              }
                            />
                          )}
                        />
                      </FormField>
                    </Grid>
                  )}

                  <Grid item xs={12} md={12}>
                    <FormField label="Solution(s) dans l'inventaire" required>
                      <Controller
                        name="solutions_inventory"
                        control={control}
                        render={({ field }) => (
                          <Autocomplete
                            {...field}
                            multiple
                            key={JSON.stringify(solutionsInventoryOptions)}
                            options={solutionsInventoryOptions}
                            getOptionLabel={(option) => {
                              const solutionDetail = inventorySolutionsMap.get(option);
                              if (solutionDetail) {
                                const acronym = solutionDetail.entity_acronym || solutionDetail.entity || "AWB";

                                // Vérifier si le nom contient déjà l'acronyme entre parenthèses
                                const solutionName = solutionDetail.solution_name;
                                const acronymInParenthesesRegex = /\(([^)]+)\)$/;
                                const match = solutionName.match(acronymInParenthesesRegex);

                                if (match && match[1] === acronym) {
                                  // Si l'acronyme est déjà dans le nom, on affiche seulement le nom
                                  return solutionName;
                                } else {
                                  // Sinon, on ajoute l'acronyme
                                  return `${solutionName} (${acronym})`;
                                }
                              }
                              return option;
                            }}
                            disabled={isViewMode}
                            onChange={(_, value) => field.onChange(value || [])}
                            loading={loadingInventorySolutions}
                            renderInput={(params) => (
                              <TextField
                                {...params}
                                placeholder="Solution(s) dans l'inventaire"
                                error={!!errors.solutions_inventory}
                                helperText={errors.solutions_inventory?.message}
                                InputProps={{
                                  ...params.InputProps,
                                  endAdornment: (
                                    <>
                                      {loadingInventorySolutions && (
                                        <CircularProgress color="inherit" size={20} />
                                      )}
                                      {params.InputProps.endAdornment}
                                    </>
                                  ),
                                }}
                                sx={{
                                  "& .MuiOutlinedInput-root": {
                                    borderRadius: 0.3,
                                    backgroundColor: isViewMode ? "#f5f5f5" : "white",
                                  },
                                }}
                              />
                            )}
                            renderTags={(value, getTagProps) =>
                              value.map((option, index) => {
                                const solutionDetail = inventorySolutionsMap.get(option);
                                let displayName = option;

                                if (solutionDetail) {
                                  const acronym = solutionDetail.entity_acronym || solutionDetail.entity || "AWB";
                                  const solutionName = solutionDetail.solution_name;
                                  const acronymInParenthesesRegex = /\(([^)]+)\)$/;
                                  const match = solutionName.match(acronymInParenthesesRegex);

                                  if (match && match[1] === acronym) {
                                    displayName = solutionName;
                                  } else {
                                    displayName = `${solutionName} (${acronym})`;
                                  }
                                }

                                return (
                                  <Chip
                                    label={displayName}
                                    {...getTagProps({ index })}
                                    size="small"
                                    sx={{
                                      backgroundColor: "#e8f5e8",
                                      color: "#2e7d32",
                                      fontWeight: 500,
                                      fontSize: "0.875rem",
                                      height: "24px",
                                      "& .MuiChip-label": {
                                        px: 1,
                                      },
                                    }}
                                  />
                                );
                              })
                            }
                          />
                        )}
                      />
                    </FormField>
                  </Grid>
                </FormSection>

                {/* Détails des solutions d'inventaire sélectionnées (toujours affichée) */}
                <FormSection title="Détails des solutions d'inventaire sélectionnées">
                  {selectedInventorySolutionsDetails.length > 0 ? (
                    selectedInventorySolutionsDetails.map((solution) => (
                      <Box
                        key={solution.id}
                        sx={{
                          mb: 2,
                          p: 2,
                          border: "1px solid #e0e0e0",
                          borderRadius: 0.3,
                        }}
                      >
                        <Typography
                          variant="subtitle1"
                          sx={{ fontWeight: 600, mb: 1 }}
                        >
                          Nom de l'application: {solution.solution_name}
                        </Typography>
                        <Typography variant="body2" sx={{ mb: 0.5 }}>
                          Fiabilité:{" "}
                          <Chip
                            label={solution.fiable ? "Fiable" : "Non fiable"}
                            size="small"
                            color={solution.fiable ? "success" : "error"}
                            sx={{
                              fontSize: "0.875rem",
                              height: "24px",
                              "& .MuiChip-label": { px: 1 },
                            }}
                          />
                        </Typography>
                        <Typography variant="body2" sx={{ mb: 1 }}>
                          Arborescence:{" "}
                          <Chip
                            label={`${getHierarchyValue(solution.domain)} > ${getHierarchyValue(solution.pole)} > ${getHierarchyValue(solution.entity)}`}
                            size="small"
                            sx={{
                              backgroundColor: "#e0f2f7",
                              color: "#006064",
                              fontSize: "0.875rem",
                              height: "24px",
                              "& .MuiChip-label": { px: 1 },
                            }}
                          />
                        </Typography>

                        {/* Affichage des administrateurs techniques pour cette solution */}
                        {solution.technical_admins &&
                          solution.technical_admins.length > 0 && (
                            <Box sx={{ mb: 1 }}>
                              <Typography
                                variant="body2"
                                sx={{ fontWeight: 500, mb: 0.5 }}
                              >
                                Administrateurs techniques:
                              </Typography>
                              <Box
                                sx={{
                                  display: "flex",
                                  flexWrap: "wrap",
                                  gap: 1,
                                }}
                              >
                                {solution.technical_admins.map(
                                  (
                                    admin:
                                      | string
                                      | number
                                      | boolean
                                      | React.ReactElement<
                                        any,
                                        | string
                                        | React.JSXElementConstructor<any>
                                      >
                                      | Iterable<React.ReactNode>
                                      | React.ReactPortal
                                      | null
                                      | undefined,
                                    _index: any,
                                  ) => (
                                    <Chip
                                      label={admin}
                                      size="small"
                                      sx={{
                                        backgroundColor: "#e8f5e9",
                                        color: "#388e3c",
                                        fontSize: "0.875rem",
                                        height: "24px",
                                        "& .MuiChip-label": { px: 1 },
                                      }}
                                    />
                                  ),
                                )}
                              </Box>
                            </Box>
                          )}

                        {/* Affichage des administrateurs fonctionnels pour cette solution */}
                        {solution.functional_admins &&
                          solution.functional_admins.length > 0 && (
                            <Box sx={{ mb: 1 }}>
                              <Typography
                                variant="body2"
                                sx={{ fontWeight: 500, mb: 0.5 }}
                              >
                                Administrateurs fonctionnels:
                              </Typography>
                              <Box
                                sx={{
                                  display: "flex",
                                  flexWrap: "wrap",
                                  gap: 1,
                                }}
                              >
                                {solution.functional_admins.map(
                                  (
                                    admin:
                                      | string
                                      | number
                                      | boolean
                                      | React.ReactElement<
                                        any,
                                        | string
                                        | React.JSXElementConstructor<any>
                                      >
                                      | Iterable<React.ReactNode>
                                      | React.ReactPortal
                                      | null
                                      | undefined,
                                    _index: any,
                                  ) => (
                                    <Chip
                                      label={admin}
                                      size="small"
                                      sx={{
                                        backgroundColor: "#e0f2f7",
                                        color: "#0277bd",
                                        fontSize: "0.875rem",
                                        height: "24px",
                                        "& .MuiChip-label": { px: 1 },
                                      }}
                                    />
                                  ),
                                )}
                              </Box>
                            </Box>
                          )}

                        {/* Affichage des TAMs pour cette solution */}
                        {solution.tams && solution.tams.length > 0 && (
                          <Box>
                            <Typography
                              variant="body2"
                              sx={{ fontWeight: 500, mb: 0.5 }}
                            >
                              TAMs:
                            </Typography>
                            <Box
                              sx={{ display: "flex", flexWrap: "wrap", gap: 1 }}
                            >
                              {solution.tams.map(
                                (
                                  tam:
                                    | string
                                    | number
                                    | boolean
                                    | React.ReactElement<
                                      any,
                                      | string
                                      | React.JSXElementConstructor<any>
                                    >
                                    | Iterable<React.ReactNode>
                                    | React.ReactPortal
                                    | null
                                    | undefined,
                                  _index: any,
                                ) => (
                                  <Chip
                                    label={tam}
                                    size="small"
                                    sx={{
                                      backgroundColor: "#fbe9e7",
                                      color: "#d84315",
                                      fontSize: "0.875rem",
                                      height: "24px",
                                      "& .MuiChip-label": { px: 1 },
                                    }}
                                  />
                                ),
                              )}
                            </Box>
                          </Box>
                        )}
                      </Box>
                    ))
                  ) : (
                    <Box
                      sx={{
                        p: 2,
                        border: "1px solid #e0e0e0",
                        borderRadius: 0.3,
                        textAlign: "center",
                        color: "text.secondary",
                      }}
                    >
                      <Typography variant="body2">
                        Aucune solution d'inventaire sélectionnée pour afficher
                        les détails.
                      </Typography>
                    </Box>
                  )}
                </FormSection>
              </Grid>
            </Grid>
          )}

          {/* Message d'erreur */}
          {errorMessage && (
            <Alert
              severity="error"
              sx={{
                borderRadius: 0.3,
                mb: 2,
              }}
            >
              {errorMessage}
            </Alert>
          )}
        </form>
      </DialogContent>

      {/* Actions */}
      <DialogActions
        sx={{ p: 2.5, pt: 1, borderTop: "1px solid #e0e0e0", gap: 1 }}
      >
        <Button
          onClick={onClose}
          variant="outlined"
          sx={{
            borderColor: "#d1d5db",
            color: "#6b7280",
            borderRadius: 0.3,
            "&:hover": {
              borderColor: "#9ca3af",
              backgroundColor: "#f3f4f6",
            },
          }}
        >
          {isViewMode ? "Fermer" : "Annuler"}
        </Button>

        {!isViewMode && (
          <Button
            onClick={() => {
              const formData = getValues();

              const payloadWithUname = {
                ...formData,
                uname: formData.uname || "",
              };

              const enrichedPayload = {
                ...payloadWithUname,
                solutions_inventory_details:
                  selectedInventorySolutionsDetails.map((solution) => ({
                    solution_id: solution.id,
                    solution_name: solution.solution_name,
                    technical_admins: solution.technical_admins || [],
                    functional_admins: solution.functional_admins || [],
                    tams: solution.tams || [],
                    domain: getHierarchyValue(solution.domain),
                    pole: getHierarchyValue(solution.pole),
                    entity: getHierarchyValue(solution.entity),
                    psi: solution.psi,
                    solution_type: solution.solution_type,
                    solution_popularity: solution.solution_popularity,
                    fiable: solution.fiable,
                  })),
              };

              console.log("Payload enrichi:", enrichedPayload);
              onSubmit(enrichedPayload);
            }}
            variant="contained"
            disabled={
              isEditMode
                ? !watchedSolutionsInventory?.length ||
                !watchedNaturesInventory?.length ||
                !watchedEnvironments?.length ||
                keycloak.hasRoles(["read_only_role"])
                : !isValid
            }
            startIcon={<SaveIcon />}
            sx={{
              backgroundColor: isDeleteMode ? "#d32f2f" : "#1976d2",
              borderRadius: 0.3,
              "&:hover": {
                backgroundColor: isDeleteMode ? "#c62828" : "#1565c0",
              },
              "&:disabled": {
                backgroundColor: "#e0e0e0",
                color: "#9e9e9e",
              },
            }}
          >
            {isEditMode
              ? "Modifier"
              : isDeleteMode
                ? "Confirmer la suppression"
                : "Ajouter"}
          </Button>
        )}

        {(getValues("solutions_inventory")?.length === 0 ||
          getValues("natures_inventory")?.length === 0 ||
          getValues("environments")?.length === 0) && (
            <Typography color="error" variant="body2" sx={{ mt: 1 }}>
              Veuillez remplir tous les champs obligatoires (Solutions
              d'inventaire, Nature d'inventaire et Environnement).
            </Typography>
          )}
      </DialogActions>
    </Dialog>
  );
};

export default ModifiedServerModal;
