// src/components/modals/EditEntityModal.tsx
import { useEffect, useState } from "react";
import {
  Grid,
  Typography,
  TextField,
  Autocomplete,
  Box,
  Button,
  CircularProgress,
  Alert,
  Snackbar,
} from "@mui/material";
import { useForm } from "react-hook-form";
import { z as zod } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

import MyModal from "@/components/modals/MyModal";
import { getAllPersons } from "@/services/admin/PersonService";
import { updateEntity } from "@/services/admin/EntityService";
import { PersonShortResponseDTO } from "@/types/dto/PersonDTO";

const schema = zod.object({
  new_name: zod.string().trim().min(1, "Le nouveau nom est requis."),
});

type FormEditEntity = zod.infer<typeof schema>;

interface EditEntityModalProps {
  open: boolean;
  onClose: () => void;
  onSave: () => void;
  entityId: number;
  currentName: string;
  currentManagerId?: number;
}

export const EditEntityModal: React.FC<EditEntityModalProps> = ({
  open,
  onClose,
  onSave,
  entityId,
  currentName,
  currentManagerId,
}) => {
  const {
    register,
    handleSubmit,
    reset,
    setValue,
    watch,
    formState: { errors, isValid },
  } = useForm<FormEditEntity>({
    resolver: zodResolver(schema),
    mode: "all",
    defaultValues: { new_name: "" },
  });

  const [persons, setPersons] = useState<PersonShortResponseDTO[]>([]);
  const [loadingPersons, setLoadingPersons] = useState(false);
  const [selectedManager, setSelectedManager] =
    useState<PersonShortResponseDTO | null>(null);
  const [loadingSave, setLoadingSave] = useState(false);
  const [errorMessage, setErrorMsg] = useState<string | null>(null);
  const [successSnackbar, setSuccessSnackbar] = useState(false);

  const watchedName = watch("new_name");

  useEffect(() => {
    if (!open) return;

    const fetchData = async () => {
      try {
        setLoadingPersons(true);
        const data = await getAllPersons();
        setPersons(data);

        const current =
          data.find((p) => p.person_id === currentManagerId) || null;
        setSelectedManager(current);

        reset();
        setValue("new_name", currentName);
        setErrorMsg(null);
      } finally {
        setLoadingPersons(false);
      }
    };

    fetchData();
  }, [open]);

  const hasChanges =
    isValid &&
    (watchedName.trim() !== currentName.trim() ||
      (selectedManager?.person_id ?? null) !== (currentManagerId ?? null));

  const onSubmit = async (data: FormEditEntity) => {
    setLoadingSave(true);
    setErrorMsg(null);

    try {
      await updateEntity(entityId, {
        entity_name: data.new_name,
        entity_manager_id: selectedManager?.person_id ?? null,
      });

      onSave();
      setSuccessSnackbar(true);
      onClose();
    } catch (err) {
      console.error("Erreur de mise à jour :", err);
      setErrorMsg("Échec de la mise à jour de l'entité.");
    } finally {
      setLoadingSave(false);
    }
  };

  return (
    <>
      <MyModal open={open} onClose={onClose} title="Modifier l'entité">
        <form onSubmit={handleSubmit(onSubmit)}>
          <Grid container spacing={2} sx={{ px: 2, pt: 1 }}>
            <Grid item xs={12} container alignItems="center" spacing={2}>
              <Grid item xs={4}>
                <Typography fontWeight="bold">Nouveau nom</Typography>
              </Grid>
              <Grid item xs={8} width={500}>
                <TextField
                  {...register("new_name")}
                  error={!!errors.new_name}
                  helperText={errors.new_name?.message}
                  fullWidth
                  placeholder="Entrer un nouveau nom"
                />
              </Grid>
            </Grid>

            <Grid item xs={12} container alignItems="center" spacing={2}>
              <Grid item xs={4}>
                <Typography fontWeight="bold">Manager</Typography>
              </Grid>
              <Grid item xs={8}>
                {loadingPersons ? (
                  <CircularProgress size={24} />
                ) : (
                  <Autocomplete
                    options={persons}
                    getOptionLabel={(o) => `${o.firstname} ${o.lastname}`}
                    value={selectedManager}
                    onChange={(_, v) => setSelectedManager(v)}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Sélectionner un manager"
                        fullWidth
                      />
                    )}
                  />
                )}
              </Grid>
            </Grid>

            {errorMessage && (
              <Grid item xs={12}>
                <Alert severity="error" variant="filled">
                  {errorMessage}
                </Alert>
              </Grid>
            )}
          </Grid>

          <Box textAlign="right" p={2}>
            <Button onClick={onClose} sx={{ mr: 1 }}>
              Annuler
            </Button>
            <Button
              type="submit"
              variant="contained"
              disabled={!hasChanges || loadingSave}
            >
              {loadingSave ? "Sauvegarde…" : "Modifier"}
            </Button>
          </Box>
        </form>
      </MyModal>

      <Snackbar
        open={successSnackbar}
        autoHideDuration={3000}
        onClose={() => setSuccessSnackbar(false)}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <Alert
          onClose={() => setSuccessSnackbar(false)}
          severity="success"
          variant="filled"
        >
          Entité mise à jour avec succès !
        </Alert>
      </Snackbar>
    </>
  );
};

export default EditEntityModal;
