import React, { useEffect, useState } from "react";
import {
  Box,
  Button,
  TextField,
  Snackbar,
  Alert,
  Stepper,
  Step,
  StepLabel,
  Checkbox,
  FormControlLabel,
  Grid,
  CircularProgress,
} from "@mui/material";
import { useForm } from "react-hook-form";
import { z as zod } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

import MyModal from "@/components/modals/MyModal";
import { addUrl } from "@/services/UrlService";
import { UrlDTO } from "@/types/dto/UrlDTO";

const formSchema = zod.object({
  url: zod.string().url("URL invalide").min(1, "L'URL est requise"),
  customEmail: zod
    .string()
    .email("Email invalide")
    .optional()
    .or(zod.literal("")),
  useCustomEmail: zod.boolean(),
});

type AddUrlForm = zod.infer<typeof formSchema>;

interface AddUrlFormModalProps {
  open: boolean;
  onClose: () => void;
  onSuccess: (
    site: UrlDTO & {
      timeLeft: string;
      isExpiringSoon: boolean;
      isExpired: boolean;
    },
  ) => void;
}

const AddUrlModal: React.FC<AddUrlFormModalProps> = ({
  open,
  onClose,
  onSuccess,
}) => {
  const {
    register,
    handleSubmit,
    reset,
    watch,
    formState: { errors, isValid },
  } = useForm<AddUrlForm>({
    resolver: zodResolver(formSchema),
    mode: "all",
    defaultValues: {
      url: "",
      customEmail: "",
      useCustomEmail: false,
    },
  });

  const [steps, setSteps] = useState<string[]>([]);
  const [activeStep, setActiveStep] = useState(0);
  const [isVerificationFinished, setIsVerificationFinished] = useState(false);
  const [loading, setLoading] = useState(false);

  const [snackbar, setSnackbar] = useState<{
    open: boolean;
    message: string;
    severity: "success" | "error";
  }>({
    open: false,
    message: "",
    severity: "error",
  });

  const [successSnackbar, setSuccessSnackbar] = useState(false);
  const useCustomEmail = watch("useCustomEmail");

  // ✅ Reset all form values and states when modal is opened
  useEffect(() => {
    if (open) {
      reset(); // reset form fields
      setSteps([]);
      setActiveStep(0);
      setIsVerificationFinished(false);
    }
  }, [open, reset]);

  const calculateTimeLeft = (expirationDate: string) => {
    const now = new Date();
    const expiry = new Date(expirationDate);
    const diff = expiry.getTime() - now.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    return {
      label: diff <= 0 ? "Expiré" : `${days} jour(s)`,
      isExpiringSoon: days <= 30 && days > 0,
      isExpired: diff <= 0,
    };
  };

  const handleVerifier = async (data: AddUrlForm) => {
    setLoading(true);
    setIsVerificationFinished(false);
    const baseSteps = ["Vérification du format de l’URL", "", ""];
    setSteps(baseSteps);
    setActiveStep(0);

    try {
      const parsed = new URL(data.url);
      const domain = parsed.hostname;
      baseSteps[1] = `Domaine détecté : ${domain}`;
      setSteps([...baseSteps]);
      setActiveStep(1);

      const isInterne = domain.includes("attijariwafa.net");
      baseSteps[2] = isInterne
        ? "Adresse identifiée comme interne"
        : "Adresse identifiée comme externe";
      setSteps([...baseSteps]);
      setActiveStep(2);

      const emailToUse: string =
        data.useCustomEmail && data.customEmail
          ? data.customEmail
          : "sghirisamir@gmail.com";

      const site = await addUrl({
        url_name: data.url,
        notified_email: emailToUse,
      });

      if (!site || !site.expiration_date) {
        throw new Error(
          "L'URL n'a pas pu être vérifiée. Certificat SSL introuvable.",
        );
      }

      const time = calculateTimeLeft(site.expiration_date);
      onSuccess({ ...site, timeLeft: time.label, ...time });

      setSteps((prev) => [...prev, "Calcul de la durée restante"]);
      setActiveStep((prev) => prev + 1);
      setIsVerificationFinished(true);
      setSuccessSnackbar(true);
    } catch (e: any) {
      console.error(e);
      setSnackbar({
        open: true,
        message: e.message || "Erreur lors de la vérification",
        severity: "error",
      });
      baseSteps[1] = "Erreur lors de la vérification";
      setSteps([...baseSteps]);
      setActiveStep(1);
    }

    setLoading(false);
  };

  const handleClose = () => {
    onClose(); // fermeture seulement, reset déjà fait via useEffect
  };

  return (
    <>
      <MyModal open={open} onClose={handleClose} title="Ajouter une URL">
        <form onSubmit={handleSubmit(handleVerifier)}>
          <Grid container spacing={2} sx={{ p: 2 }}>
            {/* Champ URL */}
            <Grid item xs={12}>
              <TextField
                label="URL"
                fullWidth
                placeholder="https://example.com"
                {...register("url")}
                error={!!errors.url}
                helperText={errors.url?.message}
              />
            </Grid>

            {/* Case à cocher + email personnalisé */}
            <Grid item xs={12}>
              <FormControlLabel
                control={<Checkbox {...register("useCustomEmail")} />}
                label="Souhaitez-vous recevoir l’alerte sur un email spécifique ?"
              />
            </Grid>

            {useCustomEmail && (
              <Grid item xs={12}>
                <TextField
                  label="Email pour notification"
                  fullWidth
                  type="email"
                  {...register("customEmail")}
                  error={!!errors.customEmail}
                  helperText={errors.customEmail?.message}
                />
              </Grid>
            )}

            {/* Stepper */}
            {steps.length > 0 && (
              <Grid item xs={12}>
                <Stepper activeStep={activeStep} orientation="vertical">
                  {steps.map((label, index) => (
                    <Step key={index} completed={index <= activeStep}>
                      <StepLabel>{label || "..."}</StepLabel>
                    </Step>
                  ))}
                </Stepper>
              </Grid>
            )}
          </Grid>

          {/* Boutons */}
          <Box textAlign="right" px={2} pb={2}>
            <Button onClick={handleClose} disabled={loading} sx={{ mr: 1 }}>
              Annuler
            </Button>
            <Button
              type="submit"
              variant="contained"
              disabled={loading || !isValid || isVerificationFinished}
            >
              {loading ? <CircularProgress size={20} /> : "Vérifier"}
            </Button>
          </Box>
        </form>
      </MyModal>

      {/* Snackbar erreur */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <Alert
          severity={snackbar.severity}
          onClose={() => setSnackbar({ ...snackbar, open: false })}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>

      {/* Snackbar succès */}
      <Snackbar
        open={successSnackbar}
        autoHideDuration={4000}
        onClose={() => setSuccessSnackbar(false)}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <Alert
          severity="success"
          onClose={() => setSuccessSnackbar(false)}
          variant="filled"
        >
          URL ajoutée avec succès !
        </Alert>
      </Snackbar>
    </>
  );
};

export default AddUrlModal;
