// src/components/BackstageDataTable.tsx

import React, { useState, useEffect, useMemo } from "react";
import {
  Box,
  Tabs,
  Tab,
  Typography,
  Button,
  Switch,
  Grid,
  Chip,
} from "@mui/material";
import {
  useMaterialReactTable,
  MRT_ColumnDef,
  MRT_GlobalFilterTextField,
  MRT_TableContainer,
  MRT_TablePagination,
  MRT_ShowHideColumnsButton,
  MRT_ToggleFiltersButton,
} from "material-react-table";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import { CiExport } from "react-icons/ci";
import WidgetMainContainer from "@/components/containers/WidgetMainContainer";
import { getCssVariableValue } from "@/utils/getDynamicColor";
import BackStageView from "@/types/view/BackStageView";
import MyModal from "@/components/modals/MyModal";
import { fetchAllDataBySection } from "@/services/BackStageService";

interface Section {
  title: string;
  data: BackStageView[];
}

const initialSections: Section[] = [
  { title: "Component", data: [] },
  { title: "Domain", data: [] },
  { title: "Group", data: [] },
  { title: "System", data: [] },
  { title: "Template", data: [] },
  { title: "User", data: [] },
];

const OrganisationBackstageDataTable: React.FC = () => {
  const [activeTab, setActiveTab] = useState<number>(0);
  const [sections, setSections] = useState<Section[]>(initialSections);
  const [onlySquad, setOnlySquad] = useState<boolean>(false);
  const [openEntityModal, setOpenEntityModal] = useState<boolean>(false);
  const [openOwnerModal, setOpenOwnerModal] = useState<boolean>(false);
  const [selectedEntity, setSelectedEntity] = useState<BackStageView | null>(
    null,
  );

  useEffect(() => {
    (async () => {
      const curr = sections[activeTab];
      if (!curr.data.length) {
        const data = await fetchAllDataBySection(curr.title);
        setSections((s) =>
          s.map((sec, i) => (i === activeTab ? { ...sec, data } : sec)),
        );
      }
    })();
  }, [activeTab]);

  const displayedData = useMemo(() => {
    const rawData = sections[activeTab].data;
    const currentSection = sections[activeTab].title.toLowerCase();
    if (onlySquad) {
      return rawData.filter((item) => item.type?.toLowerCase() === "squad");
    }

    if (currentSection === "component") {
      return rawData.filter((item) => {
        const type = item.type?.toLowerCase();
        return type === "tool" || type === "documentation";
      });
    }
    return rawData;
  }, [sections, activeTab, onlySquad]);

  const columns = useMemo<MRT_ColumnDef<BackStageView>[]>(() => {
    if (sections[activeTab].title === "User") {
      return [
        {
          accessorKey: "displayName",
          header: "Display Name",
        },
        {
          accessorKey: "email",
          header: "Email",
        },
        {
          accessorKey: "name",
          header: "Username",
        },
      ];
    }

    return [
      {
        accessorKey: "title",
        header: "Name",
        Cell: ({ row }) => {
          const displayName =
            row.original.title && row.original.title !== "-"
              ? row.original.title?.toUpperCase()
              : row.original.name?.toUpperCase();
          return (
            <Typography
              onClick={() => {
                setSelectedEntity(row.original);
                setOpenEntityModal(true);
              }}
              sx={{
                cursor: "pointer",
                textDecoration: "underline",
                color: "primary.main",
              }}
            >
              {displayName}
            </Typography>
          );
        },
      },
      {
        accessorKey: "owner",
        header: "Owner",
        Cell: ({ cell }) => {
          const value = cell.getValue<string>();
          const formatted = value
            ? value.charAt(0).toUpperCase() + value.slice(1).toLowerCase()
            : "-";

          return <Typography variant="body2">{formatted}</Typography>;
        },
      },
      // { accessorKey: 'type', header: 'Type' },
      // { accessorKey: 'lifecycle', header: 'Lifecycle' },
      {
        accessorKey: "type",
        header: "Type",
        Cell: ({ cell }) => {
          const value = cell.getValue<string>()?.toLowerCase();

          if (!value || value === "-") {
            return <Typography variant="body2">-</Typography>;
          }

          const formatted = value.charAt(0).toUpperCase() + value.slice(1);

          const colorMap: Record<string, string> = {
            documentation: "#2196F3", // Bleu
            tool: "#AB47BC", // Violet
            squad: "#66BB6A", // Vert
            tribe: "#FFA726", // Orange
          };

          const color = colorMap[value] || "#9E9E9E";
          const bgColor = color + "10"; // Arrière-plan avec opacité

          return (
            <Chip
              label={formatted}
              size="small"
              sx={{
                backgroundColor: bgColor,
                border: `1px solid ${color}`,
                color,
                fontWeight: "bold",
                borderRadius: "6px",
              }}
            />
          );
        },
      },
      {
        accessorKey: "lifecycle",
        header: "Lifecycle",
        Cell: ({ cell }) => {
          const value = cell.getValue<string>()?.toLowerCase();

          if (!value || value === "-") {
            return <Typography variant="body2">-</Typography>;
          }

          const formatted = value.charAt(0).toUpperCase() + value.slice(1);

          const colorMap: Record<string, string> = {
            production: "#66BB6A", // Vert
            experimental: "#FFA726", // Orange
          };

          const color = colorMap[value] || "#9E9E9E";
          const bgColor = color + "10"; // Arrière-plan avec opacité

          return (
            <Chip
              label={formatted}
              size="small"
              sx={{
                backgroundColor: bgColor,
                border: `1px solid ${color}`,
                color,
                fontWeight: "bold",
                borderRadius: "6px",
              }}
            />
          );
        },
      },
      { accessorKey: "description", header: "Description" },
      {
        accessorKey: "tags",
        header: "Tags",
        Cell: ({ row }) => {
          const raw = row.original.tags;

          const isEmpty =
            !raw ||
            raw === "-" ||
            (Array.isArray(raw) && raw.length === 0) ||
            (typeof raw === "string" && raw.trim() === "");

          if (isEmpty) {
            return <Typography variant="body2">-</Typography>;
          }

          const tagsArray = Array.isArray(raw) ? raw : String(raw).split(",");

          return (
            <Box sx={{ display: "flex", gap: 1, flexWrap: "wrap" }}>
              {tagsArray.map((tag, idx) => (
                <Chip
                  key={idx}
                  label={tag.trim()}
                  size="small"
                  variant="outlined"
                />
              ))}
            </Box>
          );
        },
      },
    ];
  }, [openEntityModal, sections, activeTab]);

  const table = useMaterialReactTable({
    columns,
    data: displayedData,
    initialState: { showGlobalFilter: true },
    enableColumnOrdering: true,
    enableColumnFilters: true,
    enableDensityToggle: true,
  });

  const primaryColor = getCssVariableValue("--primary-color");
  const theme = createTheme({
    palette: {
      primary: { main: primaryColor },
    },
  });

  return (
    <ThemeProvider theme={theme}>
      <Box>
        <Box
          display="flex"
          justifyContent="space-between"
          alignItems="center"
          mb={3}
        >
          <Typography variant="h3" mb={2}>
            Organisation Backstage Data
          </Typography>
          <Tabs
            value={activeTab}
            onChange={(_, v) => setActiveTab(v)}
            variant="scrollable"
            scrollButtons="auto"
            textColor="primary"
            indicatorColor="primary"
            TabIndicatorProps={{ sx: { height: 4, transition: "0.3s" } }}
            sx={{
              "& .MuiTab-root": {
                textTransform: "uppercase",
                fontWeight: "bold",
              },
              "& .Mui-selected": { color: primaryColor },
              "& .MuiTab-root:hover": { color: primaryColor },
            }}
          >
            {sections.map((s, i) => (
              <Tab key={i} label={s.title} />
            ))}
          </Tabs>
        </Box>

        <WidgetMainContainer sx={{ mt: 2 }}>
          <Box
            sx={{
              display: "flex",
              flexDirection: "row",
              gap: "16px",
              justifyContent: "space-between",
              alignItems: "center",
              backgroundColor: "inherit",
              borderRadius: "4px",
              mb: 1,
            }}
          >
            <Box sx={{ display: "flex", alignItems: "center" }}>
              <MRT_ShowHideColumnsButton
                table={table}
                sx={{ color: primaryColor }}
              />
              <Typography variant="body2" sx={{ color: primaryColor }}>
                COLUMNS
              </Typography>
            </Box>
            <Box sx={{ display: "flex", alignItems: "center" }}>
              <MRT_ToggleFiltersButton
                table={table}
                sx={{ color: primaryColor }}
              />
              <Typography variant="body2" sx={{ color: primaryColor }}>
                FILTERS
              </Typography>
            </Box>
            <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
              <CiExport style={{ color: primaryColor, fontSize: "16px" }} />
              <Typography variant="body2" sx={{ color: primaryColor }}>
                EXPORT
              </Typography>
            </Box>
            {/* <Box sx={{ display: 'flex', alignItems: 'center' }}>
              <MRT_ToggleDensePaddingButton table={table} sx={{ color: primaryColor }} />
              <Typography variant="body2" sx={{ color: primaryColor }}>Denseity</Typography>
            </Box> */}
            <Box sx={{ display: "flex", alignItems: "center" }}>
              <Switch
                size="small"
                color="primary"
                checked={onlySquad}
                onChange={(e) => setOnlySquad(e.target.checked)}
              />
              <Typography variant="body2" sx={{ color: primaryColor }}>
                Squad only
              </Typography>
            </Box>
            <MRT_GlobalFilterTextField table={table} />
          </Box>
          <MRT_TableContainer table={table} />
          <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 2 }}>
            <MRT_TablePagination table={table} />
          </Box>
        </WidgetMainContainer>

        {/* Entity Details Modal */}
        <MyModal
          open={openEntityModal}
          onClose={() => setOpenEntityModal(false)}
          title="Details"
        >
          {selectedEntity && (
            <Grid container spacing={2} sx={{ p: 2 }}>
              {[
                "Name",
                "Owner",
                "Type",
                "Lifecycle",
                "Description",
                "Tags",
              ].map((label, idx) => (
                <React.Fragment key={idx}>
                  <Grid item xs={4}>
                    <Typography fontWeight="bold">{label}</Typography>
                  </Grid>
                  <Grid item xs={8}>
                    {label === "Owner" ? (
                      <Typography
                        onClick={() => {
                          setOpenOwnerModal(true);
                        }}
                        sx={{ cursor: "pointer", color: "primary.main" }}
                      >
                        {selectedEntity.owner}
                      </Typography>
                    ) : (
                      <Typography>
                        {(selectedEntity as any)[label.toLowerCase()]}
                      </Typography>
                    )}
                  </Grid>
                </React.Fragment>
              ))}
            </Grid>
          )}
          <Box textAlign="right" p={2}>
            <Button onClick={() => setOpenEntityModal(false)}>Close</Button>
          </Box>
        </MyModal>

        {/* Owner Details Modal */}
        <MyModal
          open={openOwnerModal}
          onClose={() => setOpenOwnerModal(false)}
          title="Owner Details"
        >
          <Box p={2}>
            <Typography>Owner: {selectedEntity?.owner}</Typography>
          </Box>
          <Box textAlign="right" p={2}>
            <Button onClick={() => setOpenOwnerModal(false)}>Close</Button>
          </Box>
        </MyModal>
      </Box>
    </ThemeProvider>
  );
};

export default OrganisationBackstageDataTable;
