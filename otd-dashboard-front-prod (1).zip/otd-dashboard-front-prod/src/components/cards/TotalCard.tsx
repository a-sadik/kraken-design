// src/components/cards/TotalCards.tsx

import { FC } from "react";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import Stack from "@mui/material/Stack";

interface TotalCardProps {
  source: string;
  total?: number;
  img: string;
  backgroundColor: string;
  textSourceColor: string;
}

const TotalCard: FC<TotalCardProps> = ({
  source = "",
  total = 0,
  img,
  backgroundColor,
  textSourceColor,
}) => {
  return (
    <Stack direction="row" spacing={2} alignContent="center">
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          width: "7rem",
          height: "7rem",
          borderRadius: "16px",
          backgroundColor: `${backgroundColor}`,
          padding: "10px",
        }}
      >
        <img
          src={img}
          alt={source}
          style={{
            width: "80%",
            height: "80%",
            objectFit: "contain",
            borderRadius: "10px",
          }}
        />
      </Box>

      <Stack direction="column" justifyContent="center">
        <Typography
          variant="h6"
          component="div"
          sx={{
            color: `${textSourceColor}`,
            fontSize: {
              xs: "0.80rem",
              sm: "1.25rem",
              md: "1.5rem",
              lg: "1.75rem",
            },
          }}
        >
          Total en {source}
        </Typography>

        <Typography
          variant="body1"
          component="div"
          sx={{
            fontWeight: "bold",
            fontSize: {
              xs: "1.5rem",
              sm: "1.75rem",
              md: "2rem",
              lg: "2.10rem",
            },
          }}
        >
          {total}
        </Typography>
      </Stack>
    </Stack>
  );
};

export default TotalCard;
