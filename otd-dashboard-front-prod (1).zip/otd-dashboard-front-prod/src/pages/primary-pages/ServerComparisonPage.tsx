/* eslint-disable @typescript-eslint/no-explicit-any */

import { Refresh as RefreshIcon } from "@mui/icons-material";
import {
  Alert,
  Box,
  Button,
  CircularProgress,
  Paper,
  TablePagination,
  Typography,
} from "@mui/material";
import { useServerComparison } from "@/hooks/useServerComparison";
import { SearchBar } from "@/components/inputs/ReliabilitySearchBar";
import { TabsSection } from "@/components/basics/CustomTabsSection";
import { ServerAccordion } from "@/components/basics/CustomAccordion";

// Enum dropdown options
const enumDropdownOptions: Record<string, string[]> = {
  environments: [
    "Production",
    "Préproduction",
    "Intégration",
    "Recette",
    "Développement",
    "POC",
    "Formation",
  ],
  solution_popularity: [
    "Agence",
    "Siège",
    "Agence et Siège",
    "Client Entreprise",
    "Client Particulier",
    "Client Particulier et Entreprise",
    "BO",
    "Client Entreprise, Siège et Agence",
  ],
  solution_role: ["Primary"],
  solution_admins: [],
  solution_type: ["InHouse", "Progiciel", "Middleware"],
  os: ["Windows", "Linux", "AIX", "MacOS"],
  pci: ["P0", "P1", "P2", "P3", "P4"],
};

const ServerComparisonPage = () => {
  const {
    loading,
    error,
    page,
    rowsPerPage,
    searchTerm,
    totalCount,
    selectedTab,
    editableValues,
    apiDropdownOptions,
    tabLabels,
    filteredData,
    paginatedData,
    handleChangePage,
    handleChangeRowsPerPage,
    handleSearchChange,
    handleTabChange,
    handleValueChange,
    handleUpdateServer,
    fetchData,
  } = useServerComparison();

  return (
    <Box sx={{ p: { xs: 2, sm: 3 }, maxWidth: "1400px", mx: "auto" }}>
      <Box
        sx={{
          display: "flex",
          flexDirection: { xs: "column", sm: "row" },
          justifyContent: "space-between",
          alignItems: { xs: "flex-start", sm: "center" },
          mb: 3,
          gap: 2,
        }}
      >
        <Typography variant="h4" component="h1" sx={{ fontWeight: 600 }}>
          Comparatif de serveur - {totalCount} {tabLabels[selectedTab]}
        </Typography>
        <Button
          variant="outlined"
          startIcon={<RefreshIcon />}
          onClick={fetchData}
          disabled={loading}
        >
          {loading ? "Refreshing..." : "Refresh Data"}
        </Button>
      </Box>

      <TabsSection
        selectedTab={selectedTab}
        onTabChange={handleTabChange}
        tabLabels={tabLabels}
      />

      <Box sx={{ mb: 3 }}>
        <SearchBar
          searchTerm={searchTerm}
          onSearchChange={handleSearchChange}
        />
      </Box>

      {loading ? (
        <Box sx={{ display: "flex", justifyContent: "center", my: 4 }}>
          <CircularProgress />
        </Box>
      ) : error ? (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      ) : (
        <>
          <Box
            sx={{
              mb: 2,
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <Typography variant="body2" color="text.secondary">
              <strong>{totalCount}</strong>{" "}
              {tabLabels[selectedTab].toLowerCase()} trouvés
              {searchTerm &&
                ` (${filteredData.length} résultats pour "${searchTerm}")`}
            </Typography>
            {filteredData.length === 0 && searchTerm && (
              <Button
                size="small"
                onClick={() =>
                  handleSearchChange({ target: { value: "" } } as any)
                }
                startIcon={<RefreshIcon fontSize="small" />}
              >
                Clear search
              </Button>
            )}
          </Box>

          {filteredData.length === 0 ? (
            <Paper sx={{ p: 4, textAlign: "center" }}>
              <Typography variant="h6" color="text.secondary">
                {searchTerm
                  ? "No servers match your search criteria"
                  : "No servers found"}
              </Typography>
            </Paper>
          ) : (
            <>
              {paginatedData.map((server) => (
                <ServerAccordion
                  key={server.id}
                  server={server}
                  editableValues={editableValues}
                  onValueChange={handleValueChange}
                  onUpdateServer={handleUpdateServer}
                  apiDropdownOptions={apiDropdownOptions}
                  enumDropdownOptions={enumDropdownOptions}
                />
              ))}

              <TablePagination
                component="div"
                count={totalCount}
                page={page}
                onPageChange={handleChangePage}
                rowsPerPage={rowsPerPage}
                onRowsPerPageChange={handleChangeRowsPerPage}
                rowsPerPageOptions={[5, 10, 15, 20]}
                sx={{
                  ".MuiTablePagination-selectLabel, .MuiTablePagination-displayedRows":
                    {
                      margin: 0,
                    },
                }}
              />
            </>
          )}
        </>
      )}
    </Box>
  );
};

export default ServerComparisonPage;
