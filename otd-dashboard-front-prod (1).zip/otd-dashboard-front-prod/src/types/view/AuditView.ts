export interface AuditView {
  id: number;
  Référence: string;
  Personne: string;
  Composant: string;
  "Status d'opération": string;
  Action: string;
  "Raison d'échec": string | null;
  "Adresse IP": string;
  "Date d'opération": string;
  Description: string;
}
