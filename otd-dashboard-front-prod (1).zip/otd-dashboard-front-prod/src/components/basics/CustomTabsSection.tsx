import type React from "react";

import type { ServerConformityType } from "@/enums/ServerConformityView";
import type { TabLabels } from "@/types/ReliabilityTypes";
import { Tab, Tabs } from "@mui/material";

interface TabsSectionProps {
  selectedTab: ServerConformityType;
  onTabChange: (
    event: React.SyntheticEvent,
    newValue: ServerConformityType,
  ) => void;
  tabLabels: TabLabels;
}

export const TabsSection = ({
  selectedTab,
  onTabChange,
  tabLabels,
}: TabsSectionProps) => (
  <Tabs
    value={selectedTab}
    onChange={onTabChange}
    indicatorColor="primary"
    textColor="primary"
    sx={{ mb: 3 }}
  >
    {(Object.keys(tabLabels) as ServerConformityType[]).map((tab) => (
      <Tab key={tab} label={tabLabels[tab]} value={tab} />
    ))}
  </Tabs>
);
