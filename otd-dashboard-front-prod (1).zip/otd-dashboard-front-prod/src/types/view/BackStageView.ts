// src/types/view/BackStageView.ts

export default interface BackStageView {
  title: string;
  name: string;
  owner: string;
  type: string;
  lifecycle: string;
  description: string;
  tags: string[] | string;
  displayName?: string;
  email?: string;
}
