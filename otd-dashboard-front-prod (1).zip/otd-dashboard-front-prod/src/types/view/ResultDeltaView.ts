// src/types/view/ResultDeltaView.ts

export interface ResultDeltaView {
  existing: [];
  baseMissing: [];
  compareMissing: [];
  base?: string;
  compare?: string;
}
