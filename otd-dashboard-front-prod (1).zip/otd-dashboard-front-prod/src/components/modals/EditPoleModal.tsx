// src/components/modals/EditPoleModal.tsx

import React, { useEffect, useState } from "react";
import {
  Grid,
  Typography,
  TextField,
  Autocomplete,
  Box,
  Button,
  CircularProgress,
  Alert,
  Snackbar,
} from "@mui/material";
import MyModal from "@/components/modals/MyModal";
import { getAllPersons } from "@/services/admin/PersonService";
import { getAllEntities } from "@/services/admin/EntityService";
import { updatePole } from "@/services/admin/PoleService";
import { PersonShortResponseDTO } from "@/types/dto/PersonDTO";
import { EntityShortResponseDTO } from "@/types/dto/EntityDTO";

interface EditPoleModalProps {
  open: boolean;
  onClose: () => void;
  onSave: () => void;
  poleId: number;
  currentName: string;
  currentManagerId?: number;
  currentEntityId?: number;
}

export const EditPoleModal: React.FC<EditPoleModalProps> = ({
  open,
  onClose,
  onSave,
  poleId,
  currentName,
  currentManagerId,
  currentEntityId,
}) => {
  const [newName, setNewName] = useState("");
  const [persons, setPersons] = useState<PersonShortResponseDTO[]>([]);
  const [entities, setEntities] = useState<EntityShortResponseDTO[]>([]);
  const [selectedManager, setSelectedManager] =
    useState<PersonShortResponseDTO | null>(null);
  const [selectedEntity, setSelectedEntity] =
    useState<EntityShortResponseDTO | null>(null);
  const [loadingPersons, setLoadingPersons] = useState(false);
  const [loadingEntities, setLoadingEntities] = useState(false);
  const [loadingSave, setLoadingSave] = useState(false);

  const [successSnackbar, setSuccessSnackbar] = useState(false);

  // Charger les données
  useEffect(() => {
    if (!open) return;

    setLoadingPersons(true);
    getAllPersons()
      .then(setPersons)
      .finally(() => setLoadingPersons(false));

    setLoadingEntities(true);
    getAllEntities()
      .then(setEntities)
      .finally(() => setLoadingEntities(false));
  }, [open]);

  // Initialiser les champs à chaque ouverture
  useEffect(() => {
    if (!open) return;
    setNewName(currentName);

    const currentManager = persons.find(
      (p) => p.person_id === currentManagerId,
    );
    setSelectedManager(currentManager ?? null);

    const currentEntity = entities.find((e) => e.entity_id === currentEntityId);
    setSelectedEntity(currentEntity ?? null);
  }, [open, currentName, currentManagerId, currentEntityId, persons, entities]);

  const hasChanges =
    newName.trim() !== currentName.trim() ||
    (selectedManager?.person_id ?? null) !== (currentManagerId ?? null) ||
    (selectedEntity?.entity_id ?? null) !== (currentEntityId ?? null);

  const handleSave = async () => {
    setLoadingSave(true);
    try {
      await updatePole(poleId, {
        pole_name: newName,
        manager_id: selectedManager?.person_id ?? null,
        entity_id: selectedEntity?.entity_id ?? null,
      });

      onSave();
      setSuccessSnackbar(true);
      onClose();
    } catch (err) {
      console.error("Erreur lors de la mise à jour du pôle :", err);
    } finally {
      setLoadingSave(false);
    }
  };

  return (
    <>
      <MyModal open={open} onClose={onClose} title="Modifier le pôle">
        <Grid container spacing={2} sx={{ px: 2, pt: 1 }}>
          {/* Nom du Pôle */}
          <Grid item xs={12} container spacing={2} alignItems="center">
            <Grid item xs={4}>
              <Typography fontWeight="bold">Nouveau nom</Typography>
            </Grid>
            <Grid item xs={8}>
              <TextField
                fullWidth
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
              />
            </Grid>
          </Grid>

          {/* Manager */}
          <Grid item xs={12} container spacing={2} alignItems="center">
            <Grid item xs={4}>
              <Typography fontWeight="bold">Manager</Typography>
            </Grid>
            <Grid item xs={8}>
              {loadingPersons ? (
                <CircularProgress size={24} />
              ) : (
                <Autocomplete
                  options={persons}
                  getOptionLabel={(opt) => `${opt.firstname} ${opt.lastname}`}
                  value={selectedManager}
                  onChange={(_, val) => setSelectedManager(val)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Sélectionner un manager"
                      fullWidth
                    />
                  )}
                />
              )}
            </Grid>
          </Grid>

          {/* Entité associée */}
          <Grid item xs={12} container spacing={2} alignItems="center">
            <Grid item xs={4}>
              <Typography fontWeight="bold">Entité associée</Typography>
            </Grid>
            <Grid item xs={8}>
              {loadingEntities ? (
                <CircularProgress size={24} />
              ) : (
                <Autocomplete
                  options={entities}
                  getOptionLabel={(opt) => opt.entity_name}
                  value={selectedEntity}
                  onChange={(_, val) => setSelectedEntity(val)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Sélectionner une entité"
                      fullWidth
                    />
                  )}
                />
              )}
            </Grid>
          </Grid>
        </Grid>

        {/* Actions */}
        <Box textAlign="right" p={2}>
          <Button onClick={onClose} sx={{ mr: 1 }}>
            Annuler
          </Button>
          <Button
            variant="contained"
            onClick={handleSave}
            disabled={!hasChanges || loadingSave}
          >
            {loadingSave ? "Sauvegarde…" : "Modifier"}
          </Button>
        </Box>
      </MyModal>
      <Snackbar
        open={successSnackbar}
        autoHideDuration={3000}
        onClose={() => setSuccessSnackbar(false)}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <Alert
          onClose={() => setSuccessSnackbar(false)}
          severity="success"
          variant="filled"
        >
          Pôle mis à jour avec succès !
        </Alert>
      </Snackbar>
    </>
  );
};
