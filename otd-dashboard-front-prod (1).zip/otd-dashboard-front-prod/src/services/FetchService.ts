/* eslint-disable @typescript-eslint/no-explicit-any */
import { getFieldsApiUrl, getServersApiUrl } from "@/config/api.config";
import { ErrorResponseDto } from "@/types/dto/response/ReliabilityResponse";

class ApiService {
  private async fetchWithTimeout(
    url: string,
    options: RequestInit = {},
    timeout = 30000,
  ): Promise<Response> {
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), timeout);

    const response = await fetch(url, {
      ...options,
      signal: controller.signal,
    });

    clearTimeout(id);
    return response;
  }

  private async handleResponse<T>(response: Response): Promise<T> {
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      const errorResponse: ErrorResponseDto = {
        success: false,
        message: `API Error: ${response.status} ${response.statusText}`,
        error: errorData,
      };
      throw errorResponse;
    }

    return (await response.json()) as T;
  }

  async get<T>(endpoint: string, isOptionsApi = false): Promise<T> {
    try {
      const url = isOptionsApi
        ? getFieldsApiUrl(endpoint)
        : getServersApiUrl(endpoint);
      const response = await this.fetchWithTimeout(url);
      return this.handleResponse<T>(response);
    } catch (error) {
      if (error instanceof Error && error.name === "AbortError") {
        throw {
          success: false,
          message: "Request timeout",
        } as ErrorResponseDto;
      }
      throw error;
    }
  }

  async post<T>(endpoint: string, data: any, isOptionsApi = false): Promise<T> {
    try {
      const url = isOptionsApi
        ? getFieldsApiUrl(endpoint)
        : getServersApiUrl(endpoint);
      const response = await this.fetchWithTimeout(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
      return this.handleResponse<T>(response);
    } catch (error) {
      if (error instanceof Error && error.name === "AbortError") {
        throw {
          success: false,
          message: "Request timeout",
        } as ErrorResponseDto;
      }
      throw error;
    }
  }

  async put<T>(endpoint: string, data: any, isOptionsApi = false): Promise<T> {
    try {
      const url = isOptionsApi
        ? getFieldsApiUrl(endpoint)
        : getServersApiUrl(endpoint);
      const response = await this.fetchWithTimeout(url, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
      return this.handleResponse<T>(response);
    } catch (error) {
      if (error instanceof Error && error.name === "AbortError") {
        throw {
          success: false,
          message: "Request timeout",
        } as ErrorResponseDto;
      }
      throw error;
    }
  }
}

export const apiService = new ApiService();
