import { useState } from "react";
import { MachineData } from "../machineRequestModal/types";

function DataGrid({
  data,
  loading,
  onRefresh,
}: {
  data: MachineData[];
  loading: boolean;
  onRefresh: () => void;
}) {
  const [sortField, setSortField] = useState<keyof MachineData>(
    "machine_request_ref",
  );
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);
  const [searchTerm, setSearchTerm] = useState("");

  const handleSort = (field: keyof MachineData) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  const filteredData = data.filter((item) =>
    Object.values(item).some((value) => {
      if (Array.isArray(value)) {
        return value.some(
          (v) =>
            v != null &&
            v.toString().toLowerCase().includes(searchTerm.toLowerCase()),
        );
      }
      return (
        value != null &&
        value.toString().toLowerCase().includes(searchTerm.toLowerCase())
      );
    }),
  );

  const sortedData = [...filteredData].sort((a, b) => {
    const aVal = a[sortField];
    const bVal = b[sortField];

    // Handle arrays (hostnames, ip_addresses, disks)
    if (Array.isArray(aVal) && Array.isArray(bVal)) {
      const aStr = aVal.join(", ");
      const bStr = bVal.join(", ");
      return sortDirection === "asc"
        ? aStr.localeCompare(bStr)
        : bStr.localeCompare(aStr);
    }

    // Handle null or undefined values
    if (aVal == null && bVal == null) return 0;
    if (aVal == null) return sortDirection === "asc" ? 1 : -1;
    if (bVal == null) return sortDirection === "asc" ? -1 : 1;

    if (sortDirection === "asc") {
      return aVal > bVal ? 1 : aVal < bVal ? -1 : 0;
    } else {
      return aVal < bVal ? 1 : aVal > bVal ? -1 : 0;
    }
  });

  const totalPages = Math.ceil(sortedData.length / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const paginatedData = sortedData.slice(startIndex, startIndex + pageSize);

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "approved":
        return "#10b981";
      case "pending":
        return "#f59e0b";
      case "rejected":
        return "#ef4444";
      default:
        return "#6b7280";
    }
  };

  const getEnvironmentColor = (env: string) => {
    switch (env.toLowerCase()) {
      case "prod":
        return "#ef4444";
      case "pre-prod":
        return "#f59e0b";
      case "dev":
        return "#3b82f6";
      case "test":
        return "#8b5cf6";
      default:
        return "#6b7280";
    }
  };

  const renderArrayData = (data: string[] | string) => {
    if (Array.isArray(data)) {
      return (
        <div
          style={{ display: "flex", flexDirection: "column", gap: "0.25rem" }}
        >
          {data.map((item, index) => (
            <span
              key={index}
              style={{
                fontSize: "0.75rem",
                padding: "0.125rem 0.375rem",
                backgroundColor: "#f3f4f6",
                borderRadius: "0.25rem",
                whiteSpace: "nowrap",
              }}
            >
              {item}
            </span>
          ))}
        </div>
      );
    }
    return data;
  };

  // Nouvelle fonction pour afficher les disques
  const renderDisksData = (disks: string[] | number[]) => {
    if (!disks || disks.length === 0) {
      return <span style={{ color: "#6b7280", fontStyle: "italic" }}>-</span>;
    }

    return (
      <div style={{ display: "flex", flexDirection: "column", gap: "0.25rem" }}>
        {disks.map((disk, index) => (
          <span
            key={index}
            style={{
              fontSize: "0.75rem",
              padding: "0.125rem 0.375rem",
              backgroundColor: "#fef3c7",
              color: "#92400e",
              borderRadius: "0.25rem",
              whiteSpace: "nowrap",
              fontWeight: "500",
            }}
          >
            {typeof disk === "number" ? `${disk} GB` : disk}
          </span>
        ))}
      </div>
    );
  };

  const columns = [
    { key: "machine_request_ref", label: "Référence", width: "150px" },
    { key: "request_type", label: "Type", width: "100px" },
    { key: "cluster_type", label: "Cluster", width: "120px" },
    { key: "datacenter", label: "Datacenter", width: "100px" },
    { key: "environment_nature", label: "Environnement", width: "120px" },
    { key: "os_type", label: "OS", width: "100px" },
    { key: "os_version", label: "Version OS", width: "100px" },
    { key: "ip_addresses", label: "IPs", width: "150px" },
    { key: "hostnames", label: "Hostnames", width: "150px" },
    { key: "cpu_cores", label: "CPU", width: "80px" },
    { key: "ram_gb", label: "RAM (GB)", width: "100px" },
    { key: "disks", label: "Disques", width: "150px" },
    { key: "status", label: "Statut", width: "100px" },
    { key: "requester_name", label: "Demandé par", width: "150px" },
    { key: "itop_ticket_ref", label: "Réf itop", width: "120px" },
  ];

  return (
    <div
      style={{
        backgroundColor: "white",
        borderRadius: "0.5rem",
        boxShadow: "0 1px 3px rgba(0, 0, 0, 0.1)",
        overflow: "hidden",
      }}
    >
      {/* Toolbar */}
      <div
        style={{
          padding: "1rem",
          borderBottom: "1px solid #e5e7eb",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          flexWrap: "wrap",
          gap: "1rem",
          backgroundColor: "#f9fafb",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
          <input
            type="text"
            placeholder="Rechercher..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={{
              padding: "0.5rem 0.75rem",
              border: "1px solid #d1d5db",
              borderRadius: "0.375rem",
              fontSize: "0.875rem",
              outline: "none",
              minWidth: "250px",
              transition: "all 0.2s",
              boxShadow: searchTerm
                ? "0 0 0 3px rgba(59, 130, 246, 0.1)"
                : "none",
              borderColor: searchTerm ? "#3b82f6" : "#d1d5db",
            }}
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm("")}
              style={{
                padding: "0.5rem",
                backgroundColor: "#f3f4f6",
                border: "none",
                borderRadius: "50%",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "1rem",
                lineHeight: "1",
              }}
            >
              ×
            </button>
          )}
        </div>

        <div style={{ display: "flex", gap: "0.5rem", alignItems: "center" }}>
          <select
            value={pageSize}
            onChange={(e) => setPageSize(Number(e.target.value))}
            style={{
              padding: "0.5rem",
              border: "1px solid #d1d5db",
              borderRadius: "0.375rem",
              fontSize: "0.875rem",
              backgroundColor: "white",
              cursor: "pointer",
            }}
          >
            <option value={10}>10 par page</option>
            <option value={25}>25 par page</option>
            <option value={50}>50 par page</option>
            <option value={100}>100 par page</option>
          </select>
          <button
            onClick={onRefresh}
            disabled={loading}
            style={{
              padding: "0.5rem 1rem",
              backgroundColor: loading ? "#d1d5db" : "#3b82f6",
              color: "white",
              border: "none",
              borderRadius: "0.375rem",
              cursor: loading ? "not-allowed" : "pointer",
              fontSize: "0.875rem",
              display: "flex",
              alignItems: "center",
              gap: "0.5rem",
              transition: "all 0.2s",
            }}
          >
            {loading ? (
              <>
                <div
                  style={{
                    width: "16px",
                    height: "16px",
                    border: "2px solid rgba(255,255,255,0.3)",
                    borderTop: "2px solid white",
                    borderRadius: "50%",
                    animation: "spin 1s linear infinite",
                  }}
                />
              </>
            ) : (
              "Actualiser"
            )}
          </button>
        </div>
      </div>

      {/* Table */}
      <div style={{ overflowX: "auto", maxHeight: "calc(100vh - 200px)" }}>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead
            style={{
              backgroundColor: "#f9fafb",
              position: "sticky",
              top: 0,
              zIndex: 10,
            }}
          >
            <tr>
              {columns.map((column) => (
                <th
                  key={column.key}
                  onClick={() => handleSort(column.key as keyof MachineData)}
                  style={{
                    padding: "0.75rem",
                    textAlign: "left",
                    fontSize: "0.875rem",
                    fontWeight: "500",
                    color: "#374151",
                    cursor: "pointer",
                    borderBottom: "1px solid #e5e7eb",
                    whiteSpace: "nowrap",
                    width: column.width,
                    minWidth: column.width,
                    position: "relative",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "0.25rem",
                      justifyContent: "space-between",
                    }}
                  >
                    {column.label}
                    {sortField === column.key && (
                      <span
                        style={{
                          fontSize: "0.75rem",
                          color:
                            sortDirection === "asc" ? "#3b82f6" : "#ef4444",
                        }}
                      >
                        {sortDirection === "asc" ? "↑" : "↓"}
                      </span>
                    )}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td
                  colSpan={columns.length}
                  style={{ padding: "2rem", textAlign: "center" }}
                >
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                      gap: "0.5rem",
                      color: "#4b5563",
                    }}
                  >
                    <div
                      style={{
                        width: "20px",
                        height: "20px",
                        border: "2px solid #e5e7eb",
                        borderTop: "2px solid #3b82f6",
                        borderRadius: "50%",
                        animation: "spin 1s linear infinite",
                      }}
                    />
                    Chargement des données...
                  </div>
                </td>
              </tr>
            ) : paginatedData.length === 0 ? (
              <tr>
                <td
                  colSpan={columns.length}
                  style={{
                    padding: "2rem",
                    textAlign: "center",
                    color: "#6b7280",
                    fontStyle: "italic",
                  }}
                >
                  {searchTerm
                    ? "Aucun résultat trouvé"
                    : "Aucune donnée disponible"}
                </td>
              </tr>
            ) : (
              paginatedData.map((row) => (
                <tr
                  key={row.machine_request_ref}
                  style={{
                    borderBottom: "1px solid #f3f4f6",
                  }}
                >
                  <td
                    style={{
                      padding: "0.75rem",
                      fontSize: "0.875rem",
                      fontWeight: "500",
                      color: "#1e40af",
                    }}
                  >
                    {row.machine_request_ref}
                  </td>
                  <td style={{ padding: "0.75rem", fontSize: "0.875rem" }}>
                    <span
                      style={{
                        padding: "0.25rem 0.5rem",
                        borderRadius: "0.375rem",
                        fontSize: "0.75rem",
                        fontWeight: "500",
                        backgroundColor: "#2563eb10",
                        color: "#2563eb",
                        textTransform: "capitalize",
                      }}
                    >
                      {row.request_type}
                    </span>
                  </td>
                  <td style={{ padding: "0.75rem", fontSize: "0.875rem" }}>
                    {row.cluster_type === "standard" ? (
                      <span style={{ color: "#6b7280" }}>Standard</span>
                    ) : (
                      <span
                        style={{
                          fontWeight: "500",
                          color: "#1e40af",
                        }}
                      >
                        {row.cluster_type}
                      </span>
                    )}
                  </td>
                  <td style={{ padding: "0.75rem", fontSize: "0.875rem" }}>
                    <span
                      style={{
                        padding: "0.25rem 0.5rem",
                        borderRadius: "0.375rem",
                        fontSize: "0.75rem",
                        fontWeight: "500",
                        backgroundColor: "#10b98110",
                        color: "#10b981",
                        textTransform: "uppercase",
                      }}
                    >
                      {row.datacenter}
                    </span>
                  </td>
                  <td style={{ padding: "0.75rem", fontSize: "0.875rem" }}>
                    <span
                      style={{
                        padding: "0.25rem 0.5rem",
                        borderRadius: "0.375rem",
                        fontSize: "0.75rem",
                        fontWeight: "500",
                        backgroundColor: `${getEnvironmentColor(row.environment_nature)}10`,
                        color: getEnvironmentColor(row.environment_nature),
                        textTransform: "capitalize",
                      }}
                    >
                      {row.environment_nature}
                    </span>
                  </td>
                  <td style={{ padding: "0.75rem", fontSize: "0.875rem" }}>
                    {row.os_type}
                  </td>
                  <td style={{ padding: "0.75rem", fontSize: "0.875rem" }}>
                    {row.os_version || "-"}
                  </td>
                  <td style={{ padding: "0.75rem", fontSize: "0.875rem" }}>
                    {renderArrayData(row.ip_addresses)}
                  </td>
                  <td style={{ padding: "0.75rem", fontSize: "0.875rem" }}>
                    {renderArrayData(row.hostnames)}
                  </td>
                  <td
                    style={{
                      padding: "0.75rem",
                      fontSize: "0.875rem",
                      textAlign: "center",
                    }}
                  >
                    {row.cpu_cores}
                  </td>
                  <td
                    style={{
                      padding: "0.75rem",
                      fontSize: "0.875rem",
                      textAlign: "center",
                    }}
                  >
                    {row.ram_gb}
                  </td>
                  <td style={{ padding: "0.75rem", fontSize: "0.875rem" }}>
                    {renderDisksData(row.disks)}
                  </td>
                  <td style={{ padding: "0.75rem", fontSize: "0.875rem" }}>
                    <span
                      style={{
                        padding: "0.25rem 0.5rem",
                        borderRadius: "0.375rem",
                        fontSize: "0.75rem",
                        fontWeight: "500",
                        backgroundColor: `${getStatusColor(row.status)}20`,
                        color: getStatusColor(row.status),
                        textTransform: "capitalize",
                        display: "inline-block",
                        minWidth: "80px",
                        textAlign: "center",
                      }}
                    >
                      {row.status}
                    </span>
                  </td>
                  <td style={{ padding: "0.75rem", fontSize: "0.875rem" }}>
                    {row.requester_name}
                  </td>
                  <td style={{ padding: "0.75rem", fontSize: "0.875rem" }}>
                    {row.itop_ticket_ref ? (
                      <a
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{
                          color: "#3b82f6",
                          textDecoration: "none",
                        }}
                      >
                        {row.itop_ticket_ref}
                      </a>
                    ) : (
                      "-"
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div
          style={{
            padding: "1rem",
            borderTop: "1px solid #e5e7eb",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: "1rem",
            backgroundColor: "#f9fafb",
          }}
        >
          <div style={{ fontSize: "0.875rem", color: "#6b7280" }}>
            Affichage de {startIndex + 1} à{" "}
            {Math.min(startIndex + pageSize, sortedData.length)} sur{" "}
            {sortedData.length} résultats
          </div>
          <div style={{ display: "flex", gap: "0.5rem" }}>
            <button
              onClick={() => setCurrentPage(1)}
              disabled={currentPage === 1}
              style={{
                padding: "0.5rem 0.75rem",
                border: "1px solid #d1d5db",
                borderRadius: "0.375rem",
                backgroundColor: currentPage === 1 ? "#f3f4f6" : "white",
                color: currentPage === 1 ? "#9ca3af" : "#374151",
                cursor: currentPage === 1 ? "not-allowed" : "pointer",
                fontSize: "0.875rem",
                minWidth: "40px",
              }}
            >
              «
            </button>
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              style={{
                padding: "0.5rem 0.75rem",
                border: "1px solid #d1d5db",
                borderRadius: "0.375rem",
                backgroundColor: currentPage === 1 ? "#f3f4f6" : "white",
                color: currentPage === 1 ? "#9ca3af" : "#374151",
                cursor: currentPage === 1 ? "not-allowed" : "pointer",
                fontSize: "0.875rem",
              }}
            >
              Précédent
            </button>

            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
              let page;
              if (totalPages <= 5) {
                page = i + 1;
              } else if (currentPage <= 3) {
                page = i + 1;
              } else if (currentPage >= totalPages - 2) {
                page = totalPages - 4 + i;
              } else {
                page = currentPage - 2 + i;
              }

              return (
                <button
                  key={page}
                  onClick={() => setCurrentPage(page)}
                  style={{
                    padding: "0.5rem 0.75rem",
                    border: "1px solid #d1d5db",
                    borderRadius: "0.375rem",
                    backgroundColor: currentPage === page ? "#3b82f6" : "white",
                    color: currentPage === page ? "white" : "#374151",
                    cursor: "pointer",
                    fontSize: "0.875rem",
                    minWidth: "40px",
                    fontWeight: currentPage === page ? "600" : "normal",
                  }}
                >
                  {page}
                </button>
              );
            })}

            {totalPages > 5 && currentPage < totalPages - 2 && (
              <span
                style={{
                  padding: "0.5rem 0.75rem",
                  fontSize: "0.875rem",
                  color: "#6b7280",
                }}
              >
                ...
              </span>
            )}

            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              style={{
                padding: "0.5rem 0.75rem",
                border: "1px solid #d1d5db",
                borderRadius: "0.375rem",
                backgroundColor:
                  currentPage === totalPages ? "#f3f4f6" : "white",
                color: currentPage === totalPages ? "#9ca3af" : "#374151",
                cursor: currentPage === totalPages ? "not-allowed" : "pointer",
                fontSize: "0.875rem",
              }}
            >
              Suivant
            </button>
            <button
              onClick={() => setCurrentPage(totalPages)}
              disabled={currentPage === totalPages}
              style={{
                padding: "0.5rem 0.75rem",
                border: "1px solid #d1d5db",
                borderRadius: "0.375rem",
                backgroundColor:
                  currentPage === totalPages ? "#f3f4f6" : "white",
                color: currentPage === totalPages ? "#9ca3af" : "#374151",
                cursor: currentPage === totalPages ? "not-allowed" : "pointer",
                fontSize: "0.875rem",
                minWidth: "40px",
              }}
            >
              »
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default DataGrid;
