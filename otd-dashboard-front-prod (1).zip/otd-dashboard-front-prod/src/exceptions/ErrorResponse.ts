// src/exceptions/ErrorResponse.ts

export interface ErrorResponse {
  status: number;
  message: string;
}
