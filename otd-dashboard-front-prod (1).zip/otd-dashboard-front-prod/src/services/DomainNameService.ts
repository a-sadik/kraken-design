// src/services/DomainNameService.ts

import { AxiosError } from "axios";
import { ErrorResponse } from "../exceptions/ErrorResponse";
import { DomainNameResponseDTO } from "@/types/dto/response/DomainNameResponseDTO";
import apiClientHttp from "./apiClientHttp";

const path = "/domain-names";

// Function to recieve all domaine names
export const getAllDomaineNames = async (): Promise<
  DomainNameResponseDTO[]
> => {
  try {
    const response = await apiClientHttp.dataApiClient.get<
      DomainNameResponseDTO[]
    >(`${path}`);

    // Mapper les données
    // const mappedData: CertificateView[] = certificateResToView(response.data);

    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error(
      "Error fetching all certificates data:",
      err.response?.data.message,
    );
    throw err;
  }
};
