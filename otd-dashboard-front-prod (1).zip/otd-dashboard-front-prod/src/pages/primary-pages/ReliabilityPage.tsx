// src/pages/ReliabilityPage.tsx

import { useState, useEffect } from "react";
import { AxiosError } from "axios";
import { Stack, Box } from "@mui/material";

// imports files
import WidgetMainContainer from "@/components/containers/WidgetMainContainer";
import { DifferenceForm } from "@/components/forms/DifferenceForm";
import SignatureSheetTable from "@/components/data-tables/SignatureSheetDataTable";
import CustomLoading from "@/components/basics/CustomLoading";
import { getCssVariableValue } from "@/utils/getDynamicColor";
import PieChart from "@/components/charts/PieChart";
import { getHealthBackendData } from "@/services/ServerService";
import { getHealthSourceService } from "@/services/HealthService";
import { ResultDeltaView } from "@/types/view/ResultDeltaView";

// import messages
import {
  service_unavailable,
  service_failure,
  service_source,
  service_data,
} from "@/utils/customMessages";

export default function ReliabilityPage() {
  const [source, setSource] = useState<string | null>(null);
  const [destination, setDestination] = useState<string | null>(null);
  const [result, setResult] = useState<ResultDeltaView | null>(null);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const getHealth = async () => {
    try {
      await Promise.all([getHealthBackendData(), getHealthSourceService()]);
      setErrorMsg(null);
    } catch (err) {
      const error = err as AxiosError;
      if (error.code === "ERR_NETWORK")
        setErrorMsg(
          `${service_unavailable} : ${service_source} et/ou ${service_data}`,
        );
      else
        setErrorMsg(
          `${service_failure} : ${service_source} et/ou ${service_data}`,
        );
    }
  };

  useEffect(() => {
    setLoading(true);
    getHealth();
    setTimeout(() => {
      setLoading(false);
    }, 3000);
  }, []);

  function getColor(agent: string) {
    switch (agent) {
      case "bigfix":
        return getCssVariableValue("--bigfix-primary-color");
      case "cmdb":
        return getCssVariableValue("--cmdb-primary-color");
      case "inventory":
        return getCssVariableValue("--inventory-primary-color");
      default:
        return getCssVariableValue("--primary-color");
    }
  }

  if (loading) return <CustomLoading />;
  else if (errorMsg !== null) {
    return (
      <Box
        color="error.main"
        sx={{ textAlign: "center", marginTop: 2, fontWeight: "bold" }}
      >
        {errorMsg}
      </Box>
    );
  } else
    return (
      <>
        <WidgetMainContainer
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Stack
            direction="row"
            spacing={{ xs: 2, sm: 5, md: 10 }}
            justifyContent="center"
            alignItems="center"
          >
            <DifferenceForm
              source={source}
              setSource={setSource}
              destination={destination}
              setDestination={setDestination}
              setLoading={setLoading}
              setResult={setResult}
            />
          </Stack>
        </WidgetMainContainer>

        {/* Affichage des résultats */}

        {result && (
          <WidgetMainContainer>
            <PieChart
              chartData={{
                labels: ["Communs", source, destination].map((data) => data),
                datasets: [
                  {
                    label: "Nombre des serveurs disponibles",
                    data: [
                      result?.existing.length,
                      result?.baseMissing.length,
                      result?.compareMissing.length,
                    ],
                    backgroundColor: [
                      getColor(""),
                      getColor(result.base!),
                      getColor(result.compare!),
                    ],
                    borderColor: getCssVariableValue(
                      "--layout-background-color",
                    ),
                    borderWidth: 1.5,
                  },
                ],
              }}
            />
          </WidgetMainContainer>
        )}

        {result && (
          <SignatureSheetTable
            key={"delta-table-1"}
            color={getColor("")}
            title={`Actifs communs`}
            rows={result?.existing || []}
          />
        )}

        {result && (
          <SignatureSheetTable
            key={"delta-table-2"}
            color={getColor(result.base!)}
            title={`Actifs en ${source}`}
            rows={result?.baseMissing || []}
          />
        )}

        {result && (
          <SignatureSheetTable
            key={"delta-table-3"}
            color={getColor(result.compare!)}
            title={`Actifs en ${destination}`}
            rows={result?.compareMissing || []}
          />
        )}
      </>
    );
}
