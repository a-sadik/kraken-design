import React from "react";
import { useNavigate } from "react-router-dom";

// import icons
import { FaBuildingColumns } from "react-icons/fa6";
import { RxLapTimer } from "react-icons/rx";
import { RiAdminFill } from "react-icons/ri";
import { TbWorldWww } from "react-icons/tb";

import { Button, Grid2, Grid, Box, Typography } from "@mui/material";
import routes, { PageTitle } from "@/routes";
import { Campaign } from "@mui/icons-material";
import ContentPasteIcon from '@mui/icons-material/ContentPaste';
// import { keycloak } from "@/auth/keycloakConnectAdapter";

const AuditAdminPage: React.FC = () => {
  const navigate = useNavigate();

  const goToPage = (path: string) => {
    navigate(path);
  };

  const itemAdmin = [
    {
      label: routes.at(9)?.title,
      icon: <RiAdminFill size={60} />,
      path: routes.at(9)?.path,
    }, // Admin
    {
      label: routes.at(10)?.title,
      icon: <FaBuildingColumns size={60} />,
      path: routes.at(10)?.path,
    }, // Audit
    {
      label: routes.at(17)?.title,
      icon: routes.at(17)?.icon,
      path: routes.at(17)?.path,
    }, // Organigramme
    {
      label: routes.at(18)?.title,
      icon: routes.at(18)?.icon,
      path: routes.at(18)?.path,
    }, // Backstage Data
    {
      label: PageTitle.DOMAINENAME,
      icon: <TbWorldWww size={60} />,
      path: routes.find((item) => item.title === PageTitle.DOMAINENAME)?.path,
    }, // verifierUrl
    {
      label: "Audit Fiabilisation",
      icon: <FaBuildingColumns size={60} />,
      path: routes.find((item) => item.title === PageTitle.AUDIT_REAL)?.path,
    },
    {
      label: PageTitle.CRONJOBS_CRUD_PANEL,
      icon: <RxLapTimer size={60} />,
      path: routes.find((item) => item.title === PageTitle.CRONJOBS_CRUD_PANEL)?.path,
    },

    // annonce
    {
      label: PageTitle.Announcement,
      icon: <Campaign style={{ fontSize: '60px' }} />,
      path: routes.find((item) => item.title === PageTitle.Announcement)?.path,
    },

    // Documentation
    {
      label: PageTitle.Documentation,
      icon: <ContentPasteIcon  style={{ fontSize: '60px' }} />,
      path: routes.find((item) => item.title === PageTitle.Documentation)?.path,
    },
  ];

  return (
    <Grid2
      container
      spacing={2}
      sx={{
        width: "70%",
        marginX: "auto",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      {itemAdmin.map(({ label, icon, path }, index) => (
        <>
          <Grid
            key={index}
            item
            xs={4}
            component="div"
            sx={{ display: "flex", justifyContent: "center" }}
          >
            <Button
              className="btn-self-service certificat"
              color="primary"
              variant="contained"
              size="large"
              onClick={() => goToPage(path!)}
              sx={{
                minWidth: "120px",
                height: "140px",
                margin: 1,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                textTransform: "uppercase",
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                }}
              >
                {icon}
                <Typography
                  variant="body2"
                  sx={{ mt: 1, fontWeight: "bold", fontSize: "16px" }}
                >
                  {label}
                </Typography>
              </Box>
            </Button>
          </Grid>
        </>
      ))}
    </Grid2>
  );
};

export default AuditAdminPage;
