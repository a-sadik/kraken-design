// src/types/view-modals/DeltaDataResponseDTO.ts

import DataResponseDTO from "./DataResponseDTO";

export interface DeltaDataResponseDTO {
  existingVMs: DataResponseDTO;
  missingVMs: DataResponseDTO;
}
