/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * Formats a value for display
 * @param value Any value to format
 * @returns Formatted string representation
 */
export const formatValue = (value: any): string => {
  if (value === null || value === undefined) return "";
  if (Array.isArray(value)) return value.join(", ");
  return String(value);
};

/**
 * Creates a semi-transparent color with the specified opacity
 * @param color Base color in hex format
 * @param opacity Opacity value between 0 and 1
 * @returns Color with opacity applied
 */
export const alpha = (color: string, opacity: number): string => {
  return (
    color +
    Math.round(opacity * 255)
      .toString(16)
      .padStart(2, "0")
  );
};

/**
 * Formats a field name for display by replacing underscores with spaces and translate it to french
 * @param fieldName Original field name
 * @returns Formatted field name
 */
export const formatFieldName = (fieldName: string): string => {
  const spaceless = fieldName.replace(/_/g, " ");
  if (spaceless.toLowerCase() === "pci") return "Psi";
  if (spaceless.toLowerCase() === "ip addresses") return "Adresses IP";
  if (spaceless.toLowerCase() === "os details") return "Détails de l'OS";
  if (spaceless.toLowerCase() === "server nature") return "Nature du serveur";
  if (spaceless.toLowerCase() === "environments") return "Environnements";
  if (spaceless.toLowerCase() === "solution name") return "Nom de solution";
  if (spaceless.toLowerCase() === "solution role") return "Rôle de solution";
  if (spaceless.toLowerCase() === "solution type") return "Type de solution";
  if (spaceless.toLowerCase() === "solution popularity")
    return "Population de solution";
  if (spaceless.toLowerCase() === "functionals admins")
    return "Admins Fonctionnels";
  if (spaceless.toLowerCase() === "technicals admins")
    return "Admins Techniques";
  if (spaceless.toLowerCase() === "domain") return "Domaine";
  if (spaceless.toLowerCase() === "pole") return "Pôle";
  if (spaceless.toLowerCase() === "entity") return "Entité";
  return spaceless.charAt(0).toUpperCase() + spaceless.slice(1);
};

// export const formatKeyContent = (texte: string): string => {
//   return texte.replace(/\n/g, '\\n');
// }

// export const formatKeyContent = (rawKey: string): string => {
//   return `'${rawKey
//     .replace(/\r?\n/g, '\\n') // remplace les vrais retours à la ligne par \n
//     .replace(/'/g, "\\'")     // échappe les apostrophes si nécessaire
//   }\\n'`; // ajoute un \n final si requis
// };

// const keyContent = `
// -----BEGIN RSA PRIVATE KEY-----
// MIIEpAIBAAKCAQEAvHk+KV+OUDJ2w/OVDneYaFJyMPemQ2mW0CnEHAbd/HcJ+nSa
// P9HFtSJ3jei4+3LpUCDi1jaSpE0W/As/FUq8hNxvOwViUMvTsm6zsUml1yu4unke
// dcB4MeeKdee9QkoozoFkAaouujcXpksA+ZFj+yKky1j5qastRJe0awg7nIazy9PR
// nPdN0fkBKsB5P/z2kEegAp6WJeh8gjRAjzAMUk1x2UjEPnzUhDr7QgvONEpwdqd+
// IiR37mqM5qHYiCguQGgFYcO8m7ZWeufux0hZF+Rejb1a88t/w6PCi4aN0Ce5t1xN
// 69xu1RCW32Hyf8HDM/sLPBgy4bRZA0Rica0xuwIDAQABAoIBAD1PV3hP/FR8RgQy
// Ta+6Gdr9zuW8+dn+FDA9Fe1kEnxZIObXXYIbNCxbPPbt2Jb7Z4hIWmICuKs35J0y
// 7192w2KY7poNg1DzLTdjKZMneQpIz7vhQJZfePoK7xCxxPA2fZXHo4ejG7Y5y7it
// t3B36kU8nM0FcZnO9FfW3brfn7ynyWXp1h8ECpv3qhYoNO3k4h8HTDRWggD9aV0P
// Pvyf23NufMrnR6P/FlkWdcxH2OskNCGr/S1rpwcc+Xh+LnuVPjuAhA4b8r6DfY1X
// XwUOB5KlY0yv6dhGCDSm//VopeSGp9ZC0Jwr+wOrXqsce6KwWZPSCVW9FLFdckXP
// 036p1pkCgYEA8k7RZ88P+8OEp2TNct12v5Md5ofqW8NJe+3+6q6MTzz1XsVBYw3b
// tB+TWnGn09ReqB1W6/ImS7EDjJWdV+gTD8Ug068DDRGQmLGwRUu5v8Ezt+N+6Av+
// 1GQ1wdABtPwIVZH+SONziNyskz8tzyiDRvV6gSvKMS5DO5NMKLew1H0CgYEAxx+q
// +22MhSBtYqY7hECRVYbITN7nHTlCpNsMcorU8l8oizz/3joF4dEpeQjPBw4rK4BB
// ZQg/ihLep5VPyAQgACb49HMZDgmfTFkJ+qDIDM/mY0Zbt9dvGMg1qmnhfFD86WN0
// AgsCJ7HToAZtMQEAl7FKt6AAEbC58sHykOYyDJcCgYEAltKao6wOPd64fl1PSHUz
// ShGvpePp645F+j7s0nUtXtEJxiCwD5D7tUWGOeDO3xqshKYmiZzjW2/mTqZ+Fs6c
// ts80HK8uDf9l6rWHi8qT5xjCMW8IejWlO9zYXTg1J8tNAL5r8kCplIIPZWQJBo4o
// EI4R3787DpvGO5n26M1V4x0CgYAIs6mVM0RgzPn6xaj0Lp4rTqiSM2uGK2puKeRx
// XP/RV7c93nyQCZkYNTvKvkfN1yCr1f8Fm0arkgeI602BQCzl1M4sYJtHscP0Yi+9
// dClJ5gv7aqe3cQK54oX13IquFBv5Vw9Kx5Bgi7Tj2WQMMC8GcgkB3UwjecWmhjND
// gcvOIQKBgQCTOx2zDTDNG5NrACtahx5Jq6mKnc19QjD75LzU7JqFaoW6jS+7M49x
// R+AfhfN/y6GiJvNeGur+YjqF7P40wjMn3odQ/l4/UoRzuMCZWoOU5sL8vIUz3ggj
// 4yAaJSt6UHyHDW04Ts4zqvGa4vbqNnNw7s4GqyIMInsOO80qF6CQyQ==
// -----END RSA PRIVATE KEY-----
// `;

// this.formatKeyContent(keyContent);

export const formatKeyContent = (keyContent: string): string => {
  // Supprime les vrais retours à la ligne ET les séquences d'échappement \n littérales
  const cleanKey = keyContent
    .replace(/\r?\n/g, "")
    .replace(/\\n/g, "\n")
    .trim();

  const data = " ";

  // console.log('cleanKey length:', cleanKey.length);
  // console.log('data length:', data.length);
  // console.log('Are they equal?', data === cleanKey);

  // Pour débugger, affichons les premiers caractères
  // console.log('cleanKey start:', cleanKey.substring(0, 50));
  // console.log('data start:', data.substring(0, 50));

  if (data === cleanKey) {
    // console.log('Keys match!');
    return cleanKey;
  } else {
    // console.log('Keys do not match');
    // Pour plus de debug, comparons caractère par caractère
    for (let i = 0; i < Math.min(cleanKey.length, data.length); i++) {
      if (cleanKey[i] !== data[i]) {
        // console.log(`First difference at position ${i}:`);
        // console.log(`cleanKey[${i}]: "${cleanKey[i]}" (code: ${cleanKey.charCodeAt(i)})`);
        // console.log(`data[${i}]: "${data[i]}" (code: ${data.charCodeAt(i)})`);
        break;
      }
    }
    return cleanKey;
  }
};

// return '-----BEGIN RSA PRIVATE KEY-----\nMIIEpAIBAAKCAQEAvHk+KV+OUDJ2w/OVDneYaFJyMPemQ2mW0CnEHAbd/HcJ+nSa\nP9HFtSJ3jei4+3LpUCDi1jaSpE0W/As/FUq8hNxvOwViUMvTsm6zsUml1yu4unke\ndcB4MeeKdee9QkoozoFkAaouujcXpksA+ZFj+yKky1j5qastRJe0awg7nIazy9PR\nnPdN0fkBKsB5P/z2kEegAp6WJeh8gjRAjzAMUk1x2UjEPnzUhDr7QgvONEpwdqd+\nIiR37mqM5qHYiCguQGgFYcO8m7ZWeufux0hZF+Rejb1a88t/w6PCi4aN0Ce5t1xN\n69xu1RCW32Hyf8HDM/sLPBgy4bRZA0Rica0xuwIDAQABAoIBAD1PV3hP/FR8RgQy\nTa+6Gdr9zuW8+dn+FDA9Fe1kEnxZIObXXYIbNCxbPPbt2Jb7Z4hIWmICuKs35J0y\n7192w2KY7poNg1DzLTdjKZMneQpIz7vhQJZfePoK7xCxxPA2fZXHo4ejG7Y5y7it\nt3B36kU8nM0FcZnO9FfW3brfn7ynyWXp1h8ECpv3qhYoNO3k4h8HTDRWggD9aV0P\nPvyf23NufMrnR6P/FlkWdcxH2OskNCGr/S1rpwcc+Xh+LnuVPjuAhA4b8r6DfY1X\nXwUOB5KlY0yv6dhGCDSm//VopeSGp9ZC0Jwr+wOrXqsce6KwWZPSCVW9FLFdckXP\n036p1pkCgYEA8k7RZ88P+8OEp2TNct12v5Md5ofqW8NJe+3+6q6MTzz1XsVBYw3b\ntB+TWnGn09ReqB1W6/ImS7EDjJWdV+gTD8Ug068DDRGQmLGwRUu5v8Ezt+N+6Av+\n1GQ1wdABtPwIVZH+SONziNyskz8tzyiDRvV6gSvKMS5DO5NMKLew1H0CgYEAxx+q\n+22MhSBtYqY7hECRVYbITN7nHTlCpNsMcorU8l8oizz/3joF4dEpeQjPBw4rK4BB\nZQg/ihLep5VPyAQgACb49HMZDgmfTFkJ+qDIDM/mY0Zbt9dvGMg1qmnhfFD86WN0\nAgsCJ7HToAZtMQEAl7FKt6AAEbC58sHykOYyDJcCgYEAltKao6wOPd64fl1PSHUz\nShGvpePp645F+j7s0nUtXtEJxiCwD5D7tUWGOeDO3xqshKYmiZzjW2/mTqZ+Fs6c\nts80HK8uDf9l6rWHi8qT5xjCMW8IejWlO9zYXTg1J8tNAL5r8kCplIIPZWQJBo4o\nEI4R3787DpvGO5n26M1V4x0CgYAIs6mVM0RgzPn6xaj0Lp4rTqiSM2uGK2puKeRx\nXP/RV7c93nyQCZkYNTvKvkfN1yCr1f8Fm0arkgeI602BQCzl1M4sYJtHscP0Yi+9\ndClJ5gv7aqe3cQK54oX13IquFBv5Vw9Kx5Bgi7Tj2WQMMC8GcgkB3UwjecWmhjND\ngcvOIQKBgQCTOx2zDTDNG5NrACtahx5Jq6mKnc19QjD75LzU7JqFaoW6jS+7M49x\nR+AfhfN/y6GiJvNeGur+YjqF7P40wjMn3odQ/l4/UoRzuMCZWoOU5sL8vIUz3ggj\n4yAaJSt6UHyHDW04Ts4zqvGa4vbqNnNw7s4GqyIMInsOO80qF6CQyQ==\n-----END RSA PRIVATE KEY-----';
