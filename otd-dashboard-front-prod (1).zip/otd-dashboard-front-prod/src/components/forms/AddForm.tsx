import React, { useState } from "react";

import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from "@mui/material";

interface AddFormProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (data: { nom: string; manager: string }) => void;
  adminType: string;
}

const AddForm: React.FC<AddFormProps> = ({
  open,
  onClose,
  onSubmit,
  adminType,
}) => {
  const [nom, setNom] = useState("");
  const [manager, setManager] = useState("");
  const handleSubmit = () => {
    // Vous pouvez ajouter des validations ici avant de soumettre
    if (nom.trim() === "") {
      alert("Veuillez saisir un nom.");
      return;
    }
    onSubmit({ nom, manager });
    // Réinitialisation des champs
    setNom("");
    setManager("");
  };

  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="sm">
      <DialogTitle>Ajouter {adminType}</DialogTitle>
      <DialogContent>
        <TextField
          label="Nom"
          value={nom}
          onChange={(e) => setNom(e.target.value)}
          fullWidth
          margin="normal"
        />

        <FormControl fullWidth margin="normal">
          <InputLabel id="manager-label">Manager</InputLabel>
          <Select
            labelId="manager-label"
            value={manager}
            label="Manager"
            onChange={(e) => setManager(e.target.value as string)}
          >
            <MenuItem value="">Aucun</MenuItem>
            <MenuItem value="Manager1">Manager1</MenuItem>
            <MenuItem value="Manager2">Manager2</MenuItem>
            <MenuItem value="Manager3">Manager3</MenuItem>
          </Select>
        </FormControl>
      </DialogContent>

      <DialogActions>
        <Button onClick={onClose} color="secondary">
          Annuler
        </Button>
        <Button onClick={handleSubmit} variant="contained" color="primary">
          Ajouter
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default AddForm;
