/* eslint-disable @typescript-eslint/no-explicit-any */
import React from 'react';
import { TextField, Button, Switch, FormControlLabel, Stack } from '@mui/material';

interface Props {
  name: string;
  command: string;
  interval: number;
  active: boolean;
  description: string;
  editingJob: any | null;
  onChange: (field: string, value: any) => void;
  onSubmit: (e: React.FormEvent) => void;
  onCancel: () => void;
}

const CronJobForm: React.FC<Props> = ({
  name, command, interval, active, description, editingJob,
  onChange, onSubmit, onCancel
}) => (
  <form onSubmit={onSubmit}>
    <TextField label="Nom" value={name} onChange={(e) => onChange('name', e.target.value)} fullWidth margin="normal" />
    <TextField label="Commande" value={command} onChange={(e) => onChange('command', e.target.value)} fullWidth margin="normal" placeholder="ex: openshift_dev" />
    <TextField label="Intervalle (min)" type="number" value={interval} onChange={(e) => onChange('interval', Number(e.target.value))} fullWidth margin="normal" />
    <TextField label="Description" value={description} onChange={(e) => onChange('description', e.target.value)} fullWidth margin="normal" multiline rows={3} placeholder="Décris ce que fait ce batch..." />
    <FormControlLabel control={<Switch checked={active} onChange={(e) => onChange('active', e.target.checked)} />} label="Actif" />
    <Stack direction="row" spacing={2} sx={{ mt: 2 }}>
      <Button type="submit" variant="contained" color="primary">{editingJob ? 'Modifier' : 'Créer'}</Button>
      {editingJob && <Button variant="outlined" onClick={onCancel}>Annuler</Button>}
    </Stack>
  </form>
);

export default CronJobForm;
