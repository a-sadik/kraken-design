import type { ServerResponseDTO } from "./response/ServerResponseDTO";

export interface PaginatedServerResponseDTO {
  environment_counts: never[];
  data(data: any): unknown;
  count: number;
  next: string | null;
  previous: string | null;
  results: ServerResponseDTO[];
}
