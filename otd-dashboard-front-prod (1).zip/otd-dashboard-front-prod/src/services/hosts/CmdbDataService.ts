// src/services/hosts/CmdbDataService.ts

import axios from "axios";

// import files
import { HostView } from "@/types/view/HostView";
import DataResponseDTO from "@/types/dto/response/DataResponseDTO";
import { mapData } from "@/mappers/DataMapper";

const PREFIX_PATH = import.meta.env.VITE_PREFIX_SOURCE_PATH;
const SUFFIX_PATH = import.meta.env.VITE_SUFFIX_SOURCE_PATH;
const SERVER_PORT = import.meta.env.VITE_SOURCE_SERVER_PORT;
const path = `${PREFIX_PATH}:${SERVER_PORT}/${SUFFIX_PATH}`;

export const getInventoryData = async (): Promise<HostView> => {
  try {
    const response = await axios.get<DataResponseDTO[]>(`${path}/cmdb/hosts`);

    // Mapper les données
    const mappedData = mapData(response.data);

    // Construire l'objet HostView
    const hostData: HostView = {
      source: "CMDB",
      number: mappedData.length,
      data: mappedData,
      primaryColor: "#1c4196",
      secondaryColor: "#cbe8ff",
    };

    return hostData;
  } catch (error) {
    console.error("Error fetching CMDB data:", error);
    throw error;
  }
};
