// AffectPostModal.tsx

import React, { useEffect, useState } from "react";
import {
  TextField,
  Button,
  Box,
  CircularProgress,
  Autocomplete,
  Snackbar,
  Alert,
} from "@mui/material";
import MyModal from "@/components/modals/MyModal";
import axios from "axios";
import { getPersonById } from "@/services/admin/PersonService";

interface Option {
  id: string;
  name: string;
}

interface AffectPostModalProps {
  open: boolean;
  onClose: () => void;
  onSave: (payload: { personneIds: string[]; postIds: string[] }) => void;
  personName: string;
  personId: string;
}

export const AffectPostModal: React.FC<AffectPostModalProps> = ({
  open,
  onClose,
  personName,
  personId,
}) => {
  const [posts, setPosts] = useState<Option[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedPosts, setSelectedPosts] = useState<Option[]>([]);
  const [successSnackbar, setSuccessSnackbar] = useState(false);

  useEffect(() => {
    if (!open) return;

    const fetchData = async () => {
      setLoading(true);
      try {
        const token = localStorage.getItem("access_token");

        // 1. Récupérer tous les posts disponibles
        const postsRes = await axios.get(
          "http://localhost:3001/api/v1/persons/enums/posts",
          {
            headers: { Authorization: `Bearer ${token}` },
          },
        );
        const allPosts: Option[] = postsRes.data.map((p: string) => ({
          id: p,
          name: p,
        }));
        setPosts(allPosts);

        // 2. Récupérer les posts actuels de la personne
        const personData = await getPersonById(Number(personId));

        if (personData && personData.posts) {
          const parsedPosts: string[] = Array.isArray(personData.posts)
            ? personData.posts
            : (() => {
                try {
                  return JSON.parse(personData.posts || "[]");
                } catch {
                  return [];
                }
              })();

          // 3. Préremplir selectedPosts
          const selected = allPosts.filter((p) => parsedPosts.includes(p.id));
          setSelectedPosts(selected);
        }
      } catch (err) {
        console.error("Erreur de chargement:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [open, personId]);

  const handleSave = async () => {
    const token = localStorage.getItem("access_token");
    const postNames = selectedPosts.map((p) => p.id);

    try {
      await axios.patch(
        `http://localhost:3001/api/v1/persons/${personId}/post`,
        {
          posts: postNames,
          operation_by: "Admin",
        },
        {
          headers: { Authorization: `Bearer ${token}` },
        },
      );

      setSuccessSnackbar(true);
      onClose();
    } catch (err) {
      console.error("Erreur lors de l’affectation:", err);
    }
  };

  return (
    <>
      <MyModal open={open} onClose={onClose} title="Affecter les Posts">
        <Box sx={{ minWidth: 500, px: 2, pt: 1 }}>
          <TextField
            label="Personne"
            value={personName}
            fullWidth
            margin="normal"
            disabled
          />

          <Autocomplete
            multiple
            options={posts}
            getOptionLabel={(o) => o.name}
            loading={loading}
            value={selectedPosts}
            onChange={(_, vals) => setSelectedPosts(vals)}
            renderInput={(params) => (
              <TextField
                {...params}
                label="Posts"
                margin="normal"
                InputProps={{
                  ...params.InputProps,
                  endAdornment: (
                    <>
                      {loading && <CircularProgress size={20} />}
                      {params.InputProps.endAdornment}
                    </>
                  ),
                }}
              />
            )}
          />

          <Box textAlign="right" mt={3}>
            <Button onClick={onClose} variant="outlined" sx={{ mr: 1 }}>
              Annuler
            </Button>
            <Button
              onClick={handleSave}
              variant="contained"
              disabled={loading || selectedPosts.length === 0}
            >
              Enregistrer
            </Button>
          </Box>
        </Box>
      </MyModal>

      <Snackbar
        open={successSnackbar}
        autoHideDuration={3000}
        onClose={() => setSuccessSnackbar(false)}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <Alert
          onClose={() => setSuccessSnackbar(false)}
          severity="success"
          variant="filled"
        >
          Postes affectés avec succès !
        </Alert>
      </Snackbar>
    </>
  );
};
