import { useState, useEffect } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  Stepper,
  Step,
  StepLabel,
  Grid,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Button,
  IconButton,
  Typography,
  Card,
  CardContent,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  Alert,
  Box,
  Divider,
} from "@mui/material";
import {
  Computer,
  ArrowBack,
  CheckCircle,
  Add,
  Delete,
  Close,
  Layers,
} from "@mui/icons-material";
import { BiLogoPostgresql } from "react-icons/bi";
import { SiOracle, SiMongodb } from "react-icons/si";
import { postMachinesUrl } from "@/config/api.config";

interface MachineRequest {
  user_email: string;
  request_type: string;
  cluster_type: string;
  os_type: string;
  os_version: string;
  ip_addresses: string[];
  cpu_cores: number; // Changé de string à number
  ram_gb: number; // Changé de string à number
  disks: number[]; // Changé de string[] à number[]
  hostnames: string[];
  datacenter: string;
  environment_nature: string;
}

interface IpHostnamePair {
  ip: string;
  hostname: string;
}

const osOptions = [
  { value: "RedHat", label: "RedHat" },
  { value: "Windows", label: "Windows" },
  { value: "AIX", label: "AIX" },
  { value: "Linux", label: "Linux" },
];

const datacenterOptions = [
  { value: "MLY", label: "MLY" },
  { value: "YEM", label: "YEM" },
];

const environmentOptions = [
  { value: "prod", label: "Production" },
  { value: "pré-prod", label: "Pré-production" },
  { value: "recette", label: "Recette" },
  { value: "formation", label: "Formation" },
  { value: "dev", label: "Développement" },
  { value: "test", label: "Test" },
  { value: "provisoire", label: "Provisoire" },
];

const clusterOptions = [
  { value: "PostgreSQL", label: "Cluster PostgreSQL", icon: BiLogoPostgresql },
  { value: "Oracle RAC", label: "Cluster Oracle RAC", icon: SiOracle },
  { value: "MongoDB", label: "Cluster MongoDB", icon: SiMongodb },
];

const steps = ["Type de machine", "Spécifications"];

function MachineRequestModal({
  isOpen,
  onClose,
  onSuccess,
}: {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}) {
  const [stepIndex, setStepIndex] = useState(0);
  const [loading, setLoading] = useState(false);
  const [bearerToken, setBearerToken] = useState("");
  const [userEmail, setUserEmail] = useState("");
  const [machineRequests, setMachineRequests] = useState<MachineRequest[]>([]);
  const [currentRequestIndex, setCurrentRequestIndex] = useState(0);
  const [notification, setNotification] = useState<{
    message: string;
    type: "success" | "error";
  } | null>(null);
  const [disks, setDisks] = useState<string[]>([""]);

  const [machineRequest, setMachineRequest] = useState<MachineRequest>({
    user_email: userEmail,
    request_type: "creation",
    cluster_type: "",
    os_type: "",
    os_version: "latest",
    ip_addresses: [""],
    cpu_cores: 0,
    ram_gb: 0,
    disks: [0],
    hostnames: [""],
    datacenter: "",
    environment_nature: "",
  });

  const [ipHostnamePairs, setIpHostnamePairs] = useState<IpHostnamePair[]>([
    { ip: "", hostname: "" },
  ]);

  const deploymentType =
    ipHostnamePairs.length === 1 ? "standalone" : "cluster";
  const maxIps = 3;

  useEffect(() => {
    if (isOpen) {
      const token =
        localStorage.getItem("token") ||
        localStorage.getItem("access_token") ||
        localStorage.getItem("authToken");
      if (token) {
        setBearerToken(token);

        setUserEmail("user@example.com");
      }
    }
  }, [isOpen]);

  useEffect(() => {
    const ips = ipHostnamePairs.map((pair) => pair.ip);
    const hostnames = ipHostnamePairs.map((pair) => pair.hostname);
    setMachineRequest((prev) => ({
      ...prev,
      ip_addresses: ips,
      hostnames: hostnames,
      cluster_type:
        deploymentType === "cluster" ? prev.cluster_type : "standard",
    }));
  }, [ipHostnamePairs, deploymentType]);

  const resetForm = () => {
    setStepIndex(0);
    setMachineRequests([]);
    setCurrentRequestIndex(0);
    setIpHostnamePairs([{ ip: "", hostname: "" }]);
    setDisks([""]);
    setMachineRequest({
      user_email: userEmail,
      request_type: "creation",
      cluster_type: "",
      os_type: "",
      os_version: "latest",
      ip_addresses: [""],
      cpu_cores: 0,
      ram_gb: 0,
      disks: [0],
      hostnames: [""],
      datacenter: "",
      environment_nature: "",
    });
    setNotification(null);
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  const next = () => setStepIndex((i) => Math.min(i + 1, steps.length - 1));
  const prev = () => setStepIndex((i) => Math.max(0, i - 1));

  const handleCluster = (type: string) => {
    setMachineRequest((prev) => ({
      ...prev,
      cluster_type: type,
    }));
    next();
  };

  const handleNormal = () => {
    setMachineRequest((prev) => ({
      ...prev,
      cluster_type: "standard",
    }));
    next();
  };

  const addIpHostnamePair = () => {
    if (ipHostnamePairs.length < maxIps) {
      setIpHostnamePairs((prev) => [...prev, { ip: "", hostname: "" }]);
    }
  };

  const removeIpHostnamePair = (index: number) => {
    if (ipHostnamePairs.length > 1) {
      setIpHostnamePairs((prev) => prev.filter((_, i) => i !== index));
    }
  };

  const updateIpHostnamePair = (
    index: number,
    field: "ip" | "hostname",
    value: string,
  ) => {
    setIpHostnamePairs((prev) =>
      prev.map((pair, i) => (i === index ? { ...pair, [field]: value } : pair)),
    );
  };

  const addDisk = () => {
    setDisks((prev) => [...prev, ""]);
  };

  const removeDisk = (index: number) => {
    if (disks.length > 1) {
      setDisks((prev) => prev.filter((_, i) => i !== index));
    }
  };

  const updateDisk = (index: number, value: string) => {
    const numValue = parseInt(value) || 0;
    setDisks((prev) =>
      prev.map((disk, i) => (i === index ? numValue.toString() : disk)),
    );
  };

  const updateField = (field: keyof MachineRequest, val: string | number) => {
    setMachineRequest((prev) => ({ ...prev, [field]: val }));
  };

  const validateSpecs = () => {
    const { cpu_cores, ram_gb, os_type, datacenter, environment_nature } =
      machineRequest;

    if (!os_type || !datacenter || !environment_nature) {
      setNotification({
        message: "Tous les champs obligatoires doivent être remplis",
        type: "error",
      });
      return false;
    }

    // Validation des paires IP/Hostname
    const validPairs = ipHostnamePairs.filter(
      (pair) => pair.ip.trim() !== "" && pair.hostname.trim() !== "",
    );
    if (validPairs.length === 0) {
      setNotification({
        message: "Au moins une paire IP/Hostname est requise",
        type: "error",
      });
      return false;
    }

    // Validation format IP
    const ipRegex =
      /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    for (const pair of validPairs) {
      if (!ipRegex.test(pair.ip)) {
        setNotification({
          message: `Format IP invalide: ${pair.ip}`,
          type: "error",
        });
        return false;
      }
    }

    // Validation format hostname
    const hostnameRegex = /^[a-zA-Z0-9-]+$/;
    for (const pair of validPairs) {
      if (!hostnameRegex.test(pair.hostname)) {
        setNotification({
          message: `Format de hostname invalide: ${pair.hostname}`,
          type: "error",
        });
        return false;
      }
    }

    // Validation des disques
    const validDisks = disks.filter((disk) => disk.trim() !== "");
    if (validDisks.length === 0) {
      setNotification({
        message: "Au moins un disque doit être spécifié",
        type: "error",
      });
      return false;
    }

    for (const disk of validDisks) {
      if (isNaN(Number(disk))) {
        setNotification({
          message: `Taille de disque invalide: ${disk}`,
          type: "error",
        });
        return false;
      }
    }

    // Validation valeurs techniques
    if (Number(cpu_cores) <= 0 || Number(ram_gb) <= 0) {
      setNotification({
        message: "Valeurs techniques doivent être positives",
        type: "error",
      });
      return false;
    }

    return true;
  };

  const addMachineToList = () => {
    if (!validateSpecs()) return;

    const validPairs = ipHostnamePairs.filter(
      (pair) => pair.ip.trim() !== "" && pair.hostname.trim() !== "",
    );
    const cleanedIps = validPairs.map((pair) => pair.ip);
    const cleanedHostnames = validPairs.map((pair) => pair.hostname);

    const cleanedDisks = disks.map((disk) => parseInt(disk as string) || 0);

    const newMachine = {
      ...machineRequest,
      ip_addresses: cleanedIps,
      hostnames: cleanedHostnames,
      disks: cleanedDisks,
      user_email: userEmail,
      cpu_cores: parseInt(machineRequest.cpu_cores as unknown as string) || 0,
      ram_gb: parseInt(machineRequest.ram_gb as unknown as string) || 0,
      cluster_type:
        deploymentType === "cluster" ? machineRequest.cluster_type : "standard",
    };

    setMachineRequests((prev) => [...prev, newMachine]);

    // Reset form pour nouvelle machine
    setIpHostnamePairs([{ ip: "", hostname: "" }]);
    setDisks([""]);
    setMachineRequest((prev) => ({
      ...prev,
      os_type: "",
      os_version: "latest",
      cpu_cores: 0,
      ram_gb: 0,
      disks: [0],
    }));

    setNotification({ message: "Machine ajoutée à la liste", type: "success" });
  };

  const submit = async () => {
    // Si aucune machine n'est dans la liste mais que le formulaire est valide
    if (machineRequests.length === 0) {
      if (!validateSpecs()) {
        setNotification({
          message: "Veuillez valider les spécifications",
          type: "error",
        });
        return;
      }
      addMachineToList();
      return;
    }

    setLoading(true);

    try {
      // Simulation d'appel API
      const responses = await Promise.all(
        machineRequests.map(async (request) => {
          const response = await fetch(postMachinesUrl(), {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${bearerToken}`,
            },
            body: JSON.stringify(request),
          });
          return response.json();
        }),
      );

      setNotification({
        message: `${responses.length} demande(s) créée(s) avec succès`,
        type: "success",
      });

      setTimeout(() => {
        onSuccess();
        handleClose();
      }, 1500);
    } catch (error) {
      console.error("Erreur:", error);
      setNotification({
        message: "Erreur lors de la soumission",
        type: "error",
      });
    } finally {
      setLoading(false);
    }
  };

  const removeMachineFromList = (index: number) => {
    setMachineRequests((prev) => prev.filter((_, i) => i !== index));
  };

  return (
    <Dialog
      open={isOpen}
      onClose={handleClose}
      maxWidth="lg"
      fullWidth
      PaperProps={{ sx: { minHeight: "80vh" } }}
    >
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Typography variant="h5">Demander une nouvelle VM</Typography>
        <IconButton onClick={handleClose}>
          <Close />
        </IconButton>
      </DialogTitle>

      <DialogContent>
        <Stepper activeStep={stepIndex} sx={{ mb: 4 }}>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>

        {notification && (
          <Alert
            severity={notification.type}
            onClose={() => setNotification(null)}
            sx={{ mb: 2 }}
          >
            {notification.message}
          </Alert>
        )}

        {stepIndex === 0 && (
          <Grid container spacing={3}>
            {clusterOptions.map((opt) => {
              const IconComponent = opt.icon;
              return (
                <Grid item xs={12} sm={6} md={4} key={opt.value}>
                  <Card
                    sx={{
                      cursor: "pointer",
                      "&:hover": {
                        transform: "translateY(-2px)",
                        boxShadow: 4,
                      },
                      transition: "all 0.3s ease",
                      textAlign: "center",
                      p: 2,
                    }}
                    onClick={() => handleCluster(opt.value)}
                  >
                    <CardContent>
                      <IconComponent
                        style={{
                          fontSize: 56,
                          color: "#1976d2",
                          marginBottom: 16,
                        }}
                      />
                      <Typography variant="h6" gutterBottom>
                        {opt.label}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Cluster haute disponibilité
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>
              );
            })}

            <Grid item xs={12}>
              <Card
                sx={{
                  cursor: "pointer",
                  "&:hover": { transform: "translateY(-2px)", boxShadow: 4 },
                  transition: "all 0.3s ease",
                  textAlign: "center",
                  p: 2,
                }}
                onClick={handleNormal}
              >
                <CardContent>
                  <Computer
                    sx={{ fontSize: 56, color: "success.main", mb: 2 }}
                  />
                  <Typography variant="h6" gutterBottom>
                    Machine Standard
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Machine virtuelle classique
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        )}

        {stepIndex === 1 && (
          <Box>
            <Box sx={{ mb: 3 }}>
              <Chip
                label={
                  deploymentType === "standalone"
                    ? "STANDALONE"
                    : `CLUSTER (${ipHostnamePairs.length} machines)`
                }
                color={
                  deploymentType === "standalone" ? "primary" : "secondary"
                }
                size="medium"
                variant="outlined"
                sx={{ fontSize: "1rem", height: 40, px: 2 }}
              />
            </Box>

            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <FormControl fullWidth required>
                  <InputLabel>Datacenter</InputLabel>
                  <Select
                    value={machineRequest.datacenter}
                    onChange={(e) => updateField("datacenter", e.target.value)}
                    label="Datacenter"
                  >
                    {datacenterOptions.map((opt) => (
                      <MenuItem key={opt.value} value={opt.value}>
                        {opt.label}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>

              <Grid item xs={12} md={6}>
                <FormControl fullWidth required>
                  <InputLabel>Environnement</InputLabel>
                  <Select
                    value={machineRequest.environment_nature}
                    onChange={(e) =>
                      updateField("environment_nature", e.target.value)
                    }
                    label="Environnement"
                  >
                    {environmentOptions.map((opt) => (
                      <MenuItem key={opt.value} value={opt.value}>
                        {opt.label}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>

              <Grid item xs={12} md={6}>
                <FormControl fullWidth required>
                  <InputLabel>Système d'exploitation</InputLabel>
                  <Select
                    value={machineRequest.os_type}
                    onChange={(e) => updateField("os_type", e.target.value)}
                    label="Système d'exploitation"
                  >
                    {osOptions.map((opt) => (
                      <MenuItem key={opt.value} value={opt.value}>
                        {opt.label}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>

              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  required
                  label="Version OS"
                  value={machineRequest.os_version}
                  onChange={(e) => updateField("os_version", e.target.value)}
                  placeholder="latest"
                  disabled={!machineRequest.os_type}
                  helperText="Par défaut: latest"
                />
              </Grid>

              <Grid item xs={12}>
                <Typography variant="h6" gutterBottom>
                  Adresses IP et Hostnames
                </Typography>

                {ipHostnamePairs.map((pair, index) => (
                  <Box
                    key={index}
                    sx={{
                      display: "flex",
                      gap: 2,
                      mb: 2,
                      alignItems: "center",
                    }}
                  >
                    <TextField
                      label="Adresse IP"
                      value={pair.ip}
                      onChange={(e) =>
                        updateIpHostnamePair(index, "ip", e.target.value)
                      }
                      placeholder="192.168.1.1"
                      required
                      sx={{ flex: 1 }}
                    />
                    <TextField
                      label="Hostname"
                      value={pair.hostname}
                      onChange={(e) =>
                        updateIpHostnamePair(index, "hostname", e.target.value)
                      }
                      placeholder="srv-web-01"
                      required
                      sx={{ flex: 1 }}
                    />
                    {ipHostnamePairs.length > 1 && (
                      <IconButton
                        onClick={() => removeIpHostnamePair(index)}
                        color="error"
                      >
                        <Delete />
                      </IconButton>
                    )}
                  </Box>
                ))}

                {ipHostnamePairs.length < maxIps && (
                  <Button
                    startIcon={<Add />}
                    onClick={addIpHostnamePair}
                    variant="outlined"
                    sx={{ mb: 2 }}
                  >
                    Ajouter IP/Hostname
                  </Button>
                )}
              </Grid>

              <Grid item xs={12}>
                <Typography variant="h6" gutterBottom>
                  Spécifications techniques
                </Typography>
              </Grid>

              <Grid item xs={6} md={3}>
                <TextField
                  fullWidth
                  required
                  type="number"
                  label="CPU Cores"
                  value={machineRequest.cpu_cores}
                  onChange={(e) =>
                    updateField("cpu_cores", parseInt(e.target.value) || 0)
                  }
                />
              </Grid>

              <Grid item xs={6} md={3}>
                <TextField
                  fullWidth
                  required
                  type="number"
                  label="RAM (GB)"
                  value={machineRequest.ram_gb}
                  onChange={(e) =>
                    updateField("ram_gb", parseInt(e.target.value) || 0)
                  }
                />
              </Grid>

              <Grid item xs={12}>
                <Typography variant="subtitle1" gutterBottom>
                  Disques (GB)
                </Typography>
                {disks.map((disk, index) => (
                  <Box
                    key={index}
                    sx={{
                      display: "flex",
                      gap: 2,
                      mb: 2,
                      alignItems: "center",
                    }}
                  >
                    <TextField
                      fullWidth
                      type="number"
                      label={`Disque ${index + 1}`}
                      value={disk}
                      onChange={(e) => updateDisk(index, e.target.value)}
                      inputProps={{ min: 1 }}
                    />
                    {disks.length > 1 && (
                      <IconButton
                        onClick={() => removeDisk(index)}
                        color="error"
                      >
                        <Delete />
                      </IconButton>
                    )}
                  </Box>
                ))}
                <Button
                  startIcon={<Add />}
                  onClick={addDisk}
                  variant="outlined"
                >
                  Ajouter un disque
                </Button>
              </Grid>

              <Grid item xs={12}>
                <Button
                  fullWidth
                  variant="contained"
                  color="success"
                  startIcon={<Add />}
                  onClick={addMachineToList}
                  sx={{ py: 1.5 }}
                >
                  Ajouter à la liste
                </Button>
              </Grid>

              {machineRequests.length > 0 && (
                <Grid item xs={12}>
                  <Paper sx={{ p: 2 }}>
                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        mb: 2,
                      }}
                    >
                      <Typography
                        variant="h6"
                        sx={{ display: "flex", alignItems: "center", gap: 1 }}
                      >
                        <Layers />
                        Machines à créer
                      </Typography>
                      <Chip
                        label={`${machineRequests.length} machine${machineRequests.length > 1 ? "s" : ""}`}
                      />
                    </Box>

                    <TableContainer>
                      <Table size="small">
                        <TableHead>
                          <TableRow>
                            <TableCell>Hostnames</TableCell>
                            <TableCell>IP Addresses</TableCell>
                            <TableCell>OS</TableCell>
                            <TableCell>CPU</TableCell>
                            <TableCell>RAM</TableCell>
                            <TableCell>Disques</TableCell>
                            <TableCell>Action</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {machineRequests.map((machine, index) => (
                            <TableRow key={index}>
                              <TableCell>
                                {machine.hostnames.join(", ")}
                              </TableCell>
                              <TableCell>
                                {machine.ip_addresses.join(", ")}
                              </TableCell>
                              <TableCell>
                                {machine.os_type} {machine.os_version}
                              </TableCell>
                              <TableCell>{machine.cpu_cores}</TableCell>
                              <TableCell>{machine.ram_gb} GB</TableCell>
                              <TableCell>
                                {machine.disks.join(" GB, ")} GB
                              </TableCell>
                              <TableCell>
                                <IconButton
                                  size="small"
                                  color="error"
                                  onClick={() => removeMachineFromList(index)}
                                >
                                  <Delete />
                                </IconButton>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </TableContainer>
                  </Paper>
                </Grid>
              )}
            </Grid>

            <Divider sx={{ my: 3 }} />

            <Box sx={{ display: "flex", gap: 2 }}>
              <Button
                startIcon={<ArrowBack />}
                onClick={prev}
                variant="outlined"
              >
                Retour
              </Button>

              <Button
                startIcon={<CheckCircle />}
                onClick={submit}
                variant="contained"
                disabled={loading || machineRequests.length === 0}
                sx={{ flex: 1 }}
              >
                {loading
                  ? `Envoi ${currentRequestIndex + 1}/${machineRequests.length}...`
                  : `Demander ${machineRequests.length > 0 ? `(${machineRequests.length})` : "les machines"}`}
              </Button>
            </Box>
          </Box>
        )}
      </DialogContent>
    </Dialog>
  );
}

export default MachineRequestModal;
