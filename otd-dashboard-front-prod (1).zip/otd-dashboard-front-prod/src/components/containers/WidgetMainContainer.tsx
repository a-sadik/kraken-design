// src/components/containers/WidgetMainContainer.tsx

import * as React from "react";

import Box from "@mui/material/Box";
import { SxProps, Theme } from "@mui/material/styles";

interface WidgetMainContainerProps {
  children: React.ReactNode;
  sx?: SxProps<Theme>;
}

const WidgetMainContainer: React.FC<WidgetMainContainerProps> = ({
  children,
  sx,
}) => {
  return (
    <Box
      component="section"
      sx={{
        p: 3,
        backgroundColor: "white",
        borderRadius: "16px",
        boxShadow: "0px 4px 6px grey",
        width: "100%",
        height: "fit-content",
        my: "1rem",
        mb: "2rem",
        ...sx,
      }}
    >
      {children}
    </Box>
  );
};

export default WidgetMainContainer;
