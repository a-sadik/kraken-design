import React, { useState, useEffect, useCallback } from "react";
import {
  Box,
  Typography,
  Paper,
  Container,
  Alert,
  CircularProgress,
  Button,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Chip,
  Stack,
  Card,
  CardContent,
  LinearProgress,
  InputAdornment,
  IconButton,
  Tooltip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Link,
} from "@mui/material";
import {
  Add,
  Description,
  CloudUpload,
  AttachFile,
  Close,
  Visibility,
  Search,
  ArrowDownward,
  ArrowUpward,
  Cancel,
  CheckCircle,
  Edit,
} from "@mui/icons-material";
import { alpha } from "@mui/material/styles";
import MDEditor from '@uiw/react-md-editor';
import { getReleaseNotesApiUrl, getMyViewApiUrl } from "@/config/api.config";

// Thème et couleurs
const colors = {
  primary: "#1976d2",
  success: "#2e7d32",
  warning: "#ed6c02",
  error: "#d32f2f",
  background: "#f5f5f5",
  textPrimary: "#333333",
  textSecondary: "#666666",
  border: "#e0e0e0",
};

interface Solution {
  id: number;
  solution_name: string;
  solution_role?: string;
  domain?: string;
}

interface ReleaseNote {
  id: number;
  title: string;
  content: string;
  type: string; // Nouveau champ: Evolution, Correction, Test PSI
  category: string; // ECAB ou CAB
  emergency: boolean;
  solution: string;
  document_fonctionnel: string | null;
  document_technique: string | null;
  document_security: string | null;
  document_additionnel: string[];
  created_at: string;
  updated_at: string;
  reference_externe: string;
  author: string;
  accepted_at: string | null;
  refused_at: string | null;
  rejection_reason: string | null;
}

interface FileUpload {
  file: File;
  type: 'fonctionnel' | 'technique' | 'security' | 'additionnel';
  id: string;
}

// Contenu par défaut du modèle
const DEFAULT_CONTENT = `# ✅ Motif de passage en prod
*(Décrire la raison principale du déploiement)*

---

## 🔍 Features
- [ ] Feature 1
- [ ] Feature 2

## 🛠 Fixes
- [ ] Fix 1
- [ ] Fix 2

## ❌ Removal
- [ ] Élément supprimé 1
- [ ] Élément supprimé 2

---

## 🏷️ Versions
- **Backend-service** : vX.X.X
- **Frontend-service** : vX.X.X
- **Autres-service** : vX.X.X

---

## 🛢️ Scripts à éxecuter

${"```"}sql
--Si le script fait plus de 10 lignes merci de le renseigner comme pièce jointe
SELECT 
    column_name, 
    data_type, 
    character_maximum_length, 
    is_nullable, 
    column_default
FROM 
    information_schema.columns;
${"```"}

---

## 🔗 Merge Request
- Lien MR 1
- Lien MR 2
---

## 🌍 Scope d'impact
*(Lister les modules, services ou utilisateurs impactés)*

---

## 👥 Personnes Impliquées
- Nom 1
- Nom 2
`;


const AdminReleaseNotesPage: React.FC = () => {
  // États
  const [releaseNotes, setReleaseNotes] = useState<ReleaseNote[]>([]);
  const [solutions, setSolutions] = useState<Solution[]>([]);
  const [loading, setLoading] = useState(false);
  const [solutionsLoading, setSolutionsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const [refuseDialogOpen, setRefuseDialogOpen] = useState(false);
  const [refuseReason, setRefuseReason] = useState("");
  const [noteToRefuse, setNoteToRefuse] = useState<number | null>(null);

  // États pour la création/modification
  const [dialogOpen, setDialogOpen] = useState(false);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [selectedNote, setSelectedNote] = useState<ReleaseNote | null>(null);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState(DEFAULT_CONTENT);
  const [type, setType] = useState<string>("Evolution");
  const [category, setCategory] = useState<string>("ECAB");
  const [selectedSolution, setSelectedSolution] = useState<string>("");
  const [emergency, setEmergency] = useState<boolean>(true);
  const [files, setFiles] = useState<FileUpload[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [editMode, setEditMode] = useState(false);
  const [editingNoteId, setEditingNoteId] = useState<number | null>(null);

  const [userEmail, setUserEmail] = useState<string>("");
  const [userSolutions, setUserSolutions] = useState<any[]>([]);

  // Fonction pour extraire l'email de l'utilisateur depuis le token
  const getUserEmailFromToken = () => {
    try {
      const token = localStorage.getItem("bearerToken") ||
        localStorage.getItem("access_token") ||
        localStorage.getItem("token");

      if (!token) return "";

      // Décoder le token JWT (partie payload)
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.email || payload.username || "";
    } catch (error) {
      console.error("Erreur lors de la récupération de l'email:", error);
      return "";
    }
  };

  // Fonction pour vérifier si l'utilisateur peut accepter/refuser une note
  const canUserApproveNote = (note: ReleaseNote) => {
    if (!userEmail) return false;

    // Trouver la solution correspondante dans userSolutions
    const solution = userSolutions.find(sol =>
      sol.solution_name === note.solution
    );

    if (!solution) return false;

    // Vérifier si l'utilisateur est admin technique ou TAM de cette solution
    const isTechnicalAdmin = solution.technical_admins?.includes(userEmail);
    const isTam = solution.tams?.includes(userEmail);

    return isTechnicalAdmin || isTam;
  };

  // Nouvelle fonction pour vérifier si l'utilisateur peut modifier une note
  const canUserEditNote = (note: ReleaseNote) => {
    if (!userEmail) return false;

    // L'auteur peut toujours modifier (si la note n'est pas acceptée/refusée)
    const isAuthor = userEmail === note.author;

    // Trouver la solution correspondante dans userSolutions
    const solution = userSolutions.find(sol =>
      sol.solution_name === note.solution
    );

    if (!solution) return false;

    // Vérifier si l'utilisateur est admin technique de cette solution
    const isTechnicalAdmin = solution.technical_admins?.includes(userEmail);

    // Un admin technique peut modifier si la note n'est pas acceptée/refusée
    return (isAuthor || isTechnicalAdmin) && !note.accepted_at && !note.refused_at;
  };

  const [sortConfig, setSortConfig] = useState<{
    field: string;
    direction: 'asc' | 'desc';
  }>({
    field: "created_at",
    direction: "desc"
  });

  // Fonction pour gérer le tri
  const handleSort = (field: string) => {
    setSortConfig(current => {
      // Si on clique sur un nouveau champ, tri ascendant par défaut
      if (!current || current.field !== field) {
        return { field, direction: 'asc' };
      }
      // Si on clique sur le même champ, inverser le sens
      if (current.direction === 'asc') {
        return { field, direction: 'desc' };
      }
      // Si on clique une troisième fois, revenir à l'état initial (desc pour created_at)
      return { field: "created_at", direction: "desc" };
    });
  };

  // Fonction pour trier les notes
  const getSortedNotes = () => {
    // Supprimez cette condition : if (!sortConfig) return filteredReleaseNotes;
    const { field, direction } = sortConfig;

    return [...filteredReleaseNotes].sort((a, b) => {
      let aValue: any = a[field as keyof ReleaseNote];
      let bValue: any = b[field as keyof ReleaseNote];

      // Traitement spécial pour les champs spécifiques
      if (field === 'emergency') {
        aValue = aValue ? 1 : 0;
        bValue = bValue ? 1 : 0;
      } else if (field === 'created_at' || field === 'updated_at') {
        aValue = new Date(aValue).getTime();
        bValue = new Date(bValue).getTime();
      } else {
        aValue = String(aValue || '').toLowerCase();
        bValue = String(bValue || '').toLowerCase();
      }

      if (aValue < bValue) return direction === 'asc' ? -1 : 1;
      if (aValue > bValue) return direction === 'asc' ? 1 : -1;
      return 0;
    });
  };

  // Composant de cellule triable
  const SortableHeaderCell = ({
    field,
    label,
    currentSort
  }: {
    field: string;
    label: string;
    currentSort: typeof sortConfig
  }) => (
    <TableCell
      sx={{
        fontWeight: 700,
        cursor: 'pointer',
        userSelect: 'none',
        whiteSpace: 'nowrap',
        '&:hover': { backgroundColor: alpha(colors.primary, 0.1) }
      }}
      onClick={() => handleSort(field)}
    >
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
        {label}
        {currentSort?.field === field && (
          currentSort.direction === 'asc' ?
            <ArrowUpward sx={{ fontSize: 16 }} /> :
            <ArrowDownward sx={{ fontSize: 16 }} />
        )}
      </Box>
    </TableCell>
  );

  // Types disponibles
  const noteTypes = ["Evolution", "Correction", "Test PSI", "Evolution et Correction"];

  // Fonction pour charger les solutions
  const fetchSolutions = useCallback(async () => {
    setSolutionsLoading(true);
    try {
      const token = localStorage.getItem("bearerToken") ||
        localStorage.getItem("access_token") ||
        localStorage.getItem("token");

      if (!token) {
        console.error("❌ Aucun token d'authentification trouvé");
        setError("Aucun token d'authentification trouvé. Veuillez vous reconnecter.");
        return;
      }

      console.log("🔗 Chargement des solutions depuis:", getMyViewApiUrl());

      const response = await fetch(getMyViewApiUrl(), {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`Erreur ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      console.log("📦 Données brutes des solutions:", data);

      // Extraction des applications
      let solutionsData: Solution[] = [];
      let allSolutionsData: any[] = [];

      if (data && data.applications && Array.isArray(data.applications)) {
        console.log("✅ Structure 'applications' détectée");
        solutionsData = data.applications
          .filter((app: any) => app.solution_name)
          .map((app: any) => ({
            id: app.id || 0,
            solution_name: app.solution_name || `Solution ${app.id}`,
            solution_role: app.solution_role,
            domain: app.domain,
          }));
        allSolutionsData = data.applications;
      } else if (Array.isArray(data)) {
        console.log("✅ Structure tableau direct détectée");
        solutionsData = data
          .filter((app: any) => app.solution_name)
          .map((app: any) => ({
            id: app.id || 0,
            solution_name: app.solution_name || `Solution ${app.id}`,
            solution_role: app.solution_role,
            domain: app.domain,
          }));
        allSolutionsData = data;
      } else {
        console.warn("⚠️ Structure inattendue des données:", data);
        Object.keys(data).forEach(key => {
          console.log(`🔍 Clé '${key}':`, data[key]);
          if (Array.isArray(data[key])) {
            console.log(`✅ Tableau trouvé dans la clé '${key}'`);
            solutionsData = data[key]
              .filter((app: any) => app.solution_name)
              .map((app: any) => ({
                id: app.id || 0,
                solution_name: app.solution_name || `Solution ${app.id}`,
                solution_role: app.solution_role,
                domain: app.domain,
              }));
            allSolutionsData = data[key];
          }
        });
      }

      console.log("🎯 Solutions extraites:", solutionsData);
      setSolutions(solutionsData || []);
      setUserSolutions(allSolutionsData || []);

    } catch (err) {
      console.error("💥 Erreur lors du chargement des solutions:", err);
      setError("Erreur lors du chargement des solutions: " + (err as Error).message);
    } finally {
      setSolutionsLoading(false);
      console.log("🏁 Chargement des solutions terminé");
    }
  }, []);

  // Fonction pour charger les release notes
  const fetchReleaseNotes = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const token = localStorage.getItem("bearerToken") ||
        localStorage.getItem("access_token") ||
        localStorage.getItem("token");

      if (!token) {
        console.error("❌ Aucun token d'authentification trouvé");
        setError("Aucun token d'authentification trouvé. Veuillez vous reconnecter.");
        return;
      }

      console.log("🔗 Chargement des release notes depuis:", getReleaseNotesApiUrl());

      const response = await fetch(getReleaseNotesApiUrl(), {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`Erreur ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      console.log("📦 Release notes reçues:", data);
      setReleaseNotes(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error("💥 Erreur lors du chargement des release notes:", err);
      setError("Erreur lors du chargement des release notes: " + (err as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  // Accepter une release note
  const acceptReleaseNote = async (id: number) => {
    try {
      const token = localStorage.getItem("bearerToken") ||
        localStorage.getItem("access_token") ||
        localStorage.getItem("token");

      if (!token) {
        throw new Error("Aucun token d'authentification trouvé");
      }

      // URL spécifique pour l'API
      const response = await fetch(`${getReleaseNotesApiUrl()}advance/${id}/accept/`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({}), // Corps vide car data est un objet
      });

      if (!response.ok) {
        throw new Error(`Erreur ${response.status}: ${response.statusText}`);
      }

      const updatedNote = await response.json();

      // Mettre à jour la liste
      setReleaseNotes(prev =>
        prev.map(note => note.id === id ? updatedNote : note)
      );

      setSuccess("Release note acceptée avec succès !");
    } catch (err) {
      console.error("💥 Erreur lors de l'acceptation:", err);
      setError("Erreur lors de l'acceptation: " + (err as Error).message);
    }
  };

  // Refuser une release note
  const refuseReleaseNote = async (id: number, reason: string) => {
    try {
      const token = localStorage.getItem("bearerToken") ||
        localStorage.getItem("access_token") ||
        localStorage.getItem("token");

      if (!token) {
        throw new Error("Aucun token d'authentification trouvé");
      }

      const response = await fetch(`${getReleaseNotesApiUrl()}advance/${id}/refuse/`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ reason: reason }), // Ajouter la raison
      });

      if (!response.ok) {
        throw new Error(`Erreur ${response.status}: ${response.statusText}`);
      }

      const updatedNote = await response.json();

      // Mettre à jour la liste
      setReleaseNotes(prev =>
        prev.map(note => note.id === id ? updatedNote : note)
      );

      setSuccess("Release note refusée avec succès !");
      setRefuseDialogOpen(false);
      setRefuseReason("");
      setNoteToRefuse(null);
    } catch (err) {
      console.error("💥 Erreur lors du refus:", err);
      setError("Erreur lors du refus: " + (err as Error).message);
    }
  };

  // Fonction pour gérer le changement de catégorie
  const handleCategoryChange = (value: string) => {
    setCategory(value);
    setEmergency(value === "ECAB");
  };

  // Fonction pour gérer l'ajout de fichiers
  const handleFileAdd = (event: React.ChangeEvent<HTMLInputElement>, type: FileUpload['type']) => {
    const selectedFiles = event.target.files;
    if (!selectedFiles) return;

    // Pour les types simples (fonctionnel, technique, security), on remplace le précédent
    if (type !== 'additionnel') {
      setFiles(prev => prev.filter(f => f.type !== type));
    }

    // Ajout des nouveaux fichiers
    Array.from(selectedFiles).forEach(file => {
      const newFile: FileUpload = {
        file,
        type,
        id: `${type}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      };
      setFiles(prev => [...prev, newFile]);
    });

    // Réinitialiser l'input pour permettre l'ajout du même fichier
    event.target.value = '';
  };

  // Fonction pour supprimer un fichier
  const handleFileRemove = (id: string) => {
    setFiles(prev => prev.filter(file => file.id !== id));
  };

  // Fonction pour créer une release note
  const createReleaseNote = async () => {
    setIsSubmitting(true);
    setError(null);
    setSuccess(null);

    try {
      const token = localStorage.getItem("bearerToken") ||
        localStorage.getItem("access_token") ||
        localStorage.getItem("token");

      if (!token) {
        throw new Error("Aucun token d'authentification trouvé");
      }

      // Validation
      if (!title.trim()) {
        throw new Error("Le titre est obligatoire");
      }

      if (!content.trim()) {
        throw new Error("Le contenu est obligatoire");
      }

      if (!selectedSolution) {
        throw new Error("La solution est obligatoire");
      }

      if (!type) {
        throw new Error("Le type est obligatoire");
      }

      // Vérifier que le document fonctionnel est présent
      const hasFonctionnelDoc = files.some(f => f.type === 'fonctionnel');
      if (!hasFonctionnelDoc) {
        throw new Error("Le document fonctionnel est obligatoire");
      }

      // Préparation du FormData
      const formData = new FormData();
      formData.append('title', title);
      formData.append('content', content);
      formData.append('type', type);
      formData.append('category', category);
      formData.append('emergency', emergency.toString());
      formData.append('solution', selectedSolution);

      // Ajout des fichiers selon leur type
      files.forEach(fileUpload => {
        const fieldName = `document_${fileUpload.type}`;
        formData.append(fieldName, fileUpload.file);
      });

      console.log("📤 Envoi des données:", {
        title,
        type,
        content,
        category,
        emergency,
        solution: selectedSolution,
        files: files.map(f => ({ type: f.type, name: f.file.name, size: f.file.size }))
      });

      // Envoi de la requête
      const response = await fetch(getReleaseNotesApiUrl(), {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });

      console.log("📡 Réponse du serveur:", response.status, response.statusText);

      if (!response.ok) {
        let errorMessage = `Erreur ${response.status}: ${response.statusText}`;
        try {
          const errorData = await response.json();
          errorMessage = errorData.detail || errorData.message || JSON.stringify(errorData);
        } catch (e) {
          console.error("Erreur de parsing JSON:", e);
        }
        throw new Error(errorMessage);
      }

      const newReleaseNote = await response.json();
      console.log("✅ Release note créée:", newReleaseNote);

      // Mise à jour de la liste
      setReleaseNotes(prev => [...prev, newReleaseNote]);

      // Réinitialisation du formulaire
      resetForm();
      setSuccess("Release note créée avec succès !");

      // Fermer le dialog après un délai
      setTimeout(() => {
        setDialogOpen(false);
        setSuccess(null);
        fetchReleaseNotes();
      }, 2000);

    } catch (err) {
      console.error("💥 Erreur lors de la création de la release note:", err);
      setError("Erreur lors de la création: " + (err as Error).message);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Fonction pour réinitialiser le formulaire ou le remplir avec une note existante
  const resetForm = (note?: ReleaseNote) => {
    if (note) {
      // Mode édition
      setTitle(note.title);
      setContent(note.content);
      setType(note.type);
      setCategory(note.category);
      setSelectedSolution(note.solution);
      setEmergency(note.emergency);
      setEditingNoteId(note.id);
      setEditMode(true);
      setSelectedNote(note);
    } else {
      // Mode création
      setTitle("");
      setContent(DEFAULT_CONTENT);
      setType("Evolution");
      setCategory("ECAB");
      setSelectedSolution("");
      setEmergency(true);
      setEditingNoteId(null);
      setEditMode(false);
      setSelectedNote(null);
    }
    setFiles([]);
  };

  // Fonction pour ouvrir le dialog de création
  const handleCreateClick = () => {
    resetForm();
    setDialogOpen(true);
  };

  // Fonction pour visualiser une release note
  const handleViewNote = (note: ReleaseNote) => {
    setSelectedNote(note);
    setViewDialogOpen(true);
  };

  // Fonction pour ouvrir le dialog de création/modification
  const handleCreateOrEditClick = (note?: ReleaseNote) => {
    if (note) {
      resetForm(note);
    } else {
      resetForm();
    }
    setDialogOpen(true);
  };

  // Fonction pour modifier une release note (sans fichiers)
  const updateReleaseNote = async (id: number) => {
    setIsSubmitting(true);
    setError(null);
    setSuccess(null);

    try {
      const token = localStorage.getItem("bearerToken") ||
        localStorage.getItem("access_token") ||
        localStorage.getItem("token");

      if (!token) {
        throw new Error("Aucun token d'authentification trouvé");
      }

      // Validation
      if (!title.trim()) {
        throw new Error("Le titre est obligatoire");
      }

      if (!content.trim()) {
        throw new Error("Le contenu est obligatoire");
      }

      if (!selectedSolution) {
        throw new Error("La solution est obligatoire");
      }

      if (!type) {
        throw new Error("Le type est obligatoire");
      }

      // Préparation du FormData même sans fichiers
      const formData = new FormData();
      formData.append('title', title);
      formData.append('content', content);
      formData.append('type', type);
      formData.append('category', category);
      formData.append('emergency', emergency.toString());
      formData.append('solution', selectedSolution);

      console.log("📤 Envoi des données de modification (PATCH):", {
        title,
        content,
        type,
        category,
        emergency,
        solution: selectedSolution,
        method: "PATCH"
      });

      // Envoi de la requête PATCH avec FormData
      const response = await fetch(`${getReleaseNotesApiUrl()}${id}/`, {
        method: "PATCH",
        headers: {
          Authorization: `Bearer ${token}`,
          // Ne pas définir Content-Type, il sera automatiquement défini avec la boundary
        },
        body: formData,
      });

      console.log("📡 Réponse du serveur (PATCH):", response.status, response.statusText);

      if (!response.ok) {
        let errorMessage = `Erreur ${response.status}: ${response.statusText}`;
        try {
          const errorData = await response.json();
          errorMessage = errorData.detail || errorData.message || JSON.stringify(errorData);
        } catch (e) {
          console.error("Erreur de parsing JSON:", e);
        }
        throw new Error(errorMessage);
      }

      const updatedNote = await response.json();
      console.log("✅ Release note modifiée:", updatedNote);

      // Mise à jour de la liste
      setReleaseNotes(prev => prev.map(note =>
        note.id === id ? updatedNote : note
      ));

      // Réinitialisation du formulaire
      resetForm();
      setSuccess("Release note modifiée avec succès !");

      // Fermer le dialog après un délai
      setTimeout(() => {
        setDialogOpen(false);
        setSuccess(null);
        fetchReleaseNotes();
      }, 2000);

    } catch (err) {
      console.error("💥 Erreur lors de la modification de la release note:", err);
      setError("Erreur lors de la modification: " + (err as Error).message);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Fonction pour créer ou modifier une release note
  const handleSubmit = async () => {
    setIsSubmitting(true);
    setError(null);
    setSuccess(null);

    try {
      // Validation commune
      if (!title.trim()) throw new Error("Le titre est obligatoire");
      if (!content.trim()) throw new Error("Le contenu est obligatoire");
      if (!selectedSolution) throw new Error("La solution est obligatoire");
      if (!type) throw new Error("Le type est obligatoire");

      if (editMode && editingNoteId) {
        // Mode édition - pas de validation de fichiers
        await updateReleaseNote(editingNoteId);
      } else {
        // Mode création - validation des fichiers
        const hasFonctionnelDoc = files.some(f => f.type === 'fonctionnel');
        if (!hasFonctionnelDoc) {
          throw new Error("Le document fonctionnel est obligatoire");
        }
        await createReleaseNote();
      }
    } catch (err) {
      console.error("💥 Erreur:", err);
      setError((err as Error).message);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Composant pour afficher les fichiers
  const FileChip = ({ fileUpload, onRemove }: { fileUpload: FileUpload, onRemove: (id: string) => void }) => {
    const getColor = (type: FileUpload['type']) => {
      switch (type) {
        case 'fonctionnel': return colors.primary;
        case 'technique': return colors.success;
        case 'security': return colors.warning;
        case 'additionnel': return colors.textSecondary;
        default: return colors.textSecondary;
      }
    };

    const getLabel = (type: FileUpload['type']) => {
      switch (type) {
        case 'fonctionnel': return 'Fonctionnel';
        case 'technique': return 'Technique';
        case 'security': return 'Sécurité';
        case 'additionnel': return 'Additionnel';
        default: return type;
      }
    };

    return (
      <Chip
        label={`${getLabel(fileUpload.type)}: ${fileUpload.file.name}`}
        onDelete={() => onRemove(fileUpload.id)}
        deleteIcon={<Close />}
        sx={{
          backgroundColor: alpha(getColor(fileUpload.type), 0.1),
          color: getColor(fileUpload.type),
          border: `1px solid ${alpha(getColor(fileUpload.type), 0.3)}`,
          fontWeight: fileUpload.type === 'fonctionnel' ? 600 : 400,
          m: 0.5,
        }}
        size="small"
      />
    );
  };

  // Filtrage des release notes
  const filteredReleaseNotes = Array.isArray(releaseNotes)
    ? releaseNotes.filter(note =>
      note?.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      note?.content?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      note?.solution?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      note?.type?.toLowerCase().includes(searchTerm.toLowerCase())
    )
    : [];

  // Fonction pour formater la date
  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleDateString('fr-FR', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return dateString;
    }
  };

  // Chargement initial
  useEffect(() => {
    // Récupérer l'email de l'utilisateur
    const email = getUserEmailFromToken();
    setUserEmail(email);
    console.log("👤 Utilisateur connecté:", email);

    fetchSolutions();
    fetchReleaseNotes();
  }, [fetchSolutions, fetchReleaseNotes]);

  return (
    <Box sx={{ minHeight: "100vh", backgroundColor: colors.background, py: 4 }}>
      <Container maxWidth="xl">
        {/* En-tête */}
        <Box sx={{ mb: 4 }}>
          <Typography variant="h3" sx={{ fontWeight: 800, color: colors.primary, mb: 2 }}>
            📋 Administration des Release Notes
          </Typography>
          <Typography variant="h6" sx={{ color: colors.textSecondary }}>
            Gestion des notes de version avec documents - Environnement Production
          </Typography>
        </Box>

        {/* Cartes de statistiques */}
        <Stack direction={{ xs: "column", sm: "row" }} spacing={2} sx={{ mb: 4 }}>
          <Card sx={{ flex: 1, backgroundColor: alpha(colors.primary, 0.1) }}>
            <CardContent>
              <Typography variant="h4" sx={{ fontWeight: 800, color: colors.primary }}>
                {Array.isArray(releaseNotes) ? releaseNotes.length : 0}
              </Typography>
              <Typography variant="body2" sx={{ color: colors.textSecondary, fontWeight: 600 }}>
                Release Notes Total
              </Typography>
            </CardContent>
          </Card>
          <Card sx={{ flex: 1, backgroundColor: alpha(colors.error, 0.1) }}>
            <CardContent>
              <Typography variant="h4" sx={{ fontWeight: 800, color: colors.error }}>
                {Array.isArray(releaseNotes)
                  ? releaseNotes.filter(r => r?.category === 'ECAB').length
                  : 0}
              </Typography>
              <Typography variant="body2" sx={{ color: colors.textSecondary, fontWeight: 600 }}>
                ECAB (Emergency = True)
              </Typography>
            </CardContent>
          </Card>
          <Card sx={{ flex: 1, backgroundColor: alpha(colors.success, 0.1) }}>
            <CardContent>
              <Typography variant="h4" sx={{ fontWeight: 800, color: colors.success }}>
                {Array.isArray(releaseNotes)
                  ? releaseNotes.filter(r => r?.category === 'CAB').length
                  : 0}
              </Typography>
              <Typography variant="body2" sx={{ color: colors.textSecondary, fontWeight: 600 }}>
                CAB (Emergency = False)
              </Typography>
            </CardContent>
          </Card>
        </Stack>

        {/* Messages d'état */}
        {error && (
          <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError(null)}>
            {error}
          </Alert>
        )}

        {success && (
          <Alert severity="success" sx={{ mb: 3 }} onClose={() => setSuccess(null)}>
            {success}
          </Alert>
        )}

        {/* Barre de recherche et bouton de création */}
        <Paper sx={{ p: 3, mb: 3 }}>
          <Box sx={{ display: 'flex', gap: 2, alignItems: 'center', flexWrap: 'wrap' }}>
            <TextField
              placeholder="Rechercher par titre, contenu, solution ou type..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              sx={{ flex: 1, minWidth: 300 }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <Search />
                  </InputAdornment>
                ),
              }}
            />
            <Button
              variant="contained"
              startIcon={<Add />}
              onClick={handleCreateClick}
              sx={{
                backgroundColor: colors.primary,
                '&:hover': {
                  backgroundColor: alpha(colors.primary, 0.8),
                },
              }}
            >
              Nouvelle Release Note
            </Button>
          </Box>
        </Paper>

        {/* Liste des release notes */}
        <Paper sx={{ overflow: 'hidden' }}>
          {loading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
              <CircularProgress />
            </Box>
          ) : !Array.isArray(releaseNotes) || filteredReleaseNotes.length === 0 ? (
            <Box sx={{ textAlign: 'center', p: 4 }}>
              <Description sx={{ fontSize: 64, color: colors.textSecondary, mb: 2, opacity: 0.5 }} />
              <Typography variant="h6" sx={{ mb: 1, color: colors.textSecondary }}>
                {!Array.isArray(releaseNotes) || releaseNotes.length === 0
                  ? 'Aucune release note'
                  : 'Aucun résultat'}
              </Typography>
              <Typography variant="body2" sx={{ mb: 2, color: colors.textSecondary }}>
                {!Array.isArray(releaseNotes) || releaseNotes.length === 0
                  ? 'Commencez par créer votre première release note.'
                  : 'Aucune release note ne correspond à votre recherche.'
                }
              </Typography>
              {(!Array.isArray(releaseNotes) || releaseNotes.length === 0) && (
                <Button
                  variant="contained"
                  startIcon={<Add />}
                  onClick={handleCreateClick}
                >
                  Créer une release note
                </Button>
              )}
            </Box>
          ) : (
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow sx={{ backgroundColor: alpha(colors.primary, 0.1) }}>
                    <SortableHeaderCell
                      field="title"
                      label="Titre"
                      currentSort={sortConfig}
                    />
                    <SortableHeaderCell
                      field="type"
                      label="Type"
                      currentSort={sortConfig}
                    />
                    <SortableHeaderCell
                      field="solution"
                      label="Solution"
                      currentSort={sortConfig}
                    />
                    <SortableHeaderCell
                      field="category"
                      label="Catégorie"
                      currentSort={sortConfig}
                    />
                    <SortableHeaderCell
                      field="emergency"
                      label="Emergency"
                      currentSort={sortConfig}
                    />
                    <SortableHeaderCell
                      field="reference_externe"
                      label="Référence Itop"
                      currentSort={sortConfig}
                    />
                    <SortableHeaderCell
                      field="author"
                      label="Auteur"
                      currentSort={sortConfig}
                    />
                    <SortableHeaderCell
                      field="created_at"
                      label="Créé le"
                      currentSort={sortConfig}
                    />
                    <TableCell sx={{ fontWeight: 700, whiteSpace: 'nowrap' }}>
                      Statut
                    </TableCell>
                    <TableCell sx={{ fontWeight: 700, whiteSpace: 'nowrap' }}>
                      Motif de refus
                    </TableCell>
                    <TableCell sx={{ fontWeight: 700, width: 100 }}>
                      Actions
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {getSortedNotes().map((note) => (
                    <TableRow
                      key={note.id}
                      sx={{
                        '&:hover': {
                          backgroundColor: alpha(colors.primary, 0.05),
                        }
                      }}
                    >
                      <TableCell>
                        <Typography variant="body1" sx={{ fontWeight: 500 }}>
                          {note.title}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={note.type}
                          size="small"
                          sx={{
                            backgroundColor: alpha(colors.warning, 0.1),
                            color: colors.warning,
                            fontWeight: 600,
                          }}
                        />
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={note.solution}
                          size="small"
                          sx={{
                            backgroundColor: alpha(colors.primary, 0.2),
                            color: colors.primary,
                            fontWeight: 600,
                          }}
                        />
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={note.category}
                          size="small"
                          sx={{
                            backgroundColor: note.category === 'ECAB'
                              ? alpha(colors.error, 0.1)
                              : alpha(colors.success, 0.1),
                            color: note.category === 'ECAB'
                              ? colors.error
                              : colors.success,
                            fontWeight: 600,
                          }}
                        />
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={note.emergency ? "Oui" : "Non"}
                          size="small"
                          sx={{
                            backgroundColor: note.emergency
                              ? alpha(colors.warning, 0.1)
                              : alpha(colors.success, 0.1),
                            color: note.emergency
                              ? colors.warning
                              : colors.success,
                          }}
                        />
                      </TableCell>
                      <TableCell>
                        {note.reference_externe ? (
                          <Tooltip title="Ouvrir le ticket iTop">
                            <Link
                              href={
                                note.category === 'ECAB'
                                  ? `https://itop.attijariwafa.net/pages/UI.php?operation=details&class=RoutineChange&id=${note.reference_externe}`
                                  : `https://itop.attijariwafa.net/pages/UI.php?operation=details&class=NormalChange&id=${note.reference_externe}`
                              }
                              target="_blank"
                              rel="noopener noreferrer"
                              sx={{
                                color: note.category === 'ECAB' ? colors.error : colors.warning,
                                fontWeight: 600,
                                textDecoration: 'none',
                                fontFamily: 'monospace',
                                fontSize: '0.875rem',
                                '&:hover': {
                                  textDecoration: 'underline',
                                  color: note.category === 'ECAB' ? colors.error : colors.warning,
                                }
                              }}
                            >
                              {note.reference_externe}
                            </Link>
                          </Tooltip>
                        ) : (
                          <Typography variant="body2" color="text.secondary">
                            -
                          </Typography>
                        )}
                      </TableCell>
                      <TableCell>
                        {note.author ? (
                          <Tooltip title={note.author}>
                            <Chip
                              label={note.author.split('@')[0]}
                              size="small"
                              sx={{
                                backgroundColor: alpha(colors.textSecondary || colors.primary, 0.1),
                                color: colors.textPrimary,
                                fontWeight: 500,
                                maxWidth: 120,
                                textOverflow: 'ellipsis',
                                overflow: 'hidden',
                              }}
                            />
                          </Tooltip>
                        ) : (
                          <Typography variant="body2" color="text.secondary">
                            -
                          </Typography>
                        )}
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2">
                          {formatDate(note.created_at)}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        {note.accepted_at ? (
                          <Chip
                            label={`Accepté ${formatDate(note.accepted_at)}`}
                            size="small"
                            sx={{
                              backgroundColor: alpha(colors.success, 0.2),
                              color: colors.success,
                              fontWeight: 600,
                            }}
                          />
                        ) : note.refused_at ? (
                          <Chip
                            label={`Refusé ${formatDate(note.refused_at)}`}
                            size="small"
                            sx={{
                              backgroundColor: alpha(colors.error, 0.2),
                              color: colors.error,
                              fontWeight: 600,
                            }}
                          />
                        ) : (
                          <Chip
                            label="En attente"
                            size="small"
                            sx={{
                              backgroundColor: alpha(colors.warning, 0.2),
                              color: colors.warning,
                              fontWeight: 600,
                            }}
                          />
                        )}
                      </TableCell>

                      {/* cellule pour le motif de refus */}
                      <TableCell>
                        {note.refused_at && note.rejection_reason ? (
                          <Tooltip title={note.rejection_reason}>
                            <Typography
                              variant="body2"
                              sx={{
                                color: colors.error,
                                fontWeight: 500,
                                maxWidth: '50px',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                whiteSpace: 'nowrap',
                                cursor: 'pointer',
                                '&:hover': {
                                  textDecoration: 'underline',
                                }
                              }}
                              onClick={() => {
                                setSelectedNote(note);
                                setViewDialogOpen(true);
                              }}
                            >
                              {note.rejection_reason.length > 30
                                ? `${note.rejection_reason.substring(0, 30)}...`
                                : note.rejection_reason}
                            </Typography>
                          </Tooltip>
                        ) : note.refused_at ? (
                          <Typography
                            variant="body2"
                            sx={{
                              color: colors.textSecondary,
                              fontStyle: 'italic'
                            }}
                          >
                            Aucun motif
                          </Typography>
                        ) : (
                          <Typography
                            variant="body2"
                            sx={{
                              color: colors.textSecondary,
                            }}
                          >
                            -
                          </Typography>
                        )}
                      </TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', gap: 0.5, alignItems: 'center' }}>
                          <Tooltip title="Voir les détails">
                            <IconButton
                              size="small"
                              onClick={() => handleViewNote(note)}
                              sx={{ color: colors.primary }}
                            >
                              <Visibility />
                            </IconButton>
                          </Tooltip>

                          {/* Bouton d'édition - pour l'auteur ET les admins techniques */}
                          {!note.accepted_at && !note.refused_at && canUserEditNote(note) && (
                            <Tooltip title="Modifier">
                              <IconButton
                                size="small"
                                onClick={() => handleCreateOrEditClick(note)}
                                sx={{
                                  color: colors.primary,
                                  backgroundColor: alpha(colors.primary, 0.1),
                                  '&:hover': {
                                    backgroundColor: alpha(colors.primary, 0.2),
                                  }
                                }}
                              >
                                <Edit fontSize="small" />
                              </IconButton>
                            </Tooltip>
                          )}

                          {/* Boutons d'acceptation/refus */}
                          {!note.accepted_at && !note.refused_at && canUserApproveNote(note) && (
                            <>
                              <Tooltip title="Accepter">
                                <IconButton
                                  size="small"
                                  onClick={() => acceptReleaseNote(note.id)}
                                  sx={{
                                    color: colors.success,
                                    backgroundColor: alpha(colors.success, 0.1),
                                    '&:hover': {
                                      backgroundColor: alpha(colors.success, 0.2),
                                    }
                                  }}
                                >
                                  <CheckCircle fontSize="small" />
                                </IconButton>
                              </Tooltip>
                              <Tooltip title="Refuser">
                                <IconButton
                                  size="small"
                                  onClick={() => {
                                    setNoteToRefuse(note.id);
                                    setRefuseDialogOpen(true);
                                  }}
                                  sx={{
                                    color: colors.error,
                                    backgroundColor: alpha(colors.error, 0.1),
                                    '&:hover': {
                                      backgroundColor: alpha(colors.error, 0.2),
                                    }
                                  }}
                                >
                                  <Cancel fontSize="small" />
                                </IconButton>
                              </Tooltip>
                            </>
                          )}

                          {/* Boutons grisés si l'utilisateur n'a pas les droits */}
                          {!note.accepted_at && !note.refused_at && !canUserApproveNote(note) && (
                            <Tooltip title="Non autorisé - Vous devez être admin technique ou TAM de cette solution">
                              <Box sx={{
                                display: 'flex',
                                gap: 0.5,
                                opacity: 0.5,
                                filter: 'grayscale(100%)'
                              }}>
                                <IconButton
                                  size="small"
                                  disabled
                                  sx={{
                                    color: colors.textSecondary,
                                    backgroundColor: alpha(colors.textSecondary, 0.1),
                                  }}
                                >
                                  <CheckCircle fontSize="small" />
                                </IconButton>
                                <IconButton
                                  size="small"
                                  disabled
                                  sx={{
                                    color: colors.textSecondary,
                                    backgroundColor: alpha(colors.textSecondary, 0.1),
                                  }}
                                >
                                  <Cancel fontSize="small" />
                                </IconButton>
                              </Box>
                            </Tooltip>
                          )}
                        </Box>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </Paper>

        {/* Dialog de création */}
        <Dialog
          open={dialogOpen}
          onClose={() => !isSubmitting && setDialogOpen(false)}
          maxWidth="md"
          fullWidth
        >
          <DialogTitle>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Description sx={{ color: colors.primary }} />
              <Typography variant="h6">
                Nouvelle Release Note
              </Typography>
            </Box>
          </DialogTitle>
          <DialogContent dividers>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: 1 }}>
              {/* Titre */}
              <TextField
                label="Titre *"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                fullWidth
                required
                disabled={isSubmitting || editMode}
                helperText="Titre de la release note"
                InputProps={{
                  readOnly: editMode,
                }}
              />

              {/* Type - Lecture seule en mode édition */}
              <FormControl fullWidth disabled={isSubmitting || editMode}>
                <InputLabel>Type *</InputLabel>
                <Select
                  value={type}
                  label="Type *"
                  onChange={(e) => setType(e.target.value)}
                  readOnly={editMode} // ← Lecture seule en mode édition
                >
                  {noteTypes.map((noteType) => (
                    <MenuItem key={noteType} value={noteType}>
                      {noteType}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>

              {/* Catégorie - Lecture seule en mode édition */}
              <FormControl fullWidth disabled={isSubmitting || editMode}>
                <InputLabel>Catégorie *</InputLabel>
                <Select
                  value={category}
                  label="Catégorie *"
                  onChange={(e) => handleCategoryChange(e.target.value)}
                  readOnly={editMode} // ← Lecture seule en mode édition
                >
                  <MenuItem value="ECAB">ECAB (Emergency = True)</MenuItem>
                  <MenuItem value="CAB">CAB (Emergency = False)</MenuItem>
                </Select>
                <Typography variant="caption" color="text.secondary" sx={{ mt: 0.5 }}>
                  {category === 'ECAB'
                    ? "ECAB = Emergency = True (Urgent)"
                    : "CAB = Emergency = False (Standard)"}
                </Typography>
              </FormControl>

              {/* Solution - Lecture seule en mode édition */}
              <FormControl fullWidth disabled={solutionsLoading || isSubmitting || editMode}>
                <InputLabel>Solution *</InputLabel>
                <Select
                  value={selectedSolution}
                  label="Solution *"
                  onChange={(e) => setSelectedSolution(e.target.value)}
                  readOnly={editMode} // ← Lecture seule en mode édition
                >
                  {solutionsLoading ? (
                    <MenuItem disabled>
                      <CircularProgress size={20} sx={{ mr: 1 }} />
                      Chargement des solutions...
                    </MenuItem>
                  ) : !Array.isArray(solutions) || solutions.length === 0 ? (
                    <MenuItem disabled>
                      Aucune solution disponible
                    </MenuItem>
                  ) : (
                    solutions.map((solution) => (
                      <MenuItem key={solution.id} value={solution.solution_name}>
                        {solution.solution_name}
                      </MenuItem>
                    ))
                  )}
                </Select>
              </FormControl>


              {/* Éditeur de contenu */}
              <Box>
                <Typography variant="subtitle2" sx={{ mb: 1, color: colors.textSecondary }}>
                  Contenu (Markdown) *
                </Typography>
                <Box sx={{ border: `1px solid ${colors.border}`, borderRadius: 1 }}>
                  <MDEditor
                    value={content}
                    onChange={(value) => setContent(value || '')}
                    height={300}
                    preview="live"
                    visibleDragbar={true}
                    textareaProps={{
                      placeholder: 'Le modèle par défaut est pré-rempli. Modifiez-le selon vos besoins...',
                    }}
                  />
                </Box>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 1 }}>
                  <Typography variant="caption" color="text.secondary">
                    Modèle Markdown pré-rempli
                  </Typography>
                  <Button
                    size="small"
                    onClick={() => setContent(DEFAULT_CONTENT)}
                    disabled={isSubmitting}
                  >
                    Réinitialiser au modèle
                  </Button>
                </Box>
              </Box>

              {/* Section des documents - Cachée en mode édition */}
              {!editMode && (
                <Box>
                  <Typography variant="subtitle2" sx={{ mb: 1, color: colors.textSecondary }}>
                    Documents
                  </Typography>

                  {/* Document fonctionnel (obligatoire) */}
                  <Box sx={{ mb: 2 }}>
                    <Typography variant="body2" sx={{ mb: 1, fontWeight: 600, color: colors.primary }}>
                      Document Fonctionnel *
                    </Typography>
                    <Button
                      component="label"
                      variant="outlined"
                      startIcon={<AttachFile />}
                      sx={{
                        mr: 2,
                        borderColor: colors.primary,
                        color: colors.primary,
                        '&:hover': {
                          borderColor: alpha(colors.primary, 0.8),
                          backgroundColor: alpha(colors.primary, 0.1)
                        }
                      }}
                      disabled={isSubmitting}
                    >
                      {files.filter(f => f.type === 'fonctionnel').length > 0
                        ? `Document Fonctionnel (${files.filter(f => f.type === 'fonctionnel')[0]?.file.name})`
                        : 'Ajouter Document Fonctionnel'}
                      <input
                        type="file"
                        style={{ display: 'none' }}
                        onChange={(e) => {
                          handleFileAdd(e, 'fonctionnel');
                          e.target.value = ''; // Réinitialise le champ
                        }}
                        accept=".pdf,.doc,.docx,.xls,.xlsx,.txt"
                      />
                    </Button>
                    {files.filter(f => f.type === 'fonctionnel').length === 0 && (
                      <Typography variant="caption" color="error">
                        Ce document est obligatoire
                      </Typography>
                    )}
                    <Typography variant="caption" display="block" sx={{ mt: 0.5, color: colors.textSecondary }}>
                      Un seul fichier autorisé
                    </Typography>
                  </Box>

                  {/* Document technique (optionnel) */}
                  <Box sx={{ mb: 2 }}>
                    <Typography variant="body2" sx={{ mb: 1, color: colors.success }}>
                      Document Technique
                    </Typography>
                    <Button
                      component="label"
                      variant="outlined"
                      startIcon={<AttachFile />}
                      sx={{
                        mr: 2,
                        borderColor: colors.success,
                        color: colors.success,
                        '&:hover': {
                          borderColor: alpha(colors.success, 0.8),
                          backgroundColor: alpha(colors.success, 0.1)
                        }
                      }}
                      disabled={isSubmitting}
                    >
                      {files.filter(f => f.type === 'technique').length > 0
                        ? `Document Technique (${files.filter(f => f.type === 'technique')[0]?.file.name})`
                        : 'Ajouter Document Technique'}
                      <input
                        type="file"
                        style={{ display: 'none' }}
                        onChange={(e) => {
                          handleFileAdd(e, 'technique');
                          e.target.value = '';
                        }}
                        accept=".pdf,.doc,.docx,.xls,.xlsx,.txt"
                      />
                    </Button>
                    <Typography variant="caption" display="block" sx={{ mt: 0.5, color: colors.textSecondary }}>
                      Un seul fichier autorisé
                    </Typography>
                  </Box>

                  {/* Document sécurité (optionnel) */}
                  <Box sx={{ mb: 2 }}>
                    <Typography variant="body2" sx={{ mb: 1, fontWeight: 600, color: colors.warning }}>
                      Document Sécurité
                    </Typography>
                    <Button
                      component="label"
                      variant="outlined"
                      startIcon={<AttachFile />}
                      sx={{
                        mr: 2,
                        borderColor: colors.warning,
                        color: colors.warning,
                        '&:hover': {
                          borderColor: alpha(colors.warning, 0.8),
                          backgroundColor: alpha(colors.warning, 0.1)
                        }
                      }}
                      disabled={isSubmitting}
                    >
                      {files.filter(f => f.type === 'security').length > 0
                        ? `Document Sécurité (${files.filter(f => f.type === 'security')[0]?.file.name})`
                        : 'Ajouter Document Sécurité'}
                      <input
                        type="file"
                        style={{ display: 'none' }}
                        onChange={(e) => {
                          handleFileAdd(e, 'security');
                          e.target.value = '';
                        }}
                        accept=".pdf,.doc,.docx,.xls,.xlsx,.txt,.json"
                      />
                    </Button>
                    <Typography variant="caption" display="block" sx={{ mt: 0.5, color: colors.textSecondary }}>
                      Un seul fichier autorisé
                    </Typography>
                  </Box>

                  {/* Documents additionnels (optionnels, multiple) */}
                  <Box sx={{ mb: 2 }}>
                    <Typography variant="body2" sx={{ mb: 1, fontWeight: 600, color: colors.textSecondary }}>
                      Documents Additionnels (optionnels, multiple)
                    </Typography>
                    <Button
                      component="label"
                      variant="outlined"
                      startIcon={<AttachFile />}
                      sx={{
                        mr: 2,
                        borderColor: colors.textSecondary,
                        color: colors.textSecondary,
                        '&:hover': {
                          borderColor: alpha(colors.textSecondary, 0.8),
                          backgroundColor: alpha(colors.textSecondary, 0.1)
                        }
                      }}
                      disabled={isSubmitting}
                    >
                      {files.filter(f => f.type === 'additionnel').length > 0
                        ? `Documents Additionnels (${files.filter(f => f.type === 'additionnel').length})`
                        : 'Ajouter Documents Additionnels'}
                      <input
                        type="file"
                        style={{ display: 'none' }}
                        multiple
                        onChange={(e) => {
                          handleFileAdd(e, 'additionnel');
                          e.target.value = '';
                        }}
                        accept="*/*"
                      />
                    </Button>
                    <Typography variant="caption" display="block" sx={{ mt: 0.5, color: colors.textSecondary }}>
                      Plusieurs fichiers autorisés
                    </Typography>
                  </Box>

                  {/* Liste des fichiers ajoutés */}
                  {files.length > 0 && (
                    <Paper variant="outlined" sx={{ p: 2, mt: 2 }}>
                      <Typography variant="subtitle2" sx={{ mb: 1 }}>
                        Fichiers sélectionnés ({files.length})
                      </Typography>
                      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                        {files.map((fileUpload) => (
                          <FileChip
                            key={fileUpload.id}
                            fileUpload={fileUpload}
                            onRemove={handleFileRemove}
                          />
                        ))}
                      </Box>
                    </Paper>
                  )}
                </Box>
              )}

              {/* Afficher un message en mode édition */}
              {editMode && (
                <Alert severity="info" sx={{ mt: 2 }}>
                  {userEmail === selectedNote?.author ? (
                    "⚠️ Mode édition : Seul le contenu Markdown peut être modifié. Les autres champs sont verrouillés."
                  ) : (
                    "⚠️ Mode édition (Admin Technique) : Seul le contenu Markdown peut être modifié. Les autres champs sont verrouillés."
                  )}
                </Alert>
              )}
            </Box>

            {isSubmitting && (
              <LinearProgress sx={{ mt: 2 }} />
            )}
          </DialogContent>
          <DialogActions>
            <Button
              onClick={() => setDialogOpen(false)}
              disabled={isSubmitting}
            >
              Annuler
            </Button>
            <Button
              onClick={handleSubmit}
              variant="contained"
              disabled={
                isSubmitting ||
                !title ||
                !content ||
                !selectedSolution ||
                !type ||
                (!editMode && !files.some(f => f.type === 'fonctionnel')) // Seulement valider les fichiers en mode création
              }
              startIcon={isSubmitting ? <CircularProgress size={16} /> : <CloudUpload />}
              sx={{
                backgroundColor: editMode ? colors.warning : colors.primary,
                '&:hover': {
                  backgroundColor: editMode
                    ? alpha(colors.warning, 0.8)
                    : alpha(colors.primary, 0.8),
                },
              }}
            >
              {isSubmitting
                ? 'Envoi en cours...'
                : editMode
                  ? 'Modifier Release Note'
                  : 'Créer Release Note'}
            </Button>
          </DialogActions>
        </Dialog>

        {/* Dialog de visualisation */}
        <Dialog
          open={viewDialogOpen}
          onClose={() => setViewDialogOpen(false)}
          maxWidth="md"
          fullWidth
          scroll="paper"
        >
          <DialogTitle>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Description sx={{ color: colors.primary }} />
              <Typography variant="h6">
                {selectedNote?.title}
              </Typography>
            </Box>
            <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
              <Chip
                label={selectedNote?.type}
                size="small"
                sx={{
                  backgroundColor: alpha(colors.warning, 0.2),
                  color: colors.warning,
                  fontWeight: 600,
                }}
              />
              <Chip
                label={selectedNote?.solution}
                size="small"
                sx={{
                  backgroundColor: alpha(colors.primary, 0.2),
                  color: colors.primary,
                  fontWeight: 600,
                }}
              />
              <Chip
                label={selectedNote?.category}
                size="small"
                sx={{
                  backgroundColor: selectedNote?.category === 'ECAB'
                    ? alpha(colors.error, 0.1)
                    : alpha(colors.success, 0.1),
                  color: selectedNote?.category === 'ECAB'
                    ? colors.error
                    : colors.success,
                  fontWeight: 600,
                }}
              />
              <Chip
                label={selectedNote?.emergency ? "Emergency: Oui" : "Emergency: Non"}
                size="small"
                sx={{
                  backgroundColor: selectedNote?.emergency
                    ? alpha(colors.warning, 0.1)
                    : alpha(colors.success, 0.1),
                  color: selectedNote?.emergency
                    ? colors.warning
                    : colors.success,
                }}
              />
              <Box sx={{ mt: 1 }}>
                {selectedNote?.accepted_at && (
                  <Alert severity="success" sx={{ mb: 1 }}>
                    ✅ Accepté le: {formatDate(selectedNote.accepted_at)}
                  </Alert>
                )}
                {selectedNote?.refused_at && (
                  <Alert severity="error">
                    ❌ Refusé le: {formatDate(selectedNote.refused_at)}
                    {selectedNote.rejection_reason && (
                      <Typography variant="body2" sx={{ mt: 1 }}>
                        <strong>Raison:</strong> {selectedNote.rejection_reason}
                      </Typography>
                    )}
                  </Alert>
                )}
              </Box>
            </Stack>
          </DialogTitle>
          <DialogContent dividers>
            {selectedNote && (
              <Box sx={{ p: 1 }}>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                  Créé le: {formatDate(selectedNote.created_at)}
                </Typography>

                {/* Documents disponibles */}
                {(selectedNote.document_fonctionnel ||
                  selectedNote.document_technique ||
                  selectedNote.document_security ||
                  (Array.isArray(selectedNote.document_additionnel) && selectedNote.document_additionnel.length > 0)) && (
                    <Box sx={{ mb: 3, p: 2, backgroundColor: alpha(colors.primary, 0.05), borderRadius: 1 }}>
                      <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600 }}>
                        📎 Documents joints:
                      </Typography>
                      <Stack direction="row" spacing={1} flexWrap="wrap">
                        {selectedNote.document_fonctionnel && (
                          <Chip
                            icon={<Description />}
                            label="Document Fonctionnel"
                            size="small"
                            sx={{ backgroundColor: alpha(colors.primary, 0.2) }}
                          />
                        )}
                        {selectedNote.document_technique && (
                          <Chip
                            icon={<Description />}
                            label="Document Technique"
                            size="small"
                            sx={{ backgroundColor: alpha(colors.success, 0.2) }}
                          />
                        )}
                        {selectedNote.document_security && (
                          <Chip
                            icon={<Description />}
                            label="Document Sécurité"
                            size="small"
                            sx={{ backgroundColor: alpha(colors.warning, 0.2) }}
                          />
                        )}
                        {Array.isArray(selectedNote.document_additionnel) &&
                          selectedNote.document_additionnel.map((_doc, index) => (
                            <Chip
                              key={index}
                              icon={<Description />}
                              label={`Additionnel ${index + 1}`}
                              size="small"
                              sx={{ backgroundColor: alpha(colors.textSecondary, 0.2) }}
                            />
                          ))}
                      </Stack>
                    </Box>
                  )}

                {/* Contenu en Markdown */}
                <Box sx={{
                  border: `1px solid ${colors.border}`,
                  borderRadius: 1,
                  p: 2,
                  backgroundColor: 'white'
                }}>
                  <MDEditor.Markdown source={selectedNote.content} />
                </Box>
              </Box>
            )}
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setViewDialogOpen(false)}>
              Fermer
            </Button>
          </DialogActions>
        </Dialog>

        {/* Dialog de refus */}
        <Dialog
          open={refuseDialogOpen}
          onClose={() => {
            setRefuseDialogOpen(false);
            setRefuseReason("");
            setNoteToRefuse(null);
          }}
          maxWidth="sm"
          fullWidth
        >
          <DialogTitle>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Typography variant="h6">
                Refuser la Release Note
              </Typography>
            </Box>
          </DialogTitle>
          <DialogContent dividers>
            <Box sx={{ pt: 1 }}>
              <Typography variant="body2" sx={{ mb: 2, color: colors.textSecondary }}>
                Veuillez indiquer la raison du refus :
              </Typography>
              <TextField
                label="Raison du refus *"
                value={refuseReason}
                onChange={(e) => setRefuseReason(e.target.value)}
                multiline
                rows={3}
                fullWidth
                required
                autoFocus
                error={refuseReason.trim().length === 0}
                helperText="Ce champ est obligatoire"
              />
            </Box>
          </DialogContent>
          <DialogActions>
            <Button
              onClick={() => {
                setRefuseDialogOpen(false);
                setRefuseReason("");
                setNoteToRefuse(null);
              }}
            >
              Annuler
            </Button>
            <Button
              onClick={() => {
                if (refuseReason.trim() && noteToRefuse) {
                  refuseReleaseNote(noteToRefuse, refuseReason);
                }
              }}
              variant="contained"
              sx={{
                backgroundColor: colors.error,
                '&:hover': {
                  backgroundColor: alpha(colors.error, 0.8),
                },
              }}
              disabled={!refuseReason.trim()}
            >
              Confirmer le refus
            </Button>
          </DialogActions>
        </Dialog>
      </Container>
    </Box>
  );
};

export default AdminReleaseNotesPage;