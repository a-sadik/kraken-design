/* eslint-disable @typescript-eslint/no-explicit-any */
// src/types/dto/response/DomainResponseDTO.ts

export interface DomainResponseDTO {
  pole?: any;
  domain_id: number;
  domain_name: string;
  domain_manager: string;
  created_at?: Date;
  updated_at?: Date;
  created_by?: string;
  updated_by?: string;
}
