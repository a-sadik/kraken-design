interface Colors {
  entity: string;
  pole: string;
  domain: string;
  solution: string;
  namespace: string;
  deployment: string;
  server: string;
  pod: string;
}

export const colors: Colors = {
  entity: "#fce38a",
  pole: "#c6b3ff",
  domain: "#b3ffcc",
  solution: "#b3e6ff",
  namespace: "#a8e6b1",
  deployment: "#f3aebd",
  server: "#99caff",
  pod: "#ffd699",
};

export const darkColors: Colors = {
  entity: "#f5d95a",
  pole: "#b399ff",
  domain: "#99e6b3",
  solution: "#99d6ff",
  namespace: "#90d69e",
  deployment: "#e39eae",
  server: "#7fb2e6",
  pod: "#ffc266",
};

export const envColors: { [key: string]: string } = {
  Production: "#ffb3b3",
  Préproduction: "#ffd699",
  Intégration: "#b3e6ff",
  Recette: "#c6b3ff",
  Développement: "#a8e6b1",
  Formation: "#ffe6cc",
};

export const osColors: { [key: string]: string } = {
  Windows: "#99caff",
  Linux: "#a8e6b1",
  MacOS: "#f3aebd",
  AIX: "#fce38a",
  Default: "#7fb2e6",
};
