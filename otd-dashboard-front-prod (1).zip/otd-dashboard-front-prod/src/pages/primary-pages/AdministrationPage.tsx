/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-vars */
import type React from "react";
import { useState, useEffect, useCallback, useMemo } from "react"; // Added useMemo
import {
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Autocomplete,
  Chip,
  Paper,
  TableContainer,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  IconButton,
  CircularProgress,
  Snackbar,
  Alert,
  Tabs,
  Tab,
  Box,
  Container,
  Stack,
  Tooltip,
  TablePagination,
  Checkbox,
  Grid,
  FormControlLabel,
  FormGroup, // Added Grid for filter layout
} from "@mui/material";
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  CheckCircle as CheckCircleIcon,
  Cancel as CancelIcon,
  CloudUpload as CloudUploadIcon,
  InfoOutlined as InfoOutlinedIcon,
} from "@mui/icons-material";
import { getAdminCRUD_BaseUrl } from "@/config/api.config";
import { useSnackbar } from "@/hooks/useSnackbar";
import { ServerNaturesCRUD } from "@/components/tabs/server-natures-crud";
import ShortTextCell from "@/components/cells/ShortTextCell";
import fetchWithAuth from "@/middleware/fetch-auth";
import { keycloak } from "@/auth/keycloakConnectAdapter";

interface Person {
  firstname: string;
  lastname: string;
  email: string;
  functions?: string[];
}

interface Solution {
  id?: number;
  solution_name: string;
  solution_role: string;
  psi: string;
  solution_popularity: string;
  solution_type: string;
  domain: string;
  tams: string[];
  technical_admins: string[];
  prod_architects: string[];
  dsa_architects: string[];
  functional_admins: string[];
  application_components: string[];
  declarted_on_bigfix: boolean;
  declarted_on_itop: boolean;
  service_type: string;
  tenant: string;
  fiable: boolean;
  activated?: boolean;

}

interface Function {
  id?: number;
  fuction_name: string;
}

// Updated interface for Collaborator to reflect backend data (string array for functions)
interface Collaborator {
  id?: number;
  firstname: string;
  lastname: string;
  email: string;
  functions: string[]; // List of function names (strings) from backend
}

// New interface for Collaborator form state (uses Function objects for Autocomplete)
interface CollaboratorFormState extends Omit<Collaborator, "functions"> {
  functions: Function[]; // List of Function objects for frontend form
}

interface Entity {
  id?: number;
  entity_manager: string; // Now stores email of Person
  entity_name: string;
  entity_acronym: string;
  is_filliale: boolean;
  activated: boolean;
}

interface Pole {
  id?: number;
  entity: string; // Nom de l'entité
  pole_manager: string; // Now stores email of Person
  pole_name: string;
}

interface Domain {
  id?: number;
  pole: string; // Nom du pôle
  domain_manager: string; // Now stores email of Person
  domain_name: string;
}

interface Tenant {
  id?: number;
  tenant_name: string; // Now stores email of Person
  tenant_description: string;
}

interface ServiceType {
  id?: number;
  service_type_name: string;
}

interface Options {
  psi: string[];
  solution_popularity: string[];
  solution_type: string[];
  domain: any[];
  individuals: Person[];
  service_types: ServiceType[];
  tenants: Tenant[];
}

const API_BASE_URL = getAdminCRUD_BaseUrl();

// Composant CRUD pour les Solutions

function SolutionsCRUD() {
  const [solutions, setSolutions] = useState<Solution[]>([]);
  const [options, setOptions] = useState<Options>({
    psi: [],
    solution_popularity: [],
    solution_type: [],
    domain: [],
    individuals: [],
    service_types: [],
    tenants: [],
  });
  const [currentSolution, setCurrentSolution] = useState<Solution | null>(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const { snackbar, showSnackbar, handleCloseSnackbar } = useSnackbar();
  const [adminDetails, setAdminDetails] = useState<{
    open: boolean;
    title: string;
    emails: string[];
  }>({
    open: false,
    title: "",
    emails: [],
  });

  // Pagination states
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  // Batch action states
  const [selectedSolutionIds, setSelectedSolutionIds] = useState<number[]>([]);
  const [openBatchDialog, setOpenBatchDialog] = useState(false);

  // Filter states
  const [filterCriteria, setFilterCriteria] = useState({
    solution_name: "",
    solution_role: "",
    psi: "",
    solution_popularity: "",
    solution_type: "",
    domain: "",
    declarted_on_bigfix: "all",
    declarted_on_itop: "all",
    fiable: "all",
    activated: "all",
    tams: "",
    technical_admins: "",
    functional_admins: "",
    dsa_architects: "",
    prod_architects: "",
    service_type: "", // Nouveau filtre
    tenant: "", // Nouveau filtre
  });

  const fetchSolutionsAndOptions = useCallback(async () => {
    try {
      setLoading(true);
      const [
        psiRes,
        popularityRes,
        typeRes,
        domainRes,
        individualsRes,
        solutionsRes,
        serviceTypesRes,
        tenantsRes,
      ] = await Promise.all([
        fetchWithAuth(`${API_BASE_URL}/options/psi`),
        fetchWithAuth(`${API_BASE_URL}/options/solution_popularity`),
        fetchWithAuth(`${API_BASE_URL}/options/solution_type`),
        fetchWithAuth(`${API_BASE_URL}/domains`),
        fetchWithAuth(`${API_BASE_URL}/options/solutions/individuals`),
        fetchWithAuth(`${API_BASE_URL}/applications`),
        fetchWithAuth(`${API_BASE_URL}/service-type`),
        fetchWithAuth(`${API_BASE_URL}/tenant`),
      ]);

      const optionsData: Options = {
        psi: (await psiRes.json()).psi,
        solution_popularity: (await popularityRes.json()).solution_popularity,
        solution_type: (await typeRes.json()).solution_type,
        domain: (await domainRes.json()).map((d: any) => ({
          value: d.domain_name,
          label: `(${d.pole}) ${d.domain_name}`,
        })),
        individuals: await individualsRes.json(),
        service_types: await serviceTypesRes.json(),
        tenants: await tenantsRes.json(),
      };

      setOptions(optionsData);
      setSolutions(await solutionsRes.json());
    } catch (error) {
      showSnackbar("Erreur lors du chargement des données", "error");
      console.error(error);
    } finally {
      setLoading(false);
    }
  }, [showSnackbar]);

  useEffect(() => {
    fetchSolutionsAndOptions();
  }, [fetchSolutionsAndOptions]);

  const handleInputChange = (field: keyof Solution, value: any) => {
    setCurrentSolution((prev) => ({ ...prev!, [field]: value }));
  };

  const handlePersonSelect = (
    field: "tams" | "technical_admins" | "functional_admins" | "dsa_architects" | "prod_architects",
    emails: string[],
  ) => {
    setCurrentSolution((prev) => ({ ...prev!, [field]: emails }));
  };

  const handleCreate = () => {
    setCurrentSolution({
      solution_name: "",
      solution_role: "",
      psi: "",
      solution_popularity: "",
      solution_type: "",
      domain: "",
      tams: [],
      technical_admins: [],
      functional_admins: [],
      dsa_architects: [],
      prod_architects: [],
      application_components :[],
      declarted_on_bigfix: false,
      declarted_on_itop: false,
      fiable: false,
      activated: false,
      service_type: "",
      tenant: "",
    });
    setIsEditing(false);
    setOpenDialog(true);
  };

  const handleEdit = (solution: Solution) => {
    setCurrentSolution(solution);
    setIsEditing(true);
    setOpenDialog(true);
  };

  const handleDelete = async (id: number) => {
    if (window.confirm("Confirmer la suppression ?")) {
      try {
        await fetchWithAuth(`${API_BASE_URL}/applications/${id}/`, {
          method: "DELETE",
        });
        setSolutions(solutions.filter((s) => s.id !== id));
        showSnackbar("Solution supprimée avec succès", "success");
      } catch (error) {
        showSnackbar("Erreur lors de la suppression", "error");
      }
    }
  };

  const handleSubmit = async () => {
    try {
      const url = isEditing
        ? `${API_BASE_URL}/applications/${currentSolution!.id}/`
        : `${API_BASE_URL}/applications/`;
      const method = isEditing ? "PATCH" : "POST";
      const {
        declarted_on_bigfix,
        declarted_on_itop,
        fiable,
        activated,
        ...dataToSend
      } = currentSolution!;
      const response = await fetchWithAuth(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(dataToSend),
      });
      const result = await response.json();
      if (isEditing) {
        setSolutions(
          solutions.map((s) => (s.id === currentSolution!.id ? result : s)),
        );
      } else {
        setSolutions([...solutions, result]);
      }
      showSnackbar(
        `Solution ${isEditing ? "modifiée" : "ajoutée"} avec succès`,
        "success",
      );
      setOpenDialog(false);
    } catch (error) {
      showSnackbar("Erreur lors de l'opération", "error");
    }
  };

  const showAdminDetails = (title: string, emails: string[]) => {
    setAdminDetails({ open: true, title, emails });
  };

  const handleDeclareItop = (_id: number) => {
    alert('Fonctionnalité "Déclarer dans iTop" pas encore implémentée');
  };

  // Filter handlers
  const handleFilterChange = (
    field: keyof typeof filterCriteria,
    value: string,
  ) => {
    setFilterCriteria((prev) => ({ ...prev, [field]: value }));
    setPage(0);
  };

  const handleResetFilters = () => {
    setFilterCriteria({
      solution_name: "",
      solution_role: "",
      psi: "",
      solution_popularity: "",
      solution_type: "",
      domain: "",
      declarted_on_bigfix: "all",
      declarted_on_itop: "all",
      fiable: "all",
      activated: "all",
      tams: "",
      technical_admins: "",
      functional_admins: "",
      dsa_architects: "",
      prod_architects: "",
      service_type: "",
      tenant: "",
    });
    setPage(0);
  };

  // Memoized filtered solutions
  const filteredSolutions = useMemo(() => {
    const getBooleanValue = (value: boolean | undefined) => value === true;

    return solutions.filter((solution) => {
      // Text filters
      if (
        filterCriteria.solution_name &&
        !solution.solution_name
          .toLowerCase()
          .includes(filterCriteria.solution_name.toLowerCase())
      ) {
        return false;
      }
      if (
        filterCriteria.solution_role &&
        !solution.solution_role
          .toLowerCase()
          .includes(filterCriteria.solution_role.toLowerCase())
      ) {
        return false;
      }

      // Select filters
      if (filterCriteria.psi && solution.psi !== filterCriteria.psi) {
        return false;
      }
      if (
        filterCriteria.solution_popularity &&
        solution.solution_popularity !== filterCriteria.solution_popularity
      ) {
        return false;
      }
      if (
        filterCriteria.solution_type &&
        solution.solution_type !== filterCriteria.solution_type
      ) {
        return false;
      }
      if (filterCriteria.domain && solution.domain !== filterCriteria.domain) {
        return false;
      }
      if (
        filterCriteria.service_type &&
        solution.service_type !== filterCriteria.service_type
      ) {
        return false;
      }
      if (filterCriteria.tenant && solution.tenant !== filterCriteria.tenant) {
        return false;
      }

      // Boolean filters
      if (filterCriteria.declarted_on_bigfix !== "all") {
        const expected = filterCriteria.declarted_on_bigfix === "yes";
        if (getBooleanValue(solution.declarted_on_bigfix) !== expected)
          return false;
      }
      if (filterCriteria.declarted_on_itop !== "all") {
        const expected = filterCriteria.declarted_on_itop === "yes";
        if (getBooleanValue(solution.declarted_on_itop) !== expected)
          return false;
      }
      if (filterCriteria.fiable !== "all") {
        const expected = filterCriteria.fiable === "yes";
        if (getBooleanValue(solution.fiable) !== expected) return false;
      }
      if (filterCriteria.activated !== "all") {
        const expected = filterCriteria.activated === "yes";
        if (getBooleanValue(solution.activated) !== expected) return false;
      }

      // Person filters
      if (filterCriteria.tams) {
        const searchTerm = filterCriteria.tams.toLowerCase();
        const hasMatchingTam = solution.tams.some((email) => {
          const person = options.individuals.find((i) => i.email === email);
          if (!person) return false;
          return `${person.firstname} ${person.lastname} ${person.email}`
            .toLowerCase()
            .includes(searchTerm);
        });
        if (!hasMatchingTam) return false;
      }

      if (filterCriteria.technical_admins) {
        const searchTerm = filterCriteria.technical_admins.toLowerCase();
        const hasMatchingAdmin = solution.technical_admins.some((email) => {
          const person = options.individuals.find((i) => i.email === email);
          if (!person) return false;
          return `${person.firstname} ${person.lastname} ${person.email}`
            .toLowerCase()
            .includes(searchTerm);
        });
        if (!hasMatchingAdmin) return false;
      }
      if (filterCriteria.dsa_architects) {
        const searchTerm = filterCriteria.dsa_architects.toLowerCase();
        const hasMatchingAdmin = solution.dsa_architects.some((email) => {
          const person = options.individuals.find((i) => i.email === email);
          if (!person) return false;
          return `${person.firstname} ${person.lastname} ${person.email}`
            .toLowerCase()
            .includes(searchTerm);
        });
        if (!hasMatchingAdmin) return false;
      }
      if (filterCriteria.prod_architects) {
        const searchTerm = filterCriteria.prod_architects.toLowerCase();
        const hasMatchingAdmin = solution.prod_architects.some((email) => {
          const person = options.individuals.find((i) => i.email === email);
          if (!person) return false;
          return `${person.firstname} ${person.lastname} ${person.email}`
            .toLowerCase()
            .includes(searchTerm);
        });
        if (!hasMatchingAdmin) return false;
      }

      if (filterCriteria.functional_admins) {
        const searchTerm = filterCriteria.functional_admins.toLowerCase();
        const hasMatchingAdmin = solution.functional_admins.some((email) => {
          const person = options.individuals.find((i) => i.email === email);
          if (!person) return false;
          return `${person.firstname} ${person.lastname} ${person.email}`
            .toLowerCase()
            .includes(searchTerm);
        });
        if (!hasMatchingAdmin) return false;
      }

      return true;
    });
  }, [solutions, filterCriteria, options.individuals]);

  const tamsOptions = useMemo(
    () => options.individuals.filter((p) => p.functions?.includes("TAM")),
    [options.individuals],
  );
  const t_adminOptions = useMemo(
    () =>
      options.individuals.filter((p) =>
        p.functions?.includes("Responsable Technique"),
      ),
    [options.individuals],
  );
  const f_adminsOptions = useMemo(
    () =>
      options.individuals.filter((p) =>
        p.functions?.includes("Responsable Fonctionnel"),
      ),
    [options.individuals],
  );

  const prod_archiOptions = useMemo(
    () =>
      options.individuals.filter((p) =>
        p.functions?.includes("Architecte de production"),
      ),
    [options.individuals],
  );

  const dsa_archiOptions = useMemo(
    () =>
      options.individuals.filter((p) =>
        p.functions?.includes("Architecte DSA"),
      ),
    [options.individuals],
  );

  // Pagination handlers
  const handleChangePage = (_event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    setRowsPerPage(Number.parseInt(event.target.value, 10));
    setPage(0);
  };

  // Batch action handlers
  const handleSelectAllClick = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.checked) {
      const newSelecteds = filteredSolutions.map((n) => n.id!);
      setSelectedSolutionIds(newSelecteds);
      return;
    }
    setSelectedSolutionIds([]);
  };

  const handleClick = (_event: React.MouseEvent<unknown>, id: number) => {
    const selectedIndex = selectedSolutionIds.indexOf(id);
    let newSelected: number[] = [];
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selectedSolutionIds, id);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selectedSolutionIds.slice(1));
    } else if (selectedIndex === selectedSolutionIds.length - 1) {
      newSelected = newSelected.concat(selectedSolutionIds.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selectedSolutionIds.slice(0, selectedIndex),
        selectedSolutionIds.slice(selectedIndex + 1),
      );
    }
    setSelectedSolutionIds(newSelected);
  };

  const isSelected = (id: number) => selectedSolutionIds.indexOf(id) !== -1;

  const handleBatchAction = async (action: "activate" | "deactivate") => {
    if (selectedSolutionIds.length === 0) {
      showSnackbar("Veuillez sélectionner au moins une solution.", "warning");
      return;
    }
    try {
      const response = await fetchWithAuth(
        `${API_BASE_URL}/manage/solutions/`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ids: selectedSolutionIds, action }),
        },
      );
      if (!response.ok) {
        throw new Error("Failed to perform batch action");
      }
      await fetchSolutionsAndOptions();
      setSelectedSolutionIds([]);
      setOpenBatchDialog(false);
      showSnackbar(
        `Solutions ${action === "activate" ? "activées" : "désactivées"} avec succès`,
        "success",
      );
    } catch (error) {
      showSnackbar("Erreur lors de l'opération par lot", "error");
      console.error(error);
    }
  };

  const emptyRows =
    page > 0
      ? Math.max(0, (1 + page) * rowsPerPage - filteredSolutions.length)
      : 0;

  return (
    <Paper sx={{ p: 4, borderRadius: 2, boxShadow: 3 }}>
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          mb: 3,
        }}
      >
        <Typography
          variant="h5"
          component="h2"
          sx={{ fontWeight: "bold", color: "text.primary" }}
        >
          Gestion des Solutions
        </Typography>
        <Stack direction="row" spacing={2}>
          <Button
            variant="outlined"
            onClick={() => setOpenBatchDialog(true)}
            disabled={selectedSolutionIds.length === 0}
            sx={{
              borderRadius: 1,
              px: 3,
              py: 1.2,
            }}
          >
            Gérer les activations ({selectedSolutionIds.length})
          </Button>
          <Button
            variant="contained"
            startIcon={<AddIcon />}
            onClick={handleCreate}
            sx={{
              bgcolor: "primary.main",
              "&:hover": { bgcolor: "primary.dark" },
              borderRadius: 1,
              px: 3,
              py: 1.2,
            }}
          >
            Ajouter une Solution
          </Button>
        </Stack>
      </Box>

      {/* Filter Section */}
      <Box
        sx={{
          mb: 4,
          p: 3,
          border: "1px solid #e0e0e0",
          borderRadius: 2,
          bgcolor: "grey.50",
        }}
      >
        <Typography
          variant="h6"
          component="h3"
          sx={{ mb: 2, color: "text.primary" }}
        >
          Filtres de Solutions
        </Typography>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6} md={4}>
            <TextField
              label="Filtrer par Nom"
              fullWidth
              value={filterCriteria.solution_name}
              onChange={(e) =>
                handleFilterChange("solution_name", e.target.value)
              }
              variant="outlined"
              size="small"
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControl fullWidth variant="outlined" size="small">
              <InputLabel>PSI</InputLabel>
              <Select
                value={filterCriteria.psi}
                onChange={(e) => handleFilterChange("psi", e.target.value)}
                label="PSI"
              >
                <MenuItem value="">Tous</MenuItem>
                {options.psi.map((psi) => (
                  <MenuItem key={psi} value={psi}>
                    {psi}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControl fullWidth variant="outlined" size="small">
              <InputLabel>Population utilisateur</InputLabel>
              <Select
                value={filterCriteria.solution_popularity}
                onChange={(e) =>
                  handleFilterChange("solution_popularity", e.target.value)
                }
                label="Population utilisateur"
              >
                <MenuItem value="">Tous</MenuItem>
                {options.solution_popularity.map((pop) => (
                  <MenuItem key={pop} value={pop}>
                    {pop}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControl fullWidth variant="outlined" size="small">
              <InputLabel>Type de solution</InputLabel>
              <Select
                value={filterCriteria.solution_type}
                onChange={(e) =>
                  handleFilterChange("solution_type", e.target.value)
                }
                label="Type de solution"
              >
                <MenuItem value="">Tous</MenuItem>
                {options.solution_type.map((type) => (
                  <MenuItem key={type} value={type}>
                    {type}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControl fullWidth variant="outlined" size="small">
              <InputLabel>Domaine</InputLabel>
              <Select
                value={filterCriteria.domain}
                onChange={(e) => handleFilterChange("domain", e.target.value)}
                label="Domaine"
              >
                <MenuItem value="">Tous</MenuItem>
                {options.domain.map((domain) => (
                  <MenuItem key={domain.value} value={domain.value}>
                    {domain.label}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControl fullWidth variant="outlined" size="small">
              <InputLabel>Type de Service</InputLabel>
              <Select
                value={filterCriteria.service_type}
                onChange={(e) =>
                  handleFilterChange("service_type", e.target.value)
                }
                label="Type de Service"
              >
                <MenuItem value="">Tous</MenuItem>
                {options.service_types.map((serviceType) => (
                  <MenuItem
                    key={serviceType.id}
                    value={serviceType.service_type_name}
                  >
                    {serviceType.service_type_name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControl fullWidth variant="outlined" size="small">
              <InputLabel>Tenant</InputLabel>
              <Select
                value={filterCriteria.tenant}
                onChange={(e) => handleFilterChange("tenant", e.target.value)}
                label="Tenant"
              >
                <MenuItem value="">Tous</MenuItem>
                {options.tenants.map((tenant) => (
                  <MenuItem key={tenant.id} value={tenant.tenant_name}>
                    {tenant.tenant_name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <FormControl fullWidth variant="outlined" size="small">
              <InputLabel>Déclaré dans BigFix</InputLabel>
              <Select
                value={filterCriteria.declarted_on_bigfix}
                onChange={(e) =>
                  handleFilterChange("declarted_on_bigfix", e.target.value)
                }
                label="Déclaré dans BigFix"
              >
                <MenuItem value="all">Tous</MenuItem>
                <MenuItem value="yes">Oui</MenuItem>
                <MenuItem value="no">Non</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <FormControl fullWidth variant="outlined" size="small">
              <InputLabel>Déclaré dans Itop</InputLabel>
              <Select
                value={filterCriteria.declarted_on_itop}
                onChange={(e) =>
                  handleFilterChange("declarted_on_itop", e.target.value)
                }
                label="Déclaré dans Itop"
              >
                <MenuItem value="all">Tous</MenuItem>
                <MenuItem value="yes">Oui</MenuItem>
                <MenuItem value="no">Non</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <FormControl fullWidth variant="outlined" size="small">
              <InputLabel>Fiable</InputLabel>
              <Select
                value={filterCriteria.fiable}
                onChange={(e) => handleFilterChange("fiable", e.target.value)}
                label="Fiable"
              >
                <MenuItem value="all">Tous</MenuItem>
                <MenuItem value="yes">Oui</MenuItem>
                <MenuItem value="no">Non</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <FormControl fullWidth variant="outlined" size="small">
              <InputLabel>Activée</InputLabel>
              <Select
                value={filterCriteria.activated}
                onChange={(e) =>
                  handleFilterChange("activated", e.target.value)
                }
                label="Activée"
              >
                <MenuItem value="all">Tous</MenuItem>
                <MenuItem value="yes">Oui</MenuItem>
                <MenuItem value="no">Non</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <TextField
              label="Filtrer par TAM"
              fullWidth
              value={filterCriteria.tams}
              onChange={(e) => handleFilterChange("tams", e.target.value)}
              variant="outlined"
              size="small"
              placeholder="Nom, prénom ou email"
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <TextField
              label="Filtrer par Admin Technique"
              fullWidth
              value={filterCriteria.technical_admins}
              onChange={(e) =>
                handleFilterChange("technical_admins", e.target.value)
              }
              variant="outlined"
              size="small"
              placeholder="Nom, prénom ou email"
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <TextField
              label="Filtrer par Admin Fonctionnel"
              fullWidth
              value={filterCriteria.functional_admins}
              onChange={(e) =>
                handleFilterChange("functional_admins", e.target.value)
              }
              variant="outlined"
              size="small"
              placeholder="Nom, prénom ou email"
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <TextField
              label="Filtrer par Architecte de Production"
              fullWidth
              value={filterCriteria.prod_architects}
              onChange={(e) =>
                handleFilterChange("prod_architects", e.target.value)
              }
              variant="outlined"
              size="small"
              placeholder="Nom, prénom ou email"
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <TextField
              label="Filtrer par Architecte DSA"
              fullWidth
              value={filterCriteria.dsa_architects}
              onChange={(e) =>
                handleFilterChange("dsa_architects", e.target.value)
              }
              variant="outlined"
              size="small"
              placeholder="Nom, prénom ou email"
            />
          </Grid>
        </Grid>
        <Box sx={{ mt: 3, display: "flex", justifyContent: "flex-end" }}>
          <Button
            variant="outlined"
            onClick={handleResetFilters}
            sx={{ borderRadius: 1 }}
          >
            Réinitialiser les filtres
          </Button>
        </Box>
      </Box>

      {loading ? (
        <Box sx={{ display: "flex", justifyContent: "center", py: 4 }}>
          <CircularProgress />
        </Box>
      ) : (
        <TableContainer
          component={Paper}
          sx={{ borderRadius: 2, boxShadow: 1 }}
        >
          <Table sx={{ minWidth: 1400 }}>
            <TableHead sx={{ bgcolor: "grey.100" }}>
              <TableRow>
                <TableCell padding="checkbox">
                  <Checkbox
                    indeterminate={
                      selectedSolutionIds.length > 0 &&
                      selectedSolutionIds.length < filteredSolutions.length
                    }
                    checked={
                      filteredSolutions.length > 0 &&
                      selectedSolutionIds.length === filteredSolutions.length
                    }
                    onChange={handleSelectAllClick}
                  />
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Actions
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Nom
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Descriptif
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  PSI
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Population utilisateur
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Type
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Domaine
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Type de Service
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Tenant
                </TableCell>
                <TableCell
                  align="center"
                  sx={{ fontWeight: "bold", color: "text.secondary" }}
                >
                  BigFix
                </TableCell>
                <TableCell
                  align="center"
                  sx={{ fontWeight: "bold", color: "text.secondary" }}
                >
                  iTop
                </TableCell>
                <TableCell
                  align="center"
                  sx={{ fontWeight: "bold", color: "text.secondary" }}
                >
                  Fiable
                </TableCell>
                <TableCell
                  align="center"
                  sx={{ fontWeight: "bold", color: "text.secondary" }}
                >
                  Activée
                </TableCell>
                <TableCell
                  align="center"
                  sx={{ fontWeight: "bold", color: "text.secondary" }}
                >
                  Briques Applicatives
                </TableCell>
                <TableCell
                  align="center"
                  sx={{ fontWeight: "bold", color: "text.secondary" }}
                >
                  TAMs
                </TableCell>
                <TableCell
                  align="center"
                  sx={{ fontWeight: "bold", color: "text.secondary" }}
                >
                  Admins Tech
                </TableCell>
                <TableCell
                  align="center"
                  sx={{ fontWeight: "bold", color: "text.secondary" }}
                >
                  Admins Fonc.
                </TableCell>
                <TableCell
                  align="center"
                  sx={{ fontWeight: "bold", color: "text.secondary" }}
                >
                  Architecte de Prod.
                </TableCell>
                <TableCell
                  align="center"
                  sx={{ fontWeight: "bold", color: "text.secondary" }}
                >
                  Architecte DSA
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {(rowsPerPage > 0
                ? filteredSolutions.slice(
                  page * rowsPerPage,
                  page * rowsPerPage + rowsPerPage,
                )
                : filteredSolutions
              ).map((solution) => {
                const isItemSelected = isSelected(solution.id!);
                return (
                  <TableRow
                    hover
                    onClick={(event) => handleClick(event, solution.id!)}
                    role="checkbox"
                    aria-checked={isItemSelected}
                    tabIndex={-1}
                    key={solution.id}
                    selected={isItemSelected}
                    sx={{ "&:nth-of-type(odd)": { bgcolor: "action.hover" } }}
                  >
                    <TableCell padding="checkbox">
                      <Checkbox checked={isItemSelected} />
                    </TableCell>
                    <TableCell>
                      <Stack direction="row" spacing={0.5}>
                        <IconButton
                          color="primary"
                          size="small"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleEdit(solution);
                          }}
                        >
                          <EditIcon sx={{ fontSize: 20 }} />
                        </IconButton>
                        <IconButton
                          color="error"
                          size="small"
                          disabled={!keycloak.hasRoles("admin_role")}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDelete(solution.id!);
                          }}
                        >
                          <DeleteIcon sx={{ fontSize: 20 }} />
                        </IconButton>
                        {!solution.declarted_on_itop && (
                          <Tooltip
                            title={
                              keycloak.hasRoles("admin_role")
                                ? "Déclarer dans iTop"
                                : "Seuls les administrateurs peuvent déclarer dans iTop"
                            }
                          >
                            <span>
                              <IconButton
                                color="secondary"
                                size="small"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeclareItop(solution.id!);
                                }}
                                disabled={!keycloak.hasRoles("admin_role")}
                              >
                                <CloudUploadIcon sx={{ fontSize: 20 }} />
                              </IconButton>
                            </span>
                          </Tooltip>
                        )}
                      </Stack>
                    </TableCell>
                    <TableCell>{solution.solution_name}</TableCell>
                    <ShortTextCell text={solution.solution_role} />
                    <TableCell>{solution.psi}</TableCell>
                    <TableCell>{solution.solution_popularity}</TableCell>
                    <TableCell>{solution.solution_type}</TableCell>
                    <TableCell>{solution.domain}</TableCell>
                    <TableCell>{solution.service_type}</TableCell>
                    <TableCell>{solution.tenant}</TableCell>
                    <TableCell align="center">
                      {solution.declarted_on_bigfix ? (
                        <CheckCircleIcon
                          color="success"
                          sx={{ fontSize: 20 }}
                        />
                      ) : (
                        <CancelIcon color="error" sx={{ fontSize: 20 }} />
                      )}
                    </TableCell>
                    <TableCell align="center">
                      {solution.declarted_on_itop ? (
                        <CheckCircleIcon
                          color="success"
                          sx={{ fontSize: 20 }}
                        />
                      ) : (
                        <CancelIcon color="error" sx={{ fontSize: 20 }} />
                      )}
                    </TableCell>
                    <TableCell align="center">
                      {solution.fiable ? (
                        <CheckCircleIcon
                          color="success"
                          sx={{ fontSize: 20 }}
                        />
                      ) : (
                        <CancelIcon color="error" sx={{ fontSize: 20 }} />
                      )}
                    </TableCell>
                    <TableCell align="center">
                      {solution.activated ? (
                        <CheckCircleIcon
                          color="success"
                          sx={{ fontSize: 20 }}
                        />
                      ) : (
                        <CancelIcon color="error" sx={{ fontSize: 20 }} />
                      )}
                    </TableCell>
                    <TableCell align="center">
                      <Tooltip title="Voir les Briques">
                        <Button
                          variant="outlined"
                          size="small"
                          onClick={(e) => {
                            e.stopPropagation();
                            showAdminDetails("Briques", solution.application_components);
                          }}
                          sx={{ minWidth: 36, height: 30, borderRadius: 1 }}
                        >
                          {solution.application_components.length}
                        </Button>
                      </Tooltip>
                    </TableCell>
                    <TableCell align="center">
                      <Tooltip title="Voir les TAMs">
                        <Button
                          variant="outlined"
                          size="small"
                          onClick={(e) => {
                            e.stopPropagation();
                            showAdminDetails("TAMs", solution.tams);
                          }}
                          sx={{ minWidth: 36, height: 30, borderRadius: 1 }}
                        >
                          {solution.tams.length}
                        </Button>
                      </Tooltip>
                    </TableCell>
                    <TableCell align="center">
                      <Tooltip title="Voir les Admins Techniques">
                        <Button
                          variant="outlined"
                          size="small"
                          onClick={(e) => {
                            e.stopPropagation();
                            showAdminDetails(
                              "Admins Techniques",
                              solution.technical_admins,
                            );
                          }}
                          sx={{ minWidth: 36, height: 30, borderRadius: 1 }}
                        >
                          {solution.technical_admins.length}
                        </Button>
                      </Tooltip>
                    </TableCell>
                    <TableCell align="center">
                      <Tooltip title="Voir les Admins Fonctionnels">
                        <Button
                          variant="outlined"
                          size="small"
                          onClick={(e) => {
                            e.stopPropagation();
                            showAdminDetails(
                              "Admins Fonctionnels",
                              solution.functional_admins,
                            );
                          }}
                          sx={{ minWidth: 36, height: 30, borderRadius: 1 }}
                        >
                          {solution.functional_admins.length}
                        </Button>
                      </Tooltip>
                    </TableCell>
                    <TableCell align="center">
                      <Tooltip title="Voir les Architectes de production">
                        <Button
                          variant="outlined"
                          size="small"
                          onClick={(e) => {
                            e.stopPropagation();
                            showAdminDetails(
                              "Architectes de production",
                              solution.prod_architects,
                            );
                          }}
                          sx={{ minWidth: 36, height: 30, borderRadius: 1 }}
                        >
                          {solution.prod_architects.length}
                        </Button>
                      </Tooltip>
                    </TableCell>

                    <TableCell align="center">
                      <Tooltip title="Voir les Architectes DSA">
                        <Button
                          variant="outlined"
                          size="small"
                          onClick={(e) => {
                            e.stopPropagation();
                            showAdminDetails(
                              "Architectes DSA",
                              solution.dsa_architects,
                            );
                          }}
                          sx={{ minWidth: 36, height: 30, borderRadius: 1 }}
                        >
                          {solution.dsa_architects.length}
                        </Button>
                      </Tooltip>
                    </TableCell>


                  </TableRow>
                );
              })}
              {emptyRows > 0 && (
                <TableRow style={{ height: 53 * emptyRows }}>
                  <TableCell colSpan={17} />
                </TableRow>
              )}
            </TableBody>
          </Table>
          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component="div"
            count={filteredSolutions.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
            labelRowsPerPage="Lignes par page :"
            labelDisplayedRows={({ from, to, count }) =>
              `${from}-${to} sur ${count !== -1 ? count : `plus de ${to}`}`
            }
          />
        </TableContainer>
      )}

      {/* Dialog d'édition/création */}
      <Dialog
        open={openDialog}
        onClose={() => setOpenDialog(false)}
        fullWidth
        maxWidth="md"
      >
        <DialogTitle
          sx={{ bgcolor: "primary.main", color: "white", py: 2, px: 3 }}
        >
          <Typography variant="h6" component="span" sx={{ fontWeight: "bold" }}>
            {isEditing ? "Modifier la solution" : "Créer une nouvelle solution"}
          </Typography>
        </DialogTitle>
        <DialogContent dividers sx={{ p: 3 }}>
          {currentSolution && (
            <Stack spacing={2}>
              <TextField
                label="Nom de la solution"
                fullWidth
                value={currentSolution.solution_name}
                onChange={(e) =>
                  handleInputChange("solution_name", e.target.value)
                }
                required
                variant="outlined"
                size="small"
              />
              <TextField
                label="Descriptif de la solution"
                fullWidth
                multiline
                required
                rows={16}
                value={currentSolution.solution_role}
                onChange={(e) =>
                  handleInputChange("solution_role", e.target.value)
                }
                variant="outlined"
                size="small"
              />
              <FormControl fullWidth required variant="outlined" size="small">
                <InputLabel>PSI</InputLabel>
                <Select
                  value={currentSolution.psi}
                  onChange={(e) => handleInputChange("psi", e.target.value)}
                  label="PSI"
                >
                  {options.psi.map((psi) => (
                    <MenuItem key={psi} value={psi}>
                      {psi}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              <FormControl fullWidth required variant="outlined" size="small">
                <InputLabel>Population utilisateur</InputLabel>
                <Select
                  value={currentSolution.solution_popularity}
                  onChange={(e) =>
                    handleInputChange("solution_popularity", e.target.value)
                  }
                  label="Population utilisateur"
                >
                  {options.solution_popularity.map((pop) => (
                    <MenuItem key={pop} value={pop}>
                      {pop}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              <FormControl fullWidth required variant="outlined" size="small">
                <InputLabel>Type de solution</InputLabel>
                <Select
                  value={currentSolution.solution_type}
                  onChange={(e) =>
                    handleInputChange("solution_type", e.target.value)
                  }
                  label="Type de solution"
                >
                  {options.solution_type.map((type) => (
                    <MenuItem key={type} value={type}>
                      {type}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              <Autocomplete
                options={options.domain}
                getOptionLabel={(option) => option.label}
                value={options.domain.find((d) => d.value === currentSolution.domain) || null}
                onChange={(_event, newValue) => {
                  handleInputChange("domain", newValue ? newValue.value : "");
                }}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Domaine"
                    variant="outlined"
                    size="small"
                    required
                    fullWidth
                  />
                )}
              />
              <FormControl fullWidth required variant="outlined" size="small">
                <InputLabel>Type de Service</InputLabel>
                <Select
                  value={currentSolution.service_type || ""}
                  onChange={(e) =>
                    handleInputChange("service_type", e.target.value)
                  }
                  label="Type de Service"
                >
                  {options.service_types.map((serviceType) => (
                    <MenuItem
                      key={serviceType.id}
                      value={serviceType.service_type_name}
                    >
                      {serviceType.service_type_name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              <FormControl fullWidth required variant="outlined" size="small">
                <InputLabel>Tenant</InputLabel>
                <Select
                  value={currentSolution.tenant || ""}
                  onChange={(e) => handleInputChange("tenant", e.target.value)}
                  label="Tenant"
                >
                  {options.tenants.map((tenant) => (
                    <MenuItem key={tenant.id} value={tenant.tenant_name}>
                      {tenant.tenant_name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              
              <Autocomplete
                multiple
                freeSolo
                options={[]}
                value={currentSolution.application_components}
                onChange={(_, newValue) =>
                  handleInputChange("application_components", newValue)
                }
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Briques applicatives"
                    variant="outlined"
                    size="small"
                  />
                )}
              />

              <Autocomplete
                key="tams"
                multiple
                options={tamsOptions}
                getOptionLabel={(person) =>
                  `${person.firstname} ${person.lastname} (${person.email})`
                }
                value={options.individuals.filter((person) =>
                  currentSolution["tams"].includes(person.email),
                )}
                onChange={(_, newValue) => {
                  handlePersonSelect(
                    "tams",
                    newValue.map((person) => person.email),
                  );
                }}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label={"TAMs"}
                    variant="outlined"
                    size="small"
                    fullWidth
                  />
                )}
                renderTags={(value, getTagProps) =>
                  value.map((person, index) => (
                    <Chip
                      {...getTagProps({ index })}
                      key={person.email}
                      label={`${person.firstname} ${person.lastname}`}
                      size="small"
                      sx={{
                        bgcolor: "primary.light",
                        color: "primary.contrastText",
                      }}
                    />
                  ))
                }
              />
              <Autocomplete
                key="technical_admins"
                multiple
                options={t_adminOptions}
                getOptionLabel={(person) =>
                  `${person.firstname} ${person.lastname} (${person.email})`
                }
                value={options.individuals.filter((person) =>
                  currentSolution["technical_admins"].includes(person.email),
                )}
                onChange={(_, newValue) => {
                  handlePersonSelect(
                    "technical_admins",
                    newValue.map((person) => person.email),
                  );
                }}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label={"Admins techniques"}
                    variant="outlined"
                    size="small"
                    fullWidth
                  />
                )}
                renderTags={(value, getTagProps) =>
                  value.map((person, index) => (
                    <Chip
                      {...getTagProps({ index })}
                      key={person.email}
                      label={`${person.firstname} ${person.lastname}`}
                      size="small"
                      sx={{
                        bgcolor: "primary.light",
                        color: "primary.contrastText",
                      }}
                    />
                  ))
                }
              />
              <Autocomplete
                key="functional_admins"
                multiple
                options={f_adminsOptions}
                getOptionLabel={(person) =>
                  `${person.firstname} ${person.lastname} (${person.email})`
                }
                value={options.individuals.filter((person) =>
                  currentSolution["functional_admins"].includes(person.email),
                )}
                onChange={(_, newValue) => {
                  handlePersonSelect(
                    "functional_admins",
                    newValue.map((person) => person.email),
                  );
                }}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label={"Admins fonctionnels"}
                    variant="outlined"
                    size="small"
                    fullWidth
                  />
                )}
                renderTags={(value, getTagProps) =>
                  value.map((person, index) => (
                    <Chip
                      {...getTagProps({ index })}
                      key={person.email}
                      label={`${person.firstname} ${person.lastname}`}
                      size="small"
                      sx={{
                        bgcolor: "primary.light",
                        color: "primary.contrastText",
                      }}
                    />
                  ))
                }
              />


              <Autocomplete
                key="prod_architects"
                multiple
                options={prod_archiOptions}
                getOptionLabel={(person) =>
                  `${person.firstname} ${person.lastname} (${person.email})`
                }
                value={options.individuals.filter((person) =>
                  currentSolution["prod_architects"].includes(person.email),
                )}
                onChange={(_, newValue) => {
                  handlePersonSelect(
                    "prod_architects",
                    newValue.map((person) => person.email),
                  );
                }}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label={"Architectes de Production"}
                    variant="outlined"
                    size="small"
                    fullWidth
                  />
                )}
                renderTags={(value, getTagProps) =>
                  value.map((person, index) => (
                    <Chip
                      {...getTagProps({ index })}
                      key={person.email}
                      label={`${person.firstname} ${person.lastname}`}
                      size="small"
                      sx={{
                        bgcolor: "primary.light",
                        color: "primary.contrastText",
                      }}
                    />
                  ))
                }
              />


              <Autocomplete
                key="dsa_architects"
                multiple
                options={dsa_archiOptions}
                getOptionLabel={(person) =>
                  `${person.firstname} ${person.lastname} (${person.email})`
                }
                value={options.individuals.filter((person) =>
                  currentSolution["dsa_architects"].includes(person.email),
                )}
                onChange={(_, newValue) => {
                  handlePersonSelect(
                    "dsa_architects",
                    newValue.map((person) => person.email),
                  );
                }}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label={"Architectes DSA"}
                    variant="outlined"
                    size="small"
                    fullWidth
                  />
                )}
                renderTags={(value, getTagProps) =>
                  value.map((person, index) => (
                    <Chip
                      {...getTagProps({ index })}
                      key={person.email}
                      label={`${person.firstname} ${person.lastname}`}
                      size="small"
                      sx={{
                        bgcolor: "primary.light",
                        color: "primary.contrastText",
                      }}
                    />
                  ))
                }
              />
            </Stack>
          )}
        </DialogContent>
        <DialogActions sx={{ p: 2, borderTop: "1px solid #eee" }}>
          <Button
            onClick={() => setOpenDialog(false)}
            variant="outlined"
            sx={{ borderRadius: 1 }}
          >
            Annuler
          </Button>
          <Button
            variant="contained"
            onClick={handleSubmit}
            disabled={!currentSolution?.tenant}
            sx={{
              bgcolor: "primary.main",
              "&:hover": { bgcolor: "primary.dark" },
              borderRadius: 1,
            }}
          >
            {isEditing ? "Modifier" : "Créer"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Dialog pour voir les détails des admins */}
      <Dialog
        open={adminDetails.open}
        onClose={() => setAdminDetails({ open: false, title: "", emails: [] })}
      >
        <DialogTitle
          sx={{ bgcolor: "primary.main", color: "white", py: 2, px: 3 }}
        >
          <Typography variant="h6" component="span" sx={{ fontWeight: "bold" }}>
            {adminDetails.title}
          </Typography>
        </DialogTitle>
        <DialogContent dividers sx={{ p: 3 }}>
          <Box sx={{ minWidth: 300 }}>
            {adminDetails.emails.length > 0 ? (
              <Stack
                component="ul"
                spacing={1}
                sx={{ listStyle: "none", p: 0, m: 0 }}
              >
                {adminDetails.emails.map((email, index) => (
                  <li key={index}>
                    <Typography
                      variant="body2"
                      sx={{ display: "flex", alignItems: "center", gap: 1 }}
                    >
                      <InfoOutlinedIcon fontSize="small" color="action" />{" "}
                      {email}
                    </Typography>
                  </li>
                ))}
              </Stack>
            ) : (
              <Typography
                variant="body1"
                sx={{ fontStyle: "italic", color: "text.secondary" }}
              >
                Aucun administrateur
              </Typography>
            )}
          </Box>
        </DialogContent>
        <DialogActions sx={{ p: 2, borderTop: "1px solid #eee" }}>
          <Button
            onClick={() =>
              setAdminDetails({ open: false, title: "", emails: [] })
            }
            variant="outlined"
            sx={{ borderRadius: 1 }}
          >
            Fermer
          </Button>
        </DialogActions>
      </Dialog>

      {/* Dialog for Batch Activation/Deactivation */}
      <Dialog
        open={openBatchDialog}
        onClose={() => setOpenBatchDialog(false)}
        fullWidth
        maxWidth="xs"
      >
        <DialogTitle
          sx={{ bgcolor: "primary.main", color: "white", py: 2, px: 3 }}
        >
          <Typography variant="h6" component="span" sx={{ fontWeight: "bold" }}>
            Gérer les activations
          </Typography>
        </DialogTitle>
        <DialogContent dividers sx={{ p: 3 }}>
          <Typography variant="body1" sx={{ mb: 2 }}>
            {`Vous avez sélectionné ${selectedSolutionIds.length} solution(s).`}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Voulez-vous les activer ou les désactiver ?
          </Typography>
        </DialogContent>
        <DialogActions
          sx={{
            p: 2,
            borderTop: "1px solid #eee",
            justifyContent: "space-between",
          }}
        >
          <Button
            onClick={() => setOpenBatchDialog(false)}
            variant="outlined"
            sx={{ borderRadius: 1 }}
          >
            Annuler
          </Button>
          <Stack direction="row" spacing={1}>
            <Button
              variant="contained"
              color="success"
              onClick={() => handleBatchAction("activate")}
              sx={{ borderRadius: 1 }}
            >
              Activer
            </Button>
            <Button
              variant="contained"
              color="error"
              onClick={() => handleBatchAction("deactivate")}
              sx={{ borderRadius: 1 }}
            >
              Désactiver
            </Button>
          </Stack>
        </DialogActions>
      </Dialog>

      {/* Snackbar de notification */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          sx={{ width: "100%", boxShadow: 3 }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Paper>
  );
}

// Composant CRUD pour les Fonctions
function FunctionsCRUD() {
  const [functions, setFunctions] = useState<Function[]>([]);
  const [currentFunction, setCurrentFunction] = useState<Function | null>(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const { snackbar, showSnackbar, handleCloseSnackbar } = useSnackbar();

  useEffect(() => {
    const fetchFunctions = async () => {
      try {
        setLoading(true);
        const response = await fetchWithAuth(`${API_BASE_URL}/functions`);
        setFunctions(await response.json());
      } catch (error) {
        showSnackbar("Erreur lors du chargement des fonctions", "error");
        console.error(error);
      } finally {
        setLoading(false);
      }
    };
    fetchFunctions();
  }, [showSnackbar]);

  const handleCreate = () => {
    setCurrentFunction({ fuction_name: "" });
    setIsEditing(false);
    setOpenDialog(true);
  };

  const handleDelete = async (id: number) => {
    if (window.confirm("Confirmer la suppression ?")) {
      try {
        await fetchWithAuth(`${API_BASE_URL}/functions/${id}/`, {
          method: "DELETE",
        });
        setFunctions(functions.filter((f) => f.id !== id));
        showSnackbar("Fonction supprimée avec succès", "success");
      } catch (error) {
        showSnackbar("Erreur lors de la suppression", "error");
      }
    }
  };

  const handleSubmit = async () => {
    try {
      const url = isEditing
        ? `${API_BASE_URL}/functions/${currentFunction!.id}`
        : `${API_BASE_URL}/functions/`;
      const method = isEditing ? "PATCH" : "POST";
      const response = await fetchWithAuth(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fuction_name: currentFunction?.fuction_name }),
      });
      const result = await response.json();
      if (isEditing) {
        setFunctions(
          functions.map((f) => (f.id === currentFunction!.id ? result : f)),
        );
      } else {
        setFunctions([...functions, result]);
      }
      showSnackbar(
        `Fonction ${isEditing ? "modifiée" : "ajoutée"} avec succès`,
        "success",
      );
      setOpenDialog(false);
    } catch (error) {
      showSnackbar("Erreur lors de l'opération", "error");
    }
  };

  return (
    <Paper sx={{ p: 4, borderRadius: 2, boxShadow: 3 }}>
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          mb: 3,
        }}
      >
        <Typography
          variant="h5"
          component="h2"
          sx={{ fontWeight: "bold", color: "text.primary" }}
        >
          Gestion des Fonctions
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={handleCreate}
          sx={{
            bgcolor: "primary.main",
            "&:hover": { bgcolor: "primary.dark" },
            borderRadius: 1,
            px: 3,
            py: 1.2,
          }}
        >
          Ajouter une Fonction
        </Button>
      </Box>
      {loading ? (
        <Box sx={{ display: "flex", justifyContent: "center", py: 4 }}>
          <CircularProgress />
        </Box>
      ) : (
        <TableContainer
          component={Paper}
          sx={{ borderRadius: 2, boxShadow: 1 }}
        >
          <Table sx={{ minWidth: 600 }}>
            <TableHead sx={{ bgcolor: "grey.100" }}>
              <TableRow>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Actions
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Nom de la fonction
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {functions.map((func) => (
                <TableRow
                  key={func.id}
                  sx={{ "&:nth-of-type(odd)": { bgcolor: "action.hover" } }}
                >
                  <TableCell>
                    <Stack direction="row" spacing={0.5}>
                      <IconButton
                        color="error"
                        size="small"
                        disabled={!keycloak.hasRoles("admin_role")}
                        onClick={() => handleDelete(func.id!)}
                      >
                        <DeleteIcon sx={{ fontSize: 20 }} />
                      </IconButton>
                    </Stack>
                  </TableCell>
                  <TableCell>{func.fuction_name}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
      {/* Dialog d'édition/création */}
      <Dialog
        open={openDialog}
        onClose={() => setOpenDialog(false)}
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle
          sx={{ bgcolor: "primary.main", color: "white", py: 2, px: 3 }}
        >
          <Typography variant="h6" component="span" sx={{ fontWeight: "bold" }}>
            {isEditing ? "Modifier la fonction" : "Créer une nouvelle fonction"}
          </Typography>
        </DialogTitle>
        <DialogContent dividers sx={{ p: 3 }}>
          {currentFunction && (
            <TextField
              label="Nom de la fonction"
              fullWidth
              value={currentFunction.fuction_name}
              onChange={(e) =>
                setCurrentFunction({
                  ...currentFunction,
                  fuction_name: e.target.value,
                })
              }
              required
              variant="outlined"
              size="small"
            />
          )}
        </DialogContent>
        <DialogActions sx={{ p: 2, borderTop: "1px solid #eee" }}>
          <Button
            onClick={() => setOpenDialog(false)}
            variant="outlined"
            sx={{ borderRadius: 1 }}
          >
            Annuler
          </Button>
          <Button
            variant="contained"
            onClick={handleSubmit}
            disabled={!currentFunction?.fuction_name}
            sx={{
              bgcolor: "primary.main",
              "&:hover": { bgcolor: "primary.dark" },
              borderRadius: 1,
            }}
          >
            {isEditing ? "Modifier" : "Créer"}
          </Button>
        </DialogActions>
      </Dialog>
      {/* Snackbar de notification */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          sx={{ width: "100%", boxShadow: 3 }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Paper>
  );
}

function ServiceTypesCRUD() {
  const [serviceTypes, setServiceTypes] = useState<ServiceType[]>([]);
  const [currentServiceType, setCurrentServiceType] =
    useState<ServiceType | null>(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const { snackbar, showSnackbar, handleCloseSnackbar } = useSnackbar();

  useEffect(() => {
    const fetchServiceTypes = async () => {
      try {
        setLoading(true);
        const response = await fetchWithAuth(`${API_BASE_URL}/service-type/`);
        setServiceTypes(await response.json());
      } catch (error) {
        showSnackbar(
          "Erreur lors du chargement des types de services",
          "error",
        );
        console.error(error);
      } finally {
        setLoading(false);
      }
    };
    fetchServiceTypes();
  }, [showSnackbar]);

  const handleCreate = () => {
    setCurrentServiceType({ service_type_name: "" });
    setIsEditing(false);
    setOpenDialog(true);
  };

  const handleEdit = (serviceType: ServiceType) => {
    setCurrentServiceType(serviceType);
    setIsEditing(true);
    setOpenDialog(true);
  };

  const handleDelete = async (id: number) => {
    if (window.confirm("Confirmer la suppression ?")) {
      try {
        await fetchWithAuth(`${API_BASE_URL}/service-type/${id}/`, {
          method: "DELETE",
        });
        setServiceTypes(serviceTypes.filter((st) => st.id !== id));
        showSnackbar("Type de service supprimé avec succès", "success");
      } catch (error) {
        showSnackbar("Erreur lors de la suppression", "error");
      }
    }
  };

  const handleSubmit = async () => {
    try {
      const url = isEditing
        ? `${API_BASE_URL}/service-type/${currentServiceType!.id}/`
        : `${API_BASE_URL}/service-type/`;
      const method = isEditing ? "PATCH" : "POST";
      const response = await fetchWithAuth(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          service_type_name: currentServiceType?.service_type_name,
        }),
      });
      const result = await response.json();
      if (isEditing) {
        setServiceTypes(
          serviceTypes.map((st) =>
            st.id === currentServiceType!.id ? result : st,
          ),
        );
      } else {
        setServiceTypes([...serviceTypes, result]);
      }
      showSnackbar(
        `Type de service ${isEditing ? "modifié" : "ajouté"} avec succès`,
        "success",
      );
      setOpenDialog(false);
    } catch (error) {
      showSnackbar("Erreur lors de l'opération", "error");
    }
  };

  return (
    <Paper sx={{ p: 4, borderRadius: 2, boxShadow: 3 }}>
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          mb: 3,
        }}
      >
        <Typography
          variant="h5"
          component="h2"
          sx={{ fontWeight: "bold", color: "text.primary" }}
        >
          Gestion des Types de Services
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={handleCreate}
          sx={{
            bgcolor: "primary.main",
            "&:hover": { bgcolor: "primary.dark" },
            borderRadius: 1,
            px: 3,
            py: 1.2,
          }}
        >
          Ajouter un Type de Service
        </Button>
      </Box>

      {loading ? (
        <Box sx={{ display: "flex", justifyContent: "center", py: 4 }}>
          <CircularProgress />
        </Box>
      ) : (
        <TableContainer
          component={Paper}
          sx={{ borderRadius: 2, boxShadow: 1 }}
        >
          <Table sx={{ minWidth: 600 }}>
            <TableHead sx={{ bgcolor: "grey.100" }}>
              <TableRow>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Actions
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Nom du Type de Service
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {serviceTypes.map((serviceType) => (
                <TableRow
                  key={serviceType.id}
                  sx={{ "&:nth-of-type(odd)": { bgcolor: "action.hover" } }}
                >
                  <TableCell>
                    <Stack direction="row" spacing={0.5}>
                      <IconButton
                        color="primary"
                        size="small"
                        onClick={() => handleEdit(serviceType)}
                      >
                        <EditIcon sx={{ fontSize: 20 }} />
                      </IconButton>
                      <IconButton
                        color="error"
                        size="small"
                        disabled={!keycloak.hasRoles("admin_role")}
                        onClick={() => handleDelete(serviceType.id!)}
                      >
                        <DeleteIcon sx={{ fontSize: 20 }} />
                      </IconButton>
                    </Stack>
                  </TableCell>
                  <TableCell>{serviceType.service_type_name}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {/* Dialog d'édition/création */}
      <Dialog
        open={openDialog}
        onClose={() => setOpenDialog(false)}
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle
          sx={{ bgcolor: "primary.main", color: "white", py: 2, px: 3 }}
        >
          <Typography variant="h6" component="span" sx={{ fontWeight: "bold" }}>
            {isEditing
              ? "Modifier le type de service"
              : "Créer un nouveau type de service"}
          </Typography>
        </DialogTitle>
        <DialogContent dividers sx={{ p: 3 }}>
          {currentServiceType && (
            <TextField
              label="Nom du type de service"
              fullWidth
              value={currentServiceType.service_type_name}
              onChange={(e) =>
                setCurrentServiceType({
                  ...currentServiceType,
                  service_type_name: e.target.value,
                })
              }
              required
              variant="outlined"
              size="small"
            />
          )}
        </DialogContent>
        <DialogActions sx={{ p: 2, borderTop: "1px solid #eee" }}>
          <Button
            onClick={() => setOpenDialog(false)}
            variant="outlined"
            sx={{ borderRadius: 1 }}
          >
            Annuler
          </Button>
          <Button
            variant="contained"
            onClick={handleSubmit}
            disabled={!currentServiceType?.service_type_name}
            sx={{
              bgcolor: "primary.main",
              "&:hover": { bgcolor: "primary.dark" },
              borderRadius: 1,
            }}
          >
            {isEditing ? "Modifier" : "Créer"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar de notification */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          sx={{ width: "100%", boxShadow: 3 }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Paper>
  );
}

function TenantsCRUD() {
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [currentTenant, setCurrentTenant] = useState<Tenant | null>(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const { snackbar, showSnackbar, handleCloseSnackbar } = useSnackbar();

  useEffect(() => {
    const fetchTenants = async () => {
      try {
        setLoading(true);
        const response = await fetchWithAuth(`${API_BASE_URL}/tenant`);
        setTenants(await response.json());
      } catch (error) {
        showSnackbar("Erreur lors du chargement des tenants", "error");
        console.error(error);
      } finally {
        setLoading(false);
      }
    };
    fetchTenants();
  }, [showSnackbar]);

  const handleCreate = () => {
    setCurrentTenant({ tenant_name: "", tenant_description: "" });
    setIsEditing(false);
    setOpenDialog(true);
  };

  const handleEdit = (tenant: Tenant) => {
    setCurrentTenant(tenant);
    setIsEditing(true);
    setOpenDialog(true);
  };

  const handleDelete = async (id: number) => {
    if (window.confirm("Confirmer la suppression ?")) {
      try {
        await fetchWithAuth(`${API_BASE_URL}/tenant/${id}/`, {
          method: "DELETE",
        });
        setTenants(tenants.filter((t) => t.id !== id));
        showSnackbar("Tenant supprimé avec succès", "success");
      } catch (error) {
        showSnackbar("Erreur lors de la suppression", "error");
      }
    }
  };

  const handleSubmit = async () => {
    try {
      const url = isEditing
        ? `${API_BASE_URL}/tenant/${currentTenant!.id}/`
        : `${API_BASE_URL}/tenant/`;
      const method = isEditing ? "PATCH" : "POST";
      const response = await fetchWithAuth(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tenant_name: currentTenant?.tenant_name,
          tenant_description: currentTenant?.tenant_description,
        }),
      });
      const result = await response.json();
      if (isEditing) {
        setTenants(
          tenants.map((t) => (t.id === currentTenant!.id ? result : t)),
        );
      } else {
        setTenants([...tenants, result]);
      }
      showSnackbar(
        `Tenant ${isEditing ? "modifié" : "ajouté"} avec succès`,
        "success",
      );
      setOpenDialog(false);
    } catch (error) {
      showSnackbar("Erreur lors de l'opération", "error");
    }
  };

  return (
    <Paper sx={{ p: 4, borderRadius: 2, boxShadow: 3 }}>
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          mb: 3,
        }}
      >
        <Typography
          variant="h5"
          component="h2"
          sx={{ fontWeight: "bold", color: "text.primary" }}
        >
          Gestion des Tenants
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={handleCreate}
          sx={{
            bgcolor: "primary.main",
            "&:hover": { bgcolor: "primary.dark" },
            borderRadius: 1,
            px: 3,
            py: 1.2,
          }}
        >
          Ajouter un Tenant
        </Button>
      </Box>

      {loading ? (
        <Box sx={{ display: "flex", justifyContent: "center", py: 4 }}>
          <CircularProgress />
        </Box>
      ) : (
        <TableContainer
          component={Paper}
          sx={{ borderRadius: 2, boxShadow: 1 }}
        >
          <Table sx={{ minWidth: 600 }}>
            <TableHead sx={{ bgcolor: "grey.100" }}>
              <TableRow>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Actions
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Nom du Tenant
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Description
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {tenants.map((tenant) => (
                <TableRow
                  key={tenant.id}
                  sx={{ "&:nth-of-type(odd)": { bgcolor: "action.hover" } }}
                >
                  <TableCell>
                    <Stack direction="row" spacing={0.5}>
                      <IconButton
                        color="primary"
                        size="small"
                        onClick={() => handleEdit(tenant)}
                      >
                        <EditIcon sx={{ fontSize: 20 }} />
                      </IconButton>
                      <IconButton
                        color="error"
                        size="small"
                        disabled={!keycloak.hasRoles("admin_role")}
                        onClick={() => handleDelete(tenant.id!)}
                      >
                        <DeleteIcon sx={{ fontSize: 20 }} />
                      </IconButton>
                    </Stack>
                  </TableCell>
                  <TableCell>{tenant.tenant_name}</TableCell>
                  <TableCell>{tenant.tenant_description}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {/* Dialog d'édition/création */}
      <Dialog
        open={openDialog}
        onClose={() => setOpenDialog(false)}
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle
          sx={{ bgcolor: "primary.main", color: "white", py: 2, px: 3 }}
        >
          <Typography variant="h6" component="span" sx={{ fontWeight: "bold" }}>
            {isEditing ? "Modifier le tenant" : "Créer un nouveau tenant"}
          </Typography>
        </DialogTitle>
        <DialogContent dividers sx={{ p: 3 }}>
          {currentTenant && (
            <Stack spacing={2}>
              <TextField
                label="Nom du tenant"
                fullWidth
                value={currentTenant.tenant_name}
                onChange={(e) =>
                  setCurrentTenant({
                    ...currentTenant,
                    tenant_name: e.target.value,
                  })
                }
                required
                variant="outlined"
                size="small"
              />
              <TextField
                label="Description du tenant"
                fullWidth
                multiline
                rows={3}
                value={currentTenant.tenant_description}
                onChange={(e) =>
                  setCurrentTenant({
                    ...currentTenant,
                    tenant_description: e.target.value,
                  })
                }
                required
                variant="outlined"
                size="small"
              />
            </Stack>
          )}
        </DialogContent>
        <DialogActions sx={{ p: 2, borderTop: "1px solid #eee" }}>
          <Button
            onClick={() => setOpenDialog(false)}
            variant="outlined"
            sx={{ borderRadius: 1 }}
          >
            Annuler
          </Button>
          <Button
            variant="contained"
            onClick={handleSubmit}
            disabled={
              !currentTenant?.tenant_name || !currentTenant?.tenant_description
            }
            sx={{
              bgcolor: "primary.main",
              "&:hover": { bgcolor: "primary.dark" },
              borderRadius: 1,
            }}
          >
            {isEditing ? "Modifier" : "Créer"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar de notification */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          sx={{ width: "100%", boxShadow: 3 }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Paper>
  );
}

// Composant CRUD pour les Persons
function CollaboratorsCRUD() {
  const [collaborators, setCollaborators] = useState<Collaborator[]>([]);
  const [filteredCollaborators, setFilteredCollaborators] = useState<
    Collaborator[]
  >([]);
  const [functionsOptions, setFunctionsOptions] = useState<Function[]>([]);
  const [selectedFunctions, setSelectedFunctions] = useState<string[]>([]);
  const [searchText, setSearchText] = useState("");
  const [currentCollaborator, setCurrentCollaborator] =
    useState<CollaboratorFormState | null>(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const { snackbar, showSnackbar, handleCloseSnackbar } = useSnackbar();

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const [collaboratorsRes, functionsRes] = await Promise.all([
          fetchWithAuth(`${API_BASE_URL}/persons`),
          fetchWithAuth(`${API_BASE_URL}/functions`),
        ]);

        const functionsData: Function[] = await functionsRes.json();
        setFunctionsOptions(functionsData);

        const collaboratorsData: Collaborator[] = await collaboratorsRes.json();
        const processedCollaborators = collaboratorsData.map((col) => ({
          ...col,
          functions: col.functions || [],
        }));
        setCollaborators(processedCollaborators);
        setFilteredCollaborators(processedCollaborators);
      } catch (error) {
        showSnackbar("Erreur lors du chargement des personnes", "error");
        console.error(error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [showSnackbar]);

  useEffect(() => {
    const lowerSearch = searchText.toLowerCase();
    const filtered = collaborators.filter((col) => {
      const matchesText =
        col.firstname.toLowerCase().includes(lowerSearch) ||
        col.lastname.toLowerCase().includes(lowerSearch) ||
        col.email.toLowerCase().includes(lowerSearch);

      const matchesFunctions =
        selectedFunctions.length === 0 ||
        selectedFunctions.every((func) => (col.functions || []).includes(func));

      return matchesText && matchesFunctions;
    });
    setFilteredCollaborators(filtered);
  }, [searchText, selectedFunctions, collaborators]);

  const handleInputChange = (
    field: keyof CollaboratorFormState,
    value: any,
  ) => {
    setCurrentCollaborator((prev) => ({ ...prev!, [field]: value }));
  };

  const handleFunctionsSelect = (selectedFunctions: Function[]) => {
    setCurrentCollaborator((prev) => ({
      ...prev!,
      functions: selectedFunctions,
    }));
  };

  const handleCreate = () => {
    setCurrentCollaborator({
      firstname: "",
      lastname: "",
      email: "",
      functions: [],
    });
    setIsEditing(false);
    setOpenDialog(true);
  };

  const handleEdit = (collaborator: Collaborator) => {
    const functionsAsObjects = (collaborator.functions || [])
      .map((funcName) =>
        functionsOptions.find((f) => f.fuction_name === funcName),
      )
      .filter(Boolean) as Function[];
    setCurrentCollaborator({ ...collaborator, functions: functionsAsObjects });
    setIsEditing(true);
    setOpenDialog(true);
  };

  const handleDelete = async (id: number) => {
    if (window.confirm("Confirmer la suppression ?")) {
      try {
        await fetchWithAuth(`${API_BASE_URL}/persons/${id}/`, {
          method: "DELETE",
        });
        setCollaborators((prev) => prev.filter((c) => c.id !== id));
        showSnackbar("Personne supprimée avec succès", "success");
      } catch (error) {
        showSnackbar("Erreur lors de la suppression", "error");
      }
    }
  };

  const handleSubmit = async () => {
    try {
      const url = isEditing
        ? `${API_BASE_URL}/persons/${currentCollaborator!.id}`
        : `${API_BASE_URL}/persons/`;
      const method = isEditing ? "PATCH" : "POST";
      const dataToSend = {
        ...currentCollaborator!,
        functions: currentCollaborator!.functions.map((f) => f.fuction_name),
      };

      const response = await fetchWithAuth(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(dataToSend),
      });
      const result = await response.json();

      setCollaborators((prev) => {
        if (isEditing) {
          return prev.map((c) => (c.id === result.id ? result : c));
        } else {
          return [...prev, result];
        }
      });

      showSnackbar(`Personne ${isEditing ? "modifiée" : "ajoutée"}`, "success");
      setOpenDialog(false);
    } catch (error) {
      showSnackbar("Erreur lors de l'opération", "error");
    }
  };

  return (
    <Paper sx={{ p: 4, borderRadius: 2, boxShadow: 3 }}>
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          mb: 3,
        }}
      >
        <Typography
          variant="h5"
          component="h2"
          sx={{ fontWeight: "bold", color: "text.primary" }}
        >
          Gestion des Personnes
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={handleCreate}
          sx={{
            bgcolor: "primary.main",
            "&:hover": { bgcolor: "primary.dark" },
            borderRadius: 1,
            px: 3,
            py: 1.2,
          }}
        >
          Ajouter une Personne
        </Button>
      </Box>

      {/* 🔍 Filtres */}
      <Stack spacing={2} sx={{ mb: 3 }}>
        <TextField
          label="Recherche (Nom, Prénom, Email)"
          fullWidth
          value={searchText}
          onChange={(e) => setSearchText(e.target.value)}
          size="small"
        />
        <FormGroup row>
          {functionsOptions.map((func) => (
            <FormControlLabel
              key={func.id}
              control={
                <Checkbox
                  checked={selectedFunctions.includes(func.fuction_name)}
                  onChange={(e) => {
                    if (e.target.checked) {
                      setSelectedFunctions((prev) => [
                        ...prev,
                        func.fuction_name,
                      ]);
                    } else {
                      setSelectedFunctions((prev) =>
                        prev.filter((f) => f !== func.fuction_name),
                      );
                    }
                  }}
                />
              }
              label={func.fuction_name}
            />
          ))}
        </FormGroup>
      </Stack>

      {loading ? (
        <Box sx={{ display: "flex", justifyContent: "center", py: 4 }}>
          <CircularProgress />
        </Box>
      ) : (
        <TableContainer
          component={Paper}
          sx={{ borderRadius: 2, boxShadow: 1 }}
        >
          <Table sx={{ minWidth: 800 }}>
            <TableHead sx={{ bgcolor: "grey.100" }}>
              <TableRow>
                <TableCell sx={{ fontWeight: "bold" }}>Actions</TableCell>
                <TableCell sx={{ fontWeight: "bold" }}>Prénom</TableCell>
                <TableCell sx={{ fontWeight: "bold" }}>Nom</TableCell>
                <TableCell sx={{ fontWeight: "bold" }}>Email</TableCell>
                <TableCell sx={{ fontWeight: "bold" }}>Fonctions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredCollaborators.map((collaborator) => (
                <TableRow
                  key={collaborator.id}
                  sx={{ "&:nth-of-type(odd)": { bgcolor: "action.hover" } }}
                >
                  <TableCell>
                    <Stack direction="row" spacing={0.5}>
                      <IconButton
                        color="primary"
                        size="small"
                        onClick={() => handleEdit(collaborator)}
                      >
                        <EditIcon sx={{ fontSize: 20 }} />
                      </IconButton>
                      <IconButton
                        color="error"
                        size="small"
                        disabled={!keycloak.hasRoles("admin_role")}
                        onClick={() => handleDelete(collaborator.id!)}
                      >
                        <DeleteIcon sx={{ fontSize: 20 }} />
                      </IconButton>
                    </Stack>
                  </TableCell>
                  <TableCell>{collaborator.firstname}</TableCell>
                  <TableCell>{collaborator.lastname}</TableCell>
                  <TableCell>{collaborator.email}</TableCell>
                  <TableCell>
                    <Stack
                      direction="row"
                      spacing={0.5}
                      useFlexGap
                      flexWrap="wrap"
                    >
                      {(collaborator.functions || []).map((funcName, index) => {
                        const funcObj = functionsOptions.find(
                          (f) => f.fuction_name === funcName,
                        );
                        return funcObj ? (
                          <Chip
                            key={funcObj.id || index}
                            label={funcObj.fuction_name}
                            size="small"
                            variant="outlined"
                          />
                        ) : (
                          <Chip
                            key={index}
                            label={funcName}
                            size="small"
                            variant="outlined"
                          />
                        );
                      })}
                    </Stack>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {/* Dialog */}
      <Dialog
        open={openDialog}
        onClose={() => setOpenDialog(false)}
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle
          sx={{ bgcolor: "primary.main", color: "white", py: 2, px: 3 }}
        >
          <Typography variant="h6">
            {isEditing ? "Modifier la personne" : "Créer une nouvelle personne"}
          </Typography>
        </DialogTitle>
        <DialogContent dividers sx={{ p: 3 }}>
          {currentCollaborator && (
            <Stack spacing={2}>
              <TextField
                label="Prénom"
                fullWidth
                value={currentCollaborator.firstname}
                onChange={(e) => handleInputChange("firstname", e.target.value)}
                required
                variant="outlined"
                size="small"
              />
              <TextField
                label="Nom"
                fullWidth
                value={currentCollaborator.lastname}
                onChange={(e) => handleInputChange("lastname", e.target.value)}
                required
                variant="outlined"
                size="small"
              />
              <TextField
                label="Email"
                fullWidth
                value={currentCollaborator.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
                required
                type="email"
                variant="outlined"
                size="small"
              />
              <Autocomplete
                multiple
                options={functionsOptions}
                getOptionLabel={(option) => option.fuction_name}
                value={currentCollaborator.functions}
                onChange={(_, newValue) => handleFunctionsSelect(newValue)}
                isOptionEqualToValue={(option, value) =>
                  option.fuction_name === value.fuction_name
                }
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Fonctions"
                    variant="outlined"
                    size="small"
                  />
                )}
                renderTags={(value, getTagProps) =>
                  value.map((option, index) => (
                    <Chip
                      {...getTagProps({ index })}
                      key={option.id}
                      label={option.fuction_name}
                      size="small"
                      sx={{
                        bgcolor: "primary.light",
                        color: "primary.contrastText",
                      }}
                    />
                  ))
                }
              />
            </Stack>
          )}
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button onClick={() => setOpenDialog(false)} variant="outlined">
            Annuler
          </Button>
          <Button
            variant="contained"
            onClick={handleSubmit}
            disabled={
              !currentCollaborator?.firstname ||
              !currentCollaborator?.lastname ||
              !currentCollaborator?.email
            }
            sx={{
              bgcolor: "primary.main",
              "&:hover": { bgcolor: "primary.dark" },
            }}
          >
            {isEditing ? "Modifier" : "Créer"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          sx={{ width: "100%", boxShadow: 3 }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Paper>
  );
}

// Composant CRUD pour les Entités
function EntitiesCRUD() {
  const [entities, setEntities] = useState<Entity[]>([]);
  const [individualsOptions, setIndividualsOptions] = useState<Person[]>([]); // Added for manager dropdown
  const [currentEntity, setCurrentEntity] = useState<Entity | null>(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const { snackbar, showSnackbar, handleCloseSnackbar } = useSnackbar();

  const entityManagerOptions = useMemo(
    () =>
      individualsOptions.filter((p) =>
        p.functions?.includes("Manager d'Entité"),
      ),
    [individualsOptions],
  );

  const fetchEntitiesAndIndividuals = useCallback(async () => {
    try {
      setLoading(true);
      const [entitiesRes, individualsRes] = await Promise.all([
        fetchWithAuth(`${API_BASE_URL}/entity`),
        fetchWithAuth(`${API_BASE_URL}/options/solutions/individuals`), // Fetch individuals
      ]);
      setEntities(await entitiesRes.json());
      setIndividualsOptions(await individualsRes.json());
    } catch (error) {
      showSnackbar(
        "Erreur lors du chargement des entités ou des individus",
        "error",
      );
      console.error(error);
    } finally {
      setLoading(false);
    }
  }, [showSnackbar]);

  useEffect(() => {
    fetchEntitiesAndIndividuals();
  }, [fetchEntitiesAndIndividuals]);

  const handleInputChange = (field: keyof Entity, value: any) => {
    setCurrentEntity((prev) => ({ ...prev!, [field]: value }));
  };

  const handleCreate = () => {
    setCurrentEntity({ entity_manager: "", entity_name: "", entity_acronym: "", is_filliale: false, activated: false });
    setIsEditing(false);
    setOpenDialog(true);
  };

  const handleEdit = (entity: Entity) => {
    setCurrentEntity(entity);
    setIsEditing(true);
    setOpenDialog(true);
  };

  const handleDelete = async (id: number) => {
    if (window.confirm("Confirmer la suppression ?")) {
      try {
        await fetchWithAuth(`${API_BASE_URL}/entity/${id}/`, {
          method: "DELETE",
        });
        setEntities(entities.filter((e) => e.id !== id));
        showSnackbar("Entité supprimée avec succès", "success");
      } catch (error) {
        showSnackbar("Erreur lors de la suppression", "error");
      }
    }
  };

  const handleSubmit = async () => {
    try {
      const url = isEditing
        ? `${API_BASE_URL}/entity/${currentEntity!.id}/`
        : `${API_BASE_URL}/entity/`;
      const method = isEditing ? "PATCH" : "POST";
      const response = await fetchWithAuth(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(currentEntity),
      });
      const result = await response.json();
      if (isEditing) {
        setEntities(
          entities.map((e) => (e.id === currentEntity!.id ? result : e)),
        );
      } else {
        setEntities([...entities, result]);
      }
      showSnackbar(
        `Entité ${isEditing ? "modifiée" : "ajoutée"} avec succès`,
        "success",
      );
      setOpenDialog(false);
    } catch (error) {
      showSnackbar("Erreur lors de l'opération", "error");
    }
  };

  return (
    <Paper sx={{ p: 4, borderRadius: 2, boxShadow: 3 }}>
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          mb: 3,
        }}
      >
        <Typography
          variant="h5"
          component="h2"
          sx={{ fontWeight: "bold", color: "text.primary" }}
        >
          Gestion des Entités
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={handleCreate}
          sx={{
            bgcolor: "primary.main",
            "&:hover": { bgcolor: "primary.dark" },
            borderRadius: 1,
            px: 3,
            py: 1.2,
          }}
        >
          Ajouter une Entité
        </Button>
      </Box>
      {loading ? (
        <Box sx={{ display: "flex", justifyContent: "center", py: 4 }}>
          <CircularProgress />
        </Box>
      ) : (
        <TableContainer
          component={Paper}
          sx={{ borderRadius: 2, boxShadow: 1 }}
        >
          <Table sx={{ minWidth: 600 }}>
            <TableHead sx={{ bgcolor: "grey.100" }}>
              <TableRow>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Manager d'Entité
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Nom de l'Entité
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Abréviation
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Active
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Filliale
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Actions
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {entities.map((entity) => (
                <TableRow
                  key={entity.id}
                  sx={{ "&:nth-of-type(odd)": { bgcolor: "action.hover" } }}
                >
                  <TableCell>{entity.entity_manager}</TableCell>
                  <TableCell>{entity.entity_name}</TableCell>
                  <TableCell>{entity.entity_acronym}</TableCell>
                  <TableCell align="center">
                    {entity.activated ? (
                      <CheckCircleIcon color="success" sx={{ fontSize: 20 }} />
                    ) : (
                      <CancelIcon color="error" sx={{ fontSize: 20 }} />
                    )}
                  </TableCell>
                  <TableCell align="center">
                    {entity.is_filliale ? (
                      <CheckCircleIcon color="success" sx={{ fontSize: 20 }} />
                    ) : (
                      <CancelIcon color="error" sx={{ fontSize: 20 }} />
                    )}
                  </TableCell>
                  <TableCell>
                    <Stack direction="row" spacing={0.5}>
                      <IconButton
                        color="primary"
                        size="small"
                        onClick={() => handleEdit(entity)}
                      >
                        <EditIcon sx={{ fontSize: 20 }} />
                      </IconButton>
                      <IconButton
                        color="error"
                        size="small"
                        disabled={!keycloak.hasRoles("admin_role")}
                        onClick={() => handleDelete(entity.id!)}
                      >
                        <DeleteIcon sx={{ fontSize: 20 }} />
                      </IconButton>
                    </Stack>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
      {/* Dialog d'édition/création */}
      <Dialog
        open={openDialog}
        onClose={() => setOpenDialog(false)}
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle
          sx={{ bgcolor: "primary.main", color: "white", py: 2, px: 3 }}
        >
          <Typography variant="h6" component="span" sx={{ fontWeight: "bold" }}>
            {isEditing ? "Modifier l'entité" : "Créer une nouvelle entité"}
          </Typography>
        </DialogTitle>
        <DialogContent dividers sx={{ p: 3 }}>
          {currentEntity && (
            <Stack spacing={2}>
              <Autocomplete
                options={entityManagerOptions}
                getOptionLabel={(option) =>
                  `${option.firstname} ${option.lastname} (${option.email})`
                }
                value={
                  entityManagerOptions.find(
                    (p) => p.email === currentEntity.entity_manager,
                  ) || null
                }
                onChange={(_, newValue) => {
                  handleInputChange(
                    "entity_manager",
                    newValue ? newValue.email : "",
                  );
                }}
                isOptionEqualToValue={(option, value) =>
                  option.email === value.email
                }
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Manager d'Entité"
                    variant="outlined"
                    size="small"
                    fullWidth
                    required
                  />
                )}
              />
              <TextField
                label="Nom de l'Entité"
                fullWidth
                value={currentEntity.entity_name}
                onChange={(e) =>
                  handleInputChange("entity_name", e.target.value)
                }
                required
                variant="outlined"
                size="small"
              />

              <TextField
                label="Abréviation"
                fullWidth
                value={currentEntity.entity_acronym}
                onChange={(e) =>
                  handleInputChange("entity_acronym", e.target.value)
                }
                required
                variant="outlined"
                size="small"
              />

              <FormControlLabel
                control={
                  <Checkbox
                    checked={currentEntity.activated}
                    onChange={(e) =>
                      handleInputChange("activated", e.target.checked)
                    }
                  />
                }
                label="Activée"
              />
              <FormControlLabel
                control={
                  <Checkbox
                    checked={currentEntity.is_filliale}
                    onChange={(e) =>
                      handleInputChange("is_filliale", e.target.checked)
                    }
                  />
                }
                label="Filliale"
              />
            </Stack>
          )}
        </DialogContent>
        <DialogActions sx={{ p: 2, borderTop: "1px solid #eee" }}>
          <Button
            onClick={() => setOpenDialog(false)}
            variant="outlined"
            sx={{ borderRadius: 1 }}
          >
            Annuler
          </Button>
          <Button
            variant="contained"
            onClick={handleSubmit}
            disabled={
              !currentEntity?.entity_name || !currentEntity?.entity_manager
            }
            sx={{
              bgcolor: "primary.main",
              "&:hover": { bgcolor: "primary.dark" },
              borderRadius: 1,
            }}
          >
            {isEditing ? "Modifier" : "Créer"}
          </Button>
        </DialogActions>
      </Dialog>
      {/* Snackbar de notification */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          sx={{ width: "100%", boxShadow: 3 }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Paper>
  );
}

// Composant CRUD pour les Pôles
function PolesCRUD() {
  const [poles, setPoles] = useState<Pole[]>([]);
  const [entitiesOptions, setEntitiesOptions] = useState<Entity[]>([]);
  const [individualsOptions, setIndividualsOptions] = useState<Person[]>([]); // Added for manager dropdown
  const [currentPole, setCurrentPole] = useState<Pole | null>(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const { snackbar, showSnackbar, handleCloseSnackbar } = useSnackbar();

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      const [polesRes, entitiesRes, individualsRes] = await Promise.all([
        fetchWithAuth(`${API_BASE_URL}/poles`),
        fetchWithAuth(`${API_BASE_URL}/entity`),
        fetchWithAuth(`${API_BASE_URL}/options/solutions/individuals`), // Fetch individuals
      ]);
      setPoles(await polesRes.json());
      setEntitiesOptions(await entitiesRes.json());
      setIndividualsOptions(await individualsRes.json());
    } catch (error) {
      showSnackbar(
        "Erreur lors du chargement des pôles ou des données associées",
        "error",
      );
      console.error(error);
    } finally {
      setLoading(false);
    }
  }, [showSnackbar]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleInputChange = (field: keyof Pole, value: any) => {
    setCurrentPole((prev) => ({ ...prev!, [field]: value }));
  };

  const handleCreate = () => {
    setCurrentPole({ entity: "", pole_manager: "", pole_name: "" });
    setIsEditing(false);
    setOpenDialog(true);
  };

  const handleEdit = (pole: Pole) => {
    setCurrentPole(pole);
    setIsEditing(true);
    setOpenDialog(true);
  };

  const handleDelete = async (id: number) => {
    if (window.confirm("Confirmer la suppression ?")) {
      try {
        await fetchWithAuth(`${API_BASE_URL}/poles/${id}/`, {
          method: "DELETE",
        });
        setPoles(poles.filter((p) => p.id !== id));
        showSnackbar("Pôle supprimé avec succès", "success");
      } catch (error) {
        showSnackbar("Erreur lors de la suppression", "error");
      }
    }
  };

  const handleSubmit = async () => {
    try {
      const url = isEditing
        ? `${API_BASE_URL}/poles/${currentPole!.id}`
        : `${API_BASE_URL}/poles/`;
      const method = isEditing ? "PATCH" : "POST";
      const response = await fetchWithAuth(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(currentPole),
      });
      const result = await response.json();
      if (isEditing) {
        setPoles(poles.map((p) => (p.id === currentPole!.id ? result : p)));
      } else {
        setPoles([...poles, result]);
      }
      showSnackbar(
        `Pôle ${isEditing ? "modifié" : "ajouté"} avec succès`,
        "success",
      );
      setOpenDialog(false);
    } catch (error) {
      showSnackbar("Erreur lors de l'opération", "error");
    }
  };
  const poleManagerOptions = useMemo(
    () =>
      individualsOptions.filter((p) =>
        p.functions?.includes("Manager de Pôle"),
      ),
    [individualsOptions],
  );

  return (
    <Paper sx={{ p: 4, borderRadius: 2, boxShadow: 3 }}>
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          mb: 3,
        }}
      >
        <Typography
          variant="h5"
          component="h2"
          sx={{ fontWeight: "bold", color: "text.primary" }}
        >
          Gestion des Pôles
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={handleCreate}
          sx={{
            bgcolor: "primary.main",
            "&:hover": { bgcolor: "primary.dark" },
            borderRadius: 1,
            px: 3,
            py: 1.2,
          }}
        >
          Ajouter un Pôle
        </Button>
      </Box>
      {loading ? (
        <Box sx={{ display: "flex", justifyContent: "center", py: 4 }}>
          <CircularProgress />
        </Box>
      ) : (
        <TableContainer
          component={Paper}
          sx={{ borderRadius: 2, boxShadow: 1 }}
        >
          <Table sx={{ minWidth: 600 }}>
            <TableHead sx={{ bgcolor: "grey.100" }}>
              <TableRow>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Entité
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Manager de Pôle
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Nom du Pôle
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Actions
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {poles.map((pole) => (
                <TableRow
                  key={pole.id}
                  sx={{ "&:nth-of-type(odd)": { bgcolor: "action.hover" } }}
                >
                  <TableCell>{pole.entity}</TableCell>
                  <TableCell>{pole.pole_manager}</TableCell>
                  <TableCell>{pole.pole_name}</TableCell>
                  <TableCell>
                    <Stack direction="row" spacing={0.5}>
                      <IconButton
                        color="primary"
                        size="small"
                        onClick={() => handleEdit(pole)}
                      >
                        <EditIcon sx={{ fontSize: 20 }} />
                      </IconButton>
                      <IconButton
                        color="error"
                        size="small"
                        disabled={!keycloak.hasRoles("admin_role")}
                        onClick={() => handleDelete(pole.id!)}
                      >
                        <DeleteIcon sx={{ fontSize: 20 }} />
                      </IconButton>
                    </Stack>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
      {/* Dialog d'édition/création */}
      <Dialog
        open={openDialog}
        onClose={() => setOpenDialog(false)}
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle
          sx={{ bgcolor: "primary.main", color: "white", py: 2, px: 3 }}
        >
          <Typography variant="h6" component="span" sx={{ fontWeight: "bold" }}>
            {isEditing ? "Modifier le pôle" : "Créer un nouveau pôle"}
          </Typography>
        </DialogTitle>
        <DialogContent dividers sx={{ p: 3 }}>
          {currentPole && (
            <Stack spacing={2}>
              <FormControl fullWidth required variant="outlined" size="small">
                <InputLabel>Entité</InputLabel>
                <Select
                  value={currentPole.entity}
                  onChange={(e) => handleInputChange("entity", e.target.value)}
                  label="Entité"
                >
                  {entitiesOptions.map((entity) => (
                    <MenuItem key={entity.id} value={entity.entity_name}>
                      {entity.entity_name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              <Autocomplete
                options={poleManagerOptions}
                getOptionLabel={(option) =>
                  `${option.firstname} ${option.lastname} (${option.email})`
                }
                value={
                  poleManagerOptions.find(
                    (p) => p.email === currentPole.pole_manager,
                  ) || null
                }
                onChange={(_, newValue) => {
                  handleInputChange(
                    "pole_manager",
                    newValue ? newValue.email : "",
                  );
                }}
                isOptionEqualToValue={(option, value) =>
                  option.email === value.email
                }
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Manager de Pôle"
                    variant="outlined"
                    size="small"
                    fullWidth
                    required
                  />
                )}
              />
              <TextField
                label="Nom du Pôle"
                fullWidth
                value={currentPole.pole_name}
                onChange={(e) => handleInputChange("pole_name", e.target.value)}
                required
                variant="outlined"
                size="small"
              />
            </Stack>
          )}
        </DialogContent>
        <DialogActions sx={{ p: 2, borderTop: "1px solid #eee" }}>
          <Button
            onClick={() => setOpenDialog(false)}
            variant="outlined"
            sx={{ borderRadius: 1 }}
          >
            Annuler
          </Button>
          <Button
            variant="contained"
            onClick={handleSubmit}
            disabled={
              !currentPole?.entity ||
              !currentPole?.pole_name ||
              !currentPole?.pole_manager
            }
            sx={{
              bgcolor: "primary.main",
              "&:hover": { bgcolor: "primary.dark" },
              borderRadius: 1,
            }}
          >
            {isEditing ? "Modifier" : "Créer"}
          </Button>
        </DialogActions>
      </Dialog>
      {/* Snackbar de notification */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          sx={{ width: "100%", boxShadow: 3 }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Paper>
  );
}

// Composant CRUD pour les Domaines
function DomainsCRUD() {
  const [domains, setDomains] = useState<Domain[]>([]);
  const [polesOptions, setPolesOptions] = useState<Pole[]>([]);
  const [individualsOptions, setIndividualsOptions] = useState<Person[]>([]); // Added for manager dropdown
  const [currentDomain, setCurrentDomain] = useState<Domain | null>(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const { snackbar, showSnackbar, handleCloseSnackbar } = useSnackbar();

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      const [domainsRes, polesRes, individualsRes] = await Promise.all([
        fetchWithAuth(`${API_BASE_URL}/domains`),
        fetchWithAuth(`${API_BASE_URL}/poles`),
        fetchWithAuth(`${API_BASE_URL}/options/solutions/individuals`), // Fetch individuals
      ]);
      setDomains(await domainsRes.json());
      setPolesOptions(await polesRes.json());
      setIndividualsOptions(await individualsRes.json());
    } catch (error) {
      showSnackbar(
        "Erreur lors du chargement des domaines ou des données associées",
        "error",
      );
      console.error(error);
    } finally {
      setLoading(false);
    }
  }, [showSnackbar]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleInputChange = (field: keyof Domain, value: any) => {
    setCurrentDomain((prev) => ({ ...prev!, [field]: value }));
  };

  const handleCreate = () => {
    setCurrentDomain({ pole: "", domain_manager: "", domain_name: "" });
    setIsEditing(false);
    setOpenDialog(true);
  };

  const handleEdit = (domain: Domain) => {
    setCurrentDomain(domain);
    setIsEditing(true);
    setOpenDialog(true);
  };

  const handleDelete = async (id: number) => {
    if (window.confirm("Confirmer la suppression ?")) {
      try {
        await fetchWithAuth(`${API_BASE_URL}/domains/${id}/`, {
          method: "DELETE",
        });
        setDomains(domains.filter((d) => d.id !== id));
        showSnackbar("Domaine supprimé avec succès", "success");
      } catch (error) {
        showSnackbar("Erreur lors de la suppression", "error");
      }
    }
  };

  const handleSubmit = async () => {
    try {
      const url = isEditing
        ? `${API_BASE_URL}/domains/${currentDomain!.id}`
        : `${API_BASE_URL}/domains/`;
      const method = isEditing ? "PATCH" : "POST";
      const response = await fetchWithAuth(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(currentDomain),
      });
      const result = await response.json();
      if (isEditing) {
        setDomains(
          domains.map((d) => (d.id === currentDomain!.id ? result : d)),
        );
      } else {
        setDomains([...domains, result]);
      }
      showSnackbar(
        `Domaine ${isEditing ? "modifié" : "ajouté"} avec succès`,
        "success",
      );
      setOpenDialog(false);
    } catch (error) {
      showSnackbar("Erreur lors de l'opération", "error");
    }
  };

  const domainManagerOptions = useMemo(
    () =>
      individualsOptions.filter((p) =>
        p.functions?.includes("Manager de Domaine"),
      ),
    [individualsOptions],
  );

  return (
    <Paper sx={{ p: 4, borderRadius: 2, boxShadow: 3 }}>
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          mb: 3,
        }}
      >
        <Typography
          variant="h5"
          component="h2"
          sx={{ fontWeight: "bold", color: "text.primary" }}
        >
          Gestion des Domaines
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={handleCreate}
          sx={{
            bgcolor: "primary.main",
            "&:hover": { bgcolor: "primary.dark" },
            borderRadius: 1,
            px: 3,
            py: 1.2,
          }}
        >
          Ajouter un Domaine
        </Button>
      </Box>
      {loading ? (
        <Box sx={{ display: "flex", justifyContent: "center", py: 4 }}>
          <CircularProgress />
        </Box>
      ) : (
        <TableContainer
          component={Paper}
          sx={{ borderRadius: 2, boxShadow: 1 }}
        >
          <Table sx={{ minWidth: 600 }}>
            <TableHead sx={{ bgcolor: "grey.100" }}>
              <TableRow>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Pôle
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Manager de Domaine
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Nom du Domaine
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Actions
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {domains.map((domain) => (
                <TableRow
                  key={domain.id}
                  sx={{ "&:nth-of-type(odd)": { bgcolor: "action.hover" } }}
                >
                  <TableCell>{domain.pole}</TableCell>
                  <TableCell>{domain.domain_manager}</TableCell>
                  <TableCell>{domain.domain_name}</TableCell>
                  <TableCell>
                    <Stack direction="row" spacing={0.5}>
                      <IconButton
                        color="primary"
                        size="small"
                        onClick={() => handleEdit(domain)}
                      >
                        <EditIcon sx={{ fontSize: 20 }} />
                      </IconButton>
                      <IconButton
                        color="error"
                        size="small"
                        disabled={!keycloak.hasRoles("admin_role")}
                        onClick={() => handleDelete(domain.id!)}
                      >
                        <DeleteIcon sx={{ fontSize: 20 }} />
                      </IconButton>
                    </Stack>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
      {/* Dialog d'édition/création */}
      <Dialog
        open={openDialog}
        onClose={() => setOpenDialog(false)}
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle
          sx={{ bgcolor: "primary.main", color: "white", py: 2, px: 3 }}
        >
          <Typography variant="h6" component="span" sx={{ fontWeight: "bold" }}>
            {isEditing ? "Modifier le domaine" : "Créer un nouveau domaine"}
          </Typography>
        </DialogTitle>
        <DialogContent dividers sx={{ p: 3 }}>
          {currentDomain && (
            <Stack spacing={2}>
              <FormControl fullWidth required variant="outlined" size="small">
                <InputLabel>Pôle</InputLabel>
                <Select
                  value={currentDomain.pole}
                  onChange={(e) => handleInputChange("pole", e.target.value)}
                  label="Pôle"
                >
                  {polesOptions.map((pole) => (
                    <MenuItem key={pole.id} value={pole.pole_name}>
                      {pole.pole_name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              <Autocomplete
                options={domainManagerOptions}
                getOptionLabel={(option) =>
                  `${option.firstname} ${option.lastname} (${option.email})`
                }
                value={
                  domainManagerOptions.find(
                    (p) => p.email === currentDomain.domain_manager,
                  ) || null
                }
                onChange={(_, newValue) => {
                  handleInputChange(
                    "domain_manager",
                    newValue ? newValue.email : "",
                  );
                }}
                isOptionEqualToValue={(option, value) =>
                  option.email === value.email
                }
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Manager de Domaine"
                    variant="outlined"
                    size="small"
                    fullWidth
                    required
                  />
                )}
              />
              <TextField
                label="Nom du Domaine"
                fullWidth
                value={currentDomain.domain_name}
                onChange={(e) =>
                  handleInputChange("domain_name", e.target.value)
                }
                required
                variant="outlined"
                size="small"
              />
            </Stack>
          )}
        </DialogContent>
        <DialogActions sx={{ p: 2, borderTop: "1px solid #eee" }}>
          <Button
            onClick={() => setOpenDialog(false)}
            variant="outlined"
            sx={{ borderRadius: 1 }}
          >
            Annuler
          </Button>
          <Button
            variant="contained"
            onClick={handleSubmit}
            disabled={
              !currentDomain?.pole ||
              !currentDomain?.domain_name ||
              !currentDomain?.domain_manager
            }
            sx={{
              bgcolor: "primary.main",
              "&:hover": { bgcolor: "primary.dark" },
              borderRadius: 1,
            }}
          >
            {isEditing ? "Modifier" : "Créer"}
          </Button>
        </DialogActions>
      </Dialog>
      {/* Snackbar de notification */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          sx={{ width: "100%", boxShadow: 3 }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Paper>
  );
}

// Page principale avec onglets
export default function AdministrationPage() {
  const [tabValue, setTabValue] = useState(0);

  const handleTabChange = (_event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  return (
    <Container maxWidth="xl" sx={{ py: 4 }}>
      <Typography
        variant="h4"
        component="h1"
        gutterBottom
        sx={{ fontWeight: "bold", mb: 4, color: "text.primary" }}
      >
        Panneau de paramétrage
      </Typography>
      <Tabs
        value={tabValue}
        onChange={handleTabChange}
        sx={{
          mb: 4,
          borderBottom: 1,
          borderColor: "divider",
          "& .MuiTabs-indicator": { bgcolor: "primary.main" },
          "& .MuiTab-root": {
            textTransform: "none",
            fontWeight: "bold",
            fontSize: "1.1rem",
            color: "text.secondary",
            "&.Mui-selected": {
              color: "primary.main",
            },
          },
        }}
      >
        <Tab label="Solutions" />
        <Tab label="Personnes" />
        <Tab label="Entités" />
        <Tab label="Pôles" />
        <Tab label="Domaines" />
        <Tab label="Type de Service" /> {/* New Tab */}
        <Tab label="Tenant" /> {/* New Tab */}
        <Tab label="Fonctions" />
        <Tab label="Natures de Serveurs" /> {/* New Tab */}
      </Tabs>
      {tabValue === 0 && <SolutionsCRUD />}
      {tabValue === 1 && <CollaboratorsCRUD />}
      {tabValue === 2 && <EntitiesCRUD />}
      {tabValue === 3 && <PolesCRUD />}
      {tabValue === 4 && <DomainsCRUD />}
      {tabValue === 5 && <ServiceTypesCRUD />} {/* New Component */}
      {tabValue === 6 && <TenantsCRUD />} {/* New Component */}
      {tabValue === 7 && <FunctionsCRUD />}
      {tabValue === 8 && <ServerNaturesCRUD />} {/* New Component */}
    </Container>
  );
}
