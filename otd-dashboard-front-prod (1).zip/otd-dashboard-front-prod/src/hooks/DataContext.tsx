// src/hooks/DataContext.tsx

import React, { createContext, useContext, useState, ReactNode } from "react";
import { HostView } from "@/types/view/HostView";

interface DataContextType {
  bigFixData: HostView | null;
  inventoryData: HostView | null;
  setBigFixData: (data: HostView | null) => void;
  setInventoryData: (data: HostView | null) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: ReactNode }> = ({
  children,
}) => {
  const [bigFixData, setBigFixData] = useState<HostView | null>(null);
  const [inventoryData, setInventoryData] = useState<HostView | null>(null);

  return (
    <DataContext.Provider
      value={{ bigFixData, inventoryData, setBigFixData, setInventoryData }}
    >
      {children}
    </DataContext.Provider>
  );
};

// eslint-disable-next-line react-refresh/only-export-components
export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error("useData must be used within a DataProvider");
  }
  return context;
};
