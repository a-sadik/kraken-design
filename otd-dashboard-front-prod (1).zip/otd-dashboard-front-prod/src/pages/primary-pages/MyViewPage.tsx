import React, { useState, useEffect, useMemo, useCallback } from "react";
import {
  Box,
  Typography,
  Chip,
  Paper,
  Container,
  TextField,
  InputAdornment,
  Skeleton,
  Alert,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Avatar,
  Tooltip,
  Card,
  CardContent,
  Breadcrumbs,
  IconButton,
  CircularProgress,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  LinearProgress,
  Menu,
  MenuItem,
  ListItemIcon,
  ListItemText,
  FormControl,
  FormHelperText,
  InputLabel,
  Select,
} from "@mui/material";

import {
  FaFilePdf,
  FaFileExcel,
  FaFilePowerpoint,
  FaFileWord,
  FaFileAlt,
  FaFileImage,
  FaFile,
} from "react-icons/fa";

import { alpha } from "@mui/material/styles";
import {
  Search,
  Person,
  Apps,
  CheckCircle,
  Cancel,
  NavigateNext,
  Home,
  ArrowUpward,
  ArrowDownward,
  CloudUpload,
  AttachFile,
  CloudDownload,
  MoreVert,
  Description,
  InsertDriveFile,
} from "@mui/icons-material";
import { FiServer } from "react-icons/fi";
import { VscSymbolNamespace } from "react-icons/vsc";
import { LuRocket } from "react-icons/lu";
import { hardware_info_openshift_info, getMyView_Documents_ApiUrl, getMyViewApiUrl } from "@/config/api.config";
import { getMyViewRootApiUrl } from "@/components/topology/config/topology-config";
import SolutionDetailView from "@/components/shared/SolutionDetailsView";
import fetchWithAuth from "@/middleware/fetch-auth";
import { psiColors, theme } from "@/utils/getDynamicColor";

const serviceTypeColors: Record<string, string> = {
  Technique: "#8B5CF6",
  Métier: "#06B6D4",
  Support: "#F59E0B",
};

const colors = {
  solution: "#b3e6ff",
  server: "#99caff",
  namespace: "#a8e6b1",
  deployment: "#f3aebd",
};

interface Solution {
  count_documents: number;
  id: number;
  solution_name: string;
  solution_type: string;
  solution_role: string;
  psi: string;
  domain: string;
  pole?: string;
  entity?: string;
  tams: string[];
  technical_admins: string[];
  functional_admins: string[];
  declarted_on_bigfix: boolean;
  declarted_on_itop: boolean;
  fiable: boolean;
  activated: boolean;
  service_type: string;
  tenant: string;
  tenant_details: string;
  solution_popularity?: string;
  caas_resources?: {
    total_cpu_caas: string;
    total_ram_caas: string;
  };

  // métriques de l'API my-view
  count_servers?: number;
  count_pods?: number;
  count_namespaces?: number;
  count_deployments?: number;
  count_request?: number;
  count_cab?: number;
  count_ecab?: number;
  count_technical_admins?: number;
  count_functional_admins?: number;
  count_tams?: number;

  // données de l'API my-view
  list_solutions_types: string[];
  list_environnements: string[];
  child_namespace: string;
  child_pods: string;
  child_servers: any[];
  child_itop: {
    requests_url: string;
    cab_url: string;
    ecab_url: string;
  };
  list_admins: {
    prod_architects: any;
    dsa_architects: any;
    technical_admins: Array<{ email: string; name: string }>;
    functional_admins: Array<{ email: string; name: string }>;
    tams: Array<{ email: string; name: string }>;
  };

  // Données calculées
  pods_by_env?: { [key: string]: number };
  servers_by_env?: { [key: string]: number };
}

interface ApiResponse {
  applications: Solution[];
  count: {
    solutions: number;
    servers: number;
    namespaces: number;
    pods: number;
    deployments: number;
  };
  roles: {
    TAM: number;
    "Technical Admin": number;
    "Functional Admin": number;
  };
}

interface BreadcrumbItem {
  name: string;
  level: string;
  data: any;
  elementId: string;
}

interface NavigationState {
  currentLevel: "list" | "solutionDetail";
  currentItem: any;
  breadcrumb: BreadcrumbItem[];
}

// Types pour le tri
type SortField =
  | "solution_name"
  | "psi"
  | "count_servers"
  | "count_pods"
  | "count_namespaces"
  | "count_deployments"
  | "tenant"
  | "count_request"
  | "count_cab"
  | "count_ecab"
  | "count_documents";
type SortDirection = "asc" | "desc";

interface SortConfig {
  field: SortField;
  direction: SortDirection;
}

// Interface pour l'upload
interface UploadState {
  open: boolean;
  solutionId: number | null;
  solutionName: string;
  file: File | null;
  version: string;
  uploading: boolean;
  progress: number;
  error: string | null;
}

// Interface pour le download
interface DownloadState {
  open: boolean;
  solutionId: number | null;
  solutionName: string;
  version: string;
  downloading: boolean;
  error: string | null;
}

interface VersionsState {
  loading: boolean;
  versions: string[];
  error: string | null;
}

// Hook personnalisé pour le debounce
const useDebounce = (value: string, delay: number) => {
  const [debouncedValue, setDebouncedValue] = useState(value);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);

  return debouncedValue;
};

const MyViewPage: React.FC = () => {
  const [solutions, setSolutions] = useState<Solution[]>([]);
  const [filteredSolutions, setFilteredSolutions] = useState<Solution[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [userInfo, setUserInfo] = useState<{ email: string; name: string }>({
    email: "",
    name: "",
  });

  const [caasData, setCaasData] = useState<Map<string, Map<string, any>>>(new Map());
  const [caasLoading, setCaasLoading] = useState<Set<string>>(new Set());



  // Nouvel état pour les totaux
  const [totals, setTotals] = useState({
    solutions: 0,
    servers: 0,
    namespaces: 0,
    pods: 0,
    deployments: 0
  });

  // États pour la navigation et la vue détaillée
  const [navigation, setNavigation] = useState<NavigationState>({
    currentLevel: "list",
    currentItem: null,
    breadcrumb: [],
  });
  const [solutionViewTab, setSolutionViewTab] = useState<Map<string, number>>(
    new Map(),
  );
  const [environmentTabs, setEnvironmentTabs] = useState<Map<string, number>>(
    new Map(),
  );
  const [selectedPodEnvironments, setSelectedPodEnvironments] = useState<
    Map<string, string>
  >(new Map());
  const [showRoleDetails, setShowRoleDetails] = useState(false);
  const [detailLoading, setDetailLoading] = useState(false);
  const [podsData, setPodsData] = useState<Map<string, any[]>>(new Map());
  const [serversData, setServersData] = useState<Map<string, any[]>>(new Map());

  // État pour le tri
  const [sortConfig, setSortConfig] = useState<SortConfig>({
    field: "solution_name",
    direction: "asc",
  });

  // État pour l'upload
  const [uploadState, setUploadState] = useState<UploadState>({
    open: false,
    solutionId: null,
    solutionName: "",
    file: null,
    version: "0.0.1",
    uploading: false,
    progress: 0,
    error: null,
  });

  // État pour le download
  const [downloadState, setDownloadState] = useState<DownloadState>({
    open: false,
    solutionId: null,
    solutionName: "",
    version: "0.0.1",
    downloading: false,
    error: null,
  });

  // État pour le menu contextuel
  const [actionMenu, setActionMenu] = useState<{
    anchorEl: null | HTMLElement;
    solution: Solution | null;
  }>({
    anchorEl: null,
    solution: null,
  });

  const [versionsState, setVersionsState] = useState<VersionsState>({
    loading: false,
    versions: [],
    error: null,
  });

  const [versionsBySolution, setVersionsBySolution] = useState<Map<number, string[]>>(new Map());

  // Fonction pour formater les ressources CaaS
  // const formatCaasResource = (value: string | number, type: 'cpu' | 'ram') => {
  //   if (value === null || value === undefined) return "0";

  //   const normalized = typeof value === 'string' ? value.replace(',', '.') : String(value);
  //   const numValue = parseFloat(normalized);

  //   if (!Number.isFinite(numValue)) return "0";

  //   const fmt = (n: number, decimals = 1) => {
  //     const s = n.toFixed(decimals);
  //     return s.endsWith('.0') ? s.slice(0, -2) : s;
  //   };

  //   switch (type) {
  //     case 'cpu':
  //       // Convertir les millicores en cores
  //       if (numValue >= 1000) {
  //         return `${fmt(numValue / 1000)} cores`;
  //       } else {
  //         return `${fmt(numValue)} millicores`;
  //       }

  //     case 'ram':
  //       // Convertir les Mio en Gio
  //       if (numValue >= 1024) {
  //         return `${fmt(numValue / 1024)} Gio`;
  //       } else {
  //         return `${fmt(numValue)} Mio`;
  //       }

  //     default:
  //       return `${numValue}`;
  //   }
  // };

  // Fonction pour récupérer les données CaaS pour TOUT le niveau
  const fetchCaasDataForLevel = async (scope: string) => {
    const caasKey = `${scope}-level-caas`;

    if (caasData.has(caasKey) || caasLoading.has(caasKey)) {
      return caasData.get(caasKey) || new Map();
    }

    setCaasLoading((prev: Set<string>) => new Set(prev).add(caasKey));

    try {
      console.log(`☸️ Envoi requête CaaS pour scope: ${scope}`);

      const response = await fetchWithAuth(hardware_info_openshift_info(), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ scope: scope }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      const caasArray = Array.isArray(data) ? data : [];
      const caasMap = new Map();

      caasArray.forEach((caasItem: any) => {
        if (!caasItem) return;

        let itemName = caasItem.solution_name || "";

        if (itemName && itemName !== "undefined" && itemName.trim() !== "") {
          caasMap.set(itemName, {
            total_cpu_caas: caasItem.total_cpu_m || "0",
            total_ram_caas: caasItem.total_ram_mi || "0",
            total_disk_caas: "0",
            total_pods: "0",
            total_namespaces: "0",
            total_deployments: "0"
          });
        }
      });

      setCaasData((prev: Map<string, Map<string, any>>) => {
        const newMap = new Map(prev);
        newMap.set(caasKey, caasMap);
        return newMap;
      });

      return caasMap;
    } catch (error) {
      console.error(`❌ Erreur CaaS pour le niveau ${scope}:`, error);
      return new Map();
    } finally {
      setCaasLoading((prev: Set<string>) => {
        const newSet = new Set(prev);
        newSet.delete(caasKey);
        return newSet;
      });
    }
  };

  // Fonction utilitaire pour récupérer les données CaaS d'un item spécifique
  const getCaasDataForItem = (scope: string, itemName: string) => {
    const caasKey = `${scope}-level-caas`;
    const levelCaasData = caasData.get(caasKey);

    if (!levelCaasData || !(levelCaasData instanceof Map)) {
      return null;
    }

    // Chercher par nom exact d'abord
    let itemData = levelCaasData.get(itemName);
    if (itemData) {
      return itemData;
    }

    // Si pas trouvé, essayer de nettoyer le nom
    const cleanName = (name: string) => {
      return name
        .replace(/\(.*?\)/g, '') // Supprimer les parenthèses et leur contenu
        .replace(/\s+/g, ' ')
        .trim();
    };

    const cleanedItemName = cleanName(itemName);

    // Chercher avec le nom nettoyé
    for (const [caasName, caasData] of levelCaasData.entries()) {
      const cleanedCaasName = cleanName(caasName);
      if (cleanedCaasName === cleanedItemName) {
        return caasData;
      }
    }

    // Chercher par inclusion
    for (const [caasName, caasData] of levelCaasData.entries()) {
      const cleanedCaasName = cleanName(caasName);
      if (cleanedCaasName.includes(cleanedItemName) || cleanedItemName.includes(cleanedCaasName)) {
        return caasData;
      }
    }
    return null;
  };



  // Utilisation du debounce pour la recherche
  const debouncedSearchTerm = useDebounce(searchTerm, 300);

  // Récupérer les infos utilisateur depuis le token
  useEffect(() => {
    const getUserInfo = () => {
      try {
        let token =
          localStorage.getItem("bearerToken") ||
          localStorage.getItem("access_token") ||
          localStorage.getItem("token");

        if (token) {
          const payload = JSON.parse(atob(token.split(".")[1]));
          const email = payload.email || payload.preferred_username;
          const name =
            payload.name ||
            (payload.given_name && payload.family_name
              ? `${payload.given_name} ${payload.family_name}`
              : payload.preferred_username);

          if (email) {
            setUserInfo({ email, name });
          }
        }
      } catch (err) {
        console.error("❌ Erreur décodage token:", err);
      }
    };

    getUserInfo();
  }, []);


  // useEffect de fetchMyViewSolutions
  useEffect(() => {
    const fetchMyViewSolutions = async () => {
      setLoading(true);
      try {
        let token =
          localStorage.getItem("bearerToken") ||
          localStorage.getItem("access_token") ||
          localStorage.getItem("token");

        if (!token) {
          throw new Error("Aucun token d'authentification trouvé");
        }

        // Appeler l'API my-view
        const response = await fetch(getMyViewApiUrl(), {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        });

        if (!response.ok) {
          throw new Error(
            `Erreur ${response.status}: ${response.statusText}`,
          );
        }

        const apiData: ApiResponse = await response.json();
        const solutionsData = apiData.applications;

        // Stocker les totaux directement depuis l'API
        setTotals({
          solutions: apiData.count.solutions || 0,
          servers: apiData.count.servers || 0,
          namespaces: apiData.count.namespaces || 0,
          pods: apiData.count.pods || 0,
          deployments: apiData.count.deployments || 0
        });

        // AJOUTER: Charger les données CaaS pour les solutions
        await fetchCaasDataForLevel('solutions');

        const enrichedSolutions = solutionsData.map((solution) => {
          // Récupérer les données CaaS pour cette solution
          const caasDataForSolution = getCaasDataForItem('solutions', solution.solution_name);

          return {
            ...solution,
            // Utiliser les données directement de l'API my-view
            count_servers: solution.count_servers || 0,
            count_pods: solution.count_pods || 0,
            count_namespaces: solution.count_namespaces || 0,
            count_deployments: solution.count_deployments || 0,
            count_request: solution.count_request || 0,
            count_cab: solution.count_cab || 0,
            count_ecab: solution.count_ecab || 0,
            count_technical_admins: solution.count_technical_admins || 0,
            count_functional_admins: solution.count_functional_admins || 0,
            count_tams: solution.count_tams || 0,
            // Ajouter les données CaaS
            caas_resources: caasDataForSolution || null,
          };
        });

        setSolutions(enrichedSolutions);
        setError(null);
      } catch (err) {
        console.error("💥 Erreur:", err);
        setError(
          "Erreur lors du chargement des solutions: " + (err as Error).message,
        );
      } finally {
        setLoading(false);
      }
    };

    fetchMyViewSolutions();
  }, []);

  // Filtrer les solutions par utilisateur
  useEffect(() => {
    if (solutions.length > 0) {
      setFilteredSolutions(solutions);
    }
  }, [solutions]);

  // Fonction de tri
  const sortedSolutions = useMemo(() => {
    const solutionsToSort = [...filteredSolutions];

    return solutionsToSort.sort((a, b) => {
      let aValue: any;
      let bValue: any;

      switch (sortConfig.field) {
        case "solution_name":
          aValue = a.solution_name.toLowerCase();
          bValue = b.solution_name.toLowerCase();
          break;
        case "psi":
          aValue = a.psi;
          bValue = b.psi;
          break;
        case "count_servers":
          aValue = a.count_servers || 0;
          bValue = b.count_servers || 0;
          break;
        case "count_pods":
          aValue = a.count_pods || 0;
          bValue = b.count_pods || 0;
          break;
        case "count_namespaces":
          aValue = a.count_namespaces || 0;
          bValue = b.count_namespaces || 0;
          break;
        case "count_deployments":
          aValue = a.count_deployments || 0;
          bValue = b.count_deployments || 0;
          break;
        case "count_request":
          aValue = a.count_request || 0;
          bValue = b.count_request || 0;
          break;
        case "count_cab":
          aValue = a.count_cab || 0;
          bValue = b.count_cab || 0;
          break;
        case "count_ecab":
          aValue = a.count_ecab || 0;
          bValue = b.count_ecab || 0;
          break;
        case "tenant":
          aValue = (a.tenant || "").toLowerCase();
          bValue = (b.tenant || "").toLowerCase();
          break;
        case "count_documents":
          aValue = a.count_documents || 0;
          bValue = b.count_documents || 0;
          break;
        default:
          return 0;
      }

      if (aValue < bValue) {
        return sortConfig.direction === "asc" ? -1 : 1;
      }
      if (aValue > bValue) {
        return sortConfig.direction === "asc" ? 1 : -1;
      }
      return 0;
    });
  }, [filteredSolutions, sortConfig]);

  // Filtrer par recherche avec debounce
  const searchedSolutions = useMemo(() => {
    let filtered = sortedSolutions;

    // Appliquer la recherche
    if (debouncedSearchTerm.trim()) {
      filtered = filtered.filter(
        (solution) =>
          solution.solution_name
            .toLowerCase()
            .includes(debouncedSearchTerm.toLowerCase()) ||
          solution.domain
            ?.toLowerCase()
            .includes(debouncedSearchTerm.toLowerCase()) ||
          solution.pole
            ?.toLowerCase()
            .includes(debouncedSearchTerm.toLowerCase()) ||
          solution.entity
            ?.toLowerCase()
            .includes(debouncedSearchTerm.toLowerCase()) ||
          solution.tenant
            ?.toLowerCase()
            .includes(debouncedSearchTerm.toLowerCase()) ||
          solution.solution_type
            ?.toLowerCase()
            .includes(debouncedSearchTerm.toLowerCase()) ||
          solution.solution_popularity
            ?.toLowerCase()
            .includes(debouncedSearchTerm.toLowerCase()) ||
          solution.list_solutions_types?.some((type: string) =>
            type.toLowerCase().includes(debouncedSearchTerm.toLowerCase())
          )
      );
    }

    return filtered;
  }, [sortedSolutions, debouncedSearchTerm]);

  // Fonction pour gérer le clic sur un en-tête de colonne
  const handleSort = useCallback((field: SortField) => {
    setSortConfig((prevConfig) => ({
      field,
      direction:
        prevConfig.field === field && prevConfig.direction === "asc"
          ? "desc"
          : "asc",
    }));
  }, []);

  // Fonction pour obtenir l'icône de tri
  const getSortIcon = useCallback(
    (field: SortField) => {
      if (sortConfig.field !== field) return null;

      return sortConfig.direction === "asc" ? (
        <ArrowUpward sx={{ fontSize: 16, ml: 0.5 }} />
      ) : (
        <ArrowDownward sx={{ fontSize: 16, ml: 0.5 }} />
      );
    },
    [sortConfig],
  );

  const isUserAuthorized = useCallback((solution: Solution) => {
    if (!userInfo.email) return false;

    const userEmailLower = userInfo.email.toLowerCase();

    // Vérifier si l'utilisateur est TAM
    const isTam = solution.list_admins?.tams?.some((tam: { email: string; name: string }) =>
      tam.email.toLowerCase().includes(userEmailLower)
    );

    // Vérifier si l'utilisateur est Architecte DSA
    const isDsaArchitect = solution.list_admins?.dsa_architects?.some((arch: { email: string; name: string }) =>
      arch.email.toLowerCase().includes(userEmailLower)
    );

    // Vérifier si l'utilisateur est Architecte Prod
    const isProdArchitect = solution.list_admins?.prod_architects?.some((arch: { email: string; name: string }) =>
      arch.email.toLowerCase().includes(userEmailLower)
    );

    // Vérifier si l'utilisateur est Admin technique
    const isAdminTech = solution.list_admins?.technical_admins?.some((arch: { email: string; name: string }) =>
      arch.email.toLowerCase().includes(userEmailLower)
    );

    return isTam || isDsaArchitect || isProdArchitect || isAdminTech;
  }, [userInfo.email]);

  const fetchVersions = useCallback(async (solutionId: number) => {
    setVersionsState(prev => ({ ...prev, loading: true, error: null }));

    try {
      const token = localStorage.getItem("bearerToken") ||
        localStorage.getItem("access_token") ||
        localStorage.getItem("token");

      if (!token) {
        throw new Error("Aucun token d'authentification trouvé");
      }

      const response = await fetch(
        `${getMyView_Documents_ApiUrl()}${solutionId}`,
        {
          headers: {
            "Authorization": `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );

      if (!response.ok) {
        throw new Error(`Erreur ${response.status}: ${response.statusText}`);
      }

      const versions = await response.json();
      const versionsArray = Array.isArray(versions) ? versions : [];

      // Stocker les versions pour cette solution
      setVersionsBySolution(prev => new Map(prev).set(solutionId, versionsArray));

      setVersionsState({
        loading: false,
        versions: versionsArray,
        error: null,
      });

      return versionsArray;
    } catch (err) {
      setVersionsState({
        loading: false,
        versions: [],
        error: "Erreur lors du chargement des versions: " + (err as Error).message,
      });
      return [];
    }
  }, []);

  const isVersionExists = useCallback((version: string, _solutionId: number) => {
    return versionsState.versions.includes(version);
  }, [versionsState.versions]);

  // Fonctions pour le menu d'actions
  const handleOpenActionMenu = useCallback((event: React.MouseEvent<HTMLElement>, solution: Solution) => {
    setActionMenu({
      anchorEl: event.currentTarget,
      solution,
    });
  }, []);

  const handleCloseActionMenu = useCallback(() => {
    setActionMenu({
      anchorEl: null,
      solution: null,
    });
  }, []);

  // Fonctions pour l'upload
  const handleOpenUpload = useCallback(async (solution: Solution) => {
    // Vérifier si l'utilisateur est TAM de cette solution
    if (!isUserAuthorized(solution)) {
      setUploadState(prev => ({
        ...prev,
        error: "Seuls les TAM/Architectes de cette solution peuvent uploader des documents",
      }));
      handleCloseActionMenu();
      return;
    }

    setUploadState({
      open: true,
      solutionId: solution.id,
      solutionName: solution.solution_name,
      file: null,
      version: "", // Version vide au début
      uploading: false,
      progress: 0,
      error: null,
    });
    handleCloseActionMenu();
  }, [isUserAuthorized, handleCloseActionMenu]);

  const handleCloseUpload = useCallback(() => {
    setUploadState({
      open: false,
      solutionId: null,
      solutionName: "",
      file: null,
      version: "0.0.1",
      uploading: false,
      progress: 0,
      error: null,
    });
  }, []);

  const handleFileSelect = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0] || null;

    if (file) {
      // Liste des extensions dangereuses à bloquer
      const dangerousExtensions = ['.exe', '.bat', '.cmd', '.msi', '.scr', '.pif', '.com', '.vbs', '.js'];
      // Liste des extensions autorisées
      const allowedExtensions = ['.pdf', '.xlsx', '.xls', '.ppt', '.pptx', '.doc', '.docx', '.txt', '.jpg', '.jpeg', '.png', 'xlsm'];
      const fileExtension = '.' + file.name.split('.').pop()?.toLowerCase();

      if (fileExtension && dangerousExtensions.includes(fileExtension)) {
        setUploadState(prev => ({
          ...prev,
          file: null,
          version: "",
          error: "Type de fichier non autorisé pour des raisons de sécurité",
        }));
        return;
      }

      if (fileExtension && !allowedExtensions.includes(fileExtension)) {
        setUploadState(prev => ({
          ...prev,
          file: null,
          version: "",
          error: "Seuls les fichiers PDF, Excel, PowerPoint, Word, texte et images sont autorisés",
        }));
        return;
      }

      // Validation de la taille (50MB max)
      const maxSize = 50 * 1024 * 1024; // 50MB
      if (file.size > maxSize) {
        setUploadState(prev => ({
          ...prev,
          file: null,
          version: "",
          error: "Fichier trop volumineux. Taille maximale: 50MB",
        }));
        return;
      }

      // EXTRACTION DU NOM SANS EXTENSION POUR LA VERSION
      const fileName = file.name;
      const versionName = fileName;

      setUploadState(prev => ({
        ...prev,
        file,
        version: versionName,
        error: null,
      }));
    } else {
      setUploadState(prev => ({
        ...prev,
        file: null,
        version: "",
        error: null,
      }));
    }
  }, []);


  const handleUpload = useCallback(async () => {
    if (!uploadState.solutionId || !uploadState.file || !uploadState.version) {
      setUploadState(prev => ({
        ...prev,
        error: "Veuillez sélectionner un fichier et spécifier une version"
      }));
      return;
    }

    if (isVersionExists(uploadState.version, uploadState.solutionId)) {
      setUploadState(prev => ({
        ...prev,
        error: "Cette version existe déjà. Veuillez choisir une autre version."
      }));
      return;
    }

    setUploadState(prev => ({ ...prev, uploading: true, progress: 0, error: null }));

    try {
      const token = localStorage.getItem("bearerToken") ||
        localStorage.getItem("access_token") ||
        localStorage.getItem("token");
      if (!token) throw new Error("Aucun token d'authentification trouvé");

      const formData = new FormData();
      formData.append("version", uploadState.version);
      formData.append("document", uploadState.file);

      const response = await fetch(
        `${getMyViewApiUrl()}dat/upload/${uploadState.solutionId}`,
        {
          method: "POST",
          headers: { "Authorization": `Bearer ${token}` },
          body: formData,
        }
      );

      if (!response.ok) throw new Error(`Erreur ${response.status}: ${response.statusText}`);

      // === MISE À JOUR LOCALE DU COMPTEUR ===
      setSolutions(prevSolutions =>
        prevSolutions.map(sol =>
          sol.id === uploadState.solutionId
            ? { ...sol, count_documents: (sol.count_documents || 0) + 1 }
            : sol
        )
      );

      // === FIN DE LA PROGRESSION SIMULÉE ===
      const interval = setInterval(() => {
        setUploadState(prev => {
          const newProgress = prev.progress + 10;
          if (newProgress >= 100) {
            clearInterval(interval);
            return { ...prev, progress: 100 };
          }
          return { ...prev, progress: newProgress };
        });
      }, 200);

      setTimeout(() => {
        clearInterval(interval);
        handleCloseUpload();
        // Recharger les versions (facultatif, mais utile pour le dialog)
        if (uploadState.solutionId) {
          fetchVersions(uploadState.solutionId);
        }
      }, 2500);

    } catch (err) {
      setUploadState(prev => ({
        ...prev,
        uploading: false,
        error: "Erreur lors de l'upload: " + (err as Error).message,
      }));
    }
  }, [
    uploadState.solutionId,
    uploadState.file,
    uploadState.version,
    isVersionExists,
    handleCloseUpload,
    fetchVersions
  ]);

  const handleShowVersions = useCallback(async (solution: Solution) => {
    // Vérifier si l'utilisateur est TAM de cette solution
    if (!isUserAuthorized(solution)) {
      setVersionsState(prev => ({
        ...prev,
        error: "Seuls les TAM de cette solution peuvent voir les versions",
      }));
      handleCloseActionMenu();
      return;
    }

    await fetchVersions(solution.id);
    handleCloseActionMenu();
  }, [isUserAuthorized, fetchVersions, handleCloseActionMenu]);

  // Fonctions pour le download
  const handleOpenDownload = useCallback(async (solution: Solution) => {
    // Vérifier si l'utilisateur est TAM de cette solution
    if (!isUserAuthorized(solution)) {
      setDownloadState(prev => ({
        ...prev,
        error: "Seuls les TAM de cette solution peuvent télécharger des documents",
      }));
      handleCloseActionMenu();
      return;
    }

    // Charger les versions disponibles
    const versions = await fetchVersions(solution.id);

    // Sélectionner la dernière version par défaut
    const latestVersion = versions.length > 0 ? versions[versions.length - 1] : "0.0.1";

    setDownloadState({
      open: true,
      solutionId: solution.id,
      solutionName: solution.solution_name,
      version: latestVersion,
      downloading: false,
      error: null,
    });
    handleCloseActionMenu();
  }, [isUserAuthorized, fetchVersions, handleCloseActionMenu]);

  const handleCloseDownload = useCallback(() => {
    setDownloadState({
      open: false,
      solutionId: null,
      solutionName: "",
      version: "0.0.1",
      downloading: false,
      error: null,
    });
  }, []);


  const handleDownload = useCallback(async () => {
    if (!downloadState.solutionId || !downloadState.version) {
      setDownloadState(prev => ({
        ...prev,
        error: "Veuillez spécifier une version"
      }));
      return;
    }

    setDownloadState(prev => ({ ...prev, downloading: true, error: null }));

    try {
      const token = localStorage.getItem("bearerToken") ||
        localStorage.getItem("access_token") ||
        localStorage.getItem("token");

      if (!token) {
        throw new Error("Aucun token d'authentification trouvé");
      }

      const response = await fetch(
        `${getMyViewApiUrl()}dat/download/${downloadState.solutionId}`,
        {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            version: downloadState.version,
          }),
        }
      );

      if (!response.ok) {
        throw new Error(`Erreur ${response.status}: ${response.statusText}`);
      }

      // Traiter la réponse du download
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;

      // RÉCUPÉRATION DU NOM AVEC FALLBACK
      const contentDisposition = response.headers.get('content-disposition');
      let originalFilename = "";

      if (contentDisposition) {
        const filenameMatch = contentDisposition.match(/filename="?([^"]+)"?/);
        if (filenameMatch && filenameMatch[1]) {
          originalFilename = filenameMatch[1];
        }
      }

      let finalFilename;

      if (originalFilename) {
        // CORRECTION : Extraction correcte du nom et de l'extension
        const lastDotIndex = originalFilename.lastIndexOf('.');

        if (lastDotIndex !== -1) {
          // Fichier avec extension : document_KTC.pdf
          const filenameWithoutExtension = originalFilename.substring(0, lastDotIndex); // "document_KTC"
          finalFilename = `${filenameWithoutExtension}`;
        } else {
          // Fichier sans extension
          finalFilename = `${originalFilename}`;
        }
      } else {

        finalFilename = `document_${downloadState.solutionName}_v${downloadState.version}`;
      }

      console.log("Nom original:", originalFilename);
      console.log("Nom final:", finalFilename);

      a.download = finalFilename;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);

      setDownloadState(prev => ({ ...prev, downloading: false }));
      handleCloseDownload();

    } catch (err) {
      setDownloadState(prev => ({
        ...prev,
        downloading: false,
        error: "Erreur lors du download: " + (err as Error).message,
      }));
    }
  }, [downloadState.solutionId, downloadState.version, downloadState.solutionName, handleCloseDownload]);

  const getFileIcon = (fileName: string) => {
    const extension = fileName.split('.').pop()?.toLowerCase();

    switch (extension) {
      case 'pdf':
        return <FaFilePdf style={{ color: '#D32F2F', fontSize: '20px' }} />;
      case 'xlsx':
      case 'xls':
        return <FaFileExcel style={{ color: '#1E7D3A', fontSize: '20px' }} />;
      case 'ppt':
      case 'pptx':
        return <FaFilePowerpoint style={{ color: '#D24726', fontSize: '20px' }} />;
      case 'doc':
      case 'docx':
        return <FaFileWord style={{ color: '#1E6DB2', fontSize: '20px' }} />;
      case 'txt':
        return <FaFileAlt style={{ color: '#616161', fontSize: '20px' }} />;
      case 'jpg':
      case 'jpeg':
      case 'png':
        return <FaFileImage style={{ color: '#E91E63', fontSize: '20px' }} />;
      default:
        return <FaFile style={{ color: '#9E9E9E', fontSize: '20px' }} />;
    }
  };

  // Fonction pour charger les données détaillées d'une solution
  const loadSolutionDetails = useCallback(async (solutionId: number) => {
    try {
      const baseUrl = `${getMyViewRootApiUrl()}`;

      const podsUrl = `${baseUrl}/solutions/${solutionId}/pods/`;
      const environments = [
        "Production",
        "Préproduction",
        "Recette",
        "Intégration",
        "Développement",
        "Technique",
        "Formation",
      ];

      // 1. Charger les pods
      let pods: any[] = [];
      try {
        const podsResponse = await fetchWithAuth(podsUrl);
        if (podsResponse.ok) {
          pods = await podsResponse.json();
        }
      } catch (error) {
        console.error("Error loading pods:", error);
      }

      // 2. Charger les serveurs par environnement
      const serversByEnv: any = {};
      for (const env of environments) {
        try {
          const serversUrl = `${baseUrl}/solutions/${solutionId}/servers/${encodeURIComponent(env)}/`;
          const serversResponse = await fetchWithAuth(serversUrl);
          if (serversResponse.ok) {
            serversByEnv[env] = await serversResponse.json();
          }
        } catch (error) {
          console.error(`Error loading servers for ${env}:`, error);
          serversByEnv[env] = [];
        }
      }

      // 3. Calculer le nombre de pods par environnement
      const podsByEnv: { [key: string]: number } = {};
      pods.forEach((pod: any) => {
        const env = pod.environement || "Sans environnement";
        podsByEnv[env] = (podsByEnv[env] || 0) + 1;
      });

      return {
        pods,
        serversByEnv,
        podsByEnv,
      };
    } catch (error) {
      console.error("Error loading solution details:", error);
      throw error;
    }
  }, []);

  // Navigation vers les détails d'une solution
  const navigateToSolutionDetail = useCallback(
    async (solution: Solution) => {
      setDetailLoading(true);
      try {
        // Charger les données détaillées
        const detailedData = await loadSolutionDetails(solution.id);

        // AJOUTER: Récupérer les données CaaS pour CETTE solution spécifique
        const caasDataForSolution = getCaasDataForItem('solutions', solution.solution_name);

        // Si pas trouvé dans le cache global, essayer de charger spécifiquement
        let finalCaasData = caasDataForSolution;
        if (!finalCaasData) {
          try {
            console.log(`📡 Chargement CaaS spécifique pour: ${solution.solution_name}`);
            const response = await fetchWithAuth(hardware_info_openshift_info(), {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                scope: 'solutions',
                solution_name: solution.solution_name  // Ajouter le nom spécifique
              }),
            });

            if (response.ok) {
              const caasArray = await response.json();
              if (caasArray && caasArray.length > 0) {
                const caasItem = caasArray.find((item: any) =>
                  item.solution_name === solution.solution_name
                );
                if (caasItem) {
                  finalCaasData = {
                    total_cpu_caas: caasItem.total_cpu_m || "0",
                    total_ram_caas: caasItem.total_ram_mi || "0",
                    total_request_cpu_m: caasItem.total_request_cpu_m || "0",
                    total_request_ram_mi: caasItem.total_request_ram_mi || "0"
                  };
                }
              }
            }
          } catch (caasError) {
            console.error('Erreur chargement CaaS spécifique:', caasError);
          }
        }

        const enrichedSolution = {
          ...solution,
          ...detailedData,
          list_admins: solution.list_admins || {
            technical_admins: [],
            functional_admins: [],
            tams: [],
          },
          // Utiliser les métriques directement de l'API my-view
          count_pods: solution.count_pods || 0,
          count_servers: solution.count_servers || 0,
          count_namespaces: solution.count_namespaces || 0,
          count_deployments: solution.count_deployments || 0,
          count_technical_admins: solution.count_technical_admins || 0,
          count_functional_admins: solution.count_functional_admins || 0,
          count_tams: solution.count_tams || 0,
          count_request: solution.count_request || 0,
          count_cab: solution.count_cab || 0,
          count_ecab: solution.count_ecab || 0,
          pods_by_env: detailedData.podsByEnv || {},
          servers_by_env: detailedData.serversByEnv || {},
          // AJOUTER: Inclure les données CaaS dans la solution
          caas_resources: finalCaasData,
        };

        // Stocker les données chargées
        setPodsData((prev) =>
          new Map(prev).set(
            `solution-${solution.id}-pods`,
            detailedData.pods || [],
          ),
        );
        setServersData((prev) => {
          const newMap = new Map(prev);
          Object.entries(detailedData.serversByEnv || {}).forEach(
            ([env, servers]) => {
              newMap.set(
                `solution-${solution.id}-servers-${env}`,
                servers as any[],
              );
            },
          );
          return newMap;
        });

        const newBreadcrumbItem: BreadcrumbItem = {
          name: solution.solution_name,
          level: "solutionDetail",
          data: enrichedSolution,
          elementId: `solution-${solution.id}`,
        };

        setNavigation({
          currentLevel: "solutionDetail",
          currentItem: enrichedSolution,
          breadcrumb: [newBreadcrumbItem],
        });
      } catch (err) {
        console.error("Erreur lors du chargement des détails:", err);
        const basicEnrichedSolution = {
          ...solution,
          count_pods: solution.count_pods || 0,
          count_servers: solution.count_servers || 0,
          count_namespaces: solution.count_namespaces || 0,
          count_deployments: solution.count_deployments || 0,
          count_technical_admins: solution.count_technical_admins || 0,
          count_functional_admins: solution.count_functional_admins || 0,
          count_tams: solution.count_tams || 0,
          count_request: solution.count_request || 0,
          count_cab: solution.count_cab || 0,
          count_ecab: solution.count_ecab || 0,
          list_admins: solution.list_admins || {
            technical_admins: [],
            functional_admins: [],
            tams: [],
          },
          // AJOUTER: Données CaaS vides en cas d'erreur
          caas_resources: null,
        };

        const newBreadcrumbItem: BreadcrumbItem = {
          name: solution.solution_name,
          level: "solutionDetail",
          data: basicEnrichedSolution,
          elementId: `solution-${solution.id}`,
        };

        setNavigation({
          currentLevel: "solutionDetail",
          currentItem: basicEnrichedSolution,
          breadcrumb: [newBreadcrumbItem],
        });
      } finally {
        setDetailLoading(false);
      }
    },
    [loadSolutionDetails],
  );

  const navigateBackToList = useCallback(() => {
    setNavigation({
      currentLevel: "list",
      currentItem: null,
      breadcrumb: [],
    });
    setSearchTerm("");
  }, []);

  const navigateToBreadcrumb = useCallback(
    (index: number) => {
      if (index === -1) {
        navigateBackToList();
      }
    },
    [navigateBackToList],
  );

  // Handler pour la recherche
  const handleSearchChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      setSearchTerm(e.target.value);
    },
    [],
  );

  // Composant Breadcrumb
  const BreadcrumbNav = useCallback(() => {
    if (navigation.currentLevel === "list") return null;

    return (
      <Paper
        elevation={0}
        sx={{
          background: `linear-gradient(135deg, ${alpha(colors.solution, 0.1)} 0%, ${alpha(colors.solution, 0.05)} 100%)`,
          borderBottom: `2px solid ${alpha(colors.solution, 0.3)}`,
          py: 2,
          px: 3,
          boxShadow: `0 2px 8px rgba(0, 0, 0, 0.1)`,
          borderRadius: 0,
          mb: 2,
        }}
      >
        <Stack direction="row" alignItems="center" spacing={2}>
          <IconButton
            onClick={() => navigateToBreadcrumb(-1)}
            sx={{
              backgroundColor: alpha(colors.solution, 0.2),
              color: colors.solution,
              "&:hover": {
                backgroundColor: alpha(colors.solution, 0.3),
              },
            }}
          >
            <Home />
          </IconButton>

          <Breadcrumbs
            separator={
              <NavigateNext
                fontSize="small"
                sx={{ color: theme.textSecondary }}
              />
            }
            sx={{ flexGrow: 1 }}
          >
            <Box
              onClick={navigateBackToList}
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 1,
                cursor: "pointer",
                padding: "6px 12px",
                borderRadius: 3,
                transition: "all 0.2s ease-in-out",
                "&:hover": {
                  backgroundColor: alpha(colors.solution, 0.15),
                },
              }}
            >
              <Apps sx={{ fontSize: 18, color: colors.solution }} />
              <Typography
                variant="body2"
                sx={{
                  fontWeight: 700,
                  color: theme.textPrimary,
                  fontSize: "14px",
                }}
              >
                Mes Applications
              </Typography>
            </Box>

            {navigation.breadcrumb.map((item, index) => (
              <Box
                key={`breadcrumb-${index}`}
                sx={{
                  display: "flex",
                  alignItems: "center",
                  gap: 1,
                  padding: "6px 12px",
                  borderRadius: 3,
                }}
              >
                <Apps sx={{ fontSize: 18, color: colors.solution }} />
                <Typography
                  variant="body2"
                  sx={{
                    fontWeight: 700,
                    color: theme.textPrimary,
                    fontSize: "14px",
                  }}
                >
                  {item.name}
                </Typography>
              </Box>
            ))}
          </Breadcrumbs>
        </Stack>
      </Paper>
    );
  }, [navigation, navigateToBreadcrumb, navigateBackToList]);

  // Composant pour la vue détaillée d'une solution
  const SolutionDetailViewWrapper = useCallback(
    ({ solution }: { solution: any }) => {
      // Récupérer les données CaaS pour cette solution
      const caasDataForSolution = getCaasDataForItem('solutions', solution.solution_name);

      return (
        <SolutionDetailView
          solution={solution}
          podsData={podsData}
          serversData={serversData}
          environmentTabs={environmentTabs}
          setEnvironmentTabs={setEnvironmentTabs}
          selectedPodEnvironments={selectedPodEnvironments}
          setSelectedPodEnvironments={setSelectedPodEnvironments}
          solutionViewTab={solutionViewTab}
          setSolutionViewTab={setSolutionViewTab}
          showRoleDetails={showRoleDetails}
          setShowRoleDetails={setShowRoleDetails}
          loading={detailLoading}
          // Passer les données CaaS
          caasData={caasDataForSolution ?
            new Map([[solution.solution_name, caasDataForSolution]]) :
            new Map()
          }
        />
      );
    },
    [
      podsData,
      serversData,
      environmentTabs,
      selectedPodEnvironments,
      solutionViewTab,
      showRoleDetails,
      detailLoading,
    ],
  );

  // Rendu principal conditionnel
  return (
    <Box sx={{ minHeight: "100vh", backgroundColor: theme.background }}>
      {/* En-tête moderne avec gradient */}
      <Box
        sx={{
          background: `linear-gradient(135deg, ${theme.primary} 0%, ${theme.secondary} 100%)`,
          py: 6,
          px: 3,
          position: "relative",
          overflow: "hidden",
          "&::before": {
            content: '""',
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background:
              "radial-gradient(circle at 20% 50%, rgba(255,255,255,0.1) 0%, transparent 50%)",
          },
        }}
      >
        <Container maxWidth="xl">
          <Stack
            direction="row"
            alignItems="center"
            spacing={3}
            sx={{ position: "relative", zIndex: 1 }}
          >
            <Avatar
              sx={{
                width: 64,
                height: 64,
                bgcolor: "rgba(255, 255, 255, 0.2)",
                backdropFilter: "blur(10px)",
              }}
            >
              <Person sx={{ fontSize: 36, color: "white" }} />
            </Avatar>
            <Box>
              <Typography
                variant="h3"
                sx={{
                  fontWeight: 800,
                  color: "white",
                  mb: 1,
                  fontSize: { xs: "1.75rem", md: "2.5rem" },
                }}
              >
                {navigation.currentLevel === "solutionDetail"
                  ? navigation.currentItem?.solution_name
                  : "Mes Applications"}
              </Typography>
              <Typography
                variant="h6"
                sx={{
                  color: "rgba(255, 255, 255, 0.95)",
                  fontWeight: 400,
                  fontSize: { xs: "0.9rem", md: "1.1rem" },
                }}
              >
                {userInfo.name ? (
                  <>
                    <strong>{userInfo.name}</strong> · {userInfo.email}
                  </>
                ) : (
                  "Chargement de vos informations..."
                )}
              </Typography>
            </Box>
          </Stack>
        </Container>
      </Box>

      <Container maxWidth="xl" sx={{ py: 4 }}>
        {/* Breadcrumb */}
        <BreadcrumbNav />

        {/* Loading pour les détails */}
        {detailLoading && (
          <Box sx={{ display: "flex", justifyContent: "center", my: 4 }}>
            <CircularProgress />
          </Box>
        )}

        {/* Contenu conditionnel */}
        {navigation.currentLevel === "solutionDetail" &&
          navigation.currentItem ? (
          <SolutionDetailViewWrapper solution={navigation.currentItem} />
        ) : (
          <>
            {/* Barre de recherche et statistiques */}
            <Stack spacing={3} sx={{ mb: 4 }}>
              {/* Recherche et tri */}
              <Stack
                direction={{ xs: "column", sm: "row" }}
                spacing={2}
                alignItems="flex-end"
              >
                <Paper
                  elevation={0}
                  sx={{
                    p: 2,
                    borderRadius: 3,
                    border: `1px solid ${theme.border}`,
                    transition: "all 0.3s",
                    flex: 1,
                    "&:focus-within": {
                      boxShadow: `0 0 0 3px ${alpha(theme.primary, 0.1)}`,
                      borderColor: theme.primary,
                    },
                  }}
                >
                  <TextField
                    fullWidth
                    variant="standard"
                    placeholder="Rechercher par nom, domaine, pôle, entité, tenant, type ou popularité..."
                    value={searchTerm}
                    onChange={handleSearchChange}
                    autoComplete="off"
                    InputProps={{
                      disableUnderline: true,
                      startAdornment: (
                        <InputAdornment position="start">
                          <Search sx={{ color: theme.textSecondary }} />
                        </InputAdornment>
                      ),
                      sx: { fontSize: 16 },
                    }}
                  />
                </Paper>
              </Stack>

              {/* Cartes de statistiques */}
              <Stack direction={{ xs: "column", sm: "row" }} spacing={2}>
                {/* Applications */}
                <Card
                  elevation={0}
                  sx={{
                    flex: 1,
                    background: `linear-gradient(135deg, ${alpha(theme.primary, 0.1)} 0%, ${alpha(theme.primary, 0.05)} 100%)`,
                    border: `1px solid ${alpha(theme.primary, 0.2)}`,
                    borderRadius: 3,
                  }}
                >
                  <CardContent>
                    <Typography
                      variant="h3"
                      sx={{ fontWeight: 800, color: theme.primary, mb: 0.5 }}
                    >
                      {totals.solutions}
                    </Typography>
                    <Typography
                      variant="body2"
                      sx={{ color: theme.textSecondary, fontWeight: 600 }}
                    >
                      Applications
                    </Typography>
                  </CardContent>
                </Card>

                {/* Serveurs Total */}
                <Card
                  elevation={0}
                  sx={{
                    flex: 1,
                    background: `linear-gradient(135deg, ${alpha(theme.success, 0.1)} 0%, ${alpha(theme.success, 0.05)} 100%)`,
                    border: `1px solid ${alpha(theme.success, 0.2)}`,
                    borderRadius: 3,
                  }}
                >
                  <CardContent>
                    <Typography
                      variant="h3"
                      sx={{ fontWeight: 800, color: theme.success, mb: 0.5 }}
                    >
                      {totals.servers}
                    </Typography>
                    <Typography
                      variant="body2"
                      sx={{ color: theme.textSecondary, fontWeight: 600 }}
                    >
                      Serveurs Total
                    </Typography>
                  </CardContent>
                </Card>

                {/* Namespaces Total */}
                <Card
                  elevation={0}
                  sx={{
                    flex: 1,
                    background: `linear-gradient(135deg, ${alpha(theme.warning, 0.1)} 0%, ${alpha(theme.warning, 0.05)} 100%)`,
                    border: `1px solid ${alpha(theme.warning, 0.2)}`,
                    borderRadius: 3,
                  }}
                >
                  <CardContent>
                    <Typography
                      variant="h3"
                      sx={{ fontWeight: 800, color: theme.warning, mb: 0.5 }}
                    >
                      {totals.namespaces}
                    </Typography>
                    <Typography
                      variant="body2"
                      sx={{ color: theme.textSecondary, fontWeight: 600 }}
                    >
                      Namespaces Total
                    </Typography>
                  </CardContent>
                </Card>
              </Stack>
            </Stack>

            {/* Tableau des applications */}
            {loading ? (
              <Stack spacing={2}>
                {[1, 2, 3, 4, 5].map((i) => (
                  <Skeleton
                    key={i}
                    variant="rectangular"
                    height={80}
                    sx={{ borderRadius: 2 }}
                  />
                ))}
              </Stack>
            ) : error ? (
              <Alert severity="error" sx={{ borderRadius: 3 }}>
                {error}
              </Alert>
            ) : searchedSolutions.length === 0 ? (
              <Paper
                sx={{
                  p: 8,
                  textAlign: "center",
                  borderRadius: 3,
                  border: `1px solid ${theme.border}`,
                }}
              >
                <Apps
                  sx={{
                    fontSize: 80,
                    color: theme.textSecondary,
                    mb: 2,
                    opacity: 0.5,
                  }}
                />
                <Typography
                  variant="h5"
                  sx={{ fontWeight: 700, color: theme.textPrimary, mb: 1 }}
                >
                  {searchTerm
                    ? "Aucune application trouvée"
                    : "Aucune application"}
                </Typography>
                <Typography variant="body1" color="text.secondary">
                  {searchTerm
                    ? "Essayez de modifier votre recherche"
                    : "Vous n'êtes responsable d'aucune application pour le moment"}
                </Typography>
              </Paper>
            ) : (
              <TableContainer
                component={Paper}
                elevation={0}
                sx={{
                  borderRadius: 3,
                  border: `1px solid ${theme.border}`,
                  overflow: "hidden",
                }}
              >
                <Table>
                  <TableHead>
                    <TableRow
                      sx={{ backgroundColor: alpha(theme.primary, 0.05) }}
                    >
                      {/* Colonne Actions */}
                      <TableCell
                        sx={{
                          fontWeight: 700,
                          color: theme.textPrimary,
                          py: 2,
                          width: "12%",
                          textAlign: "center",
                        }}
                      >
                        Actions
                      </TableCell>

                      {/* Application - avec tri */}
                      <TableCell
                        sx={{
                          fontWeight: 700,
                          color: theme.textPrimary,
                          py: 2,
                          width: "18%",
                          cursor: "pointer",
                          "&:hover": {
                            backgroundColor: alpha(theme.primary, 0.08),
                          },
                        }}
                        onClick={() => handleSort("solution_name")}
                      >
                        <Box sx={{ display: "flex", alignItems: "center" }}>
                          Application
                          {getSortIcon("solution_name")}
                        </Box>
                      </TableCell>

                      <TableCell
                        sx={{
                          fontWeight: 700,
                          color: theme.textPrimary,
                          width: "20%",
                        }}
                      >
                        Organisation
                      </TableCell>

                      <TableCell
                        sx={{
                          fontWeight: 700,
                          color: theme.textPrimary,
                          width: "10%",
                        }}
                      >
                        Type & Service
                      </TableCell>

                      {/* PSI - avec tri */}
                      <TableCell
                        sx={{
                          fontWeight: 700,
                          color: theme.textPrimary,
                          width: "6%",
                          cursor: "pointer",
                          "&:hover": {
                            backgroundColor: alpha(theme.primary, 0.08),
                          },
                        }}
                        onClick={() => handleSort("psi")}
                      >
                        <Box sx={{ display: "flex", alignItems: "center" }}>
                          PSI
                          {getSortIcon("psi")}
                        </Box>
                      </TableCell>

                      {/* Infrastructure */}
                      <TableCell
                        sx={{
                          fontWeight: 700,
                          color: theme.textPrimary,
                          width: "16%",
                        }}
                      >
                        <Box sx={{ mb: 1 }}>Infrastructure</Box>
                        <Stack
                          direction="row"
                          spacing={1}
                          sx={{ flexWrap: "wrap" }}
                        >
                          <Chip
                            label="Serveurs"
                            size="small"
                            onClick={() => handleSort("count_servers")}
                            icon={getSortIcon("count_servers") || undefined}
                            sx={{
                              fontSize: 10,
                              fontWeight: 600,
                              height: 20,
                              backgroundColor: alpha(theme.primary, 0.1),
                              color: theme.primary,
                              cursor: "pointer",
                              "&:hover": {
                                backgroundColor: alpha(theme.primary, 0.2),
                              },
                            }}
                          />
                          <Chip
                            label="Pods"
                            size="small"
                            onClick={() => handleSort("count_pods")}
                            icon={getSortIcon("count_pods") || undefined}
                            sx={{
                              fontSize: 10,
                              fontWeight: 600,
                              height: 20,
                              backgroundColor: alpha(theme.secondary, 0.1),
                              color: theme.secondary,
                              cursor: "pointer",
                              "&:hover": {
                                backgroundColor: alpha(theme.secondary, 0.2),
                              },
                            }}
                          />
                          <Chip
                            label="Namespaces"
                            size="small"
                            onClick={() => handleSort("count_namespaces")}
                            icon={getSortIcon("count_namespaces") || undefined}
                            sx={{
                              fontSize: 10,
                              fontWeight: 600,
                              height: 20,
                              backgroundColor: alpha(theme.success, 0.1),
                              color: theme.success,
                              cursor: "pointer",
                              "&:hover": {
                                backgroundColor: alpha(theme.success, 0.2),
                              },
                            }}
                          />
                          {/* Ajouter le chip pour Déploiements */}
                          <Chip
                            label="Déploiements"
                            size="small"
                            onClick={() => handleSort("count_deployments")}
                            icon={getSortIcon("count_deployments") || undefined}
                            sx={{
                              fontSize: 10,
                              fontWeight: 600,
                              height: 20,
                              backgroundColor: alpha(theme.accent, 0.1),
                              color: theme.accent,
                              cursor: "pointer",
                              "&:hover": {
                                backgroundColor: alpha(theme.accent, 0.2),
                              },
                            }}
                          />
                        </Stack>
                      </TableCell>

                      {/* Métriques iTop */}
                      <TableCell
                        sx={{
                          fontWeight: 700,
                          color: theme.textPrimary,
                          width: "12%",
                        }}
                      >
                        <Box sx={{ mb: 1 }}>iTop</Box>
                        <Stack
                          direction="row"
                          spacing={1}
                          sx={{ flexWrap: "wrap" }}
                        >
                          <Chip
                            label="Requêtes"
                            size="small"
                            onClick={() => handleSort("count_request")}
                            icon={getSortIcon("count_request") || undefined}
                            sx={{
                              fontSize: 10,
                              fontWeight: 600,
                              height: 20,
                              backgroundColor: alpha(theme.accent, 0.1),
                              color: theme.accent,
                              cursor: "pointer",
                              "&:hover": {
                                backgroundColor: alpha(theme.accent, 0.2),
                              },
                            }}
                          />
                          <Chip
                            label="CAB"
                            size="small"
                            onClick={() => handleSort("count_cab")}
                            icon={getSortIcon("count_cab") || undefined}
                            sx={{
                              fontSize: 10,
                              fontWeight: 600,
                              height: 20,
                              backgroundColor: alpha(theme.warning, 0.1),
                              color: theme.warning,
                              cursor: "pointer",
                              "&:hover": {
                                backgroundColor: alpha(theme.warning, 0.2),
                              },
                            }}
                          />
                          <Chip
                            label="eCAB"
                            size="small"
                            onClick={() => handleSort("count_ecab")}
                            icon={getSortIcon("count_ecab") || undefined}
                            sx={{
                              fontSize: 10,
                              fontWeight: 600,
                              height: 20,
                              backgroundColor: alpha(theme.success, 0.1),
                              color: theme.success,
                              cursor: "pointer",
                              "&:hover": {
                                backgroundColor: alpha(theme.success, 0.2),
                              },
                            }}
                          />
                        </Stack>
                      </TableCell>

                      {/* Tenant - avec tri */}
                      <TableCell
                        sx={{
                          fontWeight: 700,
                          color: theme.textPrimary,
                          width: "8%",
                          cursor: "pointer",
                          "&:hover": {
                            backgroundColor: alpha(theme.primary, 0.08),
                          },
                        }}
                        onClick={() => handleSort("tenant")}
                      >
                        <Box sx={{ display: "flex", alignItems: "center" }}>
                          Tenant
                          {getSortIcon("tenant")}
                        </Box>
                      </TableCell>

                      <TableCell
                        sx={{
                          fontWeight: 700,
                          color: theme.textPrimary,
                          width: "6%",
                        }}
                        align="center"
                      >
                        Statut
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {searchedSolutions.map((solution, index) => (
                      <TableRow
                        key={solution.id}
                        sx={{
                          transition: "all 0.2s",
                          "&:hover": {
                            backgroundColor: alpha(theme.primary, 0.03),
                            transform: "scale(1.001)",
                            cursor: "pointer",
                          },
                          borderBottom:
                            index === searchedSolutions.length - 1
                              ? "none"
                              : `1px solid ${theme.border}`,
                        }}
                      >
                        {/* Colonne Actions avec nombre de documents */}
                        <TableCell
                          sx={{
                            py: 2.5,
                            textAlign: "center",
                            borderRight: `1px solid ${alpha(theme.border, 0.5)}`
                          }}
                          onClick={(e) => e.stopPropagation()}
                        >
                          {/* Nombre de documents avec icône, texte et flèches de tri */}
                          <Box
                            sx={{
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "center",
                              gap: 0.5,
                              mb: 1,
                              cursor: "pointer",
                              padding: "4px 8px",
                              borderRadius: 2,
                              backgroundColor:
                                (solution.count_documents || 0) > 0
                                  ? alpha(theme.success, 0.05)
                                  : alpha(theme.textSecondary, 0.05),
                              "&:hover": {
                                backgroundColor:
                                  (solution.count_documents || 0) > 0
                                    ? alpha(theme.success, 0.1)
                                    : alpha(theme.textSecondary, 0.1),
                              },
                            }}
                            onClick={() => handleSort("count_documents")}
                          >
                            <Description
                              sx={{
                                color: (solution.count_documents || 0) > 0 ? theme.success : theme.textSecondary,
                                fontSize: 16,
                                opacity: (solution.count_documents || 0) > 0 ? 1 : 0.5,
                              }}
                            />
                            <Typography
                              variant="caption"
                              sx={{
                                fontWeight: 600,
                                fontSize: "9px",
                                color: (solution.count_documents || 0) > 0 ? theme.success : theme.textSecondary,
                              }}
                            >
                              Documents: {solution.count_documents || 0}
                            </Typography>
                            {/* Flèches de tri - aussi en gris si 0 */}
                            {sortConfig.field === "count_documents" && (
                              sortConfig.direction === "asc" ?
                                <ArrowUpward
                                  sx={{
                                    fontSize: 14,
                                    color: (solution.count_documents || 0) > 0 ? theme.success : theme.textSecondary,
                                    opacity: (solution.count_documents || 0) > 0 ? 1 : 0.5,
                                  }}
                                /> :
                                <ArrowDownward
                                  sx={{
                                    fontSize: 14,
                                    color: (solution.count_documents || 0) > 0 ? theme.success : theme.textSecondary,
                                    opacity: (solution.count_documents || 0) > 0 ? 1 : 0.5,
                                  }}
                                />
                            )}
                          </Box>

                          {/* Bouton d'actions */}
                          <Tooltip title="Actions" arrow>
                            <IconButton
                              onClick={(e) => handleOpenActionMenu(e, solution)}
                              sx={{
                                backgroundColor: alpha(theme.primary, 0.1),
                                color: theme.primary,
                                "&:hover": {
                                  backgroundColor: alpha(theme.primary, 0.2),
                                  transform: "scale(1.1)",
                                },
                                transition: "all 0.2s ease-in-out",
                                width: 40,
                                height: 40,
                              }}
                            >
                              <MoreVert />
                            </IconButton>
                          </Tooltip>
                        </TableCell>

                        {/* Application */}
                        <TableCell
                          sx={{ py: 2.5 }}
                          onClick={() => navigateToSolutionDetail(solution)}
                        >
                          <Stack
                            direction="row"
                            alignItems="center"
                            spacing={2}
                          >
                            <Avatar
                              sx={{
                                width: 40,
                                height: 40,
                                bgcolor: alpha(theme.primary, 0.15),
                                color: theme.primary,
                              }}
                            >
                              <Apps sx={{ fontSize: 20 }} />
                            </Avatar>
                            <Box sx={{ flexGrow: 1 }}>
                              <Typography
                                sx={{
                                  fontWeight: 700,
                                  color: theme.textPrimary,
                                  fontSize: 14,
                                  mb: 0.3,
                                }}
                              >
                                {solution.solution_name}
                              </Typography>

                              {/* Rôle avec fonctionnalité dépliante */}
                              <Box>
                                <Typography
                                  variant="caption"
                                  sx={{
                                    color: theme.textSecondary,
                                    fontSize: 11,
                                    display: "block",
                                    lineHeight: 1.2,
                                    cursor:
                                      solution.solution_role &&
                                        solution.solution_role.length > 660
                                        ? "pointer"
                                        : "default",
                                    "&:hover":
                                      solution.solution_role &&
                                        solution.solution_role.length > 660
                                        ? {
                                          backgroundColor: alpha(
                                            theme.primary,
                                            0.05,
                                          ),
                                          borderRadius: 1,
                                        }
                                        : {},
                                  }}
                                  onClick={(e) => {
                                    if (
                                      solution.solution_role &&
                                      solution.solution_role.length > 660
                                    ) {
                                      e.stopPropagation();
                                      const solutionElement =
                                        document.getElementById(
                                          `role-${solution.id}`,
                                        );
                                      if (solutionElement) {
                                        solutionElement.style.display =
                                          solutionElement.style.display ===
                                            "none"
                                            ? "block"
                                            : "none";
                                      }
                                    }
                                  }}
                                >
                                  {solution.solution_role &&
                                    solution.solution_role.length > 660
                                    ? `${solution.solution_role.substring(0, 660)}...`
                                    : solution.solution_role}
                                </Typography>

                                {/* Rôle complet (caché par défaut) */}
                                {solution.solution_role &&
                                  solution.solution_role.length > 660 && (
                                    <Typography
                                      id={`role-${solution.id}`}
                                      variant="caption"
                                      sx={{
                                        color: theme.textSecondary,
                                        fontSize: 11,
                                        display: "none",
                                        lineHeight: 1.2,
                                        backgroundColor: alpha(
                                          theme.primary,
                                          0.05,
                                        ),
                                        borderRadius: 1,
                                        p: 0.5,
                                        mt: 0.5,
                                      }}
                                    >
                                      {solution.solution_role}
                                    </Typography>
                                  )}
                              </Box>
                            </Box>
                          </Stack>
                        </TableCell>

                        {/* Organisation (Domaine / Pôle / Entité) */}
                        <TableCell
                          onClick={() => navigateToSolutionDetail(solution)}
                        >
                          <Typography
                            variant="caption"
                            sx={{
                              fontSize: 11,
                              color: theme.textSecondary,
                              display: "block",
                              mb: 0.3,
                            }}
                          >
                            <Box component="span" sx={{ fontWeight: "normal" }}>
                              Domaine :{" "}
                            </Box>
                            <Box component="span" sx={{ fontWeight: 600 }}>
                              {solution.domain}
                            </Box>
                          </Typography>
                          <Typography
                            variant="caption"
                            sx={{
                              fontSize: 11,
                              color: theme.textSecondary,
                              display: "block",
                              mb: 0.3,
                            }}
                          >
                            <Box component="span" sx={{ fontWeight: "normal" }}>
                              Pôle :{" "}
                            </Box>
                            <Box component="span" sx={{ fontWeight: 600 }}>
                              {solution.pole}
                            </Box>
                          </Typography>
                          <Typography
                            variant="caption"
                            sx={{
                              fontSize: 11,
                              color: theme.textSecondary,
                              display: "block",
                            }}
                          >
                            <Box component="span" sx={{ fontWeight: "normal" }}>
                              Entité :{" "}
                            </Box>
                            <Box component="span" sx={{ fontWeight: 600 }}>
                              {solution.entity}
                            </Box>
                          </Typography>
                          {solution.solution_popularity && (
                            <Typography
                              variant="caption"
                              sx={{
                                fontSize: 11,
                                color: theme.textSecondary,
                                display: "block",
                                mt: 0.5,
                              }}
                            >
                              <Box component="span" sx={{ fontWeight: "normal" }}>
                                Popularité :{" "}
                              </Box>
                              <Box component="span" sx={{ fontWeight: 600 }}>
                                {solution.solution_popularity}
                              </Box>
                            </Typography>
                          )}
                        </TableCell>

                        {/* Type & Service */}
                        <TableCell
                          onClick={() => navigateToSolutionDetail(solution)}
                        >
                          <Stack spacing={0.5}>
                            <Chip
                              label={solution.solution_type}
                              size="small"
                              sx={{
                                fontSize: 10,
                                fontWeight: 600,
                                height: 22,
                                backgroundColor: alpha(theme.primary, 0.1),
                                color: theme.primary,
                              }}
                            />
                            <Chip
                              label={solution.service_type}
                              size="small"
                              sx={{
                                fontSize: 10,
                                fontWeight: 600,
                                height: 22,
                                backgroundColor: alpha(
                                  serviceTypeColors[solution.service_type] ||
                                  theme.textSecondary,
                                  0.1,
                                ),
                                color:
                                  serviceTypeColors[solution.service_type] ||
                                  theme.textSecondary,
                              }}
                            />
                          </Stack>
                        </TableCell>

                        {/* PSI */}
                        <TableCell
                          onClick={() => navigateToSolutionDetail(solution)}
                        >
                          <Chip
                            label={solution.psi}
                            size="small"
                            sx={{
                              fontSize: 12,
                              fontWeight: 700,
                              backgroundColor:
                                psiColors[solution.psi] || theme.textSecondary,
                              color: "white",
                              minWidth: 45,
                              height: 26,
                            }}
                          />
                        </TableCell>

                        {/* Infrastructure */}
                        <TableCell
                          onClick={() => navigateToSolutionDetail(solution)}
                        >
                          <Stack spacing={1}>
                            {/* Serveurs - Toujours afficher même à 0 */}
                            <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                              <FiServer size={14} color={colors.server} />
                              <Typography
                                variant="caption"
                                sx={{
                                  fontWeight: 700,
                                  flex: 1,
                                  fontSize: "12px",
                                }}
                              >
                                Serveurs: {solution.count_servers || 0}
                              </Typography>
                            </Box>

                            {/* Pods - Afficher seulement si > 0 */}
                            {(solution.count_pods || 0) > 0 && (
                              <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                                <LuRocket size={14} color={colors.deployment} />
                                <Typography
                                  variant="caption"
                                  sx={{
                                    fontWeight: 700,
                                    flex: 1,
                                    fontSize: "12px",
                                  }}
                                >
                                  Pods: {solution.count_pods}
                                </Typography>
                              </Box>
                            )}

                            {/* Namespaces - Afficher seulement si > 0 */}
                            {(solution.count_namespaces || 0) > 0 && (
                              <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                                <VscSymbolNamespace size={14} color={colors.namespace} />
                                <Typography
                                  variant="caption"
                                  sx={{
                                    fontWeight: 700,
                                    flex: 1,
                                    fontSize: "12px",
                                  }}
                                >
                                  Namespaces: {solution.count_namespaces}
                                </Typography>
                              </Box>
                            )}

                            {/* Déploiements - Afficher seulement si > 0 */}
                            {(solution.count_deployments || 0) > 0 && (
                              <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                                <LuRocket size={14} color={theme.accent} />
                                <Typography
                                  variant="caption"
                                  sx={{
                                    fontWeight: 700,
                                    flex: 1,
                                    fontSize: "12px",
                                  }}
                                >
                                  Déploiements: {solution.count_deployments}
                                </Typography>
                              </Box>
                            )}
                          </Stack>
                        </TableCell>

                        {/* Métriques iTop */}
                        <TableCell
                          onClick={() => navigateToSolutionDetail(solution)}
                        >
                          <Stack spacing={1}>
                            {/* Requêtes */}
                            <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                              <Box
                                sx={{
                                  width: 14,
                                  height: 14,
                                  borderRadius: "50%",
                                  backgroundColor: theme.accent,
                                  display: "flex",
                                  alignItems: "center",
                                  justifyContent: "center",
                                }}
                              >
                                <Typography
                                  variant="caption"
                                  sx={{
                                    color: "white",
                                    fontSize: "8px",
                                    fontWeight: 700,
                                  }}
                                >
                                  R
                                </Typography>
                              </Box>
                              <Typography
                                variant="caption"
                                sx={{
                                  fontWeight: 700,
                                  flex: 1,
                                  fontSize: "12px",
                                }}
                              >
                                Requêtes: {solution.count_request || 0}
                              </Typography>
                            </Box>

                            {/* CAB */}
                            <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                              <Box
                                sx={{
                                  width: 14,
                                  height: 14,
                                  borderRadius: "50%",
                                  backgroundColor: theme.warning,
                                  display: "flex",
                                  alignItems: "center",
                                  justifyContent: "center",
                                }}
                              >
                                <Typography
                                  variant="caption"
                                  sx={{
                                    color: "white",
                                    fontSize: "8px",
                                    fontWeight: 700,
                                  }}
                                >
                                  C
                                </Typography>
                              </Box>
                              <Typography
                                variant="caption"
                                sx={{
                                  fontWeight: 700,
                                  flex: 1,
                                  fontSize: "12px",
                                }}
                              >
                                CAB: {solution.count_cab || 0}
                              </Typography>
                            </Box>

                            {/* eCAB */}
                            <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                              <Box
                                sx={{
                                  width: 14,
                                  height: 14,
                                  borderRadius: "50%",
                                  backgroundColor: theme.success,
                                  display: "flex",
                                  alignItems: "center",
                                  justifyContent: "center",
                                }}
                              >
                                <Typography
                                  variant="caption"
                                  sx={{
                                    color: "white",
                                    fontSize: "8px",
                                    fontWeight: 700,
                                  }}
                                >
                                  E
                                </Typography>
                              </Box>
                              <Typography
                                variant="caption"
                                sx={{
                                  fontWeight: 700,
                                  flex: 1,
                                  fontSize: "12px",
                                }}
                              >
                                eCAB: {solution.count_ecab || 0}
                              </Typography>
                            </Box>
                          </Stack>
                        </TableCell>

                        {/* Tenant */}
                        <TableCell
                          onClick={() => navigateToSolutionDetail(solution)}
                        >
                          {solution.tenant ? (
                            <Card
                              elevation={0}
                              sx={{
                                background: `linear-gradient(135deg, ${alpha(theme.warning, 0.05)} 0%, ${alpha(theme.warning, 0.02)} 100%)`,
                                border: `1px solid ${alpha(theme.warning, 0.1)}`,
                                borderRadius: 1,
                                p: 0.5,
                                maxWidth: 120,
                                margin: "0 auto",
                              }}
                            >
                              <Typography
                                variant="caption"
                                sx={{
                                  fontWeight: 600,
                                  color: theme.warning,
                                  fontSize: "10px",
                                  display: "block",
                                  textAlign: "center",
                                }}
                              >
                                {solution.tenant.length > 12
                                  ? `${solution.tenant.substring(0, 12)}...`
                                  : solution.tenant}
                              </Typography>
                              {solution.tenant_details && (
                                <Tooltip title={solution.tenant_details} arrow>
                                  <Typography
                                    variant="caption"
                                    sx={{
                                      color: theme.textSecondary,
                                      fontSize: "8px",
                                      display: "block",
                                      textAlign: "center",
                                      mt: 0.2,
                                      overflow: "hidden",
                                      textOverflow: "ellipsis",
                                      whiteSpace: "nowrap",
                                    }}
                                  >
                                    {solution.tenant_details.length > 15
                                      ? `${solution.tenant_details.substring(0, 15)}...`
                                      : solution.tenant_details}
                                  </Typography>
                                </Tooltip>
                              )}
                            </Card>
                          ) : (
                            <Typography
                              variant="caption"
                              sx={{
                                color: theme.textSecondary,
                                fontStyle: "italic",
                                fontSize: "10px",
                                textAlign: "center",
                                display: "block",
                              }}
                            >
                              Non spécifié
                            </Typography>
                          )}
                        </TableCell>

                        {/* Statut */}
                        <TableCell
                          align="center"
                          onClick={() => navigateToSolutionDetail(solution)}
                        >
                          <Tooltip
                            title={
                              solution.activated
                                ? "Application active"
                                : "Application inactive"
                            }
                            arrow
                          >
                            {solution.activated ? (
                              <CheckCircle
                                sx={{
                                  color: theme.success,
                                  fontSize: 28,
                                  filter:
                                    "drop-shadow(0 2px 4px rgba(16, 185, 129, 0.2))",
                                }}
                              />
                            ) : (
                              <Cancel
                                sx={{
                                  color: theme.error,
                                  fontSize: 28,
                                  opacity: 0.6,
                                }}
                              />
                            )}
                          </Tooltip>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </>
        )}
      </Container>

      {/* Menu d'actions */}
      <Menu
        anchorEl={actionMenu.anchorEl}
        open={Boolean(actionMenu.anchorEl)}
        onClose={handleCloseActionMenu}
        onClick={handleCloseActionMenu}
      >
        {/* Upload - Réservé aux TAM */}
        <MenuItem
          onClick={() => actionMenu.solution && handleOpenUpload(actionMenu.solution)}
          disabled={actionMenu.solution ? !isUserAuthorized(actionMenu.solution) : true}
        >
          <ListItemIcon>
            <CloudUpload fontSize="small" />
          </ListItemIcon>
          <ListItemText>
            Upload Document
            {actionMenu.solution && !isUserAuthorized(actionMenu.solution) && (
              <Typography variant="caption" display="block" color="text.secondary">
                Réservé aux TAM
              </Typography>
            )}
          </ListItemText>
        </MenuItem>

        {/* Download - Réservé aux TAM */}
        <MenuItem
          onClick={() => actionMenu.solution && handleOpenDownload(actionMenu.solution)}
          disabled={actionMenu.solution ? !isUserAuthorized(actionMenu.solution) : true}
        >
          <ListItemIcon>
            <CloudDownload fontSize="small" />
          </ListItemIcon>
          <ListItemText>
            Download Document
            {actionMenu.solution && !isUserAuthorized(actionMenu.solution) && (
              <Typography variant="caption" display="block" color="text.secondary">
                Réservé aux TAM
              </Typography>
            )}
          </ListItemText>
        </MenuItem>

        {/* Afficher les versions - Réservé aux TAM */}
        <MenuItem
          onClick={() => actionMenu.solution && handleShowVersions(actionMenu.solution)}
          disabled={actionMenu.solution ? !isUserAuthorized(actionMenu.solution) : true}
        >
          <ListItemIcon>
            <AttachFile fontSize="small" />
          </ListItemIcon>
          <ListItemText>
            Afficher les Documents
            {actionMenu.solution && !isUserAuthorized(actionMenu.solution) && (
              <Typography variant="caption" display="block" color="text.secondary">
                Réservé aux TAM
              </Typography>
            )}
          </ListItemText>
        </MenuItem>
      </Menu>

      {/* Dialog d'upload */}
      <Dialog
        open={uploadState.open}
        onClose={handleCloseUpload}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
            <CloudUpload color="primary" />
            <Typography variant="h6" component="span">
              Uploader un document
            </Typography>
            <Chip
              label="TAM/Architecte"
              size="small"
              color="primary"
              variant="outlined"
              sx={{ ml: 1 }}
            />
          </Box>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
            Pour l'application: <strong>{uploadState.solutionName}</strong>
          </Typography>
        </DialogTitle>

        <DialogContent>
          <Box sx={{ mt: 2 }}>
            {/* Champ Document */}
            {/* Afficher la version automatique au lieu du champ de saisie */}
            <Box sx={{ mb: 3, p: 2, backgroundColor: alpha(theme.primary, 0.05), borderRadius: 1 }}>
              <Typography variant="body2" sx={{ fontWeight: 600, color: theme.primary }}>
                Veillez sélectionner un fichier
              </Typography>
              <Typography variant="body2" sx={{ mt: 1, fontFamily: 'monospace' }}>
                {uploadState.version || "Aucun fichier sélectionné"}
              </Typography>

            </Box>

            {/* Sélection de fichier */}
            <input
              type="file"
              accept=".pdf,.xlsx,.xls,.ppt,.pptx,.doc,.docx,.txt,.jpg,.jpeg,.png"
              onChange={handleFileSelect}
              style={{ display: "none" }}
              id="file-upload"
            />
            <label htmlFor="file-upload">
              <Button
                variant="outlined"
                component="span"
                startIcon={<AttachFile />}
                fullWidth
                sx={{
                  py: 1.5,
                  borderStyle: "dashed",
                  borderWidth: 2,
                  borderColor: theme.primary,
                  backgroundColor: alpha(theme.primary, 0.05),
                  "&:hover": {
                    backgroundColor: alpha(theme.primary, 0.1),
                    borderColor: theme.primary,
                    borderWidth: 2,
                  },
                }}
              >
                {uploadState.file ? uploadState.file.name : "Sélectionner un fichier"}
              </Button>
            </label>

            {uploadState.file && (
              <Box sx={{ mt: 2, p: 2, backgroundColor: alpha(theme.success, 0.05), borderRadius: 1 }}>
                <Typography variant="body2" sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    {getFileIcon(uploadState.file.name)}
                    <strong>{uploadState.file.name}</strong>
                  </Box>                  Fichier sélectionné: <strong>{uploadState.file.name}</strong>
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  Type: {uploadState.file.type || "Non spécifié"} |
                  Taille: {(uploadState.file.size / 1024 / 1024).toFixed(2)} MB |
                  Extension: {uploadState.file.name.split('.').pop()?.toUpperCase() || "Aucune"}
                </Typography>
              </Box>
            )}

            {uploadState.uploading && (
              <Box sx={{ mt: 2 }}>
                <LinearProgress
                  variant="determinate"
                  value={uploadState.progress}
                  sx={{
                    height: 8,
                    borderRadius: 4,
                    backgroundColor: alpha(theme.primary, 0.1),
                    "& .MuiLinearProgress-bar": {
                      backgroundColor: theme.success,
                      borderRadius: 4,
                    }
                  }}
                />
                <Typography variant="body2" align="center" sx={{ mt: 1 }}>
                  Upload en cours... {uploadState.progress}%
                </Typography>
              </Box>
            )}

            {uploadState.error && (
              <Alert severity="error" sx={{ mt: 2 }}>
                {uploadState.error}
              </Alert>
            )}
          </Box>
        </DialogContent>

        <DialogActions>
          <Button onClick={handleCloseUpload} disabled={uploadState.uploading}>
            Annuler
          </Button>
          <Button
            onClick={handleUpload}
            disabled={!uploadState.file || !uploadState.version || uploadState.uploading}
            variant="contained"
            startIcon={uploadState.uploading ? <CircularProgress size={16} /> : <CloudUpload />}
          >
            {uploadState.uploading ? "Upload en cours..." : "Uploader"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Dialog de download */}
      <Dialog
        open={downloadState.open}
        onClose={handleCloseDownload}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
            <CloudDownload color="primary" />
            <Typography variant="h6" component="span">
              Télécharger un document
            </Typography>
            <Chip
              label="TAM/Architecte"
              size="small"
              color="primary"
              variant="outlined"
              sx={{ ml: 1 }}
            />
          </Box>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
            Pour l'application: <strong>{downloadState.solutionName}</strong>
          </Typography>
        </DialogTitle>

        <DialogContent>
          <Box sx={{ mt: 2 }}>

            <FormControl fullWidth sx={{ mb: 3 }}>
              <InputLabel id="version-select-label">Document</InputLabel>
              <Select
                labelId="version-select-label"
                value={downloadState.version}
                label="Document"
                onChange={(event) => setDownloadState(prev => ({
                  ...prev,
                  version: event.target.value,
                  error: null
                }))}
              >
                {versionsBySolution.get(downloadState.solutionId || 0)?.map((version) => (
                  <MenuItem key={version} value={version}>
                    <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                      <Chip
                        icon={getFileIcon(version)}
                        label={version}
                        variant="outlined"
                        sx={{
                          justifyContent: 'flex-start',
                          py: 2,
                          fontSize: '14px',
                          '& .MuiChip-icon': { mr: 1 },
                        }}
                      />
                    </Box>
                  </MenuItem>
                ))}
                {(!versionsBySolution.get(downloadState.solutionId || 0) ||
                  versionsBySolution.get(downloadState.solutionId || 0)?.length === 0) && (
                    <MenuItem value="0.0.1">
                      <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                        <InsertDriveFile sx={{ color: theme.textSecondary }} />
                        Document 0.0.1 (par défaut)
                      </Box>
                    </MenuItem>
                  )}
              </Select>
              <FormHelperText>
                Sélectionnez la version à télécharger
                {versionsBySolution.get(downloadState.solutionId || 0)?.length === 0 &&
                  " - Aucune version disponible, utilisation de la version par défaut"}
              </FormHelperText>
            </FormControl>

            {downloadState.downloading && (
              <Box sx={{ mt: 2 }}>
                <LinearProgress
                  sx={{
                    height: 8,
                    borderRadius: 4,
                    backgroundColor: alpha(theme.primary, 0.1),
                    "& .MuiLinearProgress-bar": {
                      backgroundColor: theme.success,
                      borderRadius: 4,
                    }
                  }}
                />
                <Typography variant="body2" align="center" sx={{ mt: 1 }}>
                  Téléchargement en cours...
                </Typography>
              </Box>
            )}

            {downloadState.error && (
              <Alert severity="error" sx={{ mt: 2 }}>
                {downloadState.error}
              </Alert>
            )}
          </Box>
        </DialogContent>

        <DialogActions>
          <Button onClick={handleCloseDownload} disabled={downloadState.downloading}>
            Annuler
          </Button>
          <Button
            onClick={handleDownload}
            disabled={!downloadState.version || downloadState.downloading}
            variant="contained"
            startIcon={downloadState.downloading ? <CircularProgress size={16} /> : <CloudDownload />}
          >
            {downloadState.downloading ? "Téléchargement..." : "Télécharger"}
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog
        open={versionsState.versions.length > 0 && !uploadState.open && !downloadState.open}
        onClose={() => setVersionsState(prev => ({ ...prev, versions: [] }))}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
            <AttachFile color="primary" />
            <Typography variant="h6" component="span">
              Documents disponibles
            </Typography>
            <Chip
              label="TAM/Architecte"
              size="small"
              color="primary"
              variant="outlined"
              sx={{ ml: 1 }}
            />
          </Box>
        </DialogTitle>

        <DialogContent>
          {versionsState.loading ? (
            <Box sx={{ display: "flex", justifyContent: "center", py: 3 }}>
              <CircularProgress />
            </Box>
          ) : versionsState.error ? (
            <Alert severity="error" sx={{ mt: 2 }}>
              {versionsState.error}
            </Alert>
          ) : (
            <Stack spacing={1} sx={{ mt: 2 }}>
              {versionsState.versions.map((version, index) => (
                <Chip
                  key={index}
                  label={
                    <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                      <MenuItem key={version} value={version}>
                        <ListItemIcon sx={{ minWidth: 36 }}>
                          {getFileIcon(version)}
                        </ListItemIcon>
                        <ListItemText>{version}</ListItemText>
                      </MenuItem>
                    </Box>
                  }
                  variant="outlined"
                  sx={{
                    justifyContent: "flex-start",
                    py: 2,
                    fontSize: "14px",
                  }}
                />
              ))}
              {versionsState.versions.length === 0 && (
                <Typography color="text.secondary" textAlign="center" py={2}>
                  Aucune version disponible
                </Typography>
              )}
            </Stack>
          )}
        </DialogContent>

        <DialogActions>
          <Button onClick={() => setVersionsState(prev => ({ ...prev, versions: [] }))}>
            Fermer
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default MyViewPage;