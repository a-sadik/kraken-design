// src/services/ServerService.ts

import axios, { AxiosError } from "axios";

// import files
import { postDeploySignatureApiUrl } from "@/config/api.config";
import { ErrorResponse } from "@/exceptions/ErrorResponse";
import { serverResToManyCreateReq } from "@/mappers/ServerMapper";
import { ServerRequestDTO } from "@/types/dto/request/ServerRequestDTO";
import { ServerResponseDTO } from "@/types/dto/response/ServerResponseDTO";
import { PaginatedServerResponseDTO } from "@/types/dto/PaginatedServerResponseDTO";

const PREFIX_PATH = import.meta.env.VITE_PREFIX_DATA_PATH;
// const SUFFIX_PATH = import.meta.env.VITE_SUFFIX_DATA_PATH;
const SERVER_PORT = import.meta.env.VITE_DATA_SERVER_PORT;

const PREFIX_CORE_PATH = import.meta.env.VITE_PREFIX_RELIABILITY_PATH;
const SUFFIX_CORE_PATH = import.meta.env.VITE_SUFFIX_RELIABILITY_PATH;
const SERVER_CORE_PATH = import.meta.env.VITE_RELIABILITY_SERVER_PORT;
// const path = `${PREFIX_PATH}:${SERVER_PORT}/${SUFFIX_PATH}/servers`;
const path_core = `${PREFIX_CORE_PATH}:${SERVER_CORE_PATH}/${SUFFIX_CORE_PATH}`;

// Function to receive all servers
export const getAllServers = async (): Promise<ServerResponseDTO[]> => {
  try {
    const token = localStorage.getItem("access_token");
    const url = `${path_core}/fiabilisation/servers/`;

    const response = await axios.get<PaginatedServerResponseDTO>(url, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    return response.data.results;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;
    console.error(
      "Error fetching all servers data:",
      err.response?.data.message,
    );
    throw err;
  }
};

// Function to receive one server by id
export const getServerById = async (
  id: number,
): Promise<ServerResponseDTO | null> => {
  try {
    const token = localStorage.getItem("access_token");
    const response = await axios.get<ServerResponseDTO | null>(
      `${path_core}/fiabilisation/servers/details/${id}/`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      },
    );
    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;
    console.error("Error fetching server data by id:", err.response?.data);
    throw error;
  }
};

// Function for create one server
export const createSingleServer = async (server: ServerRequestDTO) => {
  try {
    const token = localStorage.getItem("access_token");
    await axios.post<ServerResponseDTO | null>(
      `${path_core}/admin/servers/`,
      server,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      },
    );
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;
    console.error(
      "Error create one new server data:",
      err.response?.data.message,
    );
    throw err;
  }
};

// Function for create many server
export const createManyServer = async (servers: []) => {
  try {
    const token = localStorage.getItem("access_token");
    const reqBody = await serverResToManyCreateReq(servers);
    await axios.post(`${path_core}/fiabilisation/servers/many`, reqBody, {
      // Adjusted endpoint
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
  } catch (err) {
    const error = err as AxiosError<ErrorResponse>;
    console.error("Error create many server:", error);
    throw error.response;
  }
};

// Function for update one server by id
export const updateServer = async (
  serverId: number,
  server: ServerRequestDTO,
  _solution_ids: number[],
) => {
  try {
    const token = localStorage.getItem("access_token");
    const reqBody: ServerRequestDTO = server;
    await axios.patch<ServerResponseDTO | null>(
      `${path_core}/admin/servers/${serverId}/`,
      reqBody,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      },
    );
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;
    console.error("Error update one server data:", err.response?.data.message);
    throw err;
  }
};

// Function for delete one server by id
export const deleteServer = async (sereverId: number) => {
  try {
    const token = localStorage.getItem("access_token");
    await axios.delete(`${path_core}/fiabilisation/servers/${sereverId}/`, {
      // Adjusted endpoint
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
  } catch (error) {
    console.error("Error delete server by id:", error);
    throw error;
  }
};

export const deployServerSignature = async (
  _sereverId: number,
  deploy_payload: any,
) => {
  try {
    const token = localStorage.getItem("access_token");
    await axios.post(postDeploySignatureApiUrl(), deploy_payload, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
  } catch (error) {
    console.error("Error signing server by id:", error);
    throw error;
  }
};

// Function to receive health of data service
export const getHealthBackendData = async () => {
  const healthPath = `${PREFIX_PATH}:${SERVER_PORT}/health`; // Using imported constants
  const response = await axios.get(healthPath);
  return response.data;
};
