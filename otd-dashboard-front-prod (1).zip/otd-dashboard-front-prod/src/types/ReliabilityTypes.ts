import { ServerConformityType } from "@/enums/ServerConformityView";

export interface Comparatif {
  count: number;
  next: string | null;
  previous: string | null;
  results: ServerResult[];
}

export interface ServerResult {
  id: number;
  differences: Differences;
  ip: string;
  bigfix_data: BigfixData;
  inventory_data: InventoryData;
}

export interface InventoryData {
  id: number;
  hostname: string;
  ip_addresses: string[];
  os: string;
  functionals_admins: string[] | null;
  technicals_admins: string[] | null;
  tam: string | null;
  pci: string | null;
  domain: string | null;
  entity: string | null;
  pole: string | null;
  environments: string[];
  server_nature: string[];
  solution_popularity: string | null;
  solution_role: string | null;
  solution_name: string;
  solution_type: string | null;
  solution_deployed_version: string | null;
}

export interface BigfixData {
  id: number;
  hostname: string;
  last_seen: string;
  ip_addresses: string[];
  technicals_admins: string | null;
  os: string;
  solution_type: string | null;
  domain: string | null;
  entity: string | null;
  environments: string | null;
  server_nature: string | null;
  solution_popularity: string | null;
  solution_role: string | null;
  solution_name: string | null;
  functionals_admins: string | null;
  solution_deployed_version: string | null;
  tam: string | null;
}

export interface Differences {
  [key: string]: {
    bigfix: unknown;
    inventory: unknown;
  };
}

export interface DropdownOptions {
  [key: string]: string[];
}

export interface EditableValues {
  [key: string]: string;
}

export interface ServerComparisonState {
  data: ServerResult[];
  loading: boolean;
  error: string | null;
  page: number;
  rowsPerPage: number;
  searchTerm: string;
  totalCount: number;
  selectedTab: ServerConformityType;
  editableValues: EditableValues;
  apiDropdownOptions: DropdownOptions;
}

type BaseLabels = {
  extraProperty?: string;
};

export type TabLabels = BaseLabels & {
  [key in ServerConformityType]: string;
};

export interface ApiFieldMapping {
  [key: string]: string;
}
