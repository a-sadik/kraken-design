// src/types/dto/PersonPostDTO.ts

export interface PersonPostRequestDTO {
  person_id: number;
  post_id: number;
}

export interface AssignPostsRequestDTO {
  postIds: number[];
}

export interface PersonPostShortResponseDTO {
  id: number;
  person_id: number;
  post_id: number;
}

export interface PersonPostDetailResponseDTO {
  id: number;
  person: {
    person_id: number;
    firstname: string;
    lastname: string;
    email?: string;
  };
  post: {
    post_id: number;
    post_name: string;
  };
}
