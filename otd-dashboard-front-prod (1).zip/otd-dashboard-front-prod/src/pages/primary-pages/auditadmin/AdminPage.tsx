// src/pages/primary-pages/auditadmin/AdminPage.tsx

import React from "react";
import { ThemeProvider, createTheme } from "@mui/material/styles";
import { Container, Box, Divider, Typography, Grid } from "@mui/material";
import { getCssVariableValue } from "@/utils/getDynamicColor";

// Sections
import PostSection from "@/pages/primary-pages/auditadmin/sections/PostSection";
import PersonSection from "@/pages/primary-pages/auditadmin/sections/PersonSection";
import SolutionSection from "@/pages/primary-pages/auditadmin/sections/SolutionSection";
import EntitySection from "@/pages/primary-pages/auditadmin/sections/EntitySection";
import PoleSection from "@/pages/primary-pages/auditadmin/sections/PoleSection";
import DomaineSection from "@/pages/primary-pages/auditadmin/sections/DomaineSection";

const AdminPage: React.FC = () => {
  const color = getCssVariableValue("--bigfix-primary-color");
  const theme = createTheme({
    palette: {
      primary: { main: color },
      success: { main: "#00b894", contrastText: "#fff" },
      info: { main: "#0984e3", contrastText: "#fff" },
    },
    typography: {
      h4: {
        fontWeight: 800,
        fontFamily: "Open Sans, sans-serif",
        letterSpacing: "0.05em",
      },
    },
  });

  return (
    <ThemeProvider theme={theme}>
      <Container maxWidth="xl" disableGutters>
        <Box p={3}>
          <Typography
            variant="h2"
            gutterBottom
            display={"flex"}
            justifyContent="center"
            alignItems="center"
          >
            Panneau d'administration
          </Typography>

          {/* ===== Gestion principale ===== */}
          {/* <Typography variant="h5" align="center" fontWeight="bold" sx={{ mb: 3 }}>
              Gestion principale
            </Typography> */}

          {/* Post centered */}
          {/* <Grid container spacing={3} sx={{ mb: 4, justifyContent: 'center' }}>
              <Grid item xs={12} sm={6} md={6}>
                <Box sx={{ width: '100%' }}>
                  <PostSection />
                </Box>
              </Grid>
            </Grid> */}

          {/* Personne & Solution side by side */}
          <Divider sx={{ my: 4 }} />
          <Grid
            container
            spacing={4}
            justifyContent="space-between"
            alignItems="flex-start"
          >
            <Grid item xs={12} sm={6} md={4}>
              <PersonSection />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <SolutionSection />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <PostSection />
            </Grid>
          </Grid>

          {/* ===== Gestion d'organisme ===== */}
          <Divider sx={{ my: 4 }} />
          {/* <Typography variant="h5" align="center" fontWeight="bold" sx={{ mb: 3 }}>
              Gestion d'organisme
            </Typography> */}

          {/* Entity, Pole & Domaine side by side */}
          <Grid
            container
            spacing={4}
            justifyContent="space-between"
            alignItems="flex-start"
          >
            <Grid item xs={12} sm={6} md={4}>
              <Box sx={{ width: "100%" }}>
                <EntitySection />
              </Box>
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <Box sx={{ width: "100%" }}>
                <PoleSection />
              </Box>
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <Box sx={{ width: "100%" }}>
                <DomaineSection />
              </Box>
            </Grid>
          </Grid>
        </Box>
      </Container>
    </ThemeProvider>
  );
};

export default AdminPage;
