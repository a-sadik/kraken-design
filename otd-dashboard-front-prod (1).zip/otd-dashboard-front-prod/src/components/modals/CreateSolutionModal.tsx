import { useEffect, useState } from "react";
import {
  TextField,
  Button,
  Box,
  Grid,
  Typography,
  CircularProgress,
  Snackbar,
  Alert,
  Autocomplete,
} from "@mui/material";
import { useForm, Controller } from "react-hook-form";
import { z as zod } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

import MyModal from "@/components/modals/MyModal";
import { getAllDomains } from "@/services/admin/DomainService";
// import { createSolution } from '@/services/SolutionService';

const formSchema = zod.object({
  solution_name: zod
    .string()
    .trim()
    .min(1, "Le nom de la solution est requis."),
  domainId: zod.number({ required_error: "Le domaine est requis." }),
});

type FormCreateSolution = zod.infer<typeof formSchema>;

interface DomainOption {
  domain_id: number;
  domain_name: string;
}

export const CreateSolutionModal = ({ open, onClose }: any) => {
  const {
    register,
    handleSubmit,
    reset,
    control,
    formState: { errors, isValid },
  } = useForm<FormCreateSolution>({
    resolver: zodResolver(formSchema),
    mode: "all",
    defaultValues: {
      solution_name: "",
      domainId: undefined,
    },
  });

  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successSnackbar, setSuccessSnackbar] = useState(false);
  const [domains, setDomains] = useState<DomainOption[]>([]);
  const [loadingDomains, setLoadingDomains] = useState(false);

  useEffect(() => {
    if (open) {
      reset();
      setErrorMessage(null);
      fetchDomains();
    }
  }, [open]);

  const fetchDomains = async () => {
    setLoadingDomains(true);
    try {
      const data = await getAllDomains();
      setDomains(data);
    } catch (err) {
      console.error("Erreur lors de la récupération des domaines:", err);
    } finally {
      setLoadingDomains(false);
    }
  };

  const handleSave = async (data: FormCreateSolution) => {
    console.log("Création solution avec:", data);
    setLoading(true);
    setErrorMessage(null);

    // try {
    //   await createSolution(data);
    //   setSuccessSnackbar(true);
    //   onClose();
    // } catch (error) {
    //   console.error('Erreur lors de la création:', error);
    //   setErrorMessage("Échec de la création.");
    // } finally {
    //   setLoading(false);
    // }
  };

  return (
    <>
      <MyModal open={open} onClose={onClose} title="Ajouter une Solution">
        <form onSubmit={handleSubmit(handleSave)}>
          <Grid container spacing={2} sx={{ p: 2 }}>
            {/* Nom de la solution */}
            <Grid item xs={12} container spacing={2} alignItems="center">
              <Grid item xs={4}>
                <Typography fontWeight="bold">Nom de la solution</Typography>
              </Grid>
              <Grid item xs={8} style={{ width: 500 }}>
                <TextField
                  {...register("solution_name")}
                  error={!!errors.solution_name}
                  helperText={errors.solution_name?.message}
                  fullWidth
                  placeholder="Entrer le nom de la solution"
                />
              </Grid>
            </Grid>

            {/* Sélection du domaine */}
            <Grid item xs={12} container spacing={2} alignItems="center">
              <Grid item xs={4}>
                <Typography fontWeight="bold">Domaine</Typography>
              </Grid>
              <Grid item xs={8}>
                <Controller
                  control={control}
                  name="domainId"
                  render={({ field }) => (
                    <Autocomplete
                      options={domains}
                      getOptionLabel={(option) => option.domain_name}
                      loading={loadingDomains}
                      onChange={(_, newValue) =>
                        field.onChange(newValue?.domain_id ?? null)
                      }
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          placeholder="Choisir un domaine"
                          error={!!errors.domainId}
                          helperText={errors.domainId?.message}
                          fullWidth
                        />
                      )}
                    />
                  )}
                />
              </Grid>
            </Grid>

            {errorMessage && (
              <Grid item xs={12}>
                <Alert severity="error" variant="filled">
                  {errorMessage}
                </Alert>
              </Grid>
            )}
          </Grid>

          <Box textAlign="right" px={2} pb={2}>
            <Button onClick={onClose} sx={{ mr: 1 }}>
              Annuler
            </Button>
            <Button
              type="submit"
              variant="contained"
              disabled={!isValid || loading}
            >
              {loading ? <CircularProgress size={20} /> : "Ajouter"}
            </Button>
          </Box>
        </form>
      </MyModal>

      <Snackbar
        open={successSnackbar}
        autoHideDuration={3000}
        onClose={() => setSuccessSnackbar(false)}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <Alert
          onClose={() => setSuccessSnackbar(false)}
          severity="success"
          variant="filled"
        >
          Solution ajoutée avec succès !
        </Alert>
      </Snackbar>
    </>
  );
};
