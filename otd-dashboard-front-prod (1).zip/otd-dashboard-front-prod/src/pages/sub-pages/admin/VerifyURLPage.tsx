import type React from "react";
import { useState } from "react"; // Added useMemo
import {
  Typography,
  Tabs,
  Tab,
  Container, // Added Grid for filter layout
} from "@mui/material";
import TeamsCRUD from "@/components/tabs/teams-crud";
import CertificatesTab from "@/components/tabs/certificates-crud";

export default function AdministrationPage() {
  const [tabValue, setTabValue] = useState(0);

  const handleTabChange = (_event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  return (
    <Container maxWidth="xl" sx={{ py: 4 }}>
      <Typography
        variant="h4"
        component="h1"
        gutterBottom
        sx={{ fontWeight: "bold", mb: 4, color: "text.primary" }}
      >
        Configuration de la Supervision SSL
      </Typography>
      <Tabs
        value={tabValue}
        onChange={handleTabChange}
        sx={{
          mb: 4,
          borderBottom: 1,
          borderColor: "divider",
          "& .MuiTabs-indicator": { bgcolor: "primary.main" },
          "& .MuiTab-root": {
            textTransform: "none",
            fontWeight: "bold",
            fontSize: "1.1rem",
            color: "text.secondary",
            "&.Mui-selected": {
              color: "primary.main",
            },
          },
        }}
      >
        <Tab label="Equipes" /> {/* New Tab */}
        <Tab label="Certificats Externe" /> {/* New Tab */}
      </Tabs>
      {tabValue === 0 && <TeamsCRUD />} {/* New Component */}
      {tabValue === 1 && <CertificatesTab />}
    </Container>
  );
}
