// src/pages/DetailsPage.tsx

import Typography from "@mui/material/Typography";
// import { useData } from '@/hooks/DataContext';

export default function DetailsPage() {
  // const { bigFixData, inventoryData } = useData();

  return (
    <>
      <div>
        <Typography variant="h4">Details Page</Typography>
      </div>

      {/* <Typography variant="h6">BigFix Data:</Typography>
      <pre>{JSON.stringify(bigFixData, null, 2)}</pre>

      <Typography variant="h6">Inventory Data:</Typography>
      <pre>{JSON.stringify(inventoryData, null, 2)}</pre> */}
    </>
  );
}
