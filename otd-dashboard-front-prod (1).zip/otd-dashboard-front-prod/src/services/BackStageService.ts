// src/services/backstageService.ts

import { AxiosError } from "axios";
import { BackStageResponseDTO } from "@/types/dto/BackStageDTO";
import { backStageResToView } from "@/mappers/BackStageMapper";
import { ErrorResponse } from "@/exceptions/ErrorResponse";
import BackStageView from "@/types/view/BackStageView";
import apiClientHttp from "./apiClientHttp";

export const fetchAllDataBySection = async (
  section: string,
): Promise<BackStageView[]> => {
  try {
    // const url = `http://localhost:3000/api/catalog/entities?filter=${section.toLowerCase()}`;
    const url = `/backstage?filter=${section.toLowerCase()}`;

    const resp =
      await apiClientHttp.dataApiClient.get<BackStageResponseDTO[]>(url);
    return backStageResToView(resp.data);
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error("Error fetching all Data:", err.response?.data.message);
    throw err;
  }
};
