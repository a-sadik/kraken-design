// src/types/dto/BackStageDTO.ts

export interface BackStageResponseDTO {
  name?: string;
  title: string;
  owner: string;
  type: string | null;
  lifecycle: string | null;
  description: string | null;
  tags: string[] | null;
  displayName?: string;
  email?: string;
}

export interface APIEntity {
  name: string;
  title?: string;
  type: string;
  parent?: string;
  relations?: {
    type: string;
    target?: {
      kind: string;
      name: string;
    };
  }[];
}
