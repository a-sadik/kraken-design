// src/types/dto/response/EntityResponseDTO.ts

export interface EntityResponseDTO {
  entity_id: number;
  entity_name: string;
  entity_manager: string;
  created_at: Date;
  updated_at?: Date;
  created_by: string;
  updated_by?: string;
}
