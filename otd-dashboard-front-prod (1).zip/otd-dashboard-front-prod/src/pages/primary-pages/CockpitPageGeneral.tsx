// src/pages/SelfServicePage.tsx
import React from "react";
import { useNavigate } from "react-router-dom";
import { Button, Grid2, Grid, Box, Typography } from "@mui/material";
// import files
import { keycloak } from "../../auth/keycloakConnectAdapter";
// import icons
// import StorageIcon from '@mui/icons-material/Storage';
import { PiCertificateLight } from "react-icons/pi";
import { FiServer } from "react-icons/fi";
import { MdDashboard } from "react-icons/md";
// import { MdDashboard } from "react-icons/md";
// import { SiAmazons3 } from "react-icons/si";
// import { HiOutlineServerStack } from "react-icons/hi2";
// import { MdSettingsBackupRestore } from "react-icons/md";

const SelfServicePage: React.FC = () => {
  const navigate = useNavigate();

  const goToPage = (path: string) => {
    navigate(path);
  };

  const selfServiceItems = [
    // Certificat management
    ...(keycloak.hasRoles([
      "security_role",
      "tam_role",
      "ops_role",
      "read_only_role",
    ])
      ? [
        {
          label: "Cockpit certificat",
          icon: <PiCertificateLight size={60} />,
          path: "/cockpit",
          onClick: () => goToPage("/cockpit"),
          type: "certificat", // Identifiant pour la couleur spéciale
        },
      ]
      : []),


    // OpenShift management
    ...(keycloak.hasRoles(["tam_role", "ops_role", "read_only_role"])
      ? [
        {
          label: "Cockpit Fiabilisation",
          icon: <FiServer size={60} />,
          path: "/",
          onClick: () => goToPage("/cockpit-serveur"),
          type: "certificat",
        },
      ]
      : []),


    //serveur AITA
    ...(keycloak.hasRoles(["admin_role", "tam_role"])
      ? [
        {
          label: "Cockpit AITA",
          icon: <MdDashboard size={60} />, 
          path: "/",
          onClick: () => goToPage("/cockpit-AITA"),
          type: "certificat",
        }
      ]
      : []),

  ];

  return (
    <Grid2
      container
      spacing={2}
      sx={{
        width: "70%",
        marginX: "auto",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      {selfServiceItems.map(({ label, icon, onClick, type }, index) => (
        <Grid
          key={index}
          item
          xs={4}
          component="div"
          sx={{ display: "flex", justifyContent: "center" }}
        >
          <Button
            className={`btn-self-service ${type === "certificat" ? "certificat" : "other"}`}
            color={type === "certificat" ? "primary" : "inherit"}
            variant="contained"
            size="large"
            onClick={onClick}
            sx={{
              minWidth: "120px",
              height: "140px",
              margin: 1,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              textTransform: "uppercase",
              ...(type !== "certificat" && {
                backgroundColor: "",
                color: "#ffffff",
                "&:hover": {
                  backgroundColor: "#757575", // Couleur grise plus foncée au survol
                },
              }),
            }}
          >
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
              }}
            >
              {icon}
              <Typography
                variant="body2"
                sx={{ mt: 1, fontWeight: "bold", fontSize: "16px" }}
              >
                {label}
              </Typography>
            </Box>
          </Button>
        </Grid>
      ))}
    </Grid2>
  );
};

export default SelfServicePage;
