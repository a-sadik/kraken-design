// src/api/apiClientHttp.ts

import axios from "axios";

const PREFIX_DATA_PATH = import.meta.env.VITE_PREFIX_DATA_PATH;
const SUFFIX_DATA_PATH = import.meta.env.VITE_SUFFIX_DATA_PATH;
const SERVER_DATA_PORT = import.meta.env.VITE_DATA_SERVER_PORT;
const baseUrlApiData = `${PREFIX_DATA_PATH}:${SERVER_DATA_PORT}/${SUFFIX_DATA_PATH}`;

const PREFIX_CORE_PATH = import.meta.env.VITE_PREFIX_SOURCE_PATH;
const SUFFIX_CORE_PATH = import.meta.env.VITE_SUFFIX_SOURCE_PATH;
const SERVER_CORE_PORT = import.meta.env.VITE_SOURCE_SERVER_PORT;
const baseURLApiCore = `${PREFIX_CORE_PATH}:${SERVER_CORE_PORT}/${SUFFIX_CORE_PATH}`;

const dataApiClient = axios.create({ baseURL: baseUrlApiData });
const coreApiClient = axios.create({ baseURL: baseURLApiCore });

dataApiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("access_token");

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }

    return config;
  },
  (error) => {
    return Promise.reject(error);
  },
);

coreApiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("access_token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  },
);

export default { dataApiClient, coreApiClient };
