// src/pages/primary-pages/auditadmin/sections/PersonSection.tsx

import React, { useEffect, useMemo, useState } from "react";
// import { useNavigate } from 'react-router-dom';

import {
  Box,
  Grid,
  Stack,
  Typography,
  IconButton,
  Collapse,
  TextField,
  Button,
  Snackbar,
  Alert as MuiAlert,
  useMediaQuery,
} from "@mui/material";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import SearchIcon from "@mui/icons-material/Search";

import WidgetMainContainer from "@/components/containers/WidgetMainContainer";
import { MaterialReactTable, MRT_ColumnDef } from "material-react-table";

import { getAllPersons } from "@/services/admin/PersonService";
import { PersonShortResponseDTO } from "@/types/dto/PersonDTO";

import { AffectPostModal } from "@/components/modals/AffectPostModal";
import { InfoModal } from "@/components/modals/InfoModal";

const PAGE_SIZE = 5;

const PersonSection: React.FC = () => {
  const [persons, setPersons] = useState<PersonShortResponseDTO[]>([]);
  const [loading, setLoading] = useState(false);

  const [collapseOpen, setCollapseOpen] = useState(true);
  const [globalFilter, setGlobalFilter] = useState("");

  const [selected, setSelected] = useState<PersonShortResponseDTO | null>(null);
  const [openPost, setOpenPost] = useState(false);
  const [infoOpen, setInfoOpen] = useState(false);

  const [snack, setSnack] = useState({
    open: false,
    msg: "",
    severity: "success" as "success" | "error",
  });

  const isXs = useMediaQuery("(max-width:480px)");

  // const navigate = useNavigate();

  useEffect(() => {
    setLoading(true);
    fetchPersons();
  }, []);

  const fetchPersons = () => {
    setLoading(true);
    getAllPersons()
      .then((data) => {
        const sorted = [...data].sort((a, b) => b.person_id - a.person_id);
        setPersons(sorted);
      })
      .catch(() =>
        setSnack({
          open: true,
          msg: "Erreur de chargement",
          severity: "error",
        }),
      )
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    if (globalFilter.trim() && !collapseOpen) {
      setCollapseOpen(true);
    }
  }, [globalFilter]);

  const columns = useMemo<MRT_ColumnDef<PersonShortResponseDTO>[]>(
    () => [
      {
        header: "Nom complet",
        accessorFn: (row) => `${row.firstname} ${row.lastname}`,
        id: "fullname",
        size: 150,
        Cell: ({ row }) => (
          <Typography
            variant="subtitle1"
            sx={{
              cursor: "pointer",
              fontWeight: 500,
              color: "primary.main",
              "&:hover": { textDecoration: "underline" },
            }}
            onClick={() => {
              setSelected(row.original);
              setInfoOpen(true);
            }}
          >
            {row.original.firstname} {row.original.lastname}
          </Typography>
        ),
        muiTableHeadCellProps: { sx: { display: "none" } },
      },
      {
        header: "",
        id: "actions",
        enableSorting: false,
        enableColumnFilter: false,
        muiTableHeadCellProps: { sx: { display: "none" } },
        muiTableBodyCellProps: { sx: { textAlign: "right" } },
        Cell: ({ row }) => (
          <Stack direction="row" justifyContent="flex-end" spacing={1}>
            <Button
              size="small"
              variant="contained"
              color="success"
              sx={{ color: "#fff" }}
              onClick={() => {
                setSelected(row.original);
                setOpenPost(true);
              }}
            >
              POSTE
            </Button>
          </Stack>
        ),
      },
    ],
    [],
  );

  const filteredData = useMemo(() => {
    if (!globalFilter) return persons;
    return persons.filter((p) =>
      `${p.firstname} ${p.lastname}`
        .toLowerCase()
        .includes(globalFilter.toLowerCase()),
    );
  }, [persons, globalFilter]);

  return (
    <Grid container spacing={3} sx={{ mb: 3 }}>
      <Grid item xs={12}>
        <WidgetMainContainer>
          <Stack
            direction="row"
            justifyContent="space-between"
            alignItems="center"
            spacing={1}
            flexWrap="wrap"
          >
            <Typography
              variant="h6"
              fontWeight="bold"
              // sx={{ cursor: 'pointer', color: 'primary.main', '&:hover': { textDecoration: 'underline' } }}
              // onClick={() => navigate('/admin/personne')}
            >
              Personnes
            </Typography>

            <Stack
              direction="row"
              spacing={1}
              alignItems="center"
              flexWrap="wrap"
            >
              {isXs ? (
                <IconButton>
                  <SearchIcon />
                </IconButton>
              ) : (
                <Box sx={{ width: { xs: "120px", sm: "230px" } }}>
                  <TextField
                    size="small"
                    fullWidth
                    placeholder="Rechercher…"
                    value={globalFilter}
                    onChange={(e) => setGlobalFilter(e.target.value)}
                  />
                </Box>
              )}

              <IconButton onClick={() => setCollapseOpen((o) => !o)}>
                {collapseOpen ? <ExpandLessIcon /> : <ExpandMoreIcon />}
              </IconButton>
            </Stack>
          </Stack>

          {collapseOpen ? (
            <Collapse in={collapseOpen}>
              <MaterialReactTable
                columns={columns}
                data={filteredData}
                enableColumnActions={false}
                enableDensityToggle={false}
                enableHiding={false}
                enableFullScreenToggle={false}
                enableToolbarInternalActions={false}
                enableGlobalFilter={false}
                initialState={{
                  pagination: { pageIndex: 0, pageSize: PAGE_SIZE },
                }}
                state={{ isLoading: loading }}
                muiTableHeadProps={{ sx: { display: "none" } }}
                muiTablePaperProps={{
                  elevation: 0,
                  sx: {
                    boxShadow: "none",
                    border: "none",
                    padding: 0,
                    margin: 0,
                  },
                }}
                muiTableContainerProps={{
                  sx: {
                    border: "none",
                    margin: 0,
                    padding: 0,
                    "& .MuiTableRow-root, & .MuiTableCell-root": {
                      borderBottom: "none",
                    },
                  },
                }}
              />
            </Collapse>
          ) : (
            globalFilter && (
              <Box mt={2}>
                <Typography variant="body2" color="textSecondary">
                  {filteredData.length > 0
                    ? `${filteredData.length} résultat(s) trouvé(s) — ouvrez la section pour les afficher.`
                    : "Aucun résultat trouvé."}
                </Typography>
              </Box>
            )
          )}
        </WidgetMainContainer>
      </Grid>

      {selected && (
        <>
          <AffectPostModal
            open={openPost}
            onClose={() => setOpenPost(false)}
            onSave={(payload: { personneIds: string[]; postIds: string[] }) => {
              console.log(payload);
              setOpenPost(false);
            }}
            personName={`${selected.firstname} ${selected.lastname}`}
            personId={selected.person_id.toString()}
          />
          <InfoModal
            open={infoOpen}
            onClose={() => setInfoOpen(false)}
            kind="person"
            id={selected.person_id}
          />
        </>
      )}

      <Snackbar
        open={snack.open}
        autoHideDuration={3000}
        onClose={() => setSnack((s) => ({ ...s, open: false }))}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <MuiAlert severity={snack.severity} variant="filled">
          {snack.msg}
        </MuiAlert>
      </Snackbar>
    </Grid>
  );
};

export default PersonSection;
