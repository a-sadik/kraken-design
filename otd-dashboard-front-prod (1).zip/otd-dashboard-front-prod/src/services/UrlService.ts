// src/services/UrlService.ts

import axios from "axios";
import { CreateUrlDTO, UrlDTO } from "@/types/dto/UrlDTO";

const BASE_URL = "http://localhost:3001/api/v1/urls";

const getAuthHeaders = () => {
  const token = localStorage.getItem("token");
  return {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  };
};

export const getAllUrls = async (): Promise<UrlDTO[]> => {
  const { data } = await axios.get(BASE_URL, getAuthHeaders());
  return data;
};

export const getUrlById = async (id: number): Promise<UrlDTO> => {
  const { data } = await axios.get(`${BASE_URL}/${id}`, getAuthHeaders());
  return data;
};

export const addUrl = async (payload: CreateUrlDTO): Promise<UrlDTO> => {
  const { data } = await axios.post(BASE_URL, payload, getAuthHeaders());
  return data;
};

export const deleteUrl = async (id: number): Promise<void> => {
  await axios.delete(`${BASE_URL}/${id}`, getAuthHeaders());
};
