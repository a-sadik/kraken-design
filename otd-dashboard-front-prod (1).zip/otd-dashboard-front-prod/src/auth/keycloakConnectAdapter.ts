// src/auth/keycloakConnectAdapter.ts

import Keycloak from "keycloak-js";

// import files
import { isInvalid } from "@/utils/validationEnvVar";
import { login, logout } from "@/services/AuthService";
import { getHealthBackendData } from "@/services/ServerService";

const V_KYC_BASE_URL = import.meta.env.VITE_KYC_BASE_URL;
const V_KYC_REALM_NAME = import.meta.env.VITE_KYC_REALM_NAME;
const V_KYC_CLIENT_ID = import.meta.env.VITE_KYC_CLIENT_ID;

const requiredEnvVars = [
  { key: "KYC_BASE_URL", value: V_KYC_BASE_URL },
  { key: "KYC_REALM_NAME", value: V_KYC_REALM_NAME },
  { key: "KYC_CLIENT_ID", value: V_KYC_CLIENT_ID },
];

// Vérification des variables avec journalisation
requiredEnvVars.forEach(({ key, value }) => {
  if (isInvalid(value)) {
    console.error(
      `Environment variable of keycloak '${key}' is missing or invalid.`,
    );
    process.exit(1);
  }
});

const config = {
  url: V_KYC_BASE_URL,
  realm: V_KYC_REALM_NAME,
  clientId: V_KYC_CLIENT_ID,
};

class KeycloakConnectAdapter {
  private keycloak: Keycloak.KeycloakInstance;
  private token: string | null = null;
  private tokenParsed: Keycloak.KeycloakTokenParsed | null = null;

  constructor(config: Keycloak.KeycloakConfig) {
    this.keycloak = new Keycloak(config);
  }

  async init(): Promise<void> {
    try {
      const authenticated = await this.keycloak.init({
        onLoad: "login-required",
        flow: "standard",
        pkceMethod: "S256",
        // flow: "implicit",
        checkLoginIframe: false,
      });

      if (authenticated) {
        this.token = this.keycloak.token || null;
        this.tokenParsed = this.keycloak.tokenParsed || null;
        console.log("Authenticated successfully");
        localStorage.setItem("access_token", this.token || "no token passed");
        await getHealthBackendData();
        await login();
      }
    } catch (error) {
      console.error("Keycloak init error:", error);
      throw error;
    }
  }

  // Méthode pour déclencher le login
  async login(redirectUri?: string): Promise<void> {
    try {
      await this.keycloak.login({ redirectUri: redirectUri });
    } catch (error) {
      console.error("Login failed:", error);
      throw error;
    }
  }

  // Méthode pour déclencher le logout
  async logout(redirectUri?: string): Promise<void> {
    try {
      await getHealthBackendData();
      await logout();
      await this.keycloak.logout({ redirectUri: redirectUri });
      this.token = null;
      this.tokenParsed = null;
    } catch (error) {
      console.error("Logout failed:", error);
      throw error;
    }
  }

  // Récupère le nom complet de l'utilisateur
  getFullName(): string | undefined {
    if (!this.tokenParsed) return undefined;

    const givenName = this.tokenParsed.given_name || "";
    const familyName = this.tokenParsed.family_name || "";

    return `${givenName} ${familyName}`.trim() || undefined;
  }

  getEmail(): string | undefined {
    if (!this.tokenParsed) return undefined;

    return this.tokenParsed.email || "";
  }

  // Méthode pour vérifier si l'utilisateur est authentifié
  isAuthenticated(): boolean {
    return !!this.token && !!this.tokenParsed;
  }

  protect() {
    return async () => {
      if (!this.token) {
        await this.keycloak.login();
        return false;
      }
      return true;
    };
  }

  middleware() {
    return {
      protect: this.protect(),
    };
  }

  getToken(): string | null {
    return this.token;
  }

  hasRoles(roles: string | string[]) {
    if (!this.token) return false;

    try {
      const payload = JSON.parse(atob(this.token.split(".")[1]));
      const tokenRoles = payload?.realm_access?.roles || [];

      const requiredRoles = Array.isArray(roles) ? roles : [roles];

      return requiredRoles.some((role) => tokenRoles.includes(role));
    } catch (error) {
      console.error("Erreur de décodage du token :", error);
      return false;
    }
  }
}

export const keycloak = new KeycloakConnectAdapter(config);
