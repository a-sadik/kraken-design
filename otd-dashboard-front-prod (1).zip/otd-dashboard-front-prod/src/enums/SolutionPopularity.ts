// src/types/enums/SolutionPopularity.ts

export enum SolutionPopularity {
  Agence = "Agence",
  Siege = "Siège",
  Agence_Siege = "Agence et Siège",
  Client_Entreprise = "Client Entreprise",
  CLIENT_PARTICULIER = "Client Particulier",
  Ag_S_CE = "Client Entreprise, Siège et Agence",
}
