// src/components/basics/CustomLoading.tsx

import React from "react";
import CircularProgress from "@mui/material/CircularProgress";
import Backdrop from "@mui/material/Backdrop";

const CustomLoading: React.FC = () => {
  return (
    <Backdrop
      sx={{
        color: "#fff",
        zIndex: (theme) => theme.zIndex.drawer + 1,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
      open={true}
    >
      <CircularProgress sx={{ color: "var(--primary-color)" }} />
    </Backdrop>
  );
};

export default CustomLoading;
