// src/services/PersonService.ts

import { AxiosError } from "axios";

// import files
import {
  PersonDetailResponseDTO,
  PersonShortResponseDTO,
} from "@/types/dto/PersonDTO";
import apiClient from "../apiClientHttp";
import { ErrorResponse } from "@/exceptions/ErrorResponse";

const path = "/persons";

// Function to get all persons
export const getAllPersons = async (): Promise<PersonShortResponseDTO[]> => {
  try {
    const response =
      await apiClient.dataApiClient.get<PersonShortResponseDTO[]>(path);

    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error("Error to get all persons:", err.response?.data.message);
    throw err;
  }
};

// Function to recieve one person by id
export const getPersonById = async (
  id: number,
): Promise<PersonDetailResponseDTO | null> => {
  try {
    const response =
      await apiClient.dataApiClient.get<PersonDetailResponseDTO | null>(
        `${path}/${id}`,
      );
    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error("Error fetching person data by id:", err.response?.data);
    throw error;
  }
};
