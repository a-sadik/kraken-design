// src/types/enums/ServerNature.ts

export enum ServerNature {
  FileServer = "Serveur de fichiers",
  ApplicationServer = "Serveur d'applications",
  WebServer = "Serveur Web", // Apache HTTP Server, Nginx
  DatabaseServer = "Serveur de base de données",
  MailServer = "Serveur de messagerie/streaming", // Kafka, IBMMQ
  VirtualizationServer = "Serveur de virtualisation",
  BackupServer = "Serveur de sauvegarde",
  ProxyServer = "Serveur proxy",
  AuthenticationServer = "Serveur d'authentification", // Keycloak
  MonitoringServer = "Serveur de surveillance",
  DeploymentServer = "Serveur de déploiement", // Jenkins
  AutomationAndOrchestrationServer = "Serveur d'automatisation et d'orchestration", //  Ansible
  POC = "POC", // Serveur mélanger
}
