// src/mappers/BackStageMapper.ts

import { BackStageResponseDTO } from "@/types/dto/BackStageDTO";
import BackStageView from "@/types/view/BackStageView";

// mapper from backstage response dto to backstage view
export const backStageResToView = (
  data: BackStageResponseDTO[],
): BackStageView[] => {
  return data.map((item) => ({
    name: item.name || "-",
    title: item.title || "-",
    owner: item.owner || "-",
    type: item.type || "-",
    lifecycle: item.lifecycle || "-",
    description: item.description || "-",
    tags: item.tags || "-",
    displayName: (item as any).displayName || "-",
    email: (item as any).email || "-",
  }));
};
