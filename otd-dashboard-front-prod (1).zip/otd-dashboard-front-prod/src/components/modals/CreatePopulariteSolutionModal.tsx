// CreatePopulariteSolutionModal.tsx
import React, { useState, useEffect } from "react";
import { TextField, Button, Box } from "@mui/material";
import axios from "axios";
import MyModal from "@/components/modals/MyModal";

interface Props {
  open: boolean;
  onClose: () => void;
  onSave: () => void;
}

export const CreatePopulariteSolutionModal: React.FC<Props> = ({
  open,
  onClose,
  onSave,
}) => {
  const [value, setValue] = useState("");
  const handleSave = () => {
    axios
      .post("/api/solution/popularite/add", { name: value })
      .then(() => onSave())
      .finally(() => setValue(""));
  };
  useEffect(() => {
    if (!open) setValue("");
  }, [open]);
  return (
    <MyModal open={open} onClose={onClose} title="Ajouter une Popularité">
      <Box sx={{ minWidth: 400, px: 2, pt: 1 }}>
        <TextField
          fullWidth
          label="Nom de la Popularité"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          sx={{ mt: 2, mb: 3 }}
        />
        <Box textAlign="right">
          <Button
            onClick={onClose}
            variant="outlined"
            color="secondary"
            sx={{ mr: 1 }}
          >
            Annuler
          </Button>
          <Button
            onClick={handleSave}
            variant="contained"
            disabled={!value.trim()}
            sx={{
              backgroundColor: "#8bc34a",
              color: "#fff",
              fontWeight: "bold",
              "&:hover": { backgroundColor: "#7cb342" },
            }}
          >
            Ajouter
          </Button>
        </Box>
      </Box>
    </MyModal>
  );
};
