// src/components/modals/BulkValidateCertificatesModal.tsx

import React, { useState } from "react";

import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogActions,
  Button,
  Typography,
  Box,
  List,
  ListItem,
  ListItemText,
  Paper,
  TextField,
  Divider,
  Alert,
} from "@mui/material";

import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import CertificateView from "@/types/view/CertificateView";

interface BulkValidateCertificatesModalProps {
  open: boolean;
  onClose: () => void;
  onValidate: (comment: string | null) => Promise<void>;
  certificates: CertificateView[];
}

export default function BulkValidateCertificatesModal({
  open,
  onClose,
  onValidate,
  certificates,
}: BulkValidateCertificatesModalProps) {
  const [validationComment, setValidationComment] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleValidation = async () => {
    try {
      setIsSubmitting(true);
      await onValidate(validationComment);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle sx={{ bgcolor: "success.main", color: "white" }}>
        <Box display="flex" alignItems="center" gap={1}>
          <CheckCircleIcon />
          <Typography variant="h6">
            Validation de {certificates.length} certificat
            {certificates.length > 1 ? "s" : ""}
          </Typography>
        </Box>
      </DialogTitle>
      <DialogContent>
        <Box sx={{ mt: 2 }}>
          <Alert severity="info" sx={{ mb: 2 }}>
            Vous êtes sur le point de valider {certificates.length} certificat
            {certificates.length > 1 ? "s" : ""} en attente. Cette action
            validera tous les certificats sélectionnés.
          </Alert>

          <Typography variant="subtitle1" sx={{ mb: 1, fontWeight: "bold" }}>
            Certificats à valider :
          </Typography>

          <Paper
            variant="outlined"
            sx={{ maxHeight: 300, overflow: "auto", mb: 3 }}
          >
            <List dense>
              {certificates.map((cert, index) => (
                <React.Fragment key={cert.id}>
                  <ListItem>
                    <ListItemText
                      primary={`${cert["Common Name"]}`}
                      secondary={
                        <>
                          <Typography
                            component="span"
                            variant="body2"
                            color="text.primary"
                          >
                            Solution: {cert.Solution} | Type:{" "}
                            {cert["Interne/Externe"]}
                          </Typography>

                          <Typography component="span" variant="body2">
                            Demandeur: {cert.Demandeur}
                          </Typography>
                        </>
                      }
                    />
                  </ListItem>
                  {index < certificates.length - 1 && <Divider />}
                </React.Fragment>
              ))}
            </List>
          </Paper>

          <TextField
            fullWidth
            label="Commentaire de validation (optionnel)"
            multiline
            rows={3}
            value={validationComment}
            onChange={(e) => setValidationComment(e.target.value)}
            variant="outlined"
            sx={{ mb: 2 }}
          />
        </Box>
      </DialogContent>
      <DialogActions sx={{ p: 2 }}>
        <Button onClick={onClose} color="inherit" disabled={isSubmitting}>
          Annuler
        </Button>
        <Button
          onClick={handleValidation}
          variant="contained"
          color="success"
          startIcon={<CheckCircleIcon />}
          disabled={isSubmitting}
        >
          {isSubmitting
            ? "Validation en cours..."
            : "Valider tous les certificats"}
        </Button>
      </DialogActions>
    </Dialog>
  );
}
