// src/mappers/DataMapper.ts

import DataResponseDTO from "@/types/dto/response/DataResponseDTO";
import DataView from "@/types/view/DataView";

// Fonction pour mapper les données avec des noms de champs sans underscore
export const mapData = (data: DataResponseDTO[]): DataView[] => {
  return data.map((item) => ({
    Hostname: item.hostname,
    "Adresses IP": item.ip_addresses,
    OS: item.os,
    Solutions: item.solution_name,
    Environnements: item.environments,
    Domaine: item.domain,
    Pôle: item.pole,
    Entity: item.entity,
    "Admins techniques": item.technicals_admins,
    "Admins fonctionnels": item.functionals_admins,
    TAM: item.tam,
    "Nature de serveur": item.server_nature,
    Popularité: item.solution_popularity,
    Rôle: item.solution_role,
    "Type de solution": item.solution_type,
    // 'Version de la solution déployée': item.solution_depoyed_version,
    PCI: item.pci,
  }));
};
