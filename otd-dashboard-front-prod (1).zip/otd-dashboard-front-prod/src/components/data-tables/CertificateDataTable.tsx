/* eslint-disable @typescript-eslint/no-explicit-any */
// src/components/data-tables/CertificateDataTable.tsx
import { useState, useEffect, useMemo, Dispatch, SetStateAction } from "react";

import { AxiosError } from "axios";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import { DataGrid, GridDeleteIcon } from "@mui/x-data-grid";
import {
  IconButton,
  Box,
  Button,
  Typography,
  Divider,
  Link,
  Card,
  TextField,
  InputAdornment,
  Snackbar,
  Alert,
} from "@mui/material";

// import files
import WidgetMainContainer from "@/components/containers/WidgetMainContainer";
import CustomTooltip from "@/components/basics/CustomToolTip";
import CustomBadge from "@/components/basics/CustomBadge";
import CustomLoading from "@/components/basics/CustomLoading";
import CustomToolBarHome from "./CustomToolBarHome";
import MyModal from "@/components/modals/MyModal";
import DisplayCertificateModal from "@/components/modals/DisplayCertificateModal";
import RenewCertificateModal, {
  Mode,
} from "@/components/modals/RenewCertificateModal";
import {
  InternCertificateForm,
  InternCertificateFormData,
} from "../forms/certificate/CreateInternCertificateForm";
import {
  ExternCertificateForm,
  ExternCertificateFormData,
} from "../forms/certificate/CreateExternCertificateForm";
import { GetKeyForm } from "../forms/certificate/GetKeyForm";
import {
  InternCertificateRequestDTO,
  CertificateAfterCreatingRequestDTO,
  ExternCertificateRequestDTO,
} from "@/types/dto/request/CertificateRequestDTO";
import {
  externCertificateDataFormToReq,
  internCertificateDataFormToReq,
} from "@/mappers/CertificateMapper";
import { getFormatedDate } from "@/utils";
import { getCssVariableValue } from "@/utils/getDynamicColor";
import { getHealthBackendData } from "@/services/ServerService";
import {
  createOneInternCertificate,
  getAllCertificates,
  getCertificateById,
  validateCertificate,
  rejectCertificate,
  renewCertificateWithOldKey,
  renewCertificateWithNewKey,
  holdCertificate,
  downloadCertificateFilesById,
  downloadCertificateKeyFileById,
  recoverPasswordForKeyFile,
  createOneExternCertificate,
} from "@/services/CertificateService";
import CertificateView from "@/types/view/CertificateView";
import {
  CertificateDetailResponseDTO,
  CertificateResponseDTO,
} from "@/types/dto/response/CertificateResponseDTO";
import { ErrorResponse } from "@/exceptions/ErrorResponse";
import CertificateConfigDisplay from "../cards/CertificateConfigDisplay";
import { isInvalid } from "@/utils/validationEnvVar";
import { keycloak } from "../../auth/keycloakConnectAdapter";

// import icons
import VisibilityIcon from "@mui/icons-material/Visibility";
import VerifiedUserIcon from "@mui/icons-material/VerifiedUser";
import PlayCircleFilledIcon from "@mui/icons-material/PlayCircleFilled";
import DownloadIcon from "@mui/icons-material/Download";
import TaskIcon from "@mui/icons-material/Task";
import AutorenewIcon from "@mui/icons-material/Autorenew";
import KeyboardIcon from "@mui/icons-material/Keyboard";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import UnpublishedIcon from "@mui/icons-material/Unpublished";
import GppBadIcon from "@mui/icons-material/GppBad";
import KeyIcon from "@mui/icons-material/Key";
import PauseCircleFilledIcon from "@mui/icons-material/PauseCircleFilled";
import InfoIcon from "@mui/icons-material/Info";
import EmailIcon from "@mui/icons-material/Email";

// imports style
import "@/styles/reliability-data-table.css";

// import files
import { CertificateStateEnum } from "@/enums/CertificateState";
import { AuditDetailDTO } from "@/types/dto/AuditDTO";
import { getAuditCertificateById } from "@/services/AuditService";

// import messages
import {
  service_unavailable,
  service_failure,
  service_data,
} from "@/utils/customMessages";
// import { formatKeyContent } from "@/utils/format.utils";

// import env varibales
const V_ITOP_TICKET_ID_URL = import.meta.env.VITE_ITOP_TICKET_ID_URL;

const requiredEnvVars = [
  { key: "ITOP_TICKET_ID_URL", value: V_ITOP_TICKET_ID_URL },
];

// Vérification des variables avec journalisation
requiredEnvVars.forEach(({ key, value }) => {
  if (isInvalid(value)) {
    console.error(`Environment variable '${key}' is missing or invalid.`);
    process.exit(1);
  }
});

interface CertificateDataTableProps {
  openModalCreate: boolean;
  setOpenModalCreate: Dispatch<SetStateAction<boolean>>;
}

interface CertificateAdd {
  crt: CertificateResponseDTO;
  class: string;
}

export default function CertificateDataTable({
  openModalCreate,
  setOpenModalCreate,
}: CertificateDataTableProps) {
  const [isInterne, setIsInterne] = useState(true);
  const [isExterne, setIsExterne] = useState(true);
  const [isInProgress, setIsInProgress] = useState(false);
  const [selectedRowData, setSelectedRowData] =
    useState<CertificateView | null>(null);

  // modals use state
  const [modalType, setModalType] = useState<string>("");
  // const [openModalCreate, setOpenModalCreate] = useState(false);
  const [openModalDisplay, setOpenModalDisplay] = useState(false);
  const [openModalValidate, setOpenModalValidate] = useState(false);
  const [openModalGetKey, setOpenModalGetKey] = useState(false);
  const [openModalRenew, setOpenModalRenew] = useState(false);

  // toast use state
  const [showEmailNotification, setShowEmailNotification] = useState(false);
  const [emailSnackbarOpen, setEmailSnackbarOpen] = useState(false);
  const [, setPasswordRecoverySnackbarOpen] = useState(false);

  const [auditsCertificateById, setAuditsCertificateById] = useState<
    AuditDetailDTO[] | null
  >(null);

  const [certificates, setCertificates] = useState<CertificateView[] | null>(
    [],
  );
  const [certificateById, setCertificateById] =
    useState<CertificateDetailResponseDTO | null>(null);
  const [certificateAdd, setCertificateAdd] = useState<CertificateAdd | null>(
    null,
  );
  // const [selectedRowId, setSelectedRowId] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [errorOperationMsg, setErrorOperationMsg] = useState<string | null>(
    null,
  );
  const [errorServiceMsg, setErrorServiceMsg] = useState<string | null>(null);
  const [columnVisibility, setColumnVisibility] = useState({});

  const [rejectComment, setRejectComment] = useState<string | null>("");
  const [commentError, setCommentError] = useState(false);

  // use case pour la validation en groupe
  const [selectedCertificates, setSelectedCertificates] = useState<
    CertificateView[]
  >([]);
  const [openBulkValidationModal, setOpenBulkValidationModal] = useState(false);

  // message pour la validation en groupe
  // const [bulkOperationSuccessMsg, setBulkOperationSuccessMsg] = useState<string | null>(null);
  const [bulkOperationSuccessDetails, setBulkOperationSuccessDetails] =
    useState<{ commonName: string; solution: string }[]>([]);
  const [bulkSnackbarOpen, setBulkSnackbarOpen] = useState(false);

  const enum operationsName {
    CREATE_INTERN = "Demander un certificat interne",
    CREATE_EXTERN = "Demander un certificat externe",
    DISPLAY = "Visualisation d'un certificat",
    VALIDATION = "Validation de la demande",
    RENEW = "Renouvellement d'un certificat",
    GET_KEY = "Téléchargement de la clé",
  }

  const isActiveValidationButton = !keycloak.hasRoles("security_role");

  const fetchCertificates = async () => {
    setLoading(true);
    setErrorOperationMsg(null);
    setErrorServiceMsg(null);
    try {
      await getHealthBackendData();
      const data = await getAllCertificates();
      setCertificates(data);
      setErrorServiceMsg(null);
    } catch (err) {
      const error = err as AxiosError;
      console.error("Erreur lors de la récupération des certificats :", err);
      if (error.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCertificates();
  }, []);

  const handleDisplayCertificateButton = async (
    row: any,
    operationType: string,
  ) => {
    try {
      setSelectedRowData(row);
      setModalType(operationType);
      setOpenModalDisplay(true);

      const data = await getAuditCertificateById(row.id);
      setAuditsCertificateById(data);
    } catch (error) {
      const err = error as AxiosError;
      console.error("Failed to fetch certificat data by ID:", error);
      if (err.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    }
  };

  const handleRenewCertificateButton = async (
    row: any,
    operationType: string,
  ) => {
    try {
      setCertificateAdd(null);
      setLoading(true);
      setSelectedRowData(row);
      setModalType(operationType);
      setOpenModalRenew(true);
      await getHealthBackendData();
      const data = await getCertificateById(row.id);
      setCertificateById(data);
    } catch (error) {
      const err = error as AxiosError;
      console.error("Failed to fetch certificat data by ID:", error);
      if (err.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    } finally {
      setLoading(false);
    }
  };

  const renewExpireCertificate = async (mode: Mode) => {
    try {
      setLoading(true);
      if (mode === Mode.OLD)
        await renewCertificateWithOldKey(certificateById?.certificate_id || 0);
      if (mode === Mode.NEW)
        await renewCertificateWithNewKey(certificateById?.certificate_id || 0);
      handleCloseModal();
    } catch (error) {
      const err = error as AxiosError;
      console.error("Failed to add certificate :", error);
      if (err.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    } finally {
      fetchCertificates();
    }
  };

  const handleValidateData = async (row: any) => {
    try {
      setCertificateAdd(null);
      setLoading(true);
      setSelectedRowData(row);
      setModalType("");
      setOpenModalValidate(true);
      await getHealthBackendData();
      const data = await getCertificateById(row.id);
      setCertificateById(data);
    } catch (error) {
      const err = error as AxiosError;
      console.error("Failed to fetch certificat data by ID:", error);
      if (err.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateCertificateButton = (section: string) => {
    setModalType(section);
    setOpenModalCreate(true);
  };

  const handleBulkValidateCertificates = async () => {
    setLoading(true);
    try {
      // Utiliser Promise.all pour traiter toutes les validations en parallèle
      await Promise.all(
        selectedCertificates.map((cert) => {
          const dataCertificate: CertificateAfterCreatingRequestDTO = {
            action_comment: "Validation groupée",
          };
          return validateCertificate(cert.id, dataCertificate);
        }),
      );

      // Capture les détails de chaque certificat validé
      const validatedDetails = selectedCertificates.map((cert) => ({
        commonName: cert["Common Name"],
        solution: cert["Solution"],
      }));

      // Stocker les détails pour l'affichage dans le Snackbar
      setBulkOperationSuccessDetails(validatedDetails);
      setBulkSnackbarOpen(true);

      // Fermer le modal et rafraîchir la liste
      setOpenBulkValidationModal(false);
      setSelectedCertificates([]);
      fetchCertificates();
    } catch (error) {
      const err = error as AxiosError;
      console.error(
        "Erreur lors de la validation groupée des certificats :",
        error,
      );
      if (err.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    } finally {
      setLoading(false);
    }
  };

  const handleRemoveCertificateFromSelection = (certId: any) => {
    // Filtrer la liste pour enlever le certificat avec l'ID spécifié
    const updatedSelection = selectedCertificates.filter(
      (cert) => cert.id !== certId,
    );
    setSelectedCertificates(updatedSelection);

    // Si tous les certificats ont été supprimés, fermez le modal
    if (updatedSelection.length === 0) {
      setOpenBulkValidationModal(false);
    }
  };


  const handleCloseModal = () => {
    setOpenModalCreate(false);
    setOpenModalDisplay(false);
    setOpenModalValidate(false);
    setOpenModalGetKey(false);
    setOpenModalRenew(false);

    setModalType("");
    setSelectedRowData(null);
    setErrorOperationMsg(null);
    setCertificateById(null);
    setRejectComment(null);
    setErrorOperationMsg(null);
  };

  const createInternCertificateRequest = async (
    dataCertificate: InternCertificateRequestDTO,
  ) => {
    try {
      setLoading(true);
      await getHealthBackendData();
      const data: any = await createOneInternCertificate(dataCertificate);
      setCertificateAdd({ crt: data, class: "flash" });
      setEmailSnackbarOpen(true);
    } catch (error) {
      const err = error as AxiosError;
      console.error("Failed to add certificate :", error);
      if (err.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    } finally {
      fetchCertificates();
    }
  };

  const createExternCertificateRequest = async (
    dataCertificate: ExternCertificateRequestDTO,
  ) => {
    try {
      setLoading(true);
      await getHealthBackendData();
      const data: any = await createOneExternCertificate(dataCertificate);
      setCertificateAdd({ crt: data, class: "flash" });
      setEmailSnackbarOpen(true);
    } catch (error) {
      const err = error as AxiosError;
      console.error("Failed to add certificate :", error);
      if (err.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    } finally {
      fetchCertificates();
    }
  };

  const holdeValidateCertificateButton = async (id: number) => {
    const dataCertificate: CertificateAfterCreatingRequestDTO = {
      action_comment: "La raison pour laquelle la demande has ben rejected",
    };

    try {
      setLoading(true);
      const data: any = await validateCertificate(id, dataCertificate);
      setCertificateAdd({ crt: data, class: "flash" });
    } catch (error) {
      const err = error as AxiosError;
      console.error("Failed to add certificate :", error);
      if (err.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    } finally {
      handleCloseModal();
      fetchCertificates();
    }
  };

  const holdeRejectCertificateButton = async (id: number) => {
    // Vérifier si le commentaire est vide
    if (!rejectComment?.trim()) {
      setCommentError(true);
      return; // Arrêter l'exécution si pas de commentaire
    }
    setCommentError(false); // Réinitialiser l'erreur si le commentaire est valide

    const dataCertificate: CertificateAfterCreatingRequestDTO = {
      action_comment: rejectComment,
    };

    try {
      setLoading(true);
      const data: any = await rejectCertificate(id, dataCertificate);
      setCertificateAdd({ crt: data, class: "flash_red" });
    } catch (error) {
      const err = error as AxiosError;
      console.error("Failed to add certificate :", error);
      if (err.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    } finally {
      handleCloseModal();
      fetchCertificates();
    }
  };

  const holdeStandByCertificateButton = async (id: number) => {
    // Vérifier si le commentaire est vide
    if (!rejectComment?.trim()) {
      setCommentError(true);
      return; // Arrêter l'exécution si pas de commentaire
    }
    setCommentError(false); // Réinitialiser l'erreur si le commentaire est valide

    const dataCertificate: CertificateAfterCreatingRequestDTO = {
      action_comment: rejectComment,
    };

    try {
      setLoading(true);
      const data: any = await holdCertificate(id, dataCertificate);
      setCertificateAdd({ crt: data, class: "flash_grey" });
    } catch (error) {
      const err = error as AxiosError;
      console.error("Failed to add certificate :", error);
      if (err.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    } finally {
      handleCloseModal();
      fetchCertificates();
    }
  };

  const handleGetKeyFileButton = async (row: any, operationType: string) => {
    try {
      setCertificateAdd(null);
      setSelectedRowData(row);
      setModalType(operationType);
      setOpenModalGetKey(true);
      await getHealthBackendData();
      const data = await getCertificateById(row.id);

      setCertificateById(data);
    } catch (error) {
      const err = error as AxiosError;
      console.error("Failed to fetch certificat data by ID:", error);
      if (err.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    }
  };

  const handleDownloadFilesButton = async (
    id: number,
    solutionName: string,
  ) => {
    try {
      await getHealthBackendData();
      await downloadCertificateFilesById(id, solutionName);
    } catch (error) {
      const err = error as AxiosError;
      console.error("Failed to fetch certificat data by ID:", error);
      if (err.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    }
  };

  const handleDownloadKeyFileButton = async (data: any) => {
    if (!selectedRowData?.id) return;

    try {
      await getHealthBackendData();
      await downloadCertificateKeyFileById(
        selectedRowData?.id,
        data.password,
        selectedRowData,
      );
      handleCloseModal();
    } catch (error) {
      // const err = error as AxiosError<ErrorResponse>;
      console.error("Erreur lors du téléchargement de la clé :", error);
      window.alert("Mot de passe est invalide !!");

      setErrorOperationMsg("Mot de passe est invalide !!");
      // console.log(errorOperationMsg);
    }
  };

  const handleRecoverPasswordForKeyFileButton = async () => {
    if (!selectedRowData?.id) return;

    try {
      await getHealthBackendData();
      await recoverPasswordForKeyFile(selectedRowData?.id);

      // Affiche le snackbar
      setPasswordRecoverySnackbarOpen(true);

      setTimeout(() => {
        handleCloseModal();
      }, 5000);
    } catch (error) {
      console.error("Erreur lors de la récupération du mot de passe :", error);
    }
  };

  const handleCreateInetrnCertifSubmit = async (
    internData: InternCertificateFormData,
  ) => {
    try {
      const internDataCertificate: InternCertificateRequestDTO =
        internCertificateDataFormToReq(internData);
      await getHealthBackendData();

      if (modalType == operationsName.CREATE_INTERN)
        await createInternCertificateRequest(internDataCertificate);
      else console.error("Operation not good");

      const data = await getAllCertificates();
      setCertificates(data);
      setOpenModalCreate(false);
      setSelectedRowData(null);
      setErrorOperationMsg(null);
    } catch (error) {
      const err = error as AxiosError<ErrorResponse>;

      if (err.status === 409) {
        setErrorOperationMsg(
          err.response?.data.message || "Undefined message error",
        );
      } else if (err.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    }
  };

  const handleCreateExternCertifSubmit = async (
    externData: ExternCertificateFormData,
  ) => {
    try {
      // const key = formatKeyContent(externData.certificate_key || '');

      // console.log(key);

      const externDataCertificate: ExternCertificateRequestDTO =
        externCertificateDataFormToReq(externData);
      await getHealthBackendData();

      if (modalType == operationsName.CREATE_EXTERN)
        await createExternCertificateRequest(externDataCertificate);
      else console.error("Operation not good");

      const data = await getAllCertificates();
      setCertificates(data);
      setOpenModalCreate(false);
      setSelectedRowData(null);
      setErrorOperationMsg(null);
    } catch (error) {
      const err = error as AxiosError<ErrorResponse>;

      if (err.status === 409) {
        setErrorOperationMsg(
          err.response?.data.message || "Undefined message error",
        );
      } else if (err.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    }
  };

  const defaultVisibleColumns: Record<string, boolean> = {
    actions: true,
    "Réf de ticket iTop": true,
    Référence: false,
    "Interne/Externe": true,
    "Common Name": true,
    "Statut de la demande": true,
    "Statut de ticket": true,
    "Date de création": true,
    "Date d'expiration": true,
    Demandeur: true,
    Validateur: false,
    Solution: true,
  };

  const initialVisibility = (columns: any[]) => {
    const initialVisibility: Record<string, boolean> = {};

    columns.forEach((column) => {
      initialVisibility[column.field] =
        defaultVisibleColumns[column.field] || false;
    });
    setColumnVisibility(initialVisibility);
  };

  const getResponsiveWidth = (key: string) => {
    const screenWidth = window.innerWidth;

    const tableColumns1 = [
      "Common Name",
      "Statut de la demande",
      "Statut de ticket",
    ];
    const tableColumns2 = ["Interne/Externe"];

    const tableColumns3 = [
      "Solution",
      "Demandeur",
      "Validateur",
      "Date d'expiration",
    ];

    if (screenWidth < 600) {
      if (tableColumns1.includes(key)) return 75;
      else if (tableColumns2.includes(key)) return 100;
      else if (tableColumns3.includes(key)) return 120;
      return 80;
    } else if (screenWidth < 960) {
      if (tableColumns1.includes(key)) return 140;
      else if (tableColumns2.includes(key)) return 100;
      else if (tableColumns3.includes(key)) return 180;
      return 100;
    } else {
      if (tableColumns1.includes(key)) return 160;
      else if (key === tableColumns1[2] || key === tableColumns1[3]) return 220;
      else if (tableColumns3.includes(key)) return 140;
      else if (tableColumns2.includes(key)) return 100;
      return 120;
    }
  };

  const getEtapeActive = (demande: string): number => {
    if (demande === undefined) {
      return 0;
    } else if (["En cours", "Créer"].includes(demande)) {
      return 1;
    } else if (["Fermer"].includes(demande)) {
      return 2;
    } else if (["Rejeter"].includes(demande)) {
      return 2;
    }
    return -1;
  };

  const requestStatusStyles = {
    etapeEnCours: {
      backgroundColor: "#ffc107", // Jaune
      color: "#000",
      border: "1px solid #ffc107",
    },
    etapeTerminee: {
      backgroundColor: "#fff", // Vert
      color: "#6bcd3a",
      border: "1px solid #6bcd3a",
    },
    etapeRejeter: {
      backgroundColor: "#fff", // Vert
      color: "#cc3300",
      border: "1px solid #cc3300",
    },
    etapeAvenir: {
      backgroundColor: "#f8f9fa", // Gris clair
      color: "#6c757d",
      border: "1px solid #dee2e6",
    },
  };

  function valueContent(value: any, key: string, params: any) {
    // without value
    if (
      value === null ||
      value === "" ||
      (Array.isArray(value) && value.length === 0)
    ) {
      return (
        <span
          style={{
            textAlign: "center",
            fontWeight: "bold",
            fontSize: "2rem",
            display: "inline-block",
          }}
        >
          -
        </span>
      );
    }

    // string value
    if (typeof value === "string" && !Array.isArray(value)) {
      if (["Statut de ticket"].includes(key)) {
        return (
          <div className="progress-container">
            <div className="progress-line"></div>
            {[<PlayCircleFilledIcon />, <TaskIcon />, <VerifiedUserIcon />].map(
              (_, i) => {
                const etapeActive = getEtapeActive(value);
                const isExternalCert =
                  params.row["Interne/Externe"]?.includes("Externe");

                const getStepStyle = () => {
                  if (i === etapeActive) {
                    if (value === "Rejeter")
                      return requestStatusStyles.etapeRejeter;
                    if (value === "Fermer")
                      return requestStatusStyles.etapeTerminee;
                    return requestStatusStyles.etapeEnCours;
                  } else if (i < etapeActive) {
                    return requestStatusStyles.etapeTerminee;
                  } else {
                    return requestStatusStyles.etapeAvenir;
                  }
                };

                // NE PLUS PERMETTRE DE CLIQUER pour progresser manuellement
                return (
                  <div key={i} className="progress-step">
                    <span className="progress-circle" style={getStepStyle()}>
                      {i === 0 && <PlayCircleFilledIcon />}
                      {i === 1 && <TaskIcon />}
                      {i === 2 &&
                        (value === "Fermer" ? (
                          <VerifiedUserIcon />
                        ) : value === "Rejeter" ? (
                          <GppBadIcon />
                        ) : (
                          // Bouton de validation uniquement pour les internes + rôle
                          !isExternalCert && !isActiveValidationButton ? (
                            <CustomTooltip
                              title="Valider ce certificat"
                              fontSize={"0.7rem"}
                            >
                              <IconButton
                                onClick={() => handleValidateData(params.row)}
                                disabled={isActiveValidationButton}
                                style={getStepStyle()}
                              >
                                <VerifiedUserIcon />
                              </IconButton>
                            </CustomTooltip>
                          ) : (
                            <VerifiedUserIcon />
                          )
                        ))}
                    </span>
                  </div>
                );
              },
            )}
          </div>
        );
      }

      if (["Common Name"].includes(key)) {
        return (
          <CustomTooltip
            title={
              params?.row?.Dns ? Object.values(params?.row?.Dns).join(", ") : ""
            }
          >
            <Link
              color="primary"
              onClick={() =>
                handleDownloadFilesButton(params.row.id, params.row["Solution"])
              }
              // href={`${path}/download/${params.row.id}`}
              underline="always"
              rel="noopener"
              target="_blank"
              sx={{
                alignItems: "center",
                justifyContent: "flex-start",
                display: "flex",
                cursor: "pointer",
              }}
            >
              <DownloadIcon />
              {value}
            </Link>
          </CustomTooltip>
        );
      }

      if (["Interne/Externe"].includes(key)) {
        if (value === "Interne")
          return (
            <CustomBadge
              text={value}
              backgroundColor={getCssVariableValue(
                "--certifcate-badge-intern-background-color",
              )}
              textColor={getCssVariableValue("--certifcate-badge-intern-color")}
              textSize={"0.8rem"}
              withBorder
              borderColor={getCssVariableValue(
                "--certifcate-badge-intern-color",
              )}
            />
          );
        else
          return (
            <CustomBadge
              text={value}
              backgroundColor={getCssVariableValue(
                "--certifcate-badge-extern-background-color",
              )}
              textColor={getCssVariableValue("--certifcate-badge-extern-color")}
              textSize={"0.8rem"}
              withBorder
              borderColor={getCssVariableValue(
                "--certifcate-badge-extern-color",
              )}
            />
          );
      }

      if (["Date d'expiration"].includes(key)) {
        return (
          <CustomTooltip title={value !== null ? getFormatedDate(value) : ""}>
            <span>{getFormatedDate(value)}</span>
          </CustomTooltip>
        );
      }

      if (["Réf de ticket iTop"].includes(key)) {
        return (
          <CustomTooltip
            title={"Accéder à la plateforme iTop de cette ticket"}
            fontSize={"0.7rem"}
          >
            <Link
              // color="primary"
              href={`${V_ITOP_TICKET_ID_URL}=${params?.row?.id_itop_ticket}`}
              underline="always"
              rel="noopener"
              target="_blank"
              sx={{
                alignItems: "center",
                justifyContent: "flex-start",
                display: "flex",
              }}
            >
              {value}
            </Link>
          </CustomTooltip>
        );
      }
    }

    // array value
    if (Array.isArray(value) && key === "Statut de la demande") {
      return (
        <>
          {value.map((val: string | string[], index: number) => {
            switch (val) {
              case CertificateStateEnum.IN_PROGRESS:
                return (
                  <CustomBadge
                    key={index}
                    text={val}
                    backgroundColor={getCssVariableValue(
                      "--certifcate-badge-warning-contrastText",
                    )}
                    textColor={getCssVariableValue(
                      "--certifcate-badge-warning",
                    )}
                    textSize={"0.8rem"}
                    withBorder
                    borderColor={getCssVariableValue(
                      "--certifcate-badge-warning",
                    )}
                  />
                );
              case CertificateStateEnum.REJECTED:
                return (
                  <CustomBadge
                    key={index}
                    text={val}
                    backgroundColor={getCssVariableValue(
                      "--certifcate-badge-error-contrastText",
                    )}
                    textColor={getCssVariableValue("--certifcate-badge-error")}
                    textSize={"0.8rem"}
                    withBorder
                    borderColor={getCssVariableValue(
                      "--certifcate-badge-error",
                    )}
                  />
                );
              case CertificateStateEnum.ACTIVE:
                return (
                  <CustomBadge
                    key={index}
                    text={val}
                    backgroundColor={getCssVariableValue(
                      "--certifcate-badge-success-contrastText",
                    )}
                    textColor={getCssVariableValue(
                      "--certifcate-badge-success",
                    )}
                    textSize={"0.8rem"}
                    withBorder
                    borderColor={getCssVariableValue(
                      "--certifcate-badge-success",
                    )}
                  />
                );
              case CertificateStateEnum.HOLDED:
                return (
                  <CustomBadge
                    key={index}
                    text={val}
                    backgroundColor={getCssVariableValue(
                      "--certifcate-badge-hold-contrastText",
                    )}
                    textColor={getCssVariableValue("--certifcate-badge-hold")}
                    textSize={"0.8rem"}
                    withBorder
                    borderColor={getCssVariableValue("--certifcate-badge-hold")}
                  />
                );
              case CertificateStateEnum.EXPRIED:
                return (
                  <CustomBadge
                    key={index}
                    text={val}
                    backgroundColor={getCssVariableValue(
                      "--certifcate-badge-error-contrastText",
                    )}
                    textColor={getCssVariableValue("--certifcate-badge-error")}
                    textSize={"0.8rem"}
                    withBorder
                    borderColor={getCssVariableValue(
                      "--certifcate-badge-error",
                    )}
                  />
                );
              case CertificateStateEnum.RENEWED:
                return (
                  <CustomBadge
                    key={index}
                    text={val}
                    backgroundColor={getCssVariableValue(
                      "--certifcate-badge-renew-contrastText",
                    )}
                    textColor={getCssVariableValue("--certifcate-badge-renew")}
                    textSize={"0.8rem"}
                    withBorder
                    borderColor={getCssVariableValue(
                      "--certifcate-badge-renew",
                    )}
                  />
                );
            }
          })}
        </>
      );
    }

    // other value
    return (
      <CustomTooltip title={value !== null && value}>
        <span>{value}</span>
      </CustomTooltip>
    );
  }

  const columns = useMemo(() => {
    if (certificates && certificates.length === 0) return [];

    const actionColumn = {
      field: "actions",
      headerName: "Actions",
      width: 145,
      sortable: false,
      filterable: false,
      renderCell: (params: any) => (
        <div
          style={{
            display: "flex",
            gap: "8px",
            alignItems: "center",
            justifyContent: "flex-start",
            marginLeft: "18px",
          }}
        >
          {/* certificat visualisation  */}
          <IconButton
            onClick={() =>
              handleDisplayCertificateButton(params.row, operationsName.DISPLAY)
            }
            className="icon-button certifcate"
            sx={{ mt: "1.2rem" }}
          >
            <VisibilityIcon className="data-table-icon-button" />
          </IconButton>

          {/* get password  */}
          <IconButton
            onClick={() =>
              handleGetKeyFileButton(params.row, operationsName.GET_KEY)
            }
            className="icon-button key"
            sx={{
              mt: "1.2rem",
              '&.Mui-disabled': {
                opacity: 0.5,
                color: 'gray'
              }
            }}
            disabled={
              !(
                keycloak.hasRoles("security_role") ||
                keycloak.hasRoles("admin_role") ||
                (() => {
                  const normalizeName = (name: string | undefined) =>
                    name?.trim().toLowerCase().replace(/\s+/g, ' ').split(' ').sort().join(' ');

                  const demandeur = normalizeName(params.row["Demandeur"]);
                  const fullName = normalizeName(keycloak.getFullName());

                  return demandeur === fullName;
                })()
              )
            }
          >
            <KeyIcon className="data-table-icon-button" />
          </IconButton>

          {/* renew certificate  */}
          {!params?.row["Statut de la demande"].includes(
            CertificateStateEnum.HOLDED,
          ) && (
              <IconButton
                onClick={() =>
                  handleRenewCertificateButton(params.row, operationsName.RENEW)
                }
                className="icon-button certifcate-renew"
                sx={{
                  mt: "1.2rem",
                  display:
                    params.row["Statut de la demande"].includes(
                      "En cours de signature",
                    ) || params.row["Statut de la demande"].includes("Rejeté")
                      ? "none"
                      : "inline-flex",
                }}
              >
                <AutorenewIcon className="data-table-icon-button" />
              </IconButton>
            )}
        </div>
      ),
    };

    const dataColumns = Object.keys(
      Array.isArray(certificates) ? certificates[0] : [],
    )
      .filter(
        (key) =>
          key !== "id" && key !== "id_itop_ticket" && key !== "is_renewed",
      )
      .map((key) => ({
        field: key,
        headerName: key,
        description: key,
        width: getResponsiveWidth(key),
        fontSize: "2rem",
        renderCell: (params: any) => valueContent(params.value, key, params),
        sortable: true,
        sortComparator: (v1: string | [], v2: string | []) => {
          if (Array.isArray(v1) && Array.isArray(v2)) {
            return v1.join(", ").localeCompare(v2.join(", ")); // Transformer les tableaux en string pour comparer
          }
          if (typeof v1 === "string" && typeof v2 === "string") {
            return v1.localeCompare(v2);
          }
          return 0; // Par défaut, ne change pas l'ordre
        },
      }));
    initialVisibility([actionColumn, ...dataColumns]);

    return [actionColumn, ...dataColumns];
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [certificates]);

  const customTheme = createTheme({
    palette: {
      primary: { main: getCssVariableValue("--certifcate-main-color") },
      success: {
        main: getCssVariableValue("--certifcate-badge-success"),
        contrastText: getCssVariableValue(
          "--certifcate-badge-success-contrastText",
        ),
      },
    },
  });

  const certificateColor = (modalTypeCertificate: string) => {
    if (modalTypeCertificate === operationsName.CREATE_EXTERN)
      return "--certifcate-extern-color";
    else return "--certifcate-main-color";
  };

  const filteredRows = useMemo(() => {
    return (
      certificates &&
      certificates.filter((row) => {
        const isInterneCert =
          isInterne &&
          row["Interne/Externe"] &&
          row["Interne/Externe"].includes("Interne");
        const isExterneCert =
          isExterne &&
          row["Interne/Externe"] &&
          row["Interne/Externe"].includes("Externe");

        const isInProgressCert =
          isInProgress &&
          row["Statut de la demande"] &&
          row["Statut de la demande"].includes("En cours de signature");

        if (isInProgress) {
          if (isInterne || isExterne) {
            return (
              (isInterneCert && isInProgressCert) ||
              (isExterneCert && isInProgressCert)
            );
          }
        } else {
          if (isInterne || isExterne) {
            return isInterneCert || isExterneCert;
          }
        }
        return true;
      })
    );
  }, [isInterne, isExterne, isInProgress, certificates]);

  if (loading) return <CustomLoading />;
  else if (errorServiceMsg !== null) {
    return (
      <>
        <Box
          color="error.main"
          sx={{ textAlign: "center", marginTop: 2, fontWeight: "bold" }}
        >
          {errorServiceMsg}
        </Box>
      </>
    );
  } else
    return (
      <ThemeProvider theme={customTheme}>
        <Box>
          <Box
            display="flex"
            justifyContent="space-between"
            alignItems="center"
            mb={3}
          >
            {/* Texte aligné à gauche */}
            <Typography className="data-table-title">
              {certificates && certificates.length === 0
                ? "Aucun certificat disponible"
                : "Liste des demandes de certificat"}
            </Typography>

            {/* Conteneur pour les boutons à droite */}
            <Box display="flex" gap={2}>
              {selectedCertificates.length > 3 && (
                <Typography
                  variant="caption"
                  color="black"
                  sx={{ mt: 1, fontSize: "1.2rem", ml: "2px" }}
                >
                  ⚠️ Maximum 3 certificats
                </Typography>
              )}

              {!isActiveValidationButton &&
                selectedCertificates.length !== 0 && (
                  <Button
                    variant="contained"
                    color="success"
                    startIcon={<CheckCircleIcon fontSize="small" />}
                    onClick={() => setOpenBulkValidationModal(true)}
                    disabled={selectedCertificates.length > 3}
                  >
                    Valider {selectedCertificates.length} certificat
                    {selectedCertificates.length > 1 ? "s" : ""}
                  </Button>
                )}

              <Button
                variant="contained"
                color="success"
                startIcon={<KeyboardIcon />}
                onClick={() =>
                  handleCreateCertificateButton(operationsName.CREATE_EXTERN)
                }
              >
                <Typography className="text-button-add">
                  {operationsName.CREATE_EXTERN}
                </Typography>
              </Button>
              <Button
                variant="contained"
                color="primary"
                startIcon={<KeyboardIcon />}
                onClick={() =>
                  handleCreateCertificateButton(operationsName.CREATE_INTERN)
                }
              >
                <Typography className="text-button-add">
                  {operationsName.CREATE_INTERN}
                </Typography>
              </Button>
            </Box>
          </Box>

          {/* Notification pour vérifier l'email après création */}
          {showEmailNotification && (
            <Alert
              severity="info"
              icon={<EmailIcon />}
              sx={{
                mb: 2,
                mt: 1,
                border: "1px solid",
                borderColor: "info.main",
                display: "flex",
                alignItems: "center",
              }}
              onClose={() => setShowEmailNotification(false)}
            >
              Veuillez consulter votre messagerie pour récupérer le mot de passe
              de votre certificat.
            </Alert>
          )}

          {certificates && certificates.length !== 0 && (
            <WidgetMainContainer sx={{ borderColor: "--primary-color" }}>
              <DataGrid
                rows={filteredRows!}
                columns={columns}
                checkboxSelection={!isActiveValidationButton} // Activer les cases à cocher
                disableRowSelectionOnClick // Éviter la sélection par clic sur la ligne
                isRowSelectable={(params) =>
                  params.row["Interne/Externe"] !== "Externe" &&
                  params.row["Statut de la demande"]?.includes(
                    "En cours de signature",
                  )
                }
                onRowSelectionModelChange={(newSelectionModel) => {
                  const selectedRows = newSelectionModel
                    .map((id) => filteredRows?.find((row) => row.id === id))
                    .filter(
                      (row): row is CertificateView =>
                        !!row &&
                        row["Statut de la demande"]?.includes(
                          CertificateStateEnum.IN_PROGRESS,
                        ),
                    );
                  setSelectedCertificates(selectedRows);
                }}
                getRowClassName={(params) => {
                  let className = "";

                  if (
                    params.row["Interne/Externe"] &&
                    params.row["Interne/Externe"].includes("Interne")
                  ) {
                    className += "intern-row ";
                  }

                  if (params.row.id == certificateAdd?.crt?.certificate_id) {
                    className += certificateAdd?.class;
                  }

                  return className;
                }}
                getRowId={(row) => row.id}
                pageSizeOptions={[5, 10, 25, 50]}
                initialState={{
                  pagination: {
                    paginationModel: { pageSize: 25, page: 0 },
                  },
                  columns: {
                    columnVisibilityModel: columnVisibility,
                  },
                }}
                onColumnVisibilityModelChange={(newModel) =>
                  setColumnVisibility(newModel)
                }
                slots={{ toolbar: CustomToolBarHome }}
                slotProps={{
                  toolbar: {
                    existCertTypeFilter: true,
                    isInterne: isInterne,
                    setIsInterne: setIsInterne,
                    isExterne: isExterne,
                    setIsExterne: setIsExterne,
                    isInProgress: isInProgress,
                    setIsInProgress: setIsInProgress,
                    existPoleFilter: false,
                  } as any,
                }}
                sx={{
                  border: "none",
                  "& .MuiDataGrid-columnHeaderTitle": {
                    fontWeight: "bold",
                  },
                }}
              />
            </WidgetMainContainer>
          )}

          <MyModal
            mainColor="--certifcate-main-color"
            open={openBulkValidationModal}
            onClose={() => {
              setOpenBulkValidationModal(false);
            }}
            title="Validation groupée de certificats"
            data={{}}
          >
            <Box sx={{ p: 2 }}>
              <Typography variant="h5">
                Validation de {selectedCertificates.length} certificat
                {selectedCertificates.length > 1 ? "s" : ""}
              </Typography>

              <Box
                sx={{
                  maxHeight: "350px",
                  overflowY: "auto",
                  mt: 3,
                  mb: 3,
                  px: 1,
                }}
              >
                {selectedCertificates.map((cert, index) => (
                  <Card
                    key={cert.id}
                    variant="outlined"
                    sx={{
                      mb: 2,
                      p: 2,
                      bgcolor: "#e3f2fd",
                      borderRadius: 3,
                      boxShadow: 1,
                      transition: "transform 0.2s ease-in-out",
                      "&:hover": {
                        transform: "scale(1.02)",
                      },
                    }}
                  >
                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                      }}
                    >
                      <Typography variant="h6" sx={{ fontSize: "1.4rem" }}>
                        <strong>{index + 1}.</strong> {cert["Common Name"]} -{" "}
                        {cert["Solution"]}
                      </Typography>

                      <IconButton
                        size="medium"
                        color="error"
                        onClick={() =>
                          handleRemoveCertificateFromSelection(cert.id)
                        }
                        sx={{ ml: 2 }}
                      >
                        <Divider
                          orientation="vertical"
                          flexItem
                          sx={{ ml: 1 }}
                        />
                        <GridDeleteIcon fontSize="medium" />
                      </IconButton>
                    </Box>
                  </Card>
                ))}
              </Box>
              <Divider sx={{ my: 2 }} />
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  mt: 2,
                }}
              >
                <Button
                  variant="contained"
                  sx={{ marginX: "5px" }}
                  endIcon={<CheckCircleIcon />}
                  color="success"
                  onClick={() => handleBulkValidateCertificates()}
                >
                  Valider tous
                </Button>
              </Box>
            </Box>
          </MyModal>

          {/* Create a new request for certficate */}
          {openModalCreate && (
            <MyModal
              mainColor={certificateColor(modalType)}
              open={openModalCreate}
              onClose={handleCloseModal}
              title={modalType}
              data={selectedRowData || {}}
            >
              {modalType == operationsName.CREATE_INTERN && (
                <InternCertificateForm
                  initialData={certificateById}
                  onSubmit={handleCreateInetrnCertifSubmit}
                  isEditMode={false}
                  isViewMode={false}
                  isDeleteMode={false}
                  errorMessage={errorOperationMsg}
                />
              )}

              {modalType == operationsName.CREATE_EXTERN && (
                <ExternCertificateForm
                  initialData={certificateById}
                  onSubmit={handleCreateExternCertifSubmit}
                  isEditMode={false}
                  isViewMode={false}
                  isDeleteMode={false}
                  errorMessage={errorOperationMsg}
                />
              )}
            </MyModal>
          )}

          {/* Display a new request for certficate */}
          {openModalDisplay && (
            <DisplayCertificateModal
              open={openModalDisplay}
              onClose={handleCloseModal}
              title={modalType}
              data={auditsCertificateById!}
            />
          )}

          {/* Validation/Refus d'un certificat */}
          <MyModal
            mainColor="--certifcate-main-color"
            open={openModalValidate}
            onClose={handleCloseModal}
            title={operationsName.VALIDATION}
            data={certificateById || {}}
          >
            {certificateById ? (
              <Box sx={{ p: 2 }}>
                <Typography variant="h5">
                  {`Demande de certificat ${certificateById.certificate_target} pour `}
                  <b>{`${certificateById.solution?.solution_name} `} </b>
                </Typography>
                <Card
                  variant="outlined"
                  sx={{
                    marginTop: "20px",
                    width: "80%",
                    marginX: "auto",
                    bgcolor: "#f1f8ff",
                  }}
                >
                  <CertificateConfigDisplay certificateById={certificateById} />
                </Card>
                {certificateById.certificate_target.toLowerCase() !==
                  "externe" && (
                    <>
                      <Divider sx={{ my: 2 }} />
                      <Box
                        sx={{
                          display: "flex",
                          flexDirection: "column",
                          width: "100%",
                          mt: 2,
                        }}
                      >
                        <TextField
                          id="reject-comment"
                          label="Motif de rejet / mise en attente"
                          placeholder="Veuillez indiquer la raison du rejet"
                          multiline
                          rows={3}
                          variant="outlined"
                          fullWidth
                          margin="dense"
                          value={rejectComment}
                          onChange={(e) => {
                            setRejectComment(e.target.value);
                            if (e.target.value.trim()) setCommentError(false);
                          }}
                          error={commentError}
                          helperText={
                            commentError
                              ? "Le motif de rejet est obligatoire"
                              : ""
                          }
                          required
                          InputProps={{
                            endAdornment: (
                              <InputAdornment position="end">
                                <Typography
                                  component="span"
                                  sx={{ color: "text.secondary" }}
                                >
                                  <InfoIcon
                                    fontSize="small"
                                    sx={{ verticalAlign: "middle", mr: 0.5 }}
                                  />
                                </Typography>
                              </InputAdornment>
                            ),
                          }}
                          sx={{
                            marginTop: "15px",
                            backgroundColor: "rgba(253, 237, 237, 0.1)",
                            "& .MuiOutlinedInput-root": {
                              "&.Mui-focused fieldset": {
                                borderColor: "error.main",
                              },
                            },
                            "& .MuiInputLabel-root.Mui-focused": {
                              color: "error.main",
                            },
                          }}
                        />
                      </Box>

                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "center",
                          alignItems: "center",
                          mt: 2,
                        }}
                      >
                        <Button
                          variant="outlined"
                          sx={{ marginX: "5px" }}
                          endIcon={<UnpublishedIcon />}
                          color="error"
                          onClick={() =>
                            holdeRejectCertificateButton(
                              certificateById.certificate_id,
                            )
                          }
                        >
                          Rejeter
                        </Button>

                        <Button
                          variant="outlined"
                          sx={{ marginX: "5px" }}
                          endIcon={<PauseCircleFilledIcon />}
                          color="inherit"
                          disabled={
                            certificateById.certificate_state ===
                            CertificateStateEnum.HOLDED
                          }
                          onClick={() =>
                            holdeStandByCertificateButton(
                              certificateById.certificate_id,
                            )
                          }
                        >
                          Mettre en attente
                        </Button>

                        <Button
                          variant="contained"
                          sx={{ marginX: "5px" }}
                          endIcon={<CheckCircleIcon />}
                          color="success"
                          onClick={() =>
                            holdeValidateCertificateButton(
                              certificateById.certificate_id,
                            )
                          }
                        >
                          Valider
                        </Button>
                      </Box>
                    </>
                  )}
              </Box>
            ) : (
              <Typography>Aucune donnée disponible</Typography>
            )}
          </MyModal>

          {/*  Dialog get password  */}
          <MyModal
            mainColor="--key-download-color"
            open={openModalGetKey}
            onClose={handleCloseModal}
            title={modalType}
            data={selectedRowData || {}}
          >
            <GetKeyForm
              getkeyFile={async (data) =>
                await handleDownloadKeyFileButton(data)
              }
              recoverPassword={async () =>
                await handleRecoverPasswordForKeyFileButton()
              }
              isViewMode={false}
              isDeleteMode={false}
              errorMessage={null}
            />
          </MyModal>

          {/* Display a new request for certficate */}
          {openModalRenew && (
            <RenewCertificateModal
              open={openModalRenew}
              onClose={handleCloseModal}
              onSubmit={renewExpireCertificate}
              title={operationsName.RENEW}
              data={certificateById || {}}
            />
          )}
        </Box>

        {/* Toast notification pour vérifier l'email */}
        <Snackbar
          open={emailSnackbarOpen}
          autoHideDuration={4000}
          onClose={() => setEmailSnackbarOpen(false)}
          anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
        >
          <Alert
            onClose={() => setEmailSnackbarOpen(false)}
            severity="info"
            icon={<EmailIcon />}
            variant="filled"
            sx={{ width: "100%" }}
          >
            Veuillez consulter votre mail pour récupérer le mot de passe de
            votre clé.
          </Alert>
        </Snackbar>

        {/* Toast notification pour la validation groupée */}
        <Snackbar
          open={bulkSnackbarOpen}
          autoHideDuration={6000}
          onClose={() => setBulkSnackbarOpen(false)}
          anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
        >
          <Alert
            onClose={() => setBulkSnackbarOpen(false)}
            icon={<CheckCircleIcon fontSize="inherit" />}
            severity="success"
            variant="standard"
            sx={{
              width: "100%",
              maxHeight: "300px",
              overflowY: "auto",
              backgroundColor: "#e6f4ea", // plus clair pour meilleure lisibilité
              color: "#1b5e20", // vert foncé pour le texte
              boxShadow: 3,
              p: 2,
              borderRadius: 2,
            }}
          >
            <Box sx={{ mb: 2 }}>
              <Typography
                variant="h6"
                sx={{ fontWeight: "bold", fontSize: "1.1rem" }}
              >
                {bulkOperationSuccessDetails.length} certificat
                {bulkOperationSuccessDetails.length > 1 ? "s" : ""} validé
                {bulkOperationSuccessDetails.length > 1 ? "s" : ""} avec succès
              </Typography>
            </Box>

            {bulkOperationSuccessDetails.map((cert, index) => (
              <Box
                key={index}
                sx={{
                  py: 1,
                  borderTop:
                    index > 0 ? "1px solid rgba(0, 0, 0, 0.1)" : "none",
                }}
              >
                <Typography
                  variant="body1"
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    lineHeight: 1.6,
                    fontSize: "1rem",
                  }}
                >
                  <span style={{ marginRight: "8px", fontWeight: 500 }}>
                    {index + 1}.
                  </span>
                  <strong>{cert.commonName}</strong> - {cert.solution}
                </Typography>
              </Box>
            ))}
          </Alert>
        </Snackbar>
      </ThemeProvider>
    );
}
