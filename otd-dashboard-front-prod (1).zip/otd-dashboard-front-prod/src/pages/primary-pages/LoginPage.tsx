// src/pages/LoginPage.tsx

import Box from "@mui/material/Box";

// imports files
import { LoginForm } from "@/components/forms/LoginForm";
import { FormContainer } from "@/components/containers/FormContainer";

// imports logo
import AWBFullLogo from "/logos/awb/attijariwafa-bank-full-logo.svg";

export default function LoginPage() {
  return (
    <Box
      sx={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        height: "100vh",
      }}
    >
      <FormContainer>
        {/* Login form */}
        <LoginForm />

        {/* AWB logo */}
        <img
          src={AWBFullLogo}
          alt="Attijariwafa Bank Logo"
          className="w-60 h-auto mb-8"
        />
      </FormContainer>
    </Box>
  );
}
