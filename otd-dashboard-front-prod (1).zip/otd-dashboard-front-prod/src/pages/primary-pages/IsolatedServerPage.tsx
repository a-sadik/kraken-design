"use client";

import {
  Box,
  Typography,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Alert,
  Chip,
  Paper,
  Fade,
  CircularProgress,
  Tab,
  Tabs,
  Card,
  CardContent,
  Grid,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Snackbar,
  IconButton,
  TextField,
  Autocomplete,
} from "@mui/material";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import {
  DataGrid,
  type GridPaginationModel,
  type GridRowSelectionModel,
} from "@mui/x-data-grid";
import { useEffect, useState } from "react";
import ComputerIcon from "@mui/icons-material/Computer";
import PowerIcon from "@mui/icons-material/Power";
import BugReportIcon from "@mui/icons-material/BugReport";
import InventoryIcon from "@mui/icons-material/Inventory";
import CloseIcon from "@mui/icons-material/Close";
import AddToPhotosIcon from "@mui/icons-material/AddToPhotos";
import {
  export_InventoryServers,
  export_IsolatedServers,
  getSolutions_Inventory,
  Post_Correct_IP,
} from "@/config/api.config";
import fetchWithAuth from "@/middleware/fetch-auth";
import { getBadgeColorEnvironment, getHardwareColor } from "@/utils/getDynamicColor";
import CustomToolbarIsolatedServer, { ExternalFilters } from "@/components/data-tables/CustomToolbarIsolatedServer";
import CustomTooltip from "@/components/basics/CustomToolTip";

// Interfaces TypeScript
interface SolutionDetailResponseDTO {
  entity_acronym: string | null;
  id: number;
  solution_name: string;
  solution_role: string;
  psi: string | null;
  solution_popularity: string | null;
  solution_type: string | null;
  domain: string | null;
  pole: string | null;
  entity: string | null;
  tams: string[];
  technical_admins: string[];
  functional_admins: string[];
  declarted_on_bigfix: boolean;
  declarted_on_itop: boolean;
  fiable: boolean;
  activated: boolean;
}

// Ajoutez la propriété specs à l'interface BaseServer
interface BaseServer {
  id: number;
  hostname: string;
  ip_addresses: string[];
  os_type: string;
  os_details: string | null;
  nature_detail: string | null;
  server_nature: string[];
  environments: string[];
  solutions: SolutionDetailResponseDTO[];
  created_at: string;
  created_by: string;
  updated_at: string;
  updated_by: string;
  uname?: string;
  managed_system_name?: string;
  // NOUVELLE PROPRIÉTÉ
  specs?: {
    cpu?: {
      count: number;
      hot_add_enabled: boolean;
      cores_per_socket: number;
      hot_remove_enabled: boolean;
    };
    memory?: {
      size_MiB: number;
      hot_add_enabled: boolean;
      hot_add_limit_MiB: number;
      hot_add_increment_size_MiB: number;
    };
    storage?: number;
    disks?: Array<{
      id: string;
      type: string;
      label: string;
      capacity: number;
    }>;
    disques?: Array<{
      id: string;
      type: string;
      label: string;
      capacity: number;
    }>;
    vmware_id?: string;
    vmware_source?: string;
  };
}

interface IpCorrectionResponse {
  success: boolean;
  message: string;
  corrected_ip?: string;
  ip: string | [];
}

interface Inventory extends BaseServer { }
interface Bigfix extends BaseServer { }
interface Power extends BaseServer { }
interface Vmware extends BaseServer { }

interface IsolatedServersResponse {
  vmware: Vmware[];
  power: Power[];
  bigfix: Bigfix[];
  inventory: Inventory[];
}

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

interface InventorizeResponseItem {
  ip: string | string[];
  status_code: number;
  status: string;
  message: string;
}

interface ProvisionMapItem {
  ip: string[];
  source: string;
  originalIndex: number;
  id: number;

}

// Fonction utilitaire pour gérer les valeurs de l'arborescence de manière robuste
const getHierarchyValue = (value: any): string => {
  if (typeof value === "string" && value.trim() !== "") {
    return value;
  }
  if (typeof value === "object" && value !== null) {
    // Tente de trouver une propriété 'name' ou 'value'
    if (typeof value.name === "string" && value.name.trim() !== "")
      return value.name;
    if (typeof value.value === "string" && value.value.trim() !== "")
      return value.value;

    // Si aucune des propriétés standard n'est trouvée, itère sur toutes les propriétés de l'objet
    // pour trouver la première chaîne non vide.
    for (const key in value) {
      if (Object.prototype.hasOwnProperty.call(value, key)) {
        const propValue = value[key];
        if (typeof propValue === "string" && propValue.trim() !== "") {
          return propValue; // Retourne la première chaîne non vide trouvée
        }
      }
    }

    // Si l'objet ne contient aucune chaîne de caractères utile,
    // tente de le convertir en chaîne, mais évite le générique "[object Object]"
    const stringified = String(value);
    if (stringified.trim() !== "" && stringified !== "[object Object]") {
      return stringified;
    }
  }
  // Retourne "N/A" si la valeur est null, undefined, une chaîne vide,
  // ou un objet qui se convertit en "[object Object]" sans valeur utile.
  return "N/A";
};

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`isolated-tabpanel-${index}`}
      aria-labelledby={`isolated-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ pt: 3 }}>{children}</Box>}
    </div>
  );
}

// Thème moderne avec couleurs pastels cohérentes
const modernPastelTheme = createTheme({
  palette: {
    primary: {
      main: "#6366F1",
      light: "#A5B4FC",
      dark: "#4338CA",
      contrastText: "#FFFFFF",
    },
    secondary: {
      main: "#EC4899",
      light: "#F9A8D4",
      dark: "#BE185D",
      contrastText: "#FFFFFF",
    },
    success: {
      main: "#10B981",
      light: "#a8e6b1",
      dark: "#047857",
    },
    error: {
      main: "#EF4444",
      light: "#FCA5A5",
      dark: "#DC2626",
    },
    warning: {
      main: "#F59E0B",
      light: "#FCD34D",
      dark: "#D97706",
    },
    info: {
      main: "#3B82F6",
      light: "#93C5FD",
      dark: "#1D4ED8",
    },
    background: {
      default: "#F8FAFC",
      paper: "#FFFFFF",
    },
    text: {
      primary: "#1F2937",
      secondary: "#6B7280",
    },
  },
  shape: {
    borderRadius: 4,
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: "none",
          fontWeight: 600,
          borderRadius: 12,
          padding: "10px 20px",
          boxShadow:
            "0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)",
          transition: "all 0.2s ease-in-out",
          "&:hover": {
            transform: "translateY(-2px)",
            boxShadow:
              "0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1)",
          },
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          fontWeight: 500,
        },
      },
    },
    MuiTab: {
      styleOverrides: {
        root: {
          textTransform: "none",
          fontWeight: 600,
          fontSize: "1rem",
          minHeight: 48,
          "&.Mui-selected": {
            color: "#6366F1",
          },
        },
      },
    },
    MuiTabs: {
      styleOverrides: {
        indicator: {
          backgroundColor: "#6366F1",
          height: 3,
          borderRadius: "3px 3px 0 0",
        },
      },
    },
  },
});

const commonArrayStyles = {
  display: "flex",
  alignItems: "center",
  justifyContent: "flex-start",
  gap: 0.5,
  flexWrap: "wrap",
  height: "100%",
  py: 1,
  pl: 1,
};

// Fonction pour obtenir les couleurs des badges d'environnement


const getPastelColorOS = (
  value: string,
): { bgColor: string; textColor: string } => {
  switch (value?.toLowerCase()) {
    case "windows":
      return { bgColor: "#93C5FD", textColor: "#1E40AF" };
    case "linux":
      return { bgColor: "#a8e6b1", textColor: "#166534" };
    case "macos":
      return { bgColor: "#F9A8D4", textColor: "#831843" };
    case "aix":
      return { bgColor: "#fce38a", textColor: "#1E40AF" };
    default:
      return { bgColor: "#7fb2e6", textColor: "#000000" };
  }
};

const getPastelColorAdmin = (
  type: string,
): { bgColor: string; textColor: string } => {
  switch (type) {
    case "technical":
      return { bgColor: "#D1FAE5", textColor: "#059669" };
    case "functional":
      return { bgColor: "#DBEAFE", textColor: "#2563EB" };
    case "tam":
      return { bgColor: "#FEE2E2", textColor: "#DC2626" };
    default:
      return { bgColor: "#F3F4F6", textColor: "#374151" };
  }
};
const validateIP = (ip: string): boolean => {
  const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
  if (!ipRegex.test(ip)) return false;

  const parts = ip.split('.');

  // Validation de base des segments
  if (!parts.every(part => {
    const num = parseInt(part, 10);
    return num >= 0 && num <= 255;
  })) {
    return false;
  }

  const [first, second, third, fourth] = parts.map(part => parseInt(part, 10));

  // Plage 172.16.0.1 - 172.16.255.254
  if (first === 172 && second === 16) {
    if (third >= 0 && third <= 255) {
      if (third === 0 && fourth >= 1) return true;
      if (third === 255 && fourth <= 254) return true;
      if (third > 0 && third < 255) return true;
    }
  }

  // Plage 172.29.0.1 - 172.29.255.254
  if (first === 172 && second === 29) {
    if (third >= 0 && third <= 255) {
      if (third === 0 && fourth >= 1) return true;
      if (third === 255 && fourth <= 254) return true;
      if (third > 0 && third < 255) return true;
    }
  }

  // Plage 172.31.0.1 - 172.31.255.254
  if (first === 172 && second === 31) {
    if (third >= 0 && third <= 255) {
      if (third === 0 && fourth >= 1) return true;
      if (third === 255 && fourth <= 254) return true;
      if (third > 0 && third < 255) return true;
    }
  }

  // Plage 192.168.0.1 - 192.168.255.254
  if (first === 192 && second === 168) {
    if (third >= 0 && third <= 255) {
      if (third === 0 && fourth >= 1) return true;
      if (third === 255 && fourth <= 254) return true;
      if (third > 0 && third < 255) return true;
    }
  }

  return false;
};
export default function IsolatedServersPage() {
  const [isolatedData, setIsolatedData] =
    useState<IsolatedServersResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [currentTab, setCurrentTab] = useState(0);
  const [_detailsModal, setDetailsModal] = useState<{
    open: boolean;
    server: BaseServer | null;
    type: string;
  }>({
    open: false,
    server: null,
    type: "",
  });
  const [inventorizeModal, setInventorizeModal] = useState<{
    open: boolean;
    selectedServers: { server: BaseServer; source: string }[];
  }>({ open: false, selectedServers: [] });

  // États pour les solutions avec le même style que ModifiedServerModal
  const [solutionsInventoryOptions, setSolutionsInventoryOptions] = useState<
    string[]
  >([]);
  const [loadingInventorySolutions, setLoadingInventorySolutions] =
    useState<boolean>(false);
  const [inventorySolutionsMap, setInventorySolutionsMap] = useState<
    Map<string, SolutionDetailResponseDTO>
  >(new Map());
  const [selectedSolutions, setSelectedSolutions] = useState<string[]>([]);
  const [
    selectedInventorySolutionsDetails,
    setSelectedInventorySolutionsDetails,
  ] = useState<SolutionDetailResponseDTO[]>([]);

  const [editableProvisionMap, setEditableProvisionMap] = useState<
    ProvisionMapItem[]
  >([]);
  const [inventorizeResults, setInventorizeResults] = useState<
    InventorizeResponseItem[]
  >([]);
  const [resultsModalOpen, setResultsModalOpen] = useState(false);
  const [snackbar, setSnackbar] = useState<{
    open: boolean;
    message: string;
    severity: "success" | "error";
  }>({
    open: false,
    message: "",
    severity: "success",
  });

  const [, setIpCorrectionCompleted] = useState(false);
  const [, setCorrectionResults] = useState<IpCorrectionResponse[]>([]);

  const [externalFilters, setExternalFilters] = useState<ExternalFilters>({
    globalSearch: "",
  });

  const [showFilters, setShowFilters] = useState(false);

  // États de sélection
  const [selectedServers, setSelectedServers] = useState<
    Record<string, GridRowSelectionModel>
  >({
    vmware: [],
    power: [],
    bigfix: [],
  });

  // Pagination states pour chaque onglet
  const [paginationModels, setPaginationModels] = useState<
    Record<string, GridPaginationModel>
  >({
    vmware: { page: 0, pageSize: 25 },
    power: { page: 0, pageSize: 25 },
    bigfix: { page: 0, pageSize: 25 },
    inventory: { page: 0, pageSize: 25 },
  });

  // Fonction pour récupérer toutes les IPs existantes du DataGrid
  const getAllExistingIPs = (): Set<string> => {
    const allIPs = new Set<string>();

    if (isolatedData) {
      // Parcourir tous les serveurs de toutes les sources
      Object.values(isolatedData).forEach((servers: BaseServer[]) => {
        servers.forEach(server => {
          if (server.ip_addresses) {
            server.ip_addresses.forEach(ip => {
              if (ip.trim() !== "") {
                allIPs.add(ip);
              }
            });
          }
        });
      });
    }

    return allIPs;
  };

  // Appelez cette fonction dans useEffect
  useEffect(() => {
    fetchIsolatedServers();

  }, []);

  // Fonction pour récupérer les solutions d'inventaire (même logique que ModifiedServerModal)
  const fetchSolutionsInventoryNames = async () => {
    setLoadingInventorySolutions(true);
    console.log("Fetching inventory solution names and details...");
    try {
      const token = localStorage.getItem("access_token");
      const response = await fetchWithAuth(getSolutions_Inventory(), {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data: SolutionDetailResponseDTO[] = await response.json();

      // Filtrer uniquement les solutions activées
      const activeSolutions = data.filter((solution) => solution.activated);
      const names = activeSolutions.map((s) => s.solution_name);
      setSolutionsInventoryOptions(names);

      const newMap = new Map<string, SolutionDetailResponseDTO>();
      activeSolutions.forEach((sol) => {
        newMap.set(sol.solution_name, sol);
      });
      setInventorySolutionsMap(newMap);

      console.log("Fetched solution names for inventory dropdown:", names);
      console.log("Populated inventory solutions map with details:", newMap);
    } catch (error) {
      console.error(
        "Erreur lors du chargement des noms et détails de solutions d'inventaire :",
        error,
      );
      setSolutionsInventoryOptions([]);
      setInventorySolutionsMap(new Map());
      setSnackbar({
        open: true,
        message: "Erreur lors du chargement des solutions",
        severity: "error",
      });
    } finally {
      setLoadingInventorySolutions(false);
    }
  };

  // Fonction pour réinitialiser les filtres
  const resetFilters = () => {
    setExternalFilters({
      globalSearch: "",
    });
    setSelectedServers({
      vmware: [],
      power: [],
      bigfix: [],
    });
  };

  // Fonction pour gérer le changement de filtres
  const handleFiltersChange = (filters: ExternalFilters) => {
    setExternalFilters(filters);
    setSelectedServers({
      vmware: [],
      power: [],
      bigfix: [],
    });
  };

  // Fonction pour formater les valeurs hardware
  const formatHardwareValue = (value: number, type: 'cpu' | 'ram' | 'storage' | 'disk') => {
    if (!value || value === 0) return "N/A";

    switch (type) {
      case 'cpu':
        return `${value} core${value > 1 ? 's' : ''}`;
      case 'ram':
        // RAM en MiB → conversion en Go
        return `${Math.round(value / 1024)} Go`;
      case 'storage':
      case 'disk':
        // Stockage en octets → conversion en Go
        return `${Math.round(value / 1024 / 1024 / 1024)} Go`;
      default:
        return `${value}`;
    }
  };

  // Effect pour dériver les détails des solutions d'inventaire sélectionnées (même logique que ModifiedServerModal)
  useEffect(() => {
    console.log("selectedSolutions changed:", selectedSolutions);
    console.log("inventorySolutionsMap (in effect):", inventorySolutionsMap);

    const filteredSolutions: SolutionDetailResponseDTO[] = [];
    selectedSolutions?.forEach((name) => {
      const solutionDetail = inventorySolutionsMap.get(name);
      if (solutionDetail) {
        filteredSolutions.push(solutionDetail);
      }
    });
    setSelectedInventorySolutionsDetails(filteredSolutions);
    console.log("Filtered solutions for details:", filteredSolutions);

    filteredSolutions.forEach((sol, index) => {
      console.log(
        `Détails de la solution filtrée [${index}] (${sol.solution_name}):`,
        sol,
      );
    });
  }, [selectedSolutions, inventorySolutionsMap]);

  // Fonction pour récupérer les données des serveurs isolés
  const fetchIsolatedServers = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const token = localStorage.getItem("access_token");
      const response = await fetchWithAuth(export_IsolatedServers(), {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data: IsolatedServersResponse = await response.json();
      setIsolatedData(data);
    } catch (err) {
      console.error(
        "Erreur lors de la récupération des serveurs isolés :",
        err,
      );
      setErrorMsg("Erreur lors de la récupération des données");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchIsolatedServers();
  }, []);

  const handleTabChange = (_event: React.SyntheticEvent, newValue: number) => {
    setCurrentTab(newValue);
    setSelectedServers({
      vmware: [],
      power: [],
      bigfix: [],
    });
  };

  const handlePaginationChange = (
    tabName: string,
    newModel: GridPaginationModel,
  ) => {
    setPaginationModels((prev) => ({
      ...prev,
      [tabName]: newModel,
    }));

    setSelectedServers((prev) => ({
      ...prev,
      [tabName]: [],
    }));
  };

  const handleOpenDetails = (server: BaseServer, type: string) => {
    setDetailsModal({
      open: true,
      server,
      type,
    });
  };

  const handleSelectionChange = (
    tabName: string,
    newSelection: GridRowSelectionModel,
  ) => {
    setSelectedServers((prev) => ({
      ...prev,
      [tabName]: newSelection,
    }));
  };

  const handleOpenInventorizeModal = async () => {
    const tabName = getTabName(currentTab);
    const currentSelection = selectedServers[tabName];
    const currentData = getFilteredData(currentTab);
    if (!currentData || currentSelection.length === 0) return;

    const selectedServerObjects = currentData
      .filter((_, index) => currentSelection.includes(index))
      .map((server) => ({ server, source: tabName }));

    const initialProvisionMap = selectedServerObjects.map((item, index) => ({
      ip: item.server.ip_addresses && item.server.ip_addresses.length > 0
        ? item.server.ip_addresses
        : [""],
      source: item.source,
      originalIndex: index,
      id: (item.server as any).id,
    }));

    setEditableProvisionMap(initialProvisionMap);
    setSelectedSolutions([]);
    setSelectedInventorySolutionsDetails([]);
    setInventorizeModal({
      open: true,
      selectedServers: selectedServerObjects,
    });

    // Charger les solutions ET les IPs existantes
    await Promise.all([
      fetchSolutionsInventoryNames(),
    ]);
  };


  const getFilteredData = (tabIndex: number) => {
    const data = getTabData(tabIndex);
    if (!data || data.length === 0) return [];

    const searchTerm = externalFilters.globalSearch.toLowerCase().trim();

    if (!searchTerm) return data;

    return data.filter(server => {
      const searchableFields = [
        server.hostname,
        server.os_type,
        server.os_details,
        server.created_by,
        server.updated_by,
        server.nature_detail,
        (server as any).uname,
        (server as any).managed_system_name,
        ...(server.ip_addresses || []),
        ...(server.environments || []),
        ...(server.server_nature || []),
      ].filter(Boolean);

      return searchableFields.some(field =>
        String(field).toLowerCase().includes(searchTerm)
      );
    });
  };

  const handleCloseInventorizeModal = () => {
    setInventorizeModal({ open: false, selectedServers: [] });
    setSelectedSolutions([]);
    setSelectedInventorySolutionsDetails([]);
    setEditableProvisionMap([]);
    setIpCorrectionCompleted(false);
    setCorrectionResults([]);
  };

  const handleInventorizeConfirm = async () => {
    if (editableProvisionMap.length === 0) return;

    const token = localStorage.getItem("access_token");

    // Étape 1: Correction des adresses IP (UNIQUEMENT pour les nouvelles IPs)
    setLoading(true);
    setSnackbar({
      open: true,
      message: "Correction des adresses IP en cours...",
      severity: "success",
    });

    const correctionResults: IpCorrectionResponse[] = [];
    let allCorrectionsSuccessful = true;

    try {
      // Correction IP pour chaque serveur (UNIQUEMENT pour les nouvelles IPs)
      for (const provisionItem of editableProvisionMap) {
        const existingIPs = getAllExistingIPs();
        const validIPs = provisionItem.ip.filter(ip => ip.trim() !== "" && !existingIPs.has(ip));

        if (validIPs.length === 0) continue;

        try {
          const correctionPayload = {
            source: provisionItem.source,
            ip: validIPs,
            solutions: selectedSolutions
          };

          const correctionResponse = await fetchWithAuth(`${Post_Correct_IP()}/${provisionItem.id}`, {
            method: "POST",
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify(correctionPayload),
          });

          if (correctionResponse.ok) {
            const result = await correctionResponse.json();
            validIPs.forEach(ip => {
              correctionResults.push({
                ip,
                success: true,
                message: result.message || "Succès",
                corrected_ip: result.corrected_ip
              });
            });
          } else {
            allCorrectionsSuccessful = false;
            validIPs.forEach(ip => {
              correctionResults.push({
                ip,
                success: false,
                message: `Erreur HTTP ${correctionResponse.status}`,
              });
            });
          }
        } catch (error) {
          console.error(`Erreur pour le serveur ${provisionItem.id}:`, error);
          allCorrectionsSuccessful = false;
          validIPs.forEach(ip => {
            correctionResults.push({
              ip,
              success: false,
              message: "Erreur réseau",
            });
          });
        }
      }

      setCorrectionResults(correctionResults);

      // Si aucune IP à corriger (toutes existent), on passe directement à l'inventorisation
      const hasIPsToCorrect = editableProvisionMap.some(item => {
        const existingIPs = getAllExistingIPs();
        return item.ip.some(ip => ip.trim() !== "" && !existingIPs.has(ip));
      });

      if (!hasIPsToCorrect) {
        console.log("Toutes les IPs existent déjà, pas de correction nécessaire");
        allCorrectionsSuccessful = true;
        setSnackbar({
          open: true,
          message: "Toutes les IPs existent déjà, passage à l'inventorisation...",
          severity: "success",
        });
      }

      // Vérifier le résultat de la correction
      if (!allCorrectionsSuccessful) {
        const errorCount = correctionResults.filter(result => !result.success).length;
        const totalCount = correctionResults.length;

        setSnackbar({
          open: true,
          message: `Échec de la correction: ${errorCount}/${totalCount} IPs en erreur. L'inventorisation est annulée.`,
          severity: "error",
        });
        setLoading(false);
        return;
      }

      // Étape 2: Inventorisation
      const payload = {
        solutions: selectedSolutions,
        provision_map: editableProvisionMap.map(({ ip, source, id }) => ({
          ip: ip.filter(ip => ip.trim() !== ""),
          source: source.toLowerCase(),
          id: id,
        })),
      };

      const response = await fetchWithAuth(export_InventoryServers(), {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      if (response.status !== 207) {
        throw new Error(`Unexpected status: ${response.status}`);
      }

      const results: InventorizeResponseItem[] = await response.json();
      setInventorizeResults(results);
      setResultsModalOpen(true);

      // Message de succès adapté
      if (hasIPsToCorrect) {
        setSnackbar({
          open: true,
          message: "Correction IP et inventorisation terminées avec succès !",
          severity: "success",
        });
      } else {
        setSnackbar({
          open: true,
          message: "Inventorisation terminée avec succès ! (IPs existantes)",
          severity: "success",
        });
      }

      // Recharger les données
      fetchIsolatedServers();

    } catch (err) {
      console.error("Erreur lors du processus:", err);
      setSnackbar({
        open: true,
        message: "Erreur lors du processus de correction et inventorisation",
        severity: "error",
      });
    } finally {
      setLoading(false);
      handleCloseInventorizeModal();
    }
  };

  const handleCloseResultsModal = () => {
    setResultsModalOpen(false);
    setInventorizeResults([]);
  };

  const valueContent = (value: any, key: string, row: any) => {
    if (
      value === null ||
      value === undefined ||
      (Array.isArray(value) && value.length === 0)
    ) {
      return (
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-start",
            color: "#9CA3AF",
            fontWeight: 600,
            fontSize: "1.2rem",
            height: "100%",
            pl: 1,
          }}
        >
          -
        </Box>
      );
    }

    // Cas spécial pour hostname avec affichage du uname uniquement dans l'onglet Power
    if (key === "hostname") {
      const unameValue = row.uname;
      const isPowerTab = currentTab === 1; // Vérifier si on est dans l'onglet Power (tabIndex 1)

      return (
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "flex-start",
            height: "100%",
            pl: 1,
            backgroundColor: "#ffffff",
            borderLeft: `4px solid #6366F1`,
          }}
        >
          <Typography variant="body2" sx={{ fontWeight: 600 }}>
            {value}
          </Typography>

          {isPowerTab && (
            <Typography
              variant="caption"
              sx={{
                color: "#6B7280",
                fontStyle: "italic",
                display: "block",
                mt: 0.5,
              }}
            >
              uname: {unameValue || "_"}
            </Typography>
          )}
        </Box>
      );
    }

    // COLONNES HARDWARE
    if (key === "cpu") {
      const specs = row.specs;
      const cpuCount = specs?.cpu?.count;

      if (!cpuCount) {
        return (
          <Box sx={commonArrayStyles}>
            <Typography variant="caption" sx={{ color: "#9CA3AF", fontStyle: "italic" }}>
              N/A
            </Typography>
          </Box>
        );
      }

      const colors = getHardwareColor('cpu');
      return (
        <Box sx={commonArrayStyles}>
          <Chip
            label={formatHardwareValue(cpuCount, 'cpu')}
            size="small"
            sx={{
              backgroundColor: colors.bgColor,
              color: colors.textColor,
              fontWeight: 600,
              fontSize: "0.75rem",
            }}
          />
        </Box>
      );
    }

    if (key === "ram") {
      const specs = row.specs;
      const ramSize = specs?.memory?.size_MiB;

      if (!ramSize) {
        return (
          <Box sx={commonArrayStyles}>
            <Typography variant="caption" sx={{ color: "#9CA3AF", fontStyle: "italic" }}>
              N/A
            </Typography>
          </Box>
        );
      }

      const colors = getHardwareColor('ram');
      return (
        <Box sx={commonArrayStyles}>
          <Chip
            label={formatHardwareValue(ramSize, 'ram')}
            size="small"
            sx={{
              backgroundColor: colors.bgColor,
              color: colors.textColor,
              fontWeight: 600,
              fontSize: "0.75rem",
            }}
          />
        </Box>
      );
    }

    if (key === "stockage") {
      const specs = row.specs;
      const storageSize = specs?.storage;

      if (!storageSize) {
        return (
          <Box sx={commonArrayStyles}>
            <Typography variant="caption" sx={{ color: "#9CA3AF", fontStyle: "italic" }}>
              N/A
            </Typography>
          </Box>
        );
      }

      const colors = getHardwareColor('storage');
      return (
        <Box sx={commonArrayStyles}>
          <Chip
            label={formatHardwareValue(storageSize, 'storage')}
            size="small"
            sx={{
              backgroundColor: colors.bgColor,
              color: colors.textColor,
              fontWeight: 600,
              fontSize: "0.75rem",
            }}
          />
        </Box>
      );
    }

    if (key === "disques") {
      const specs = row.specs;
      const disks = specs?.disks;

      if (!disks || !Array.isArray(disks) || disks.length === 0) {
        return (
          <Box sx={commonArrayStyles}>
            <Typography variant="caption" sx={{ color: "#9CA3AF", fontStyle: "italic" }}>
              N/A
            </Typography>
          </Box>
        );
      }

      const colors = getHardwareColor('disk');

      return (
        <Box sx={commonArrayStyles}>
          <CustomTooltip
            title={
              <Box>
                <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 1 }}>
                  Détails des disques:
                </Typography>
                {disks.map((disk: any, index: number) => (
                  <Typography key={index} variant="body2">
                    {disk.label}: {formatHardwareValue(disk.capacity, 'disk')}
                  </Typography>
                ))}
              </Box>
            }
          >
            <Chip
              label={`${disks.length} disque(s)`}
              size="small"
              sx={{
                backgroundColor: colors.bgColor,
                color: colors.textColor,
                fontWeight: 600,
                fontSize: "0.75rem",
                cursor: "help",
              }}
            />
          </CustomTooltip>
        </Box>
      );
    }

    if (key === "os_type") {
      const colors = getPastelColorOS(value);
      return (
        <Box sx={commonArrayStyles}>
          <Chip
            label={value}
            size="small"
            sx={{
              backgroundColor: colors.bgColor,
              color: colors.textColor,
              fontWeight: 600,
              fontSize: "0.75rem",
            }}
          />
        </Box>
      );
    }

    if (Array.isArray(value)) {
      if (key === "environments") {
        return (
          <Box sx={commonArrayStyles}>
            {value.map((item, index) => (
              <Chip
                key={index}
                label={String(item)}
                size="small"
                sx={{
                  backgroundColor: getBadgeColorEnvironment(item),
                  color: "#000000",
                  fontWeight: 600,
                  fontSize: "0.75rem",
                }}
              />
            ))}
          </Box>
        );
      }

      if (
        key === "technical_admins" ||
        key === "functional_admins" ||
        key === "tams"
      ) {
        const adminType =
          key === "technical_admins"
            ? "technical"
            : key === "functional_admins"
              ? "functional"
              : "tam";
        const colors = getPastelColorAdmin(adminType);
        return (
          <Box sx={commonArrayStyles}>
            {value.length > 1 && (
              <Chip
                label={value.length.toString()}
                size="small"
                sx={{
                  backgroundColor: "#EEF2FF",
                  color: "#6366F1",
                  fontWeight: 600,
                  fontSize: "0.75rem",
                }}
              />
            )}
            {value.map((item, index) => (
              <Chip
                key={index}
                label={String(item)}
                size="small"
                sx={{
                  backgroundColor: colors.bgColor,
                  color: colors.textColor,
                  fontWeight: 600,
                  fontSize: "0.75rem",
                }}
              />
            ))}
          </Box>
        );
      }

      return (
        <Box sx={commonArrayStyles}>
          {value.length > 1 && (
            <Chip
              label={value.length.toString()}
              size="small"
              sx={{
                backgroundColor: "#EEF2FF",
                color: "#6366F1",
                fontWeight: 600,
                fontSize: "0.75rem",
              }}
            />
          )}
          {value.map((item, index) => (
            <Chip
              key={index}
              label={String(item)}
              size="small"
              variant="outlined"
              sx={{
                backgroundColor: "#F8FAFC",
                borderColor: "#D1D5DB",
                fontSize: "0.75rem",
              }}
            />
          ))}
        </Box>
      );
    }

    return (
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "flex-start",
          height: "100%",
          pl: 1,
        }}
      >
        <Typography variant="body2" sx={{ color: "#374151" }}>
          {String(value)}
        </Typography>
      </Box>
    );
  };

  const createColumns = (data: BaseServer[]) => {
    if (!data || data.length === 0) return [];

    const baseColumns = [
      { field: "hostname", headerName: "Hostname", width: 150 },
      { field: "ip_addresses", headerName: "Adresses IP", width: 160 },
      { field: "os_type", headerName: "Type OS", width: 120 },
      { field: "os_details", headerName: "Détail OS", width: 150 },
      { field: "created_by", headerName: "Créé par", width: 120 },
      { field: "updated_by", headerName: "Modifié par", width: 120 },
      { field: "nature_detail", headerName: "Détail Nature", width: 150, hide: true },
      { field: "uname", headerName: "Uname", width: 120, hide: true },
      { field: "managed_system_name", headerName: "Power Physique", width: 120 },
      { field: "cpu", headerName: "CPU", width: 100, hide: true },
      { field: "ram", headerName: "RAM", width: 100, hide: true },
      { field: "stockage", headerName: "Stockage", width: 120, hide: true },
      { field: "disques", headerName: "Disques", width: 150, hide: true },
    ];

    return baseColumns.map((col) => ({
      ...col,
      renderCell: (params: any) => valueContent(params.value, col.field, params.row),
      sortable: true,
    }));
  };

  const getTabData = (tabIndex: number) => {
    if (!isolatedData) return [];
    switch (tabIndex) {
      case 0:
        return isolatedData.vmware;
      case 1:
        return isolatedData.power;
      case 2:
        return isolatedData.bigfix;
      case 3:
        return isolatedData.inventory;
      default:
        return [];
    }
  };

  const getTabName = (tabIndex: number) => {
    switch (tabIndex) {
      case 0:
        return "vmware";
      case 1:
        return "power";
      case 2:
        return "bigfix";
      case 3:
        return "inventory";
      default:
        return "vmware";
    }
  };

  const getTabStats = () => {
    if (!isolatedData) return { vmware: 0, power: 0, bigfix: 0, inventory: 0 };
    return {
      vmware: isolatedData.vmware.length,
      power: isolatedData.power.length,
      bigfix: isolatedData.bigfix.length,
      inventory: isolatedData.inventory.length,
    };
  };

  // Toolbar personnalisée avec bouton d'inventorisation
  const CustomToolbar = () => {
    const tabName = getTabName(currentTab);
    const selectedCount = selectedServers[tabName]?.length || 0;
    const filteredData = getFilteredData(currentTab);
    const filteredCount = filteredData.length;

    return (
      <CustomToolbarIsolatedServer
        tabName={tabName}
        selectedCount={selectedCount}
        showFilters={showFilters}
        externalFilters={externalFilters}
        filteredCount={filteredCount}
        onShowFiltersToggle={() => setShowFilters(!showFilters)}
        onFiltersChange={handleFiltersChange}
        onFiltersReset={resetFilters}
        onInventorize={handleOpenInventorizeModal}
      />
    );
  };

  const stats = getTabStats();
  const totalServers =
    stats.vmware + stats.power + stats.bigfix + stats.inventory;

  if (loading) {
    return (
      <ThemeProvider theme={modernPastelTheme}>
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100vh",
          }}
        >
          <CircularProgress />
        </Box>
      </ThemeProvider>
    );
  }

  if (errorMsg) {
    return (
      <ThemeProvider theme={modernPastelTheme}>
        <Fade in={true} timeout={500}>
          <Paper
            elevation={2}
            sx={{
              p: 4,
              textAlign: "center",
              borderRadius: 3,
              backgroundColor: "#FEF2F2",
              border: "1px solid #FECACA",
              m: 2,
            }}
          >
            <Typography variant="h6" sx={{ color: "#DC2626", fontWeight: 600 }}>
              {errorMsg}
            </Typography>
            <Button
              variant="contained"
              onClick={fetchIsolatedServers}
              sx={{ mt: 2 }}
            >
              Réessayer
            </Button>
          </Paper>
        </Fade>
      </ThemeProvider>
    );
  }

  return (
    <ThemeProvider theme={modernPastelTheme}>
      <Fade in={true} timeout={800}>
        <Box sx={{ p: 2 }}>
          {/* Snackbar pour les notifications */}
          <Snackbar
            open={snackbar.open}
            autoHideDuration={6000}
            onClose={() => setSnackbar((prev) => ({ ...prev, open: false }))}
            anchorOrigin={{ vertical: "top", horizontal: "right" }}
          >
            <Alert
              severity={snackbar.severity}
              sx={{ width: "100%" }}
              action={
                <IconButton
                  size="small"
                  aria-label="close"
                  color="inherit"
                  onClick={() =>
                    setSnackbar((prev) => ({ ...prev, open: false }))
                  }
                >
                  <CloseIcon fontSize="small" />
                </IconButton>
              }
            >
              {snackbar.message}
            </Alert>
          </Snackbar>

          {/* En-tête avec gradient */}
          <Paper
            elevation={0}
            sx={{
              background: "linear-gradient(135deg, #EF4444 0%, #FCA5A5 100%)",
              borderRadius: 3,
              p: 3,
              mb: 3,
              color: "white",
            }}
          >
            <Box
              display="flex"
              justifyContent="space-between"
              alignItems="center"
            >
              <Box>
                <Typography variant="h4" sx={{ fontWeight: 700, mb: 1 }}>
                  Serveurs Isolés
                </Typography>
                <Typography variant="body1" sx={{ opacity: 0.9, mb: 2 }}>
                  {totalServers} serveur(s) isolé(s) au total
                </Typography>

                {/* Statistiques par source */}
                <Grid container spacing={2}>
                  <Grid item>
                    <Card
                      sx={{
                        background: "rgba(255, 255, 255, 0.2)",
                        backdropFilter: "blur(10px)",
                        border: "1px solid rgba(255, 255, 255, 0.3)",
                      }}
                    >
                      <CardContent sx={{ p: 2, "&:last-child": { pb: 2 } }}>
                        <Box display="flex" alignItems="center" gap={1}>
                          <ComputerIcon />
                          <Box>
                            <Typography variant="h6" sx={{ fontWeight: 700 }}>
                              {stats.vmware}
                            </Typography>
                            <Typography variant="caption">VMware</Typography>
                          </Box>
                        </Box>
                      </CardContent>
                    </Card>
                  </Grid>
                  <Grid item>
                    <Card
                      sx={{
                        background: "rgba(255, 255, 255, 0.2)",
                        backdropFilter: "blur(10px)",
                        border: "1px solid rgba(255, 255, 255, 0.3)",
                      }}
                    >
                      <CardContent sx={{ p: 2, "&:last-child": { pb: 2 } }}>
                        <Box display="flex" alignItems="center" gap={1}>
                          <PowerIcon />
                          <Box>
                            <Typography variant="h6" sx={{ fontWeight: 700 }}>
                              {stats.power}
                            </Typography>
                            <Typography variant="caption">Power</Typography>
                          </Box>
                        </Box>
                      </CardContent>
                    </Card>
                  </Grid>
                  <Grid item>
                    <Card
                      sx={{
                        background: "rgba(255, 255, 255, 0.2)",
                        backdropFilter: "blur(10px)",
                        border: "1px solid rgba(255, 255, 255, 0.3)",
                      }}
                    >
                      <CardContent sx={{ p: 2, "&:last-child": { pb: 2 } }}>
                        <Box display="flex" alignItems="center" gap={1}>
                          <BugReportIcon />
                          <Box>
                            <Typography variant="h6" sx={{ fontWeight: 700 }}>
                              {stats.bigfix}
                            </Typography>
                            <Typography variant="caption">BigFix</Typography>
                          </Box>
                        </Box>
                      </CardContent>
                    </Card>
                  </Grid>
                  <Grid item>
                    <Card
                      sx={{
                        background: "rgba(255, 255, 255, 0.2)",
                        backdropFilter: "blur(10px)",
                        border: "1px solid rgba(255, 255, 255, 0.3)",
                      }}
                    >
                      <CardContent sx={{ p: 2, "&:last-child": { pb: 2 } }}>
                        <Box display="flex" alignItems="center" gap={1}>
                          <InventoryIcon />
                          <Box>
                            <Typography variant="h6" sx={{ fontWeight: 700 }}>
                              {stats.inventory}
                            </Typography>
                            <Typography variant="caption">
                              Inventaire
                            </Typography>
                          </Box>
                        </Box>
                      </CardContent>
                    </Card>
                  </Grid>
                </Grid>
              </Box>

              <Button
                variant="contained"
                onClick={fetchIsolatedServers}
                sx={{
                  backgroundColor: "rgba(255, 255, 255, 0.2)",
                  backdropFilter: "blur(10px)",
                  color: "white",
                  border: "1px solid rgba(255, 255, 255, 0.3)",
                  "&:hover": {
                    backgroundColor: "rgba(255, 255, 255, 0.3)",
                  },
                }}
              >
                Actualiser
              </Button>
            </Box>
          </Paper>

          {/* Onglets pour les différentes sources */}
          <Paper
            elevation={3}
            sx={{
              borderRadius: 3,
              overflow: "hidden",
              background: "linear-gradient(145deg, #ffffff 0%, #f8fafc 100%)",
            }}
          >
            <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
              <Tabs
                value={currentTab}
                onChange={handleTabChange}
                sx={{
                  px: 2,
                  "& .MuiTabs-flexContainer": {
                    gap: 2,
                  },
                }}
              >
                <Tab
                  label={
                    <Box display="flex" alignItems="center" gap={1}>
                      <ComputerIcon />
                      VMware ({stats.vmware})
                    </Box>
                  }
                />
                <Tab
                  label={
                    <Box display="flex" alignItems="center" gap={1}>
                      <PowerIcon />
                      Power ({stats.power})
                    </Box>
                  }
                />
                <Tab
                  label={
                    <Box display="flex" alignItems="center" gap={1}>
                      <BugReportIcon />
                      BigFix ({stats.bigfix})
                    </Box>
                  }
                />
                <Tab
                  label={
                    <Box display="flex" alignItems="center" gap={1}>
                      <InventoryIcon />
                      Inventaire ({stats.inventory})
                    </Box>
                  }
                />
              </Tabs>
            </Box>

            {/* Panneaux de contenu */}
            {[0, 1, 2, 3].map((tabIndex) => (
              <TabPanel key={tabIndex} value={currentTab} index={tabIndex}>
                <Box sx={{ p: 2 }}>
                  <DataGrid
                    rows={getFilteredData(tabIndex).map((server, index) => ({
                      ...server,
                      // Propriétés pour les colonnes hardware
                      cpu: server.specs?.cpu?.count,
                      ram: server.specs?.memory?.size_MiB,
                      stockage: server.specs?.storage,
                      disques: server.specs?.disks,
                      // Propriétés existantes
                      id: index,
                      hostname: server.hostname,
                      ip_addresses: server.ip_addresses,
                      os_type: server.os_type,
                      os_details: server.os_details,
                      created_by: server.created_by,
                      updated_by: server.updated_by,
                      nature_detail: server.nature_detail,
                      uname: server.uname,
                      managed_system_name: server.managed_system_name,
                    }))}
                    key={`${getTabName(tabIndex)}-${getTabData(tabIndex).length}`}
                    columns={createColumns(getTabData(tabIndex))}
                    paginationModel={paginationModels[getTabName(tabIndex)]}
                    onPaginationModelChange={(newModel) =>
                      handlePaginationChange(getTabName(tabIndex), newModel)
                    }
                    initialState={{
                      columns: {
                        columnVisibilityModel: {
                          nature_detail: false,
                          cpu: false,
                          ram: false,
                          stockage: false,
                          disques: false,
                        },
                      },
                    }}
                    onRowClick={(params) =>
                      handleOpenDetails(
                        params.row as BaseServer,
                        getTabName(tabIndex),
                      )
                    }
                    checkboxSelection={tabIndex !== 3}
                    rowSelectionModel={selectedServers[getTabName(tabIndex)]}
                    onRowSelectionModelChange={(newSelection) =>
                      handleSelectionChange(getTabName(tabIndex), newSelection)
                    }
                    slots={{ toolbar: CustomToolbar }}
                    sx={{
                      minHeight: 400,
                      "& .MuiDataGrid-row": {
                        cursor: "pointer",
                        "&:hover": {
                          backgroundColor: "#F8FAFC",
                        },
                      },
                    }}
                  />
                </Box>
              </TabPanel>
            ))}
          </Paper>

          {/* Modal d'inventorisation avec le même style que ModifiedServerModal */}
          <Dialog
            open={inventorizeModal.open}
            onClose={handleCloseInventorizeModal}
            maxWidth="lg"
            fullWidth
            TransitionComponent={Fade}
            TransitionProps={{ timeout: 300 }}
          >
            <DialogTitle
              sx={{
                background: "linear-gradient(135deg, #10B981 0%, #a8e6b1 100%)",
                color: "white",
                textAlign: "center",
                py: 3,
              }}
            >
              <Box
                display="flex"
                alignItems="center"
                justifyContent="center"
                gap={2}
              >
                <AddToPhotosIcon fontSize="large" />
                <Typography variant="h5" sx={{ fontWeight: 700 }}>
                  Inventoriser les serveurs sélectionnés
                </Typography>
              </Box>
            </DialogTitle>

            <DialogContent sx={{ p: 3 }}>
              {/* Section pour sélectionner les solutions - même style que ModifiedServerModal */}
              <Box sx={{ mb: 3 }}>
                <Typography
                  variant="h6"
                  sx={{ mb: 2, fontWeight: 600, color: "#1976d2" }}
                >
                  Solution(s) dans l'inventaire{" "}
                  <span style={{ color: "red" }}>*</span>
                </Typography>
                <Autocomplete
                  multiple
                  options={solutionsInventoryOptions}
                  getOptionLabel={(option) => {
                    const solutionDetail = inventorySolutionsMap.get(option);
                    if (solutionDetail) {
                      const acronym = solutionDetail.entity_acronym || solutionDetail.entity || "AWB";

                      // Vérifier si le nom contient déjà l'acronyme entre parenthèses
                      const solutionName = solutionDetail.solution_name;
                      const acronymInParenthesesRegex = /\(([^)]+)\)$/;
                      const match = solutionName.match(acronymInParenthesesRegex);

                      if (match && match[1] === acronym) {
                        // Si l'acronyme est déjà dans le nom, on affiche seulement le nom
                        return solutionName;
                      } else {
                        // Sinon, on ajoute l'acronyme
                        return `${solutionName} (${acronym})`;
                      }
                    }
                    return option;
                  }}
                  value={selectedSolutions}
                  onChange={(_, value) => setSelectedSolutions(value || [])}
                  loading={loadingInventorySolutions}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      placeholder="Solution(s) dans l'inventaire"
                      InputProps={{
                        ...params.InputProps,
                        endAdornment: (
                          <>
                            {loadingInventorySolutions && (
                              <CircularProgress color="inherit" size={20} />
                            )}
                            {params.InputProps.endAdornment}
                          </>
                        ),
                      }}
                      sx={{
                        "& .MuiOutlinedInput-root": {
                          borderRadius: 0.3,
                          backgroundColor: "white",
                        },
                      }}
                    />
                  )}
                  renderTags={(value, getTagProps) =>
                    value.map((option, index) => {
                      const solutionDetail = inventorySolutionsMap.get(option);
                      let displayName = option;

                      if (solutionDetail) {
                        const acronym = solutionDetail.entity_acronym || solutionDetail.entity || "AWB";
                        const solutionName = solutionDetail.solution_name;
                        const acronymInParenthesesRegex = /\(([^)]+)\)$/;
                        const match = solutionName.match(acronymInParenthesesRegex);

                        if (match && match[1] === acronym) {
                          displayName = solutionName;
                        } else {
                          displayName = `${solutionName} (${acronym})`;
                        }
                      }

                      return (
                        <Chip
                          label={displayName}
                          {...getTagProps({ index })}
                          size="small"
                          sx={{
                            backgroundColor: "#e8f5e8",
                            color: "#2e7d32",
                            fontWeight: 500,
                            fontSize: "0.875rem",
                            height: "24px",
                            "& .MuiChip-label": {
                              px: 1,
                            },
                          }}
                        />
                      );
                    })
                  }
                />
                {loadingInventorySolutions && (
                  <Box sx={{ display: "flex", alignItems: "center", mt: 1 }}>
                    <CircularProgress size={16} sx={{ mr: 1 }} />
                    <Typography variant="caption">
                      Chargement des solutions...
                    </Typography>
                  </Box>
                )}
              </Box>

              {/* Section Détails des solutions d'inventaire sélectionnées - même style que ModifiedServerModal */}
              <Box sx={{ mb: 3 }}>
                <Card
                  variant="outlined"
                  sx={{
                    backgroundColor: "#f9fbfd",
                    borderColor: "#e0e0e0",
                    borderRadius: 0.3,
                  }}
                >
                  <CardContent sx={{ pb: "16px !important" }}>
                    <Typography
                      variant="h6"
                      component="h3"
                      sx={{
                        color: "#1976d2",
                        fontSize: "1.1rem",
                        fontWeight: 600,
                        mb: 1.2,
                        display: "flex",
                        alignItems: "center",
                        gap: 1,
                      }}
                    >
                      Détails des solutions d'inventaire sélectionnées
                    </Typography>
                    {selectedInventorySolutionsDetails.length > 0 ? (
                      selectedInventorySolutionsDetails.map((solution) => (
                        <Box
                          key={solution.id}
                          sx={{
                            mb: 2,
                            p: 2,
                            border: "1px solid #e0e0e0",
                            borderRadius: 0.3,
                          }}
                        >
                          <Typography
                            variant="subtitle1"
                            sx={{ fontWeight: 600, mb: 1 }}
                          >
                            Nom de l'application: {solution.solution_name}
                          </Typography>
                          <Typography variant="body2" sx={{ mb: 0.5 }}>
                            Fiabilité:{" "}
                            <Chip
                              label={solution.fiable ? "Fiable" : "Non fiable"}
                              size="small"
                              color={solution.fiable ? "success" : "error"}
                              sx={{
                                fontSize: "0.875rem",
                                height: "24px",
                                "& .MuiChip-label": { px: 1 },
                              }}
                            />
                          </Typography>
                          <Typography variant="body2" sx={{ mb: 1 }}>
                            Arborescence:{" "}
                            <Chip
                              label={`${getHierarchyValue(solution.domain)} > ${getHierarchyValue(solution.pole)} > ${getHierarchyValue(solution.entity)}`}
                              size="small"
                              sx={{
                                backgroundColor: "#e0f2f7",
                                color: "#006064",
                                fontSize: "0.875rem",
                                height: "24px",
                                "& .MuiChip-label": { px: 1 },
                              }}
                            />
                          </Typography>

                          {/* Affichage des administrateurs techniques */}
                          {solution.technical_admins &&
                            solution.technical_admins.length > 0 && (
                              <Box sx={{ mb: 1 }}>
                                <Typography
                                  variant="body2"
                                  sx={{ fontWeight: 500, mb: 0.5 }}
                                >
                                  Administrateurs techniques:
                                </Typography>
                                <Box
                                  sx={{
                                    display: "flex",
                                    flexWrap: "wrap",
                                    gap: 1,
                                  }}
                                >
                                  {solution.technical_admins.map(
                                    (admin, adminIndex) => (
                                      <Chip
                                        key={adminIndex}
                                        label={admin}
                                        size="small"
                                        sx={{
                                          backgroundColor: "#e8f5e9",
                                          color: "#388e3c",
                                          fontSize: "0.875rem",
                                          height: "24px",
                                          "& .MuiChip-label": { px: 1 },
                                        }}
                                      />
                                    ),
                                  )}
                                </Box>
                              </Box>
                            )}

                          {/* Affichage des administrateurs fonctionnels */}
                          {solution.functional_admins &&
                            solution.functional_admins.length > 0 && (
                              <Box sx={{ mb: 1 }}>
                                <Typography
                                  variant="body2"
                                  sx={{ fontWeight: 500, mb: 0.5 }}
                                >
                                  Administrateurs fonctionnels:
                                </Typography>
                                <Box
                                  sx={{
                                    display: "flex",
                                    flexWrap: "wrap",
                                    gap: 1,
                                  }}
                                >
                                  {solution.functional_admins.map(
                                    (admin, adminIndex) => (
                                      <Chip
                                        key={adminIndex}
                                        label={admin}
                                        size="small"
                                        sx={{
                                          backgroundColor: "#e0f2f7",
                                          color: "#0277bd",
                                          fontSize: "0.875rem",
                                          height: "24px",
                                          "& .MuiChip-label": { px: 1 },
                                        }}
                                      />
                                    ),
                                  )}
                                </Box>
                              </Box>
                            )}

                          {/* Affichage des TAMs */}
                          {solution.tams && solution.tams.length > 0 && (
                            <Box>
                              <Typography
                                variant="body2"
                                sx={{ fontWeight: 500, mb: 0.5 }}
                              >
                                TAMs:
                              </Typography>
                              <Box
                                sx={{
                                  display: "flex",
                                  flexWrap: "wrap",
                                  gap: 1,
                                }}
                              >
                                {solution.tams.map((tam, tamIndex) => (
                                  <Chip
                                    key={tamIndex}
                                    label={tam}
                                    size="small"
                                    sx={{
                                      backgroundColor: "#fbe9e7",
                                      color: "#d84315",
                                      fontSize: "0.875rem",
                                      height: "24px",
                                      "& .MuiChip-label": { px: 1 },
                                    }}
                                  />
                                ))}
                              </Box>
                            </Box>
                          )}
                        </Box>
                      ))
                    ) : (
                      <Box
                        sx={{
                          p: 2,
                          border: "1px solid #e0e0e0",
                          borderRadius: 0.3,
                          textAlign: "center",
                          color: "text.secondary",
                        }}
                      >
                        <Typography variant="body2">
                          Aucune solution d'inventaire sélectionnée pour
                          afficher les détails.
                        </Typography>
                      </Box>
                    )}
                  </CardContent>
                </Card>
              </Box>

              {/* Section pour modifier la provision map */}
              <Box>
                <Typography
                  variant="h6"
                  sx={{ mb: 2, fontWeight: 600, color: "#1976d2" }}
                >
                  Provision Map ({editableProvisionMap.length} serveur(s))
                </Typography>
                <TableContainer
                  component={Paper}
                  sx={{ maxHeight: 400, overflow: "auto" }}
                >
                  <Table stickyHeader>
                    <TableHead>
                      <TableRow>
                        <TableCell>Hostname</TableCell>
                        <TableCell>Adresses IP</TableCell>
                        <TableCell>Source</TableCell>
                        <TableCell>OS</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {editableProvisionMap.map((item, index) => {
                        const server = inventorizeModal.selectedServers[item.originalIndex]?.server;
                        return (
                          <TableRow key={index}>
                            <TableCell>
                              <Typography variant="body2" sx={{ fontWeight: 600 }}>
                                {server?.hostname || "-"}
                              </Typography>
                              <Typography variant="caption" color="text.secondary">
                                ID: {item.id}
                              </Typography>
                            </TableCell>
                            <TableCell>
                              <Box sx={{ minWidth: 200 }}>
                                {item.ip.map((ip, ipIndex) => {
                                  const existingIPs = getAllExistingIPs(); // ← Récupérer les IPs existantes
                                  const ipExists = existingIPs.has(ip) && ip.trim() !== "";

                                  return (
                                    <Box key={ipIndex} sx={{ mb: 1, display: 'flex', alignItems: 'center', gap: 1 }}>
                                      <TextField
                                        size="small"
                                        value={ip}
                                        placeholder={ipExists ? "IP existante" : "Entrer une adresse IP ..."}
                                        onChange={(e) => {
                                          // BLOQUER LA MODIFICATION SI IP EXISTE
                                          if (!ipExists) {
                                            const newValue = e.target.value;
                                            if (/^[0-9.]*$/.test(newValue)) {
                                              const newMap = [...editableProvisionMap];
                                              const newip = [...item.ip];
                                              newip[ipIndex] = newValue;
                                              newMap[index] = {
                                                ...newMap[index],
                                                ip: newip
                                              };
                                              setEditableProvisionMap(newMap);
                                            }
                                          }
                                        }}
                                        error={ip !== "" && !validateIP(ip) && !ipExists}
                                        helperText={
                                          ipExists
                                            ? "IP déjà existante - Non modifiable"
                                            : ip !== "" && !validateIP(ip)
                                              ? "Format IP invalide"
                                              : ""
                                        }
                                        sx={{
                                          flex: 1,
                                          '& .MuiInputBase-root': {
                                            backgroundColor: ipExists ? '#f5f5f5' : 'white',
                                            '&.Mui-disabled': {
                                              backgroundColor: '#f5f5f5',
                                            }
                                          },
                                          '& .MuiInputBase-input': {
                                            color: ipExists ? '#666' : 'inherit',
                                            cursor: ipExists ? 'not-allowed' : 'text',
                                          }
                                        }}
                                        disabled={ipExists}
                                        InputProps={{
                                          readOnly: ipExists,
                                        }}
                                      />
                                      {/* CACHER LE BOUTON SUPPRIMER SI IP EXISTE */}
                                      {item.ip.length > 1 && !ipExists && (
                                        <IconButton
                                          size="small"
                                          onClick={() => {
                                            const newMap = [...editableProvisionMap];
                                            const newip = item.ip.filter((_, i) => i !== ipIndex);
                                            newMap[index] = {
                                              ...newMap[index],
                                              ip: newip.length > 0 ? newip : [""]
                                            };
                                            setEditableProvisionMap(newMap);
                                          }}
                                        >
                                          <CloseIcon fontSize="small" />
                                        </IconButton>
                                      )}
                                    </Box>
                                  );
                                })}

                                {/* CACHER LE BOUTON AJOUTER SI AU MOINS UNE IP EXISTE DANS CE SERVEUR */}
                                {!item.ip.some(ip => {
                                  const existingIPs = getAllExistingIPs();
                                  return existingIPs.has(ip) && ip.trim() !== "";
                                }) && (
                                    <Button
                                      size="small"
                                      startIcon={<AddToPhotosIcon />}
                                      onClick={() => {
                                        const newMap = [...editableProvisionMap];
                                        const newip = [...item.ip, ""];
                                        newMap[index] = {
                                          ...newMap[index],
                                          ip: newip
                                        };
                                        setEditableProvisionMap(newMap);
                                      }}
                                    >
                                      Ajouter IP
                                    </Button>
                                  )}
                              </Box>
                            </TableCell>
                            <TableCell>
                              <Chip
                                label={item.source}
                                size="small"
                                sx={{
                                  backgroundColor:
                                    item.source === 'bigfix' ? '#e8f5e8' :
                                      item.source === 'vmware' ? '#e3f2fd' :
                                        '#f3e5f5',
                                  color:
                                    item.source === 'bigfix' ? '#2e7d32' :
                                      item.source === 'vmware' ? '#1565c0' :
                                        '#7b1fa2',
                                  fontWeight: 600,
                                }}
                              />
                            </TableCell>
                            <TableCell>
                              {server && (
                                <Chip
                                  label={server.os_type}
                                  size="small"
                                  sx={{
                                    backgroundColor: getPastelColorOS(server.os_type).bgColor,
                                    color: getPastelColorOS(server.os_type).textColor,
                                    fontWeight: 600,
                                  }}
                                />
                              )}
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </TableContainer>
              </Box>
            </DialogContent>

            <DialogActions sx={{ p: 3, backgroundColor: "#F8FAFC" }}>
              <Button
                onClick={handleCloseInventorizeModal}
                variant="outlined"
                sx={{
                  borderColor: "#D1D5DB",
                  color: "#6B7280",
                  "&:hover": {
                    borderColor: "#9CA3AF",
                    backgroundColor: "#F3F4F6",
                  },
                }}
              >
                Annuler
              </Button>

              {/* Un seul bouton pour les deux opérations */}
              <Button
                variant="contained"
                color="success"
                onClick={handleInventorizeConfirm}
                startIcon={<AddToPhotosIcon />}
                disabled={
                  editableProvisionMap.length === 0 ||
                  selectedSolutions.length === 0 ||
                  loading
                }
                sx={{
                  background: "linear-gradient(135deg, #10B981 0%, #047857 100%)",
                  color: "white",
                }}
              >
                {loading ? "Traitement en cours..." : "Inventoriser"}
              </Button>
            </DialogActions>
          </Dialog>

          {/* Modal des résultats d'inventorisation */}
          <Dialog
            open={resultsModalOpen}
            onClose={handleCloseResultsModal}
            maxWidth="md"
            fullWidth
            TransitionComponent={Fade}
            TransitionProps={{ timeout: 300 }}
          >
            <DialogTitle
              sx={{
                background: "linear-gradient(135deg, #3B82F6 0%, #1D4ED8 100%)",
                color: "white",
                textAlign: "center",
                py: 3,
              }}
            >
              <Typography variant="h5" sx={{ fontWeight: 700 }}>
                Résultats de l'inventorisation
              </Typography>
            </DialogTitle>

            <DialogContent sx={{ p: 3 }}>
              <TableContainer component={Paper}>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Adresse IP</TableCell>
                      <TableCell>Statut</TableCell>
                      <TableCell>Code Statut</TableCell>
                      <TableCell>Message</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {inventorizeResults.map((result, index) => (
                      <TableRow key={index}>
                        <TableCell>
                          <Typography variant="body2" sx={{ fontWeight: 600 }}>
                            {Array.isArray(result.ip) ? result.ip.join(', ') : result.ip}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip
                            label={result.status}
                            size="small"
                            sx={{
                              backgroundColor: result.status === 'success' ? '#e8f5e8' : '#ffebee',
                              color: result.status === 'success' ? '#2e7d32' : '#c62828',
                              fontWeight: 600,
                            }}
                          />
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2">
                            {result.status_code}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2">
                            {result.message}
                          </Typography>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </DialogContent>

            <DialogActions sx={{ p: 3, backgroundColor: "#F8FAFC" }}>
              <Button
                onClick={handleCloseResultsModal}
                variant="contained"
                color="primary"
              >
                Fermer
              </Button>
            </DialogActions>
          </Dialog>
        </Box>
      </Fade>
    </ThemeProvider>
  );
}
