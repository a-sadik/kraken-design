// src/mappers/AuditMapper.ts

import { AuditShortDTO } from "@/types/dto/AuditDTO";
import { AuditView } from "@/types/view/AuditView";

export const auditResToView = (data: AuditShortDTO[]): AuditView[] => {
  return data.map((item) => ({
    id: item.audit_id,
    Référence: item.audit_ref,
    Personne: item.agent,
    Composant: item.item_name,
    "Status d'opération": item.operation_status,
    Action: item.action_type,
    "Raison d'échec": item.reason_failed_operation || "-",
    "Adresse IP": item.ip_address,
    "Date d'opération": item.operation_at,
    Description: item.action_description,
  }));
};
