// src/services/OrganigrammeService.ts

import { AxiosError } from "axios";

// import files
import { ErrorResponse } from "@/exceptions/ErrorResponse";
// import apiClient from './apiClientHttp';
// import { APIEntity } from '@/types/dto/BackStageDTO';
import apiClientHttp from "./apiClientHttp";

const path = `/backstage`;

export const getBackStageData = async () => {
  try {
    const response = await apiClientHttp.dataApiClient.get(`${path}`, {
      params: { filter: "group" },
    });

    const mappedData = response.data.filter(
      (e: any) =>
        e.type === "department" &&
        (e.name === "core-processing" || e.name === "digital-center"),
    );

    return {
      groups: response.data,
      departements: mappedData,
    };
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error(
      "Error fetching all Backstages data:",
      err.response?.data.message,
    );
    throw err;
  }
};

export const getBackStageUsers = async () => {
  try {
    const response = await apiClientHttp.dataApiClient.get(
      `${path}?filter=user`,
    );

    const mappedData = response.data.map((entity: any) => ({
      name: entity.name,
      displayName: entity.displayName,
      email: entity.email,
    }));

    return mappedData;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error("Error fetching all Users:", err.response?.data.message);
    throw err;
  }
};
