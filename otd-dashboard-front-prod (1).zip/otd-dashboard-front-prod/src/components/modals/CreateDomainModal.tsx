// src/modals/AddDomainModal.tsx

import React, { useEffect, useState } from "react";
import {
  Grid,
  TextField,
  Autocomplete,
  CircularProgress,
  Alert,
  Typography,
  Button,
  Box,
  Snackbar,
} from "@mui/material";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z as zod } from "zod";

import { PersonShortResponseDTO } from "@/types/dto/PersonDTO";
import { getAllPersons } from "@/services/admin/PersonService";
import { getAllPoles } from "@/services/admin/PoleService";
import { createDomain } from "@/services/admin/DomainService";

import MyModal from "@/components/modals/MyModal";
import {
  placeholder_entity_name,
  placeholder_one_person,
  required_hostname,
  required_one_solution,
} from "@/utils/customMessages";

interface PoleShortResponseDTO {
  pole_id: number;
  pole_name: string;
}

const getFormSchema = () =>
  zod.object({
    domain_name: zod.string().trim().min(1, required_hostname),
    person: zod
      .union([
        zod.object({
          person_id: zod.number(),
          firstname: zod.string(),
          lastname: zod.string(),
        }),
        zod.literal(null),
      ])
      .refine((val) => val !== null, { message: required_one_solution }),
    pole: zod
      .union([
        zod.object({
          pole_id: zod.number(),
          pole_name: zod.string(),
        }),
        zod.literal(null),
      ])
      .refine((val) => val !== null, { message: required_one_solution }),
  });

export type FormCreateDomainData = zod.infer<ReturnType<typeof getFormSchema>>;

interface AddDomainModalProps {
  open: boolean;
  onClose: () => void;
  onSave: () => void;
  initialData?: any;
}

export const CreateDomainModal: React.FC<AddDomainModalProps> = ({
  open,
  onClose,
  onSave,
  initialData,
}) => {
  const formSchema = getFormSchema();

  const {
    control,
    register,
    handleSubmit,
    formState: { errors, isValid },
    setValue,
  } = useForm<FormCreateDomainData>({
    resolver: zodResolver(formSchema),
    mode: "all",
    defaultValues: initialData || {
      domain_name: "",
      person: null,
      pole: null,
    },
  });

  const [persons, setPersons] = useState<PersonShortResponseDTO[]>([]);
  const [poles, setPoles] = useState<PoleShortResponseDTO[]>([]);
  const [loadPersons, setLoadPersons] = useState(false);
  const [loadPoles, setLoadPoles] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const [successSnackbar, setSuccessSnackbar] = useState(false);

  const fetchPersons = async () => {
    setLoadPersons(true);
    try {
      const data = await getAllPersons();
      setPersons(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error("Erreur lors du chargement des persons:", err);
      setPersons([]);
    } finally {
      setLoadPersons(false);
    }
  };

  const fetchPoles = async () => {
    setLoadPoles(true);
    try {
      const data = await getAllPoles();
      setPoles(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error("Erreur lors du chargement des pôles:", err);
      setPoles([]);
    } finally {
      setLoadPoles(false);
    }
  };

  useEffect(() => {
    if (initialData) {
      Object.keys(initialData).forEach((key) => {
        setValue(
          key as keyof FormCreateDomainData,
          initialData[key as keyof FormCreateDomainData],
        );
      });
    }
  }, [initialData, setValue]);

  useEffect(() => {
    if (open) {
      fetchPersons();
      fetchPoles();
    }
  }, [open]);

  const createNewDomain = async (data: FormCreateDomainData) => {
    setErrorMessage(null);
    setLoading(true);
    try {
      await createDomain({
        domain_name: data.domain_name,
        manager_id: data.person.person_id,
        pole_id: data.pole.pole_id,
      });

      onSave();
      setSuccessSnackbar(true);
      onClose();
    } catch (err: any) {
      console.error("Erreur lors de la création du domaine :", err);
      setErrorMessage("Erreur lors de la création du domaine.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <MyModal open={open} onClose={onClose} title="Ajouter un Domaine">
        <form onSubmit={handleSubmit(createNewDomain)}>
          <Grid container spacing={2} sx={{ p: 2 }}>
            {/* Nom du Domaine */}
            <Grid item xs={12} container spacing={2} alignItems="center">
              <Grid item xs={4}>
                <Typography fontWeight="bold">Nom du Domaine</Typography>
              </Grid>
              <Grid item xs={8}>
                <TextField
                  {...register("domain_name")}
                  error={!!errors.domain_name}
                  helperText={errors.domain_name?.message}
                  fullWidth
                  placeholder={placeholder_entity_name}
                />
              </Grid>
            </Grid>

            {/* Responsable */}
            <Grid item xs={12} container spacing={2} alignItems="center">
              <Grid item xs={4}>
                <Typography fontWeight="bold">Responsable</Typography>
              </Grid>
              <Grid item xs={8}>
                <Controller
                  name="person"
                  control={control}
                  render={({ field }) => (
                    <Autocomplete
                      {...field}
                      options={persons}
                      getOptionLabel={(option) =>
                        option?.firstname
                          ? `${option.firstname} ${option.lastname}`
                          : ""
                      }
                      onOpen={fetchPersons}
                      loading={loadPersons}
                      onChange={(_, value) => field.onChange(value || null)}
                      isOptionEqualToValue={(option, value) =>
                        option.person_id === value?.person_id
                      }
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          placeholder={placeholder_one_person}
                          error={!!errors.person}
                          helperText={
                            errors.person?.message ||
                            (loadPersons ? "Chargement des personnes..." : "")
                          }
                          InputProps={{
                            ...params.InputProps,
                            endAdornment: (
                              <>
                                {loadPersons && <CircularProgress size={20} />}
                                {params.InputProps.endAdornment}
                              </>
                            ),
                          }}
                        />
                      )}
                    />
                  )}
                />
              </Grid>
            </Grid>

            {/* Pôle associé */}
            <Grid item xs={12} container spacing={2} alignItems="center">
              <Grid item xs={4}>
                <Typography fontWeight="bold">Pôle associé</Typography>
              </Grid>
              <Grid item xs={8}>
                <Controller
                  name="pole"
                  control={control}
                  render={({ field }) => (
                    <Autocomplete
                      {...field}
                      options={poles}
                      getOptionLabel={(option) =>
                        option?.pole_name ? option.pole_name : ""
                      }
                      onOpen={fetchPoles}
                      loading={loadPoles}
                      onChange={(_, value) => field.onChange(value || null)}
                      isOptionEqualToValue={(option, value) =>
                        option.pole_id === value?.pole_id
                      }
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          placeholder="Sélectionner un pôle"
                          error={!!errors.pole}
                          helperText={
                            errors.pole?.message ||
                            (loadPoles ? "Chargement des pôles..." : "")
                          }
                          InputProps={{
                            ...params.InputProps,
                            endAdornment: (
                              <>
                                {loadPoles && <CircularProgress size={20} />}
                                {params.InputProps.endAdornment}
                              </>
                            ),
                          }}
                        />
                      )}
                    />
                  )}
                />
              </Grid>
            </Grid>

            {/* Erreur globale */}
            {errorMessage && (
              <Grid item xs={12}>
                <Alert variant="filled" severity="error">
                  <Typography variant="body1">{errorMessage}</Typography>
                </Alert>
              </Grid>
            )}
          </Grid>

          {/* Boutons */}
          <Box textAlign="right" p={2}>
            <Button onClick={onClose} sx={{ mr: 1 }}>
              Annuler
            </Button>
            <Button
              type="submit"
              variant="contained"
              disabled={!isValid || loading}
            >
              {loading ? <CircularProgress size={20} /> : "Ajouter"}
            </Button>
          </Box>
        </form>
      </MyModal>
      <Snackbar
        open={successSnackbar}
        autoHideDuration={3000}
        onClose={() => setSuccessSnackbar(false)}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <Alert
          onClose={() => setSuccessSnackbar(false)}
          severity="success"
          variant="filled"
        >
          Domaine à été créer avec succès !
        </Alert>
      </Snackbar>
    </>
  );
};
