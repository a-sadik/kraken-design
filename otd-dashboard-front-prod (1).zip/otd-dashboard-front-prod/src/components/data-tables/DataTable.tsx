// src/components/data-tables/DataTables.tsx

import React, { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TableSortLabel,
  TablePagination,
  Paper,
  Button,
  Box,
  Badge,
} from "@mui/material";
import saveAs from "file-saver";

// Imports File
import CustomSearchField from "../inputs/CustomSearchField";
import CustomTooltip from "../basics/CustomToolTip";

type Order = "asc" | "desc";

interface DataTableProps {
  color?: string;
  fileName: string;
  rows: Array<Record<string, any>>;
}

const DataTable: React.FC<DataTableProps> = ({ color, fileName, rows }) => {
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [order, setOrder] = useState<Order>("asc");
  const [orderBy, setOrderBy] = useState<keyof (typeof rows)[0]>("name");

  const handleSortRequest = (property: keyof (typeof rows)[0]) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const handleChangePage = (_: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const filteredRows = rows.filter((row) =>
    Object.values(row).some((val) =>
      String(val).toLowerCase().includes(search.toLowerCase()),
    ),
  );

  const sortedRows = filteredRows.sort((a, b) => {
    const aValue = a[orderBy];
    const bValue = b[orderBy];
    if (typeof aValue === "string" && typeof bValue === "string") {
      return order === "asc"
        ? aValue.localeCompare(bValue)
        : bValue.localeCompare(aValue);
    }
    if (typeof aValue === "number" && typeof bValue === "number") {
      return order === "asc" ? aValue - bValue : bValue - aValue;
    }
    return 0;
  });

  const exportToCSV = (filename: string) => {
    const currentDateTime = new Date();
    const formattedDate = currentDateTime
      .toLocaleDateString()
      .replace(/\//g, "-");
    const formattedTime = currentDateTime
      .toLocaleTimeString()
      .replace(/:/g, "-");
    const csvFilename = `${filename}_${formattedDate}_${formattedTime}.csv`;

    const csvContent = [
      Object.keys(rows[0]).join(","),
      ...rows.map((row) => Object.values(row).join(",")),
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    saveAs(blob, csvFilename);
  };

  return (
    <>
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          gap: 1,
          width: "100%",
          mb: "1rem",
        }}
      >
        <Button
          variant="contained"
          color="primary"
          onClick={() => exportToCSV(fileName)}
          sx={{ backgroundColor: color }}
        >
          Exporter CSV
        </Button>
        <CustomSearchField search={search} setSearch={setSearch} />
      </Box>

      <TableContainer component={Paper} sx={{ px: 1, py: 2, width: "100%" }}>
        {" "}
        {/* 100% pour le conteneur */}
        <Table sx={{ width: "100%" }}>
          {" "}
          {/* 100% pour la table */}
          <TableHead sx={{ backgroundColor: color }}>
            <TableRow>
              {Object.keys(rows[0] || {}).map((key) => (
                <TableCell key={key}>
                  <TableSortLabel
                    active={orderBy === key}
                    direction={orderBy === key ? order : "asc"}
                    onClick={() =>
                      handleSortRequest(key as keyof (typeof rows)[0])
                    }
                    sx={{ color: "#343a40", fontWeight: "bold" }}
                  >
                    {key.charAt(0).toUpperCase() + key.slice(1)}
                  </TableSortLabel>
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {sortedRows
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((row, index) => (
                <TableRow key={index}>
                  {Object.entries(row).map(
                    (
                      // eslint-disable-next-line @typescript-eslint/no-unused-vars
                      [_, value],
                      idx,
                    ) => {
                      if (value === null) {
                        return (
                          <TableCell
                            key={idx}
                            sx={{
                              textAlign: "center",
                              fontWeight: "bold",
                              fontSize: "2rem",
                            }}
                          >
                            -
                          </TableCell>
                        );
                      }
                      if (typeof value === "object" && value !== null) {
                        return (
                          <TableCell key={idx}>
                            {/* Vous pouvez personnaliser la manière dont vous voulez afficher les objets ici */}
                            {JSON.stringify(value)}{" "}
                            {/* Convertir en chaîne JSON pour l'affichage */}
                          </TableCell>
                        );
                      }
                      if (Array.isArray(value)) {
                        return (
                          <TableCell key={idx}>
                            {value.map((item, index) => (
                              <Badge
                                key={index}
                                color="primary"
                                sx={{ marginRight: 1 }}
                              >
                                {item}
                              </Badge>
                            ))}
                          </TableCell>
                        );
                      }
                      const displayValue =
                        typeof value === "string" && value.length > 30
                          ? `${value.slice(0, 30)}...`
                          : value;

                      return (
                        <CustomTooltip title={value} key={idx}>
                          <TableCell>{displayValue}</TableCell>
                        </CustomTooltip>
                      );
                    },
                  )}
                </TableRow>
              ))}
          </TableBody>
        </Table>
      </TableContainer>

      <TablePagination
        component="div"
        count={filteredRows.length}
        page={page}
        onPageChange={handleChangePage}
        rowsPerPage={rowsPerPage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </>
  );
};

export default DataTable;
