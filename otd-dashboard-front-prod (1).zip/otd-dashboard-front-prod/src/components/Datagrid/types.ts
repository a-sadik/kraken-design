import { MachineData } from "../machineRequestModal/types";

export interface DataGridProps {
  data: MachineData[];
  loading: boolean;
  onRefresh: () => void;
}
