// src/components/ManyServersForm.tsx

import { useState, Dispatch, SetStateAction } from "react";
import { AxiosError } from "axios";
import {
  Button,
  Grid,
  Alert,
  Typography,
  Box,
  Divider,
  Collapse,
  IconButton,
  Stack,
} from "@mui/material";
import { GridColDef } from "@mui/x-data-grid";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
} from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import { useDropzone } from "react-dropzone";
import * as XLSX from "xlsx";
import { DataGrid } from "@mui/x-data-grid";

// Imports file
import { OperatingSystemType } from "@/enums/OperatingSystemType";
import { ServerNature } from "@/enums/ServerNature";
import { Environnement } from "@/enums/Environnement";
import { createManyServer, getAllServers } from "@/services/ServerService";

// Imports messages
import {
  invalid_file,
  file_data_empty,
  invalid_hostname,
  invalid_ip_adresseses,
} from "@/utils/customMessages";
import ServerView from "@/types/view/ServerView";
import { ErrorResponse } from "@/exceptions/ErrorResponse";

interface ManyServersFormProps {
  setOpenModal: Dispatch<SetStateAction<boolean>>;
  setServers: Dispatch<SetStateAction<ServerView[] | null>>;
}

export function ManyServersForm({
  setOpenModal,
  setServers,
}: ManyServersFormProps) {
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);
  const [isFileValid, setIsFileValid] = useState<boolean>(false);
  const [showInfo, setShowInfo] = useState<boolean>(false);
  const [rows, setRows] = useState<any>([]);
  const [columns, setColumns] = useState<GridColDef[]>([]);

  // Liste des options pour les champs
  const osTypeList = Object.values(OperatingSystemType);
  const solutionNatureList = Object.values(ServerNature);
  const environmentsList = Object.values(Environnement);

  // Colonnes acceptées
  const requiredColumns = [
    {
      name: "Hostname",
      constraint: "Chaîne de caractères et unique",
    },
    {
      name: "Adresses IP",
      constraint: "Ensemble des adresses IP V4 sans CIDR et non doublantes",
    },
    {
      name: "OS",
      constraint: `Type de système d'exploitation (${osTypeList.join(", ")})`,
    },
    {
      name: "Nature de serveur",
      constraint: `Ensemble des natures de serveur non redondantes (${solutionNatureList.join(", ")})`,
    },
    {
      name: "Détail de la nature",
      constraint:
        "Spécification technique détaillée sur la ou les natures de serveur choisies",
    },
    {
      name: "Solutions",
      constraint: "Ensemble des noms de solutions existants et non redondants",
    },
    {
      name: "Environnements",
      constraint: `Ensemble des environnements et non redondants (${environmentsList.join(", ")})`,
    },
  ];

  const exampleData = [
    {
      Hostname: "server01",
      "Adresses IP": "192.168.1.1",
      OS: "Windows",
      "Nature de serveur": "Serveur de base de données",
      "Détail de la nature": "MySQL version 8.0",
      Solutions: "ERP;CRM;AWB-Mobile",
      Environnements: "Production",
    },
    {
      Hostname: "server02",
      "Adresses IP": "192.168.1.2;192.168.1.3",
      OS: "Linux",
      "Nature de serveur": "Serveur de fichier;Serveur de stockage",
      "Détail de la nature": "NAS Synology",
      Solutions: "Backup;Antivirus",
      Environnements: "Préproduction;Production",
    },
  ];

  const handleSubmit = async () => {
    if (uploadedFile && isFileValid) {
      try {
        await createManyServer(rows);
        setFileError(null);
        setOpenModal(false);
        fetchServers();
      } catch (error) {
        const err = error as AxiosError<ErrorResponse>;

        if (
          err.status === 409 ||
          (err.status === 404 &&
            err.response?.data.message.includes("Nom de solution"))
        ) {
          setFileError(err.response?.data.message || "Undefined message error");
          setIsFileValid(false);
        }
      }
    }
  };

  // fetch data of servers after creation a new servers
  const fetchServers = async () => {
    try {
      const data = await getAllServers();
      setServers(data as any);
    } catch (err) {
      console.error("Erreur lors de la récupération des serveurs :", err);
    }
  };

  // Gestion des fichiers avec react-dropzone
  const onDrop = (acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      setUploadedFile(acceptedFiles[0]);
      setFileError(null);
      setRows([]);
      processFile(acceptedFiles[0]);
    } else {
      setFileError(invalid_file);
    }
  };

  // Validation du fichier Excel
  const validateFileContent = (fileData: any[]) => {
    // Vérifier qu'il y a au moins une ligne de données
    if (fileData.length === 0) {
      setFileError(file_data_empty);
      setIsFileValid(false);
      return false;
    }

    // Validation des colonnes
    const missingColumns = requiredColumns.filter(
      (col) => !Object.keys(fileData[0]).includes(col.name),
    );
    if (missingColumns.length > 0) {
      setFileError(
        `Colonnes manquantes : ${missingColumns.map((col) => col.name).join(", ")}.`,
      );
      setIsFileValid(false);
      return false;
    }

    // Validation réussie
    setFileError(null);
    return true;
  };

  const validateCell = (key: any, value: any) => {
    if (
      (key === "Hostname" ||
        key === "Solutions" ||
        key === "Détail de la nature") &&
      value === ""
    )
      return false;

    const ipRegex =
      /^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    if (key === "Adresses IP") {
      return value.split(";").every((ip: string) => ipRegex.test(ip));
    }

    if (key === "OS" && !osTypeList.includes(value)) return false;
    if (
      key === "Nature de serveur" &&
      !value
        .split(";")
        .every((val: string) =>
          solutionNatureList.includes(val as ServerNature),
        )
    )
      return false;
    if (
      key === "Environnements" &&
      !value
        .split(";")
        .every((val: string) => environmentsList.includes(val as Environnement))
    )
      return false;

    if (key === "Solutions") {
      const solutions = value.split(";").map((sol: string) => sol.trim());
      const uniqueSolutions = new Set(solutions);

      // Vérifier qu'il n'y a pas de doublons
      if (uniqueSolutions.size !== solutions.length) {
        return false;
      }
    }

    return true;
  };

  // Fonction de validation d'une ligne
  const validateRow = (row: any) => {
    return Object.keys(row).every((key) => {
      return validateCell(key, row[key]);
    });
  };

  const validateHostname = (rows: any[]) => {
    const hostnames = rows.map((row) => row.Hostname?.trim());
    const uniqueHostnames = new Set(hostnames);

    // Vérifiez les critères : non vide, non blanc, et unique
    const isValid =
      hostnames.every((hostname) => hostname) &&
      uniqueHostnames.size === hostnames.length;
    if (!isValid) {
      setFileError(invalid_hostname);
    }
    return isValid;
  };

  const validateIPAddresses = (rows: any[]) => {
    // Récupérer toutes les adresses IP
    const ipAddresses: string[] = rows.flatMap((row: any) =>
      row["Adresses IP"].split(";").map((ip: string) => ip.trim()),
    );

    // Vérifier la redondance
    const uniqueIPs = new Set(ipAddresses);
    if (ipAddresses.length !== uniqueIPs.size) {
      setFileError(invalid_ip_adresseses);
      return false;
    }

    // Validation réussie
    return true;
  };

  const handleFileData = (fileData: any[]): boolean => {
    // Initialisation de la validité globale
    let isDataValid = true;

    // Pré-validation des données
    const parsedRows = fileData.map((row, id) => {
      const validatedRow = { ...row, id };
      Object.keys(row).forEach((header) => {
        const value = row[header];
        const cellIsValid = validateCell(header, value);
        if (!cellIsValid) isDataValid = false;
      });
      return validatedRow;
    });

    // Validation spécifique pour Hostname
    if (!validateHostname(parsedRows)) {
      isDataValid = false;
    }

    // Validation spécifique pour adresses ip
    if (!validateIPAddresses(parsedRows)) {
      isDataValid = false;
    }

    // Configuration des colonnes avec gestion des styles d'erreur
    const parsedColumns = Object.keys(fileData[0]).map((header) => ({
      field: header,
      headerName: header,
      editable: true,
      flex: 1,
      cellClassName: (params: any) =>
        validateCell(header, params.value) ? "" : "error-cell",
    }));

    // Mise à jour des états
    setColumns(parsedColumns);
    setRows(parsedRows);
    setIsFileValid(isDataValid);

    // Retourner le résultat de la validation
    return isDataValid;
  };

  const processRowUpdate = (newRow: any, _: any) => {
    const updatedRows = rows.map((row: any) =>
      row.id === newRow.id ? newRow : row,
    );

    setRows(updatedRows);

    const isHostnameValid = validateHostname(updatedRows);
    const isIPAddressesValid = validateIPAddresses(updatedRows);
    if (isHostnameValid && isIPAddressesValid) {
      setFileError(null);
    }

    const isAllRowsValid =
      updatedRows.every(validateRow) && isHostnameValid && isIPAddressesValid;
    setIsFileValid(isAllRowsValid);

    return newRow;
  };

  const handleProcessRowUpdateError = (error: any) => {
    console.error("Erreur lors de la mise à jour :", error);
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "application/vnd.ms-excel": [".xls"],
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [
        ".xlsx",
      ],
    },
    maxFiles: 1,
  });

  const downloadTemplateFile = async () => {
    const worksheet = XLSX.utils.aoa_to_sheet([
      requiredColumns.map((col) => col.name),
    ]);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Template");
    XLSX.writeFile(workbook, "template_servers.xlsx");
  };

  const processFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const data = event.target?.result;
      const workbook = XLSX.read(data, { type: "binary" });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const fileData = XLSX.utils.sheet_to_json(worksheet);

      if (validateFileContent(fileData)) {
        const isDataValid = handleFileData(fileData);
        setIsFileValid(isDataValid);
      }
    };
    reader.readAsBinaryString(file);
  };

  return (
    <form>
      <Grid container spacing={2}>
        {/* Informations importantes pour l'utilisateur */}
        <Grid item xs={12}>
          <Box
            sx={{
              marginBottom: "16px",
              padding: "16px",
              backgroundColor: "#f3f3f3",
              borderRadius: "8px",
              border: "1px solid #ccc",
            }}
          >
            <Stack
              direction="row"
              alignItems="center"
              justifyContent="space-between"
            >
              <Typography variant="h6" sx={{ fontWeight: "bold" }}>
                Informations pour la validation d'importation
              </Typography>
              <IconButton onClick={() => setShowInfo(!showInfo)}>
                {showInfo ? <ExpandLessIcon /> : <ExpandMoreIcon />}
              </IconButton>
            </Stack>

            <Collapse in={showInfo}>
              <Typography variant="body2" sx={{ marginBottom: "8px" }}>
                Veuillez respecter les noms, l'ordre et les valeurs de chaque
                colonne dans votre fichier{" "}
                <strong>Excel (.xls ou .xlsx)</strong> :
              </Typography>
              {requiredColumns.map((column, index) => (
                <Box key={index} sx={{ marginBottom: "1rem" }}>
                  <Typography variant="body2">
                    <strong>
                      {index + 1}. {column.name}
                    </strong>{" "}
                    : {column.constraint}
                  </Typography>
                </Box>
              ))}

              <Typography
                variant="body2"
                sx={{
                  marginTop: "16px",
                  fontStyle: "italic",
                  color: "gray",
                }}
              >
                Remarque : Pour les champs multi-choix, utilisez `;` comme
                séparateur pour éviter les conflits.
              </Typography>

              <Divider sx={{ marginY: "2.5rem" }} />

              <Typography
                variant="h6"
                sx={{ fontWeight: "bold", marginBottom: "8px" }}
              >
                Exemple de fichier attendu :
              </Typography>

              <Typography variant="body2" sx={{ marginBottom: "16px" }}>
                Voici un exemple de tableau Excel respectant les contraintes :
              </Typography>

              <TableContainer component={Paper}>
                <Table>
                  <TableHead>
                    <TableRow>
                      {requiredColumns.map((column) => (
                        <TableCell
                          key={column.name}
                          sx={{
                            fontWeight: "bold",
                            fontSize: "0.8rem",
                            backgroundColor: "var(--aix-color)",
                          }}
                        >
                          {column.name}
                        </TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {exampleData.map((row: any, rowIndex) => (
                      <TableRow key={rowIndex}>
                        {requiredColumns.map((column) => (
                          <TableCell
                            key={column.name}
                            sx={{ fontSize: "0.85rem" }}
                          >
                            {row[column.name]}
                          </TableCell>
                        ))}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </Collapse>
          </Box>
        </Grid>

        {/* Zone de drag-and-drop */}
        <Grid item xs={12}>
          <Box
            {...getRootProps()}
            sx={{
              border: "2px dashed #cccccc",
              borderRadius: "8px",
              padding: "20px",
              textAlign: "center",
              backgroundColor: isDragActive ? "#f0f8ff" : "#fafafa",
              cursor: "pointer",
            }}
          >
            <input {...getInputProps()} />
            {uploadedFile ? (
              <Typography variant="body1">
                Fichier sélectionné : {uploadedFile.name}
              </Typography>
            ) : isDragActive ? (
              <Typography variant="body1">Déposez le fichier ici...</Typography>
            ) : (
              <Typography variant="body1">
                Glissez et déposez un fichier ici, ou cliquez pour sélectionner
                un fichier Excel (.xls, .xlsx)
              </Typography>
            )}
          </Box>
        </Grid>

        {/* Datatable */}
        {rows.length > 0 && (
          <Grid item xs={12}>
            <Box sx={{ width: "100%" }}>
              <DataGrid
                rows={rows}
                columns={columns}
                pageSizeOptions={[5, 10, 25, 50]}
                initialState={{
                  pagination: { paginationModel: { pageSize: 5 } },
                }}
                processRowUpdate={processRowUpdate}
                onProcessRowUpdateError={handleProcessRowUpdateError}
                // disableSelectionOnClick
              />
            </Box>
          </Grid>
        )}

        {/* Zone d'erreur globale */}
        {fileError && (
          <Grid item xs={12}>
            <Alert variant="filled" severity="error">
              <Typography variant="body1">{fileError}</Typography>
            </Alert>
          </Grid>
        )}

        {/* Bouton de template downloading  */}
        <Grid item md={6} xs={12}>
          <Button
            type="button"
            variant="contained"
            fullWidth
            onClick={downloadTemplateFile}
          >
            Télécharger template
          </Button>
        </Grid>

        {/* Bouton de l'insértation les serveurs */}
        <Grid item md={6} xs={12}>
          <Button
            type="button"
            variant="contained"
            color="primary"
            disabled={!isFileValid}
            fullWidth
            onClick={handleSubmit}
          >
            Ajouter
          </Button>
        </Grid>
      </Grid>
    </form>
  );
}
