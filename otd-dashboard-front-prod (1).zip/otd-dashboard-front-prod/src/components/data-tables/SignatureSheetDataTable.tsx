// src/components/data-tables/home/HomeDataTable.tsx

import { useState, useMemo } from "react";

import { createTheme, ThemeProvider } from "@mui/material/styles";
import { DataGrid } from "@mui/x-data-grid/DataGrid";
import { Collapse, Box, Stack, IconButton } from "@mui/material";

// import files
import WidgetMainContainer from "@/components/containers/WidgetMainContainer";
import CustomTooltip from "@/components/basics/CustomToolTip";
import CustomBadge from "@/components/basics/CustomBadge";
import CustomTypography from "@/components/basics/CustomTypography";
import CustomToolBarHome from "@/components/data-tables/CustomToolBarHome";
import {
  getBadgeColorEnvironment,
  getBadgeColorOS,
} from "@/utils/getDynamicColor";

// import enums
import { OperatingSystemType } from "@/enums/OperatingSystemType";

// import icons
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";

interface SignatureSheetTableProps {
  color?: string;
  title: string;
  rows: Array<Record<string, any>>;
}

export default function SignatureSheetTable({
  color,
  title,
  rows,
}: SignatureSheetTableProps) {
  const [isProduction, setIsProduction] = useState(false);
  const [isHorsProduction, setIsHorsProduction] = useState(false);
  const [isPoleOTD, setIsPoleOTD] = useState(false);
  const [isTableVisible, setIsTableVisible] = useState(true);

  const toggleTableVisibility = () => {
    setIsTableVisible((prev) => !prev);
  };

  const rowsWithId = rows.map((row, index) => ({
    ...row,
    id: row.id || index,
  }));

  function valueContent(value: string | string[], key: string) {
    if (value === null || (Array.isArray(value) && value.length === 0)) {
      return (
        <span
          style={{ textAlign: "center", fontWeight: "bold", fontSize: "2rem" }}
        >
          -
        </span>
      );
    }
    if (Array.isArray(value)) {
      if (key === "Environnements") {
        return (
          <>
            {value.map((item, index) => (
              <CustomBadge
                key={index}
                text={item}
                backgroundColor={getBadgeColorEnvironment(item)}
                textColor={"black"}
                textSize={"0.8rem"}
              />
            ))}
          </>
        );
      }
      return (
        <>
          {value.length > 1 && <CustomBadge text={value.length.toString()} />}

          {value.map((item, index) => (
            <CustomBadge key={index} text={item} />
          ))}
        </>
      );
    }

    if (
      typeof value === "string" &&
      key === "OS" &&
      Object.values(OperatingSystemType).includes(value as OperatingSystemType)
    ) {
      return (
        <CustomBadge
          text={value}
          backgroundColor={getBadgeColorOS(value)}
          textSize={"0.8rem"}
          withBorder
        />
      );
    }
    return (
      <CustomTooltip title={value}>
        <span>{value}</span>
      </CustomTooltip>
    );
  }

  const columns = useMemo(() => {
    if (rowsWithId.length === 0) return [];

    return Object.keys(rowsWithId[0])
      .filter((key) => key !== "id")
      .map((key) => ({
        field: key,
        headerName: key,
        description: key,
        flex: 1,
        renderCell: (params: any) => valueContent(params.value, key),
        sortable: true,
        sortComparator: (v1: string | [], v2: string | []) => {
          if (Array.isArray(v1) && Array.isArray(v2)) {
            // Transformer les tableaux en string pour comparer
            return v1.join(", ").localeCompare(v2.join(", "));
          }
          if (typeof v1 === "string" && typeof v2 === "string") {
            return v1.localeCompare(v2);
          }
          // Par défaut, ne change pas l'ordre
          return 0;
        },
      }));
  }, [rowsWithId]);

  const customTheme = createTheme({
    palette: { primary: { main: color! } },
  });

  const defaultVisibleColumns: Record<string, boolean> = {
    Hostname: true,
    "Adresses IP": true,
    OS: true,
    Solutions: true,
    Environnements: true,
    Domaine: true,
    Pôle: true,
    "Admins fonctionnels": true,
    "Admins techniques": true,
  };

  const [columnVisibility, setColumnVisibility] = useState(() => {
    const initialVisibility: Record<string, boolean> = {};
    columns.forEach((column) => {
      initialVisibility[column.field] =
        defaultVisibleColumns[column.field] || false;
    });
    return initialVisibility;
  });

  const filteredRows = useMemo(() => {
    const hasTAM = (row: any) =>
      row["TAM"] &&
      (row["TAM"].includes("a.sadik") || row["TAM"].includes("Amine Sadik"));
    const isProductionEnv = (row: any) =>
      Array.isArray(row["Environnements"]) &&
      row["Environnements"]?.includes("Production");
    const isHorsProductionEnv = (row: any) =>
      Array.isArray(row["Environnements"]) &&
      row["Environnements"].every((env) => env !== "Production");

    return rowsWithId.filter((row) => {
      if (isPoleOTD) {
        if (isProduction) {
          return isProductionEnv(row) && hasTAM(row);
        }
        if (isHorsProduction) {
          return isHorsProductionEnv(row) && hasTAM(row);
        }
        return hasTAM(row);
      } else {
        if (isProduction) {
          return isProductionEnv(row);
        }
        if (isHorsProduction) {
          return isHorsProductionEnv(row);
        }
        return true;
      }
    });
  }, [isProduction, isHorsProduction, isPoleOTD, rowsWithId]);

  return (
    <ThemeProvider theme={customTheme}>
      <WidgetMainContainer sx={{ borderColor: color }}>
        <Stack direction="row" justifyContent="space-between">
          <Box
            display="flex"
            alignItems="center"
            justifyContent="space-between"
            gap={2}
          >
            <CustomTypography text={title} contentBadge={filteredRows.length} />
          </Box>

          {/* nbr de lignes en datatable avec le filtre */}
          <IconButton onClick={toggleTableVisibility}>
            {isTableVisible ? (
              <ExpandLessIcon sx={{ fontSize: "2.5rem" }} />
            ) : (
              <ExpandMoreIcon sx={{ fontSize: "2.5rem" }} />
            )}
          </IconButton>
        </Stack>
        <Collapse in={isTableVisible}>
          <Box mt={2}>
            <DataGrid
              rows={filteredRows}
              columns={columns}
              getRowId={(row) => row.id}
              pageSizeOptions={[5, 10, 25, 50]}
              initialState={{
                pagination: {
                  paginationModel: { pageSize: 5 },
                },
                columns: {
                  columnVisibilityModel: columnVisibility,
                },
              }}
              onColumnVisibilityModelChange={(newModel) =>
                setColumnVisibility(newModel)
              }
              slots={{ toolbar: CustomToolBarHome }}
              slotProps={{
                toolbar: {
                  isProduction,
                  setIsProduction,
                  isHorsProduction,
                  setIsHorsProduction,
                  isPoleOTD,
                  setIsPoleOTD,
                } as any,
              }}
              sx={{
                border: "none",
                "& .MuiDataGrid-columnHeaderTitle": {
                  fontWeight: "bold",
                },
              }}
            />
          </Box>
        </Collapse>
      </WidgetMainContainer>
    </ThemeProvider>
  );
}
