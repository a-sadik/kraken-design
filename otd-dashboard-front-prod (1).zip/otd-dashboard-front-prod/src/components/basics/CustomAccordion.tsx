import type {
  DropdownOptions,
  EditableValues,
  ServerResult,
} from "@/types/ReliabilityTypes";
import { alpha, formatFieldName, formatValue } from "@/utils/format.utils";
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  Button,
  Chip,
  MenuItem,
  Paper,
  Select,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
  useTheme,
} from "@mui/material";

interface ServerAccordionProps {
  server: ServerResult;
  editableValues: EditableValues;
  onValueChange: (serverId: number, field: string, value: string) => void;
  onUpdateServer: (serverId: number) => void;
  apiDropdownOptions: DropdownOptions;
  enumDropdownOptions: Record<string, string[]>;
}

// Define field types
const apiDropdownFields = new Set([
  "technicals_admins",
  "functionals_admins",
  "domain",
  "entity",
  "solution_name",
  "solution_role",
  "tam",
  "pole",
]);

const enumDropdownFields = new Set([
  "environments",
  "solution_popularity",
  "solution_admins",
  "solution_type",
  "os",
  "pci",
]);

export const ServerAccordion = ({
  server,
  editableValues,
  onValueChange,
  onUpdateServer,
  apiDropdownOptions,
  enumDropdownOptions,
}: ServerAccordionProps) => {
  const theme = useTheme();

  const differencesList = Object.keys(server.differences ?? {}).map(
    (d) => d.split("|")[0],
  );
  const differencesCount = differencesList.length;

  const hostname = server.inventory_data.hostname;

  const ipAddress =
    server.inventory_data.ip_addresses?.[0] || server.ip || "N/A";

  const propsOrder = [
    "hostname",
    "ip_addresses",
    "os",
    "os_details",
    "server_nature",
    "environments",
    "pci",
    "solution_name",
    "solution_role",
    "solution_type",
    "solution_popularity",
    "tam",
    "functionals_admins",
    "technicals_admins",
    "domain",
    "pole",
    "entity",
  ];
  const allProps = Array.from(
    new Set(
      [
        ...Object.keys(server.bigfix_data || {}),
        ...Object.keys(server.inventory_data),
      ].filter(
        (prop) =>
          prop !== "id" &&
          prop !== "last_seen" &&
          prop !== "solution_deployed_version" &&
          prop !== "production_start_date" &&
          prop !== "owner" &&
          prop !== "signed" &&
          prop !== "source",
      ),
    ),
  )
    .sort((a, b) => {
      const indexA = propsOrder.indexOf(a);
      const indexB = propsOrder.indexOf(b);
      if (indexA !== -1 && indexB !== -1) {
        return indexA - indexB;
      }
      if (indexA !== -1) return -1; // a est prioritaire
      if (indexB !== -1)
        return 1; // b est prioritaire
      else return 0;
    })
    .sort((a, b) => {
      const aHasDiff = differencesList.includes(a);
      const bHasDiff = differencesList.includes(b);
      return (bHasDiff ? 1 : 0) - (aHasDiff ? 1 : 0);
    });

  return (
    <Accordion sx={{ mb: 2, boxShadow: 2 }}>
      <AccordionSummary
        sx={{
          background: `linear-gradient(to right, ${alpha(
            theme.palette.primary.light,
            0.05,
          )}, ${alpha(theme.palette.background.paper, 0.8)})`,
          borderLeft: `4px solid ${theme.palette.primary.main}`,
          "&:hover": {
            bgcolor: alpha(theme.palette.primary.light, 0.1),
            transform: "translateY(-1px)",
          },
          transition: "all 0.3s ease",
          borderRadius: "4px",
          py: 1,
        }}
      >
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 2,
            flexWrap: "wrap",
            width: "100%",
            "& > *": { transition: "all 0.2s ease" },
          }}
        >
          <Chip
            label={ipAddress}
            color="warning"
            variant="outlined"
            sx={{
              minWidth: "120px",
              fontSize: 14,
              fontWeight: 500,
              borderWidth: 2,
              "&:hover": { transform: "scale(1.03)" },
            }}
          />
          <Typography
            variant="subtitle1"
            sx={{
              fontWeight: 600,
              fontSize: 16,
              color: theme.palette.text.primary,
              textShadow: "0 0 1px rgba(0,0,0,0.05)",
            }}
          >
            <strong>{hostname}</strong>
          </Typography>
          {differencesCount > 0 && (
            <Chip
              label={`${differencesCount} différence${
                differencesCount > 1 ? "s" : ""
              }`}
              color="error"
              sx={{
                bgcolor: alpha(theme.palette.error.main, 0.9),
                color: "white",
                fontSize: 14,
                fontWeight: 500,
                boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
                "&:hover": { transform: "scale(1.05)" },
              }}
            />
          )}
          <Box sx={{ display: "flex", gap: 1, flexWrap: "wrap", ml: "auto" }}>
            {differencesList.slice(0, 4).map((diff, index) => (
              <Chip
                key={index}
                label={formatFieldName(diff)}
                color="primary"
                size="small"
                sx={{
                  bgcolor: alpha(theme.palette.primary.main, 0.85),
                  fontSize: 12,
                  color: "white",
                  fontWeight: 500,
                  boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
                  "&:hover": { transform: "scale(1.05)" },
                }}
              />
            ))}
            {differencesList.length > 4 && (
              <Chip
                label={`+${differencesList.length - 4}`}
                color="primary"
                size="medium"
                variant="outlined"
                sx={{
                  fontSize: 12,
                  fontWeight: 600,
                  borderWidth: 2,
                  "&:hover": { transform: "scale(1.05)" },
                }}
              />
            )}
          </Box>
        </Box>
      </AccordionSummary>

      <AccordionDetails>
        <TableContainer
          component={Paper}
          sx={{
            boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
            borderRadius: "8px",
            overflow: "hidden",
            border: `1px solid ${alpha(theme.palette.divider, 0.5)}`,
          }}
        >
          <Table size="small">
            <TableHead>
              <TableRow
                sx={{
                  bgcolor:
                    theme.palette.mode === "light"
                      ? `linear-gradient(to right, ${
                          theme.palette.primary.light
                        }, ${alpha(theme.palette.primary.main, 0.7)})`
                      : theme.palette.primary.dark,
                }}
              >
                <TableCell
                  sx={{
                    fontWeight: 600,
                    fontSize: 16,
                    color: theme.palette.common.black,
                    py: 1.5,
                  }}
                >
                  Champ
                </TableCell>
                <TableCell
                  sx={{
                    fontWeight: 600,
                    fontSize: 16,
                    color: theme.palette.common.black,
                    py: 1.5,
                  }}
                >
                  Bigfix
                </TableCell>
                <TableCell
                  sx={{
                    fontWeight: 600,
                    fontSize: 16,
                    color: theme.palette.common.black,
                    py: 1.5,
                  }}
                >
                  Inventaire
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {allProps.map((prop) => {
                const editableKey = `${server.id}-${prop}`;
                const initialValue = formatValue(
                  server.inventory_data[
                    prop as keyof typeof server.inventory_data
                  ],
                );
                const isApiDropdown = apiDropdownFields.has(prop);
                const isEnumDropdown = enumDropdownFields.has(prop);
                const isDropdown = isApiDropdown || isEnumDropdown;

                const currentValue =
                  editableValues[editableKey] ?? initialValue;

                return (
                  <TableRow
                    key={prop}
                    sx={{
                      bgcolor: differencesList.includes(prop)
                        ? alpha(theme.palette.error.light, 0.1)
                        : "inherit",
                      "&:hover": {
                        bgcolor: differencesList.includes(prop)
                          ? alpha(theme.palette.error.light, 0.2)
                          : alpha(theme.palette.action.hover, 0.7),
                      },
                      transition: "background-color 0.2s",
                      borderLeft: differencesList.includes(prop)
                        ? `4px solid ${theme.palette.error.main}`
                        : `4px solid transparent`,
                    }}
                  >
                    <TableCell
                      sx={{
                        fontWeight: differencesList.includes(prop) ? 700 : 500,
                        fontSize: differencesList.includes(prop) ? 14 : 13,
                        color: differencesList.includes(prop)
                          ? theme.palette.error.dark
                          : theme.palette.text.primary,
                        transition: "all 0.2s ease",
                      }}
                    >
                      {formatFieldName(prop)}
                      {differencesList.includes(prop) && (
                        <Box
                          component="span"
                          sx={{
                            ml: 1,
                            color: theme.palette.error.main,
                            animation: differencesList.includes(prop)
                              ? "pulse 2s infinite"
                              : "none",
                            "@keyframes pulse": {
                              "0%": { opacity: 0.6 },
                              "50%": { opacity: 1 },
                              "100%": { opacity: 0.6 },
                            },
                          }}
                        >
                          •
                        </Box>
                      )}
                    </TableCell>
                    <TableCell
                      sx={{
                        fontSize: 13,
                        color: theme.palette.text.secondary,
                        fontFamily: "monospace",
                        letterSpacing: "0.03em",
                      }}
                    >
                      {server.bigfix_data
                        ? formatValue(
                            server.bigfix_data[
                              prop as keyof typeof server.bigfix_data
                            ],
                          )
                        : "N/A"}
                    </TableCell>
                    <TableCell>
                      {isDropdown ? (
                        <Select
                          fullWidth
                          value={currentValue}
                          size="small"
                          onChange={(e) =>
                            onValueChange(server.id, prop, e.target.value)
                          }
                          sx={{
                            fontSize: 13,
                            "& .MuiOutlinedInput-notchedOutline": {
                              borderColor: differencesList.includes(prop)
                                ? alpha(theme.palette.error.main, 0.5)
                                : alpha(theme.palette.primary.main, 0.3),
                            },
                            "&:hover .MuiOutlinedInput-notchedOutline": {
                              borderColor: differencesList.includes(prop)
                                ? theme.palette.error.main
                                : theme.palette.primary.main,
                            },
                            "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
                              borderColor: differencesList.includes(prop)
                                ? theme.palette.error.main
                                : theme.palette.primary.main,
                              borderWidth: 2,
                            },
                          }}
                        >
                          {isApiDropdown &&
                            (apiDropdownOptions[prop] || []).map((option) => (
                              <MenuItem key={option} value={option}>
                                {option}
                              </MenuItem>
                            ))}
                          {/* on ajoute currentValue s’il manque */}
                          {isApiDropdown &&
                            apiDropdownOptions[prop] &&
                            !apiDropdownOptions[prop].includes(
                              currentValue,
                            ) && (
                              <MenuItem key={currentValue} value={currentValue}>
                                {currentValue}
                              </MenuItem>
                            )}

                          {isEnumDropdown &&
                            (enumDropdownOptions[prop] || []).map((option) => (
                              <MenuItem key={option} value={option}>
                                {option}
                              </MenuItem>
                            ))}
                          {/* idem pour l’enum */}
                          {isEnumDropdown &&
                            enumDropdownOptions[prop] &&
                            !enumDropdownOptions[prop].includes(
                              currentValue,
                            ) && (
                              <MenuItem key={currentValue} value={currentValue}>
                                {currentValue}
                              </MenuItem>
                            )}

                          {/* Fallback si pas de list du tout */}
                          {!apiDropdownOptions[prop] && isApiDropdown && (
                            <MenuItem value={currentValue}>
                              {currentValue}
                            </MenuItem>
                          )}
                        </Select>
                      ) : (
                        <TextField
                          value={currentValue}
                          fullWidth
                          size="small"
                          onChange={(e) =>
                            onValueChange(server.id, prop, e.target.value)
                          }
                          sx={{
                            bgcolor: "white",
                            "& .MuiOutlinedInput-root": {
                              "& fieldset": {
                                borderColor: differencesList.includes(prop)
                                  ? alpha(theme.palette.error.main, 0.5)
                                  : alpha(theme.palette.primary.main, 0.3),
                              },
                              "&:hover fieldset": {
                                borderColor: differencesList.includes(prop)
                                  ? theme.palette.error.main
                                  : theme.palette.primary.main,
                              },
                              "&.Mui-focused fieldset": {
                                borderColor: differencesList.includes(prop)
                                  ? theme.palette.error.main
                                  : theme.palette.primary.main,
                                borderWidth: 2,
                              },
                            },
                            "& .MuiInputBase-input": {
                              fontSize: 13,
                            },
                          }}
                        />
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>

        <Box sx={{ mt: 3, textAlign: "right", mb: 1 }}>
          <Button
            variant="contained"
            color="primary"
            onClick={() => onUpdateServer(server.id)}
            sx={{
              fontWeight: 600,
              px: 3,
              py: 1,
              borderRadius: "6px",
              boxShadow: "0 4px 8px rgba(0,0,0,0.1)",
              transition: "all 0.3s ease",
              "&:hover": {
                transform: "translateY(-2px)",
                boxShadow: "0 6px 12px rgba(0,0,0,0.15)",
              },
            }}
          >
            Mettre à jour l'inventaire
          </Button>
        </Box>
      </AccordionDetails>
    </Accordion>
  );
};
