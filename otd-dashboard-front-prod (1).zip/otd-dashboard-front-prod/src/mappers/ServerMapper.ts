// import type { ServerFormData } from "@/components/forms/ServerForm"
import { getSolutionByName } from "@/services/SolutionService";
import type { ServerRequestDTO } from "@/types/dto/request/ServerRequestDTO";
import type {
  ServerResponseDTO,
  SolutionDetailFromAPI,
} from "@/types/dto/response/ServerResponseDTO"; // Import SolutionDetailFromAPI
import type ServerView from "@/types/view/ServerView";

export const serverResToView = (data: ServerResponseDTO[]): ServerView[] => {
  return data.map(
    (item) =>
      ({
        id: item.server_id,
        Signature:
          item.signed === "Anonyme" ? "Non signé" : item.signed || "ERREUR",
        Hostname: item.hostname,
        "Adresses IP": item.ip_addresses,
        "Type OS": item.os_type || null,
        Uname: item.uname || null,
        "Détail OS": item.os_detail || null,
        Solutions: item.solutions || null,
        Environnements: item.environments || null,
        Domaine: item.domains || null,
        Pôle: item.poles || null,
        "Nature du serveur": item.server_nature || [],
        "Détail de la nature": item.nature_detail || null,
        "solutions dans l'inventaire": (item.solutions_inventory || []).map(
          String,
        ),
        created_by: item.created_by || null,
        updated_by: item.updated_by || null,
        created_at: item.created_at || null,
        updated_at: item.updated_at || null,
      }) as any,
  );
};

export const serverResToReq = (
  serverResponseDTO: ServerResponseDTO,
  solutions_id: number[],
): ServerRequestDTO => {
  return {
    hostname: serverResponseDTO.hostname,
    ip_addresses: serverResponseDTO.ip_addresses,
    server_nature: serverResponseDTO.server_nature,
    nature_detail: serverResponseDTO.nature_detail,
    os_type: serverResponseDTO.os_type,
    uname: serverResponseDTO.uname,
    environments: serverResponseDTO.environments,
    solution_ids: solutions_id,
    solutions_inventory: serverResponseDTO.solutions_inventory,
    natures_inventory: serverResponseDTO.natures_inventory,
    operation_by: "Admin",
  };
};

export const serverResToManyCreateReq = async (
  servers: [],
): Promise<ServerRequestDTO[]> => {
  const fetchSolutionIds = async (
    solutionNames: string[],
  ): Promise<number[]> => {
    const solutionPromises = solutionNames.map(async (name) => {
      const solution = await getSolutionByName(name);
      return solution ? solution.solution_id : undefined;
    });
    const solutions = await Promise.all(solutionPromises);
    return solutions.filter((id): id is number => id !== undefined);
  };

  const mappedServers = await Promise.all(
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    servers.map(async (item: any) => {
      const solutionIds = await fetchSolutionIds(item["Solutions"].split(";"));
      return {
        hostname: item["Hostname"],
        ip_addresses: item["Adresses IP"].split(";") || [],
        server_nature: item["Nature de serveur"].split(";") || [],
        nature_detail: item["Détail de la nature"] || "",
        os_type: item["OS"] || "Unknown",
        uname: item["Uname"] || "",
        environments: item["Environnements"].split(";") || [],
        solution_ids: solutionIds,
        operation_by: "Admin",
      } as ServerRequestDTO;
    }),
  );
  return mappedServers;
};

export const serverDataFormToRes = (dataServerForm: any): ServerResponseDTO => {
  // Map solutions from ServerFormData to SolutionDetailFromAPI structure
  const mappedSolutions: SolutionDetailFromAPI[] = (
    dataServerForm.solutions || []
  ).map((sol: any) => ({
    solution_id: sol.id, // Assuming formData.solutions has an 'id' field
    solution_name: sol.solution_name,
    solution_popularity: sol.solution_popularity || "N/A",
    // Fill in default or empty values for other fields of SolutionDetailFromAPI
    psi: sol.psi || "",
    solution_type: sol.solution_type || "",
    domain: sol.domain || "", // Assuming domain is part of solution in form
    pole: sol.pole || "", // Assuming pole is part of solution in form
    entity: sol.entity || "",
    list_admins: {
      technical_admins:
        sol.technical_admin?.map((name: string) => ({ email: "", name })) || [],
      functional_admins:
        sol.functional_admin?.map((name: string) => ({ email: "", name })) ||
        [],
      tams: sol.tam ? [{ email: "", name: sol.tam }] : [],
    },
    tam: sol.tam || "",
    tam_full_name: sol.tam || "",
    created_at: sol.created_at || new Date().toISOString(),
    solution_role: sol.solution_role || "",
    activated: sol.activated ?? false,
    itop_id: sol.itop_id || "",
    declarted_on_itop: sol.declarted_on_itop ?? false,
    declarted_on_bigfix: sol.declarted_on_bigfix ?? false,
    created_by: sol.created_by || "",
    updated_at: sol.updated_at || new Date().toISOString(),
    updated_by: sol.updated_by || "",
  }));

  return {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    server_id: (dataServerForm as any).server_id || 0,
    hostname: dataServerForm.hostname || "",
    ip_addresses: dataServerForm.ip_addresses || [],
    server_nature: dataServerForm.server_nature || [],
    nature_detail: dataServerForm.nature_detail || null,
    os_type: dataServerForm.os_type || null,
    uname: dataServerForm.uname || null,
    os_detail: "",
    solutions: mappedSolutions, // Use the mapped detailed solutions
    domains: dataServerForm.domains || [], // Map from form to plural array
    poles: dataServerForm.poles || [], // Map from form to plural array
    environments: dataServerForm.environments || [],
    solutions_inventory: dataServerForm.solutions_inventory || [],
    natures_inventory: dataServerForm.natures_inventory || [],
    created_by: "Admin",
    updated_by: "Manager",
    created_at: "",
    updated_at: "",
    signed: null,
  } as any;
};
