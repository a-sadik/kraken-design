/* eslint-disable @typescript-eslint/no-explicit-any */
import { Comparatif, ServerResult } from "@/types/ReliabilityTypes";

export interface ServerComparisonResponseDto {
  data: Comparatif;
  success: boolean;
  message?: string;
}

export interface ServerUpdateResponseDto {
  success: boolean;
  updatedServer?: ServerResult;
  message?: string;
}

export interface DropdownOptionsResponseDto {
  fieldName: string;
  options: string[];
  success: boolean;
  message?: string;
}

export interface ErrorResponseDto {
  success: false;
  message: string;
  error?: any;
}
