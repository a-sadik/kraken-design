// src/components/modals/InfoModal.tsx

import React, { useEffect, useState } from "react";
import {
  Typography,
  CircularProgress,
  Box,
  Card,
  CardContent,
  Divider,
  Stack,
  Button,
  Chip,
} from "@mui/material";

import { getEntityById } from "@/services/admin/EntityService";
import { getPoleById } from "@/services/admin/PoleService";
import { getDomainById } from "@/services/admin/DomainService";
import { getPersonById } from "@/services/admin/PersonService";

import MyModal from "@/components/modals/MyModal";

interface InfoModalProps {
  open: boolean;
  onClose: () => void;
  kind?: "entity" | "pole" | "domaine" | "person";
  id: number;
}

export const InfoModal: React.FC<InfoModalProps> = ({
  open,
  onClose,
  kind,
  id,
}) => {
  const [info, setInfo] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open && id) {
      setLoading(true);

      const fetchData = async () => {
        try {
          let data;
          if (kind === "entity") {
            data = await getEntityById(id);
          } else if (kind === "pole") {
            data = await getPoleById(id);
          } else if (kind === "domaine") {
            data = await getDomainById(id);
          } else if (kind === "person") {
            data = await getPersonById(id);
          }
          setInfo(data);
        } catch (err) {
          console.error("Erreur lors du chargement :", err);
          setInfo(null);
        } finally {
          setLoading(false);
        }
      };
      fetchData();
    }
  }, [open, id, kind]);

  const renderDetailItem = (label: string, value: string | undefined) => (
    <Stack direction="row" spacing={1} alignItems="center">
      <Typography variant="subtitle2" color="text.secondary" width="40%">
        {label}
      </Typography>
      <Typography variant="body1" fontWeight="500">
        {value || "—"}
      </Typography>
    </Stack>
  );

  const renderPostsBadges = (rawPosts: any) => {
    let parsedPosts: string[] = [];
    if (Array.isArray(rawPosts)) {
      parsedPosts = rawPosts;
    } else {
      try {
        parsedPosts = JSON.parse(rawPosts || "[]");
      } catch {
        parsedPosts = [];
      }
    }

    if (!parsedPosts.length) return "—";

    const colorCodes = [
      "#2196f3",
      "#4caf50",
      "#ff9800",
      "#e91e63",
      "#9c27b0",
      "#00bcd4",
    ];

    const rows = [];
    const itemsPerRow = 4;
    for (let i = 0; i < parsedPosts.length; i += itemsPerRow) {
      rows.push(parsedPosts.slice(i, i + itemsPerRow));
    }

    return (
      <Stack spacing={1}>
        {rows.map((row, rowIndex) => (
          <Stack key={rowIndex} direction="row" spacing={1}>
            {row.map((post, i) => {
              const color =
                colorCodes[(rowIndex * itemsPerRow + i) % colorCodes.length];
              return (
                <Chip
                  key={post}
                  label={post}
                  variant="outlined"
                  sx={{
                    height: 24,

                    fontSize: "0.75rem",
                    fontWeight: 500,
                    borderColor: color,
                    color: color,
                    backgroundColor: color + "11",
                    borderRadius: "8px",
                    lineHeight: 1,
                  }}
                />
              );
            })}
          </Stack>
        ))}
      </Stack>
    );
  };

  const renderDetails = () => {
    if (!info) return null;

    if (kind === "entity") {
      return (
        <>
          {renderDetailItem("Nom de l'entité", info.entity_name)}
          {renderDetailItem(
            "Responsable",
            `${info.entity_manager?.firstname || ""} ${info.entity_manager?.lastname || ""}`,
          )}
        </>
      );
    }

    if (kind === "pole") {
      return (
        <>
          {renderDetailItem("Nom du pôle", info.pole_name)}
          {renderDetailItem(
            "Responsable",
            `${info.pole_manager?.firstname || ""} ${info.pole_manager?.lastname || ""}`,
          )}
          {renderDetailItem("Entité associée", info.entity)}
        </>
      );
    }

    if (kind === "domaine") {
      return (
        <>
          {renderDetailItem("Nom du domaine", info.domain_name)}
          {renderDetailItem(
            "Responsable",
            `${info.domain_manager?.firstname || ""} ${info.domain_manager?.lastname || ""}`,
          )}
          {renderDetailItem("Pôle associé", info.pole)}
        </>
      );
    }

    if (kind === "person") {
      return (
        <>
          {renderDetailItem("Prénom", info.firstname)}
          {renderDetailItem("Nom", info.lastname)}
          {renderDetailItem("Email", info.email)}
          <Stack direction="row" spacing={1} alignItems="flex-start">
            <Typography variant="subtitle2" color="text.secondary" width="40%">
              Poste(s)
            </Typography>
            <Box width="60%">{renderPostsBadges(info.posts)}</Box>
          </Stack>
        </>
      );
    }

    return null;
  };

  return (
    <MyModal open={open} onClose={onClose} title={`Détails ${kind}`}>
      <Box sx={{ width: "600px", maxWidth: "90%", mx: "auto" }}>
        {loading ? (
          <Box textAlign="center" my={2}>
            <CircularProgress />
            <Typography variant="body2" color="textSecondary" mt={1}>
              Chargement des informations...
            </Typography>
          </Box>
        ) : (
          info && (
            <Card
              variant="outlined"
              sx={{
                borderRadius: 3,
                boxShadow: "0 2px 8px rgba(0,0,0,0.05)",
                px: 3,
                py: 2,
                mt: 1,
                backgroundColor: "#fafafa",
              }}
            >
              <CardContent>
                <Stack spacing={2}>
                  {renderDetails()}
                  <Divider />
                  {renderDetailItem(
                    "Créé le",
                    info.created_at
                      ? new Date(info.created_at).toLocaleString()
                      : "—",
                  )}
                  {renderDetailItem(
                    "Mis à jour le",
                    info.updated_at
                      ? new Date(info.updated_at).toLocaleString()
                      : "—",
                  )}
                </Stack>
              </CardContent>
            </Card>
          )
        )}

        <Box textAlign="right" mt={3}>
          <Button
            onClick={onClose}
            variant="outlined"
            sx={{
              borderColor: "#c2a700",
              color: "#c2a700",
              "&:hover": {
                borderColor: "#a88f00",
                backgroundColor: "#fffbea",
              },
            }}
          >
            FERMER
          </Button>
        </Box>
      </Box>
    </MyModal>
  );
};
