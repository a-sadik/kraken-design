import { CheckCircle, AlertCircle } from "lucide-react";

interface NotificationProps {
  message: string;
  type: "success" | "error";
  onClose: () => void;
}

function Notification({ message, type, onClose }: NotificationProps) {
  return (
    <div
      style={{
        position: "fixed",
        top: "1rem",
        right: "1rem",
        padding: "1rem",
        borderRadius: "0.375rem",
        boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.1)",
        zIndex: 1000,
        display: "flex",
        alignItems: "center",
        gap: "0.75rem",
        backgroundColor: type === "success" ? "#f0fdf4" : "#fef2f2",
        border: `1px solid ${type === "success" ? "#bbf7d0" : "#fecaca"}`,
        color: type === "success" ? "#166534" : "#dc2626",
      }}
    >
      {type === "success" ? (
        <CheckCircle size={20} />
      ) : (
        <AlertCircle size={20} />
      )}
      <span>{message}</span>
      <button
        onClick={onClose}
        style={{
          marginLeft: "0.5rem",
          background: "none",
          border: "none",
          cursor: "pointer",
          fontSize: "1.25rem",
          color: "inherit",
        }}
      >
        ×
      </button>
    </div>
  );
}

export default Notification;
