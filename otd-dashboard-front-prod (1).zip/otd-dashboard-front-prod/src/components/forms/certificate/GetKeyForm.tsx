// src/components/forms/certificates/GetKeyForm.tsx

import { zodResolver } from "@hookform/resolvers/zod";
import {
  Alert,
  Box,
  Button,
  Grid,
  Link,
  TextField,
  Typography,
} from "@mui/material";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { z as zod } from "zod";

const getFormSchema = (isDeleteMode: boolean) =>
  zod.object({
    password: isDeleteMode
      ? zod.string().optional()
      : zod.string().trim().min(1, "Le mot de passe est requis"),
  });

export type GetKeyFormData = zod.infer<ReturnType<typeof getFormSchema>>;

const FormLabel = ({
  label,
  isRequired = false,
}: {
  label: string;
  isRequired?: boolean;
}) => (
  <Typography
    variant="body1"
    sx={{
      fontWeight: "bold",
      display: "flex",
      alignItems: "center",
      mb: "0.5rem",
      fontSize: "1.2rem",
    }}
  >
    {label}
    {isRequired && <span style={{ color: "red", marginLeft: 4 }}>*</span>}
  </Typography>
);

interface GetKeyFormProps {
  getkeyFile: (data: GetKeyFormData) => void;
  recoverPassword: () => void;
  isViewMode: boolean;
  isDeleteMode: boolean;
  errorMessage: string | null;
}

export function GetKeyForm({
  getkeyFile,
  recoverPassword,
  isDeleteMode,
  errorMessage,
}: GetKeyFormProps) {
  const formSchema = getFormSchema(isDeleteMode);
  const [showPassword] = useState(false);
  const [emailSentMessage, setEmailSentMessage] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors, isValid },
  } = useForm<GetKeyFormData>({
    resolver: zodResolver(formSchema),
    mode: "all",
    defaultValues: {
      password: "",
    },
  });

  return (
    <form onSubmit={handleSubmit(getkeyFile)}>
      <Grid item xs={12}>
        <FormLabel label="Mot de passe" isRequired={!isDeleteMode} />
        <TextField
          {...register("password")}
          type={showPassword ? "text" : "password"}
          variant="outlined"
          fullWidth
          placeholder="Entrez un mot de passe"
          error={!!errors.password || !!errorMessage}
          helperText={
            errors.password?.message ||
            (errorMessage && !errors.password && errorMessage)
          }
        />
      </Grid>

      <Grid
        item
        xs={12}
        sx={{
          alignItems: "center",
          justifyContent: "center",
          display: "flex",
          marginTop: "2rem",
        }}
      >
        <Button
          type="submit"
          variant="contained"
          size="large"
          color="success"
          disabled={isDeleteMode ? false : !isValid}
        >
          Confirmer
        </Button>
      </Grid>

      <Box sx={{ mt: 0, textAlign: "center" }}>
        <Link
          component="button"
          variant="body2"
          onClick={(e) => {
            e.preventDefault();
            recoverPassword();
            setEmailSentMessage(true);
          }}
          sx={{
            textDecoration: "none",
            cursor: "pointer",
            color: "primary.main",
            "&:hover": {
              textDecoration: "underline",
            },
          }}
        >
          Mot de passe oublié ?
        </Link>

        {emailSentMessage && (
          <Alert severity="info" sx={{ mt: 2 }}>
            Le mot de passe a été envoyé par mail. Veuillez vérifier votre boîte
            de réception.
          </Alert>
        )}

        {errorMessage !== null && (
          <Grid item xs={12} sx={{ mt: 2 }}>
            <Alert variant="filled" severity="error">
              <Typography variant="body1">{errorMessage}</Typography>
            </Alert>
          </Grid>
        )}
      </Box>
    </form>
  );
}
