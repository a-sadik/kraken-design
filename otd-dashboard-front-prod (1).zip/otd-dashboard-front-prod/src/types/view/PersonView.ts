// src/types/view/PersonView.ts
export interface PersonView {
  id: number;
  fullName: string;
}
