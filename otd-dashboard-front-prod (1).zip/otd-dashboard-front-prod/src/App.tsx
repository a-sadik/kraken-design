
// src/App.tsx
import React, { lazy, Suspense } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Layout from "@/components/layouts/Layout";
import routes from "./routes";
import CustomLoading from "@/components/basics/CustomLoading";
import { DataProvider } from "@/hooks/DataContext";
import { ProtectedRoute } from "@/auth/ProtectedRoute";
import { keycloak } from "./auth/keycloakConnectAdapter";
import GlobalAnnouncements from "./utils/Announcement";
import SessionTimeout from "./SessionTimeout";

const HomePage = lazy(() => import("@/pages/primary-pages/HomePage"));

const App: React.FC = () => {
  const renderRoute = (route: any, index: number) => (
    <Route key={index} path={route.path} element={route.element} />
  );

  return (
    <Router>
      <Suspense fallback={<CustomLoading />}>
        <DataProvider>
          {/* Ligne ajoutée - Popup global des annonces */}
          <GlobalAnnouncements />

          <Routes>
            <Route
              element={
                <ProtectedRoute>
                  {/* Déconnexion après 1h d’INACTIVITÉ */}
                  <SessionTimeout idleMs={60 * 60 * 1000} />
                  <Layout />
                </ProtectedRoute>
              }
            >
              {/* Route par défaut */}
              <Route path="/" element={<HomePage />} />

              {/* Routes conditionnelles */}
              {keycloak.hasRoles("kraken_role") &&
                routes.map((route, index) => {
                  const hasAccess =
                    !route.requiredRoles ||
                    route.requiredRoles.length === 0 ||
                    route.requiredRoles.some((role: string) => keycloak.hasRoles(role));

                  // Si admin_role → accès total
                  if (keycloak.hasRoles("admin_role"))  {
                    return renderRoute(route, index);
                  }

                  return hasAccess ? renderRoute(route, index) : null;
                })}
            </Route>
          </Routes>
        </DataProvider>
      </Suspense>
    </Router>
  );
};

export default App;