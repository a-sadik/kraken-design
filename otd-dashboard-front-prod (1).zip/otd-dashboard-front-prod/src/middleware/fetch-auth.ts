// eslint-disable-next-line @typescript-eslint/no-explicit-any
const fetchWithAuth = (url: string | URL | Request, options: any = {}) => {
  const headers = {
    Authorization: "Bearer " + localStorage.getItem("access_token"),
    "Content-Type": "application/json",
  };

  return fetch(url, { ...options, headers });
};

export default fetchWithAuth;
