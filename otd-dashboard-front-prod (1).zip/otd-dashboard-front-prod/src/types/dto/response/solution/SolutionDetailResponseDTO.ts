// src/types/dto/response/solution/SolutionDetailResponseDTO.ts

import { SolutionPopularity } from "@/enums/SolutionPopularity";
import { SolutionType } from "@/enums/SolutionType";
import { DomainResponseDTO } from "../DomainResponseDTO";

export interface SolutionDetailResponseDTO {
  [x: string]: any;
  pole: string;
  entity: string;
  id: any;
  fiable: any;
  solution_id: number;
  solution_name: string;
  solution_popularity: SolutionPopularity | string;
  solution_type: SolutionType | string;
  solution_role: string;
  functional_admin: string[];
  technical_admin: string[];
  tam: string;
  psi: string;
  domain: DomainResponseDTO | any | undefined;
  created_at: string;
  updated_at: string;
  created_by: string;
  updated_by: string;
}
