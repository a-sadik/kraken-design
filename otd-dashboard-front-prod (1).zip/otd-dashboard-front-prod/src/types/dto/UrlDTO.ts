// src/types/dto/UrlDTO.ts

export interface CreateUrlDTO {
  url_name: string;
  notified_email: string;
}

export interface UrlDTO {
  url_id: number;
  url_name: string;
  url_type: "interne" | "externe";
  created_at: string;
  expiration_date: string;
  last_checked: string;
  notified_email?: string;
  notification_sent_at?: string;

  isExpiringSoon: boolean;
  isExpired: boolean;
}
