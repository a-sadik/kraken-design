import { useEffect, useState } from "react";
import {
  TextField,
  Button,
  Box,
  Grid,
  Typography,
  CircularProgress,
  Snackbar,
  Alert,
} from "@mui/material";
import { useForm } from "react-hook-form";
import { z as zod } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

import MyModal from "@/components/modals/MyModal";
// import { updateSolution } from '@/services/SolutionService';

const formSchema = zod.object({
  newName: zod.string().trim().min(1, "Le nouveau nom est requis."),
});

type FormEditSolution = zod.infer<typeof formSchema>;

interface EditSolutionModalProps {
  open: boolean;
  onClose: () => void;
  solutionId: number;
  currentName: string;
  onSuccess?: () => void; // pour rafraîchir après modification
}

export const EditSolutionModal: React.FC<EditSolutionModalProps> = ({
  open,
  onClose,
  // solutionId,
  currentName,
  // onSuccess,
}) => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isValid },
  } = useForm<FormEditSolution>({
    resolver: zodResolver(formSchema),
    mode: "all",
    defaultValues: {
      newName: "",
    },
  });

  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successSnackbar, setSuccessSnackbar] = useState(false);

  useEffect(() => {
    if (open) {
      reset();
      setErrorMessage(null);
    }
  }, [open, reset]);

  const handleSave = async (data: FormEditSolution) => {
    console.log("Nouveau nom de solution est:", data);
    setLoading(true);
    setErrorMessage(null);
    // try {
    //   await updateSolution(solutionId, { solution_name: data.newName });
    //   setSuccessSnackbar(true);
    //   onSuccess?.();
    //   onClose();
    // } catch (error) {
    //   console.error("Erreur lors de la mise à jour:", error);
    //   setErrorMessage("Échec de la modification de la solution.");
    // } finally {
    //   setLoading(false);
    // }
  };

  return (
    <>
      <MyModal open={open} onClose={onClose} title="Modifier la Solution">
        <form onSubmit={handleSubmit(handleSave)}>
          <Grid container spacing={2} sx={{ p: 2 }}>
            {/* Nom actuel affiché */}
            <Grid item xs={12} container spacing={2} alignItems="center">
              <Grid item xs={4}>
                <Typography fontWeight="bold">
                  Nom actuel de la solution
                </Typography>
              </Grid>
              <Grid item xs={8} style={{ width: 500 }}>
                <TextField
                  value={currentName}
                  fullWidth
                  InputProps={{ readOnly: true }}
                  sx={{ mt: 1 }}
                />
              </Grid>
            </Grid>

            {/* Nouveau nom modifiable */}
            <Grid item xs={12} container spacing={2} alignItems="center">
              <Grid item xs={4}>
                <Typography fontWeight="bold">Nouveau nom</Typography>
              </Grid>
              <Grid item xs={8}>
                <TextField
                  {...register("newName")}
                  error={!!errors.newName}
                  helperText={errors.newName?.message}
                  fullWidth
                  placeholder="Entrer le nouveau nom"
                  sx={{ mt: 1 }}
                />
              </Grid>
            </Grid>
            {errorMessage && (
              <Grid item xs={12}>
                <Alert severity="error" variant="filled">
                  {errorMessage}
                </Alert>
              </Grid>
            )}
          </Grid>

          <Box textAlign="right" px={2} pb={2}>
            <Button onClick={onClose} sx={{ mr: 1 }}>
              Annuler
            </Button>
            <Button
              type="submit"
              variant="contained"
              disabled={!isValid || loading}
            >
              {loading ? <CircularProgress size={20} /> : "Modifier"}
            </Button>
          </Box>
        </form>
      </MyModal>

      <Snackbar
        open={successSnackbar}
        autoHideDuration={3000}
        onClose={() => setSuccessSnackbar(false)}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <Alert
          onClose={() => setSuccessSnackbar(false)}
          severity="success"
          variant="filled"
        >
          Solution modifiée avec succès !
        </Alert>
      </Snackbar>
    </>
  );
};
