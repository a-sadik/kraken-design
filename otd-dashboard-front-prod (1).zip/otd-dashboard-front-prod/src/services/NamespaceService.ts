import {
  getNamespacesApiUrl,
  getPodsbyNamespacesApiUrl,
  postAffechtNamespacesToSolutionsApiUrl,
} from "@/config/api.config";
import type { Namespace, Pod } from "@/types/Namespace";

export const getAllNamespaces = async (): Promise<Namespace[]> => {
  const token = localStorage.getItem("access_token");
  const response = await fetch(getNamespacesApiUrl(), {
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
  });

  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }

  return response.json();
};

export const getNamespacePods = async (namespaceId: number): Promise<Pod[]> => {
  const token = localStorage.getItem("access_token");
  const response = await fetch(getPodsbyNamespacesApiUrl(namespaceId), {
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
  });

  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }

  return response.json();
};

export const affectNamespace = async (
  namespaceId: number,
  solutionName: string,
): Promise<void> => {
  const token = localStorage.getItem("access_token");
  const response = await fetch(
    postAffechtNamespacesToSolutionsApiUrl(namespaceId),
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ solution_name: solutionName }),
    },
  );

  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
};
