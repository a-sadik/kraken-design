// src/services/AuthService.ts

import { AxiosError } from "axios";

// import files
import { ErrorResponse } from "@/exceptions/ErrorResponse";
import apiClientHttp from "./apiClientHttp";

const path = "/auth";

// Function after a good login
export const login = async (): Promise<void> => {
  try {
    await apiClientHttp.dataApiClient.post(`${path}/login`);
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error("Error to login:", err.response?.data.message);
  }
};

// Function to logout at side server
export const logout = async (): Promise<void> => {
  try {
    await apiClientHttp.dataApiClient.post(`${path}/logout`);
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error("Error to logout:", err.response?.data.message);
  }
};
