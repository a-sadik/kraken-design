import React, { useEffect, useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  MenuItem,
} from "@mui/material";
// import { updateUrl } from '@/services/UrlService';
import { UrlDTO } from "@/types/dto/UrlDTO";

interface ModifierUrlModalProps {
  open: boolean;
  onClose: () => void;
  urlData: UrlDTO | null;
  onSuccess: () => void;
}

const ModifierUrlModal: React.FC<ModifierUrlModalProps> = ({
  open,
  onClose,
  urlData,
}) => {
  const [urlName, setUrlName] = useState("");
  const [expirationDate, setExpirationDate] = useState("");
  const [urlType, setUrlType] = useState<"interne" | "externe">("interne");

  useEffect(() => {
    if (urlData) {
      setUrlName(urlData.url_name);
      setExpirationDate(urlData.expiration_date?.substring(0, 10) || "");
      setUrlType(urlData.url_type);
    }
  }, [urlData]);

  // const handleUpdate = async () => {
  //   if (!urlData) return;
  //   const updatedData = {
  //     url_name: urlName,
  //     expiration_date: expirationDate,
  //     url_type: urlType,
  //   };
  //   try {
  //     await updateUrl(urlData.url_id, updatedData);
  //     onSuccess();
  //   } catch (err) {
  //     console.error('Erreur lors de la mise à jour', err);
  //   }
  // };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>Modifier l'URL</DialogTitle>
      <DialogContent
        sx={{ display: "flex", flexDirection: "column", gap: 2, mt: 1 }}
      >
        <TextField
          label="Nom de l'URL"
          value={urlName}
          onChange={(e) => setUrlName(e.target.value)}
          fullWidth
        />
        <TextField
          label="Date d'expiration"
          type="date"
          value={expirationDate}
          onChange={(e) => setExpirationDate(e.target.value)}
          InputLabelProps={{ shrink: true }}
          fullWidth
        />
        <TextField
          label="Type"
          select
          value={urlType}
          onChange={(e) => setUrlType(e.target.value as "interne" | "externe")}
          fullWidth
        >
          <MenuItem value="interne">Interne</MenuItem>
          <MenuItem value="externe">Externe</MenuItem>
        </TextField>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Annuler</Button>
        {/* <Button onClick={handleUpdate} variant="contained">Mettre à jour</Button> */}
      </DialogActions>
    </Dialog>
  );
};

export default ModifierUrlModal;
