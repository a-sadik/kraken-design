import React, { FC, Dispatch, SetStateAction } from "react";
import { TextField, InputAdornment } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";

interface CustomSearchFieldProps {
  search: string;
  setSearch: Dispatch<SetStateAction<string>>;
}

const CustomSearchField: FC<CustomSearchFieldProps> = ({
  search,
  setSearch,
}) => {
  const [focused, setFocused] = React.useState(false);

  return (
    <TextField
      id="outlined-input"
      label="Search"
      variant="outlined"
      value={search}
      onChange={(e) => setSearch(e.target.value)}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      sx={{
        ml: "auto",
        width: "20rem",
        transition: "width 0.3s ease",
        "& .MuiOutlinedInput-root": {
          padding: "4px",
          height: "4rem",
          "& fieldset": { borderColor: "#ADB5BD" },
          "& input": { fontSize: "1.125rem", padding: "10px 12px" },
        },
        "& .MuiInputLabel-outlined": { color: "#000000" },
        "& .MuiInputLabel-outlined.Mui-focused": { color: "#000000" },
      }}
      InputProps={{
        endAdornment:
          !focused && search === "" ? (
            <InputAdornment position="end">
              <SearchIcon />
            </InputAdornment>
          ) : null,
      }}
    />
  );
};

export default CustomSearchField;
