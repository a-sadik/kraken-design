// src/types/view/ServerView.ts

import { Environnement } from "@/enums/Environnement";
import { SolutionDetailResponseDTO } from "../dto/response/solution/SolutionDetailResponseDTO";
import { SolutionDetailFromAPI } from "../dto/response/ServerResponseDTO";

export default interface ServerView {
  solutions_inventory: number[] | string[] | null;
  id: number;
  Hostname: string;
  "Adresses IP": string[];
  "Type OS": string | null;
  "Détail OS": string | null;
  "Solutions dans Bigfix":
    | string[]
    | number[]
    | SolutionDetailResponseDTO[]
    | SolutionDetailFromAPI[]
    | null;
  // Solutions: string[] | number[] | SolutionDetailResponseDTO[] | SolutionDetailFromAPI[] | null
  "Solutions dans l'inventaire": string[] | null; // Propriété ajoutée
  Environnements: Environnement[] | string[] | null;
  Domaine: string[] | null; // Changé de string | null vers string[] | null
  Pôle: string[] | null; // Changé de string | null vers string[] | null
  "Nature du serveur dans BigFix": string[];
  "Détail de la nature dans BigFix": string | null;
  "Nature du serveur dans L'inventaire": string | string[] | null;
  Uname: string | null;
  Signature: string | null;
  created_by: string | null;
  updated_by: string | null;
  created_at: string | null;
  updated_at: string | null;
  to_decom: boolean;
}
