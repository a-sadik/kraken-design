// Interfaces principales
export interface EntitiesList {
  entity_id: number;
  entity_manager: string;
  count_poles: number;
  count_domains: number;
  count_solutions: number;
  count_namespaces: number;
  count_deployments: number;
  count_pods: number;
  count_technical_admins: number;
  count_functional_admins: number;
  count_tams: number;
  count_servers: number;
  list_solutions_types: string[] | null;
  list_environnements: string[];
  child: string;
  entity_name: string;
}

export interface PolesList {
  pole_id: number;
  pole_manager: string;
  count_domains: number;
  count_solutions: number;
  hostIP: string;
  count_namespaces: number;
  count_deployments: number;
  count_pods: number;
  count_technical_admins: number;
  count_functional_admins: number;
  count_tams: number;
  count_servers: number;
  list_solutions_types: string[] | null;
  list_environnements: string[];
  child: string;
  pole_name: string;
}

export interface DomainsList {
  domain_id: number;
  domain_manager: string;
  count_solutions: number;
  count_namespaces: number;
  hostIP: string;
  count_deployments: number;
  count_pods: number;
  count_technical_admins: number;
  count_functional_admins: number;
  count_tams: number;
  count_servers: number;
  list_solutions_types: string[] | null;
  list_environnements: string[];
  child: string;
  domain_name: string;
}

export interface SolutionList {
  declarted_on_itop: any;
  declarted_on_bigfix: any;
  itop_id: any;
  domain: any;
  tenant: any;
  service_type: any;
  id: any;
  list_admins: any;
  updated_at: any;
  solution_id: number;
  person: string;
  count_namespaces: number;
  hostIP: string;
  count_deployments: number;
  count_pods: number;
  count_technical_admins: number;
  count_functional_admins: number;
  count_tams: number;
  count_servers: number;
  count_request?: number;
  count_cab?: number;
  count_ecab?: number;
  list_solutions_types: string[];
  list_environnements: string[];
  child_namespace: string;
  child_servers: Childserver[];
  child_pods: any;
  solution_name: string;
  solution_role: string;
  psi: string;
  solution_popularity: string;
  solution_type: string;
  tams?: string[];
  functional_admins?: string[];
}

export interface NamespacesList {
  id: number;
  count_deployments: number;
  hostIP: string;
  count_pods: number;
  child: string;
  name: string;
  environment: string;
  solution_id: number;
}

export interface DeploymentsList {
  id: number;
  name: string;
  count_pods: number;
  child: string;
  namespace_id: number;
  namespace_name?: string;
}

export interface Childserver {
  Intégration?: string;
  Recette?: string;
  Préproduction?: string;
  Production?: string;
  Développement?: string;
  Formation?: string;
}

export interface ServerList {
  server_id: number;
  hostname: string;
  ip_addresses: string[];
  hostIP: string;
  os_type: string;
  os_detail: null;
  server_nature: string;
  nature_detail: string;
  environments: string;
  signed: string;
}

export interface PodsList {
  id: number;
  pod_uid: string;
  pod_name: string;
  nodeName: string;
  phase: string;
  hostIP: string;
  podIP: string;
  limitCPU: string;
  requestCPU: string;
  limitRAM: string;
  requestRAM: string;
  containerStatuses: ContainerStatus[];
  namespace: string;
  namespace_name?: string;
  deployment_name?: string;
}

export interface ContainerStatus {
  name: string;
  image: string;
  ready: boolean;
  restartCount: number;
}

export interface BreadcrumbItem {
  id?: string;
  name: string;
  level: string;
  data: any;
  elementId: string;
}

// Mock interfaces
export interface BackupStatus {
  id: number;
  name: string;
  status: "success" | "failed" | "pending" | "warning";
  lastBackup: string;
  nextBackup: string;
  size: string;
  retention: string;
  type: string;
}

export interface ChangeRequest {
  id: string;
  title: string;
  status: "approved" | "pending" | "rejected" | "completed";
  requestedBy: string;
  requestedDate: string;
  implementationDate: string;
  priority: "high" | "medium" | "low";
  impact: "high" | "medium" | "low";
  type: string;
}

export interface BatchJob {
  id: number;
  name: string;
  status: "running" | "completed" | "failed" | "scheduled";
  startTime: string;
  endTime: string | null;
  duration: string;
  progress: number;
  server: string;
}

export interface CftFlow {
  id: number;
  name: string;
  status: "active" | "inactive" | "error";
  lastExecution: string;
  frequency: string;
  source: string;
  destination: string;
  transferredFiles: number;
  averageSize: string;
}
