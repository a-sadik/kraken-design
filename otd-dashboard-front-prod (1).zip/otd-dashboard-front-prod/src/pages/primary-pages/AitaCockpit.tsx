import React, { useState, useEffect } from "react";
import {
  Box,
  Card,
  CardContent,
  Typography,
  Grid,
  Chip,
  IconButton,
  Tooltip,
  Alert,
  CircularProgress,
  LinearProgress,
  Button,
  Avatar,
  Fade,
} from "@mui/material";

import {
  Refresh,
  Router as ServerIcon,
  Group,
  Storage,
  DeveloperBoard,
  Security,
  Warning,
  CheckCircle,
  Error,
  Monitor,
  Business,
  Layers,
  Public,
  Email,
  PieChart,
} from "@mui/icons-material";
import fetchWithAuth from "@/middleware/fetch-auth";
import { getAitaStatsentiteUrl, Server_StatsRefresh } from "@/config/api.config";

// Types TypeScript
interface Admin {
  name: string;
  email: string;
}
interface DecomMap {
  pending: number;
  validated: number;
}

interface AdminsData {
  tams: Admin[];
  technical_admins: Admin[];
  functional_admins: Admin[];
  dsa_architects: Admin[];
  prod_architects: Admin[];
}

interface ArchitectureDistribution {
  x86: number;
  other: number;
  power: number;
}

interface OSRatio {
  linux: number;
  windows: number;
}

interface DuplicateIPs {
  [environment: string]: {
    [ip: string]: any;
  };
}

interface DuplicateHostnames {
  [hostname: string]: number;
}

interface ServerNatureItem {
  [nature: string]: {
    icon: string;
    prod: number;
    total: number;
    hors_prod: number;
  };
}

interface DashboardData {
  id: number;
  calculated_at: string;
  inventory_count: number;
  namespaces_count: number;
  solutions_count: number;
  signed_servers_count: number;
  expired_servers_count: number;
  unsigned_servers_count: number;
  fiable_servers_count: number;
  fibale_namespaces_count: number;
  fibale_solutions_count: number;
  activated_solutions_count: number;
  list_admins: AdminsData;
  architecture_distribution: ArchitectureDistribution;
  os_ratio: OSRatio;
  duplicate_ips: DuplicateIPs;
  duplicate_hostnames: DuplicateHostnames;
  server_count_by_nature: ServerNatureItem[];
  decom_map: DecomMap;
}

// Thème amélioré avec plus de contraste et transitions
const modernTheme = {
  primary: "#2563EB",
  secondary: "#7C3AED",
  accent: "#059669",
  surface: "#FFCE14",
  background: "#F1F5F9",
  surfaceVariant: "#e04434",
  outline: "#CBD5E1",
  shadow: "rgba(15, 23, 42, 0.12)",
  cardBackground: "#FFFFFF",
  textPrimary: "#1E293B",
  textSecondary: "#475569",
  gradients: {
    primary: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
    secondary: "linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",
    info: "linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)",
    success: "linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)",
    warning: "linear-gradient(135deg, #ff9a9e 0%, #fad0c4 100%)",
    error: "linear-gradient(135deg, #ff758c 0%, #ff7eb3 100%)",
  },
};

// Couleurs pour les différents types d'administration
const adminColors = {
  tams: "#8B5CF6",
  technical_admins: "#3B82F6",
  functional_admins: "#10B981",
  prod_architects: "#fad0c4",
  dsa_architects: "#38f9d7",

};

// Couleurs pour l'architecture
const archColors = {
  x86: "#3B82F6",
  power: "#EF4444",
  other: "#6B7280",
};

// Mapping des icônes MUI par nature de serveur
const serverNatureIcons: { [key: string]: React.ComponentType<{ sx?: any }> } = {
  web: ServerIcon,
  database: Storage,
  application: Business,
  infrastructure: Layers,
  proxy: Public,
  mail: Email,
  load_balancer: PieChart,
  firewall: Security,
  monitoring: Monitor,
  backup: Storage,
  virtual: DeveloperBoard,
  physical: ServerIcon,
  container: Layers,
  cloud: Public,
  dev: Monitor,
  test: Warning,
  staging: Business,
  prod: CheckCircle,
  default: ServerIcon,
};

// Fonction pour générer une couleur basée sur le nom
const getNatureColor = (nature: string) => {
  let hash = 0;
  for (let i = 0; i < nature.length; i++) {
    hash = nature.charCodeAt(i) + ((hash << 5) - hash);
  }
  const hue = Math.abs(hash) % 360;
  return `hsl(${hue}, 70%, 50%)`;
};

// Composant de graphique circulaire personnalisé
const CircularProgressChart: React.FC<{
  percentage: number;
  label: string;
  color: string;
  total?: number;
  successCount?: number;
}> = ({ percentage, label, color, total, successCount }) => {
  return (
    <Box sx={{ position: 'relative', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
      <svg width="160" height="160" viewBox="0 0 160 160">
        {/* Cercle de fond */}
        <circle
          cx="80"
          cy="80"
          r="70"
          stroke={modernTheme.outline}
          strokeWidth="8"
          fill="none"
        />
        {/* Cercle de progression */}
        <circle
          cx="80"
          cy="80"
          r="70"
          stroke={color}
          strokeWidth="8"
          fill="none"
          strokeDasharray="439.8"
          strokeDashoffset={439.8 - (percentage / 100) * 439.8}
          strokeLinecap="round"
          transform="rotate(-90deg)"
          style={{ transition: 'stroke-dashoffset 1.5s ease' }}
        />
      </svg>
      <Box sx={{
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        textAlign: 'center'
      }}>
        <Typography variant="h4" sx={{ fontWeight: 'bold', color, mb: 0.5 }}>
          {percentage}%
        </Typography>
        <Typography variant="body2" sx={{ color: modernTheme.textSecondary, fontSize: '0.75rem' }}>
          {label}
        </Typography>
        {total !== undefined && successCount !== undefined && (
          <Typography variant="caption" sx={{ display: 'block', color: modernTheme.textSecondary, fontSize: '0.7rem' }}>
            {successCount}/{total}
          </Typography>
        )}
      </Box>
    </Box>
  );
};

// Composant de carte de performance avec graphique circulaire
const PerformanceCard: React.FC<{
  title: string;
  percentage: number;
  value: number;
  total: number;
  icon: React.ComponentType<{ sx?: any }>;
  color: string;
  isGood?: boolean;
}> = ({ title, percentage, value, total, icon: Icon, color, isGood = true }) => (
  <Fade in timeout={600}>
    <Card sx={{
      height: '100%',
      background: modernTheme.cardBackground,
      border: `2px solid ${isGood ? `${color}20` : `${modernTheme.gradients.warning}20`}`,
      borderRadius: 3,
      boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)',
      transition: 'all 0.3s ease',
      '&:hover': {
        transform: 'translateY(-6px)',
        boxShadow: '0 20px 40px rgba(0, 0, 0, 0.15)',
      },
      position: 'relative',
      overflow: 'hidden',
      '&::before': {
        content: '""',
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        height: '4px',
        background: isGood ? color : modernTheme.gradients.warning,
      }
    }}>
      <CardContent sx={{ p: 3, pt: 4 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 3 }}>
          <Box sx={{ flex: 1 }}>
            <Typography variant="h6" sx={{ color: modernTheme.textSecondary, fontWeight: 600, fontSize: '0.9rem', mb: 1 }}>
              {title}
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
              <Icon sx={{ fontSize: 20, color }} />
              <Typography variant="h5" sx={{ fontWeight: 'bold', color: modernTheme.textPrimary }}>
                {value}/{total}
              </Typography>
            </Box>
          </Box>
          <CircularProgressChart
            percentage={percentage}
            label={title.toLowerCase()}
            color={color}
            total={total}
            successCount={value}
          />
        </Box>
        <Box sx={{ textAlign: 'center' }}>
          <Typography variant="body2" sx={{ color: modernTheme.textSecondary }}>
            {/* Taux de réussite: <strong>{percentage}%</strong> */}
            <strong>{percentage}%</strong>
          </Typography>
        </Box>
      </CardContent>
    </Card>
  </Fade>
);

// Composant pour les statistiques de décommissionnement
const DecommissionStats: React.FC<{ decom_map: DecomMap }> = ({ decom_map }) => {
  const totalDecom = decom_map.pending + decom_map.validated;
  const validatedPercentage = totalDecom > 0
    ? Math.round((decom_map.validated / totalDecom) * 100)
    : 0;

  return (
    <Fade in timeout={600}>
      <Card sx={{
        height: '100%',
        background: modernTheme.cardBackground,
        border: `2px solid ${modernTheme.secondary}20`,
        borderRadius: 3,
        boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)',
        transition: 'all 0.3s ease',
        '&:hover': {
          transform: 'translateY(-6px)',
          boxShadow: '0 20px 40px rgba(0, 0, 0, 0.15)',
        },
        position: 'relative',
        overflow: 'hidden',
        '&::before': {
          content: '""',
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          height: '4px',
          background: modernTheme.secondary,
        }
      }}>
        <CardContent sx={{ p: 3, pt: 4 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 3 }}>
            <Box sx={{ flex: 1 }}>
              <Typography variant="h6" sx={{ color: modernTheme.textSecondary, fontWeight: 600, fontSize: '0.9rem', mb: 1 }}>
                Décommissionnement
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                <Storage sx={{ fontSize: 20, color: modernTheme.secondary }} />
                <Typography variant="h5" sx={{ fontWeight: 'bold', color: modernTheme.textPrimary }}>
                  {decom_map.validated}/{totalDecom}
                </Typography>
              </Box>
            </Box>
            <CircularProgressChart
              percentage={validatedPercentage}
              label="validés"
              color={modernTheme.secondary}
              total={totalDecom}
              successCount={decom_map.validated}
            />
          </Box>
          <Box sx={{ display: 'flex', justifyContent: 'space-around', mt: 2 }}>
            <Box sx={{ textAlign: 'center' }}>
              <Chip
                label="Validés"
                color="success"
                variant="outlined"
                size="small"
              />
              <Typography variant="h6" sx={{ fontWeight: 'bold', color: modernTheme.accent, mt: 1 }}>
                {decom_map.validated}
              </Typography>
            </Box>
            <Box sx={{ textAlign: 'center' }}>
              <Chip
                label="En attente"
                color="warning"
                variant="outlined"
                size="small"
              />
              <Typography variant="h6" sx={{ fontWeight: 'bold', color: modernTheme.gradients.warning, mt: 1 }}>
                {decom_map.pending}
              </Typography>
            </Box>
          </Box>
        </CardContent>
      </Card>
    </Fade>
  );
};

// Composant StatsOverview avec TOUS les ratios
const StatsOverview: React.FC<{ dashboardData: DashboardData }> = ({ dashboardData }) => {
  // Calculs des pourcentages avec gestion des divisions par zéro
  const reliabilityPercentage = dashboardData.inventory_count > 0
    ? Math.round((dashboardData.fiable_servers_count / dashboardData.inventory_count) * 100)
    : 0;

  const signaturePercentage = dashboardData.inventory_count > 0
    ? Math.round((dashboardData.signed_servers_count / dashboardData.inventory_count) * 100)
    : 0;

  const activationPercentage = dashboardData.solutions_count > 0
    ? Math.round((dashboardData.activated_solutions_count / dashboardData.solutions_count) * 100)
    : 0;

  const unsignedPercentage = dashboardData.inventory_count > 0
    ? Math.round((dashboardData.unsigned_servers_count / dashboardData.inventory_count) * 100)
    : 0;

  // NOUVEAUX : Pourcentages pour namespaces et solutions fiables
  const namespacesReliabilityPercentage = dashboardData.namespaces_count > 0
    ? Math.round((dashboardData.fibale_namespaces_count / dashboardData.namespaces_count) * 100)
    : 0;

  const solutionsReliabilityPercentage = dashboardData.solutions_count > 0
    ? Math.round((dashboardData.fibale_solutions_count / dashboardData.solutions_count) * 100)
    : 0;

  return (
    <Grid container spacing={3} sx={{ mb: 5 }}>
      {/* Fiabilité des serveurs */}
      <Grid item xs={12} sm={6} md={3}>
        <PerformanceCard
          title="Serveurs Fiables"
          percentage={reliabilityPercentage}
          value={dashboardData.fiable_servers_count}
          total={dashboardData.inventory_count}
          icon={CheckCircle}
          color={modernTheme.accent}
          isGood={reliabilityPercentage > 80}
        />
      </Grid>

      {/* Signature des serveurs */}
      <Grid item xs={12} sm={6} md={3}>
        <PerformanceCard
          title="Serveurs Signés"
          percentage={signaturePercentage}
          value={dashboardData.signed_servers_count}
          total={dashboardData.inventory_count}
          icon={Security}
          color={signaturePercentage > 50 ? modernTheme.accent : modernTheme.gradients.warning}
          isGood={signaturePercentage > 50}
        />
      </Grid>

      {/* Activation solutions */}
      <Grid item xs={12} sm={6} md={3}>
        <PerformanceCard
          title="Solutions Activées"
          percentage={activationPercentage}
          value={dashboardData.activated_solutions_count}
          total={dashboardData.solutions_count}
          icon={PieChart}
          color={modernTheme.secondary}
          isGood={activationPercentage === 100}
        />
      </Grid>

      {/* Carte de décommissionnement */}
      <Grid item xs={12} sm={6} md={3}>
        <DecommissionStats decom_map={dashboardData.decom_map} />
      </Grid>

      {/* Serveurs non signés */}
      <Grid item xs={12} sm={6} md={3}>
        <PerformanceCard
          title="Serveurs Non Signés"
          percentage={unsignedPercentage}
          value={dashboardData.unsigned_servers_count}
          total={dashboardData.inventory_count}
          icon={Error}
          color={modernTheme.gradients.error}
          isGood={unsignedPercentage < 20}
        />
      </Grid>

      {/* Fiabilité des namespaces */}
      <Grid item xs={12} sm={6} md={3}>
        <PerformanceCard
          title="Namespaces Fiables"
          percentage={namespacesReliabilityPercentage}
          value={dashboardData.fibale_namespaces_count}
          total={dashboardData.namespaces_count}
          icon={Layers}
          color={namespacesReliabilityPercentage > 80 ? modernTheme.accent : modernTheme.gradients.warning}
          isGood={namespacesReliabilityPercentage > 80}
        />
      </Grid>

      {/*  Fiabilité des solutions */}
      <Grid item xs={12} sm={6} md={3}>
        <PerformanceCard
          title="Solutions Fiables"
          percentage={solutionsReliabilityPercentage}
          value={dashboardData.fibale_solutions_count}
          total={dashboardData.solutions_count}
          icon={CheckCircle}
          color={solutionsReliabilityPercentage > 80 ? modernTheme.accent : modernTheme.gradients.warning}
          isGood={solutionsReliabilityPercentage > 80}
        />
      </Grid>

      {/* Métriques absolues restantes */}
      <Grid item xs={12} sm={6} md={3}>
        <StatCard
          title="Total serveurs"
          value={dashboardData.inventory_count}
          icon={ServerIcon}
          color={modernTheme.primary}
        // subtitle="Total serveurs"
        />
      </Grid>

      <Grid item xs={12} sm={6} md={3}>
        <StatCard
          title="Serveurs Expirés"
          value={dashboardData.expired_servers_count}
          icon={Warning}
          color={modernTheme.gradients.warning}
          subtitle="À renouveler"
        />
      </Grid>
    </Grid>
  );
};



// Composant StatCard classique
const StatCard: React.FC<{
  title: string;
  value: number;
  icon: React.ComponentType<{ sx?: any }>;
  color: string;
  subtitle?: string;
}> = ({ title, value, icon: Icon, color, subtitle }) => (
  <Fade in timeout={800}>
    <Card sx={{
      height: '100%',
      background: modernTheme.cardBackground,
      border: `1px solid ${modernTheme.outline}`,
      borderRadius: 3,
      boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
      transition: 'all 0.3s ease',
      '&:hover': {
        boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.15)',
        transform: 'translateY(-4px)',
      }
    }}>
      <CardContent sx={{ p: 3 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
          <Box>
            <Typography variant="h3" sx={{ fontWeight: 'bold', color: modernTheme.textPrimary, mb: 1 }}>
              {value}
            </Typography>
            <Typography variant="h6" sx={{ color: modernTheme.textSecondary, fontWeight: 600, fontSize: '0.9rem' }}>
              {title}
            </Typography>
            {subtitle && (
              <Typography variant="body2" sx={{ color: modernTheme.textSecondary, mt: 0.5 }}>
                {subtitle}
              </Typography>
            )}
          </Box>
          <Box sx={{
            p: 1.5,
            borderRadius: 2,
            background: `${color}20`,
            color: color,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}>
            <Icon sx={{ fontSize: 24 }} />
          </Box>
        </Box>
      </CardContent>
    </Card>
  </Fade>
);

// Fonction utilitaire pour supprimer les doublons dans une liste d'admins
const removeDuplicateAdmins = (admins: Admin[]): Admin[] => {
  const seen = new Map<string, Admin>();
  admins.forEach(admin => {
    // Clé unique basée sur l'email et le nom (en ignorant la casse)
    const key = `${admin.email?.toLowerCase() || ''}-${admin.name?.toLowerCase() || ''}`;
    if (!seen.has(key)) {
      seen.set(key, admin);
    }
  });
  return Array.from(seen.values());
};

// Composant pour les administrateurs
const AdminsSection: React.FC<{ admins: AdminsData }> = ({ admins }) => {
  // Appliquer la suppression des doublons pour chaque type d'admin
  const filteredAdmins: AdminsData = {
    tams: removeDuplicateAdmins(admins.tams),
    technical_admins: removeDuplicateAdmins(admins.technical_admins),
    functional_admins: removeDuplicateAdmins(admins.functional_admins),
    dsa_architects: removeDuplicateAdmins(admins.dsa_architects),
    prod_architects: removeDuplicateAdmins(admins.prod_architects),
  };

  return (
    <Fade in timeout={800}>
      <Card sx={{
        background: modernTheme.cardBackground,
        border: `1px solid ${modernTheme.outline}`,
        borderRadius: 3,
        mb: 4,
        boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
      }}>
        <CardContent sx={{ p: 3 }}>
          <Typography variant="h5" sx={{ fontWeight: 700, mb: 3, color: modernTheme.textPrimary, display: 'flex', alignItems: 'center', gap: 1 }}>
            <Group sx={{ fontSize: 20 }} />
            Équipe d'Administration
          </Typography>

          <Grid container spacing={3}>
            {Object.entries(filteredAdmins).map(([type, adminList]) => (
              <Grid item xs={12} md={4} key={type}>
                <Box sx={{
                  p: 2,
                  borderRadius: 2,
                  background: `${adminColors[type as keyof typeof adminColors]}10`,
                  border: `1px solid ${adminColors[type as keyof typeof adminColors]}30`,
                  height: '100%',
                  transition: 'all 0.3s ease',
                  '&:hover': {
                    boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
                  },
                }}>
                  <Typography variant="subtitle1" sx={{
                    fontWeight: 700,
                    mb: 2,
                    color: adminColors[type as keyof typeof adminColors],
                    textTransform: 'capitalize',
                    fontSize: '0.9rem'
                  }}>
                    {type.replace('_', ' ')} ({adminList.length})
                  </Typography>

                  <Box sx={{ maxHeight: 200, overflow: 'auto' }}>
                    {adminList.length === 0 ? (
                      <Typography variant="body2" sx={{ color: modernTheme.textSecondary, textAlign: 'center' }}>
                        Aucun administrateur
                      </Typography>
                    ) : (
                      adminList.map((admin: { name: string; email: any; }, index: React.Key | null | undefined) => (
                        <Box key={index} sx={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: 1,
                          mb: 1.5,
                          p: 1,
                          borderRadius: 1,
                          background: modernTheme.background,
                          transition: 'background 0.2s',
                          '&:hover': {
                            background: `${adminColors[type as keyof typeof adminColors]}05`,
                          },
                          '&:last-child': { mb: 0 }
                        }}>
                          <Avatar sx={{
                            width: 32,
                            height: 32,
                            bgcolor: adminColors[type as keyof typeof adminColors],
                            fontSize: '0.75rem'
                          }}>
                            {admin.name?.split(' ').map((n) => n[0]).join('').toUpperCase() || '??'}
                          </Avatar>
                          <Box sx={{ flex: 1, minWidth: 0 }}>
                            <Typography variant="body2" sx={{
                              fontWeight: 600,
                              color: modernTheme.textPrimary,
                              whiteSpace: 'nowrap',
                              overflow: 'hidden',
                              textOverflow: 'ellipsis'
                            }}>
                              {admin.name || 'Non défini'}
                            </Typography>
                            <Typography variant="caption" sx={{
                              color: modernTheme.textSecondary,
                              whiteSpace: 'nowrap',
                              overflow: 'hidden',
                              textOverflow: 'ellipsis',
                              display: 'block'
                            }}>
                              {admin.email || 'Email non défini'}
                            </Typography>
                          </Box>
                        </Box>
                      ))
                    )}
                  </Box>
                </Box>
              </Grid>
            ))}
          </Grid>
        </CardContent>
      </Card>
    </Fade>
  );
};

const ArchitectureAndOSSection: React.FC<{
  architecture: ArchitectureDistribution;
  os_ratio: OSRatio;
}> = ({ architecture, os_ratio }) => {
  const totalOS = os_ratio.linux + os_ratio.windows;
  // Mapping des icônes pour les architectures
  const architectureIcons: { [key: string]: React.ComponentType<{ sx?: any }> } = {
    x86: DeveloperBoard,
    power: Storage,
    other: Layers,
  };

  // Mapping des icônes pour les systèmes d'exploitation
  const osIcons: { [key: string]: React.ComponentType<{ sx?: any }> } = {
    linux: Monitor,
    windows: Business,
  };

  return (
    <Fade in timeout={1000}>
      <Card sx={{
        background: modernTheme.cardBackground,
        border: `1px solid ${modernTheme.outline}`,
        borderRadius: 3,
        mb: 4,
        boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
      }}>
        <CardContent sx={{ p: 3 }}>
          <Typography variant="h5" sx={{ fontWeight: 700, mb: 4, color: modernTheme.textPrimary, display: 'flex', alignItems: 'center', gap: 1 }}>
            <DeveloperBoard sx={{ fontSize: 20, mr: 1 }} />
            Distribution des Architectures et Systèmes d'Exploitation
          </Typography>

          <Grid container spacing={4}>
            {/* Section Architectures */}
            <Grid item xs={12} md={6}>
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 3, color: modernTheme.textPrimary }}>
                Architectures
              </Typography>
              <Grid container spacing={2}>
                {Object.entries(architecture).map(([type, count]) => {
                  const IconComponent = architectureIcons[type.toLowerCase()] || DeveloperBoard;
                  return (
                    <Grid item xs={12} key={type}>
                      <Box sx={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: 2,
                        p: 2,
                        borderRadius: 2,
                        border: `1px solid ${modernTheme.outline}`,
                        background: modernTheme.background,
                        transition: 'all 0.3s ease',
                        '&:hover': {
                          transform: 'translateY(-4px)',
                          boxShadow: `0 6px 12px ${modernTheme.shadow}`,
                          borderColor: archColors[type as keyof typeof archColors],
                        }
                      }}>
                        <Box sx={{
                          width: 40,
                          height: 40,
                          borderRadius: 1,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          background: `${archColors[type as keyof typeof archColors]}20`,
                          color: archColors[type as keyof typeof archColors],
                        }}>
                          <IconComponent sx={{ fontSize: 24 }} />
                        </Box>
                        <Box sx={{ flex: 1 }}>
                          <Box display="flex" justifyContent="space-between" alignItems="center">
                            <Typography variant="subtitle1" sx={{ fontWeight: 600, color: modernTheme.textPrimary }}>
                              {type.toUpperCase()}
                            </Typography>
                            <Typography variant="h6" sx={{ fontWeight: 700, color: archColors[type as keyof typeof archColors] }}>
                              {count}
                            </Typography>
                          </Box>
                        </Box>
                      </Box>
                    </Grid>
                  );
                })}
              </Grid>
            </Grid>

            {/* Section Systèmes d'Exploitation */}
            <Grid item xs={12} md={6}>
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 3, color: modernTheme.textPrimary }}>
                Systèmes d'Exploitation
              </Typography>
              <Grid container spacing={2}>
                {Object.entries(os_ratio).map(([type, count]) => {
                  const percentage = totalOS > 0 ? Math.round((count / totalOS) * 100) : 0;
                  const color = type === 'linux' ? '#10B981' : '#3B82F6';
                  const IconComponent = osIcons[type.toLowerCase()] || Monitor;
                  return (
                    <Grid item xs={12} key={type}>
                      <Box sx={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: 2,
                        p: 2,
                        borderRadius: 2,
                        border: `1px solid ${modernTheme.outline}`,
                        background: modernTheme.background,
                        transition: 'all 0.3s ease',
                        '&:hover': {
                          transform: 'translateY(-4px)',
                          boxShadow: `0 6px 12px ${modernTheme.shadow}`,
                          borderColor: color,
                        }
                      }}>
                        <Box sx={{
                          width: 40,
                          height: 40,
                          borderRadius: 1,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          background: `${color}20`,
                          color: color,
                        }}>
                          <IconComponent sx={{ fontSize: 24 }} />
                        </Box>
                        <Box sx={{ flex: 1 }}>
                          <Box display="flex" justifyContent="space-between" alignItems="center">
                            <Typography variant="subtitle1" sx={{ fontWeight: 600, color: modernTheme.textPrimary }}>
                              {type.charAt(0).toUpperCase() + type.slice(1)}
                            </Typography>
                            <Typography variant="h6" sx={{ fontWeight: 700, color: color }}>
                              {count} ({percentage}%)
                            </Typography>
                          </Box>
                          <LinearProgress
                            variant="determinate"
                            value={percentage}
                            sx={{
                              height: 8,
                              borderRadius: 2,
                              mt: 1,
                              backgroundColor: modernTheme.outline,
                              '& .MuiLinearProgress-bar': {
                                backgroundColor: color,
                              },
                            }}
                          />
                        </Box>
                      </Box>
                    </Grid>
                  );
                })}
              </Grid>
            </Grid>
          </Grid>
        </CardContent>
      </Card>
    </Fade>
  );
};

// Composant pour les doublons
const DuplicatesSection: React.FC<{
  duplicate_ips: DuplicateIPs;
  duplicate_hostnames: DuplicateHostnames;
}> = ({ duplicate_ips, duplicate_hostnames }) => {
  const hasHostnameDuplicates = Object.values(duplicate_hostnames).some(count => count > 1);
  const hasIpDuplicates = Object.values(duplicate_ips).some(env => Object.keys(env).length > 0);

  return (
    <Fade in timeout={1200}>
      <Card sx={{
        background: modernTheme.cardBackground,
        border: `1px solid ${hasHostnameDuplicates || hasIpDuplicates ? modernTheme.gradients.warning + '30' : modernTheme.outline}`,
        borderRadius: 3,
        mb: 4,
        boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
      }}>
        <CardContent sx={{ p: 3 }}>
          {(!hasHostnameDuplicates && !hasIpDuplicates) ? (
            <Box textAlign="center">
              <CheckCircle sx={{ fontSize: 48, color: modernTheme.accent, mb: 2 }} />
              <Typography variant="h6" sx={{ fontWeight: 700, color: modernTheme.accent, mb: 1 }}>
                Aucun doublon détecté
              </Typography>
              <Typography variant="body2" sx={{ color: modernTheme.textSecondary }}>
                Tous les hostnames et adresses IP sont uniques
              </Typography>
            </Box>
          ) : (
            <>
              <Typography variant="h5" sx={{
                fontWeight: 700,
                mb: 3,
                color: modernTheme.textPrimary,
                display: 'flex',
                alignItems: 'center',
                gap: 1
              }}>
                <Warning sx={{ fontSize: 20 }} />
                Doublons détectés
              </Typography>

              {hasHostnameDuplicates && (
                <Box sx={{ mb: 3 }}>
                  <Typography variant="h6" sx={{ fontWeight: 600, mb: 2, color: modernTheme.textPrimary }}>
                    Hostnames en doublon
                  </Typography>
                  <Grid container spacing={1}>
                    {Object.entries(duplicate_hostnames).map(([hostname, count]) => (
                      count > 1 && (
                        <Grid item xs={12} sm={6} md={4} key={hostname}>
                          <Chip
                            label={`${hostname} (${count}x)`}
                            color="warning"
                            variant="outlined"
                            sx={{ fontWeight: 600 }}
                          />
                        </Grid>
                      )
                    ))}
                  </Grid>
                </Box>
              )}

              {hasIpDuplicates && (
                <Box>
                  <Typography variant="h6" sx={{ fontWeight: 600, mb: 2, color: modernTheme.textPrimary }}>
                    Adresses IP en doublon par environnement
                  </Typography>
                  {Object.entries(duplicate_ips).map(([env, ips]) => (
                    Object.keys(ips).length > 0 && (
                      <Box key={env} sx={{ mb: 2 }}>
                        <Typography variant="body2" sx={{ fontWeight: 600, color: modernTheme.textSecondary, mb: 1 }}>
                          {env}
                        </Typography>
                        <Grid container spacing={1}>
                          {Object.entries(ips).map(([ip, hosts]) => (
                            <Grid item key={ip}>
                              <Chip
                                label={`${ip} (${hosts})`}
                                size="small"
                                color="error"
                                variant="outlined"
                              />
                            </Grid>
                          ))}
                        </Grid>
                      </Box>
                    )
                  ))}
                </Box>
              )}
            </>
          )}
        </CardContent>
      </Card>
    </Fade>
  );
};

// Composant ServerNatureSection
const ServerNatureSection: React.FC<{ serverCountByNature: ServerNatureItem[] }> = ({ serverCountByNature }) => {
  const [expanded, setExpanded] = useState(false);

  const allItems = serverCountByNature
    .flatMap(item =>
      Object.entries(item)
        .filter(([_, data]) => data.total > 0)
        .map(([nature, data]) => ({
          nature,
          ...data
        }))
    )
    .sort((a, b) => b.total - a.total);

  const visibleItems = expanded ? allItems : allItems.slice(0, 9);
  const totalServers = allItems.reduce((sum, i) => sum + i.total, 0);

  return (
    <Fade in timeout={1400}>
      <Card sx={{
        background: modernTheme.cardBackground,
        border: `1px solid ${modernTheme.outline}`,
        borderRadius: 3,
        mb: 4,
        boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
      }}>
        <CardContent sx={{ p: 3 }}>
          <Typography variant="h5" sx={{ fontWeight: 700, mb: 3, color: modernTheme.textPrimary, display: 'flex', alignItems: 'center', gap: 1 }}>
            <Layers sx={{ fontSize: 20 }} />
            Répartition par Nature de Serveur
          </Typography>

          <Grid container spacing={2}>
            {visibleItems.map((item, index) => {
              const percentage = totalServers > 0 ? Math.round((item.total / totalServers) * 100) : 0;
              const IconComponent = serverNatureIcons[item.nature.toLowerCase().split(' ')[0]] || serverNatureIcons.default;
              const iconColor = getNatureColor(item.nature);

              return (
                <Grid item xs={12} sm={6} md={4} key={index}>
                  <Tooltip title={`Détails: Prod ${item.prod} / Hors Prod ${item.hors_prod}`} arrow>
                    <Box
                      sx={{
                        display: 'flex',
                        gap: 2,
                        alignItems: 'center',
                        p: 2,
                        borderRadius: 2,
                        border: `1px solid ${modernTheme.outline}`,
                        background: modernTheme.background,
                        transition: 'all 0.3s ease',
                        '&:hover': {
                          transform: 'translateY(-4px)',
                          boxShadow: `0 6px 12px ${modernTheme.shadow}`,
                          borderColor: iconColor,
                        }
                      }}
                    >
                      <Box
                        sx={{
                          width: 52,
                          height: 52,
                          borderRadius: 1.5,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flexShrink: 0,
                          background: `${iconColor}20`,
                          color: iconColor,
                          transition: 'background 0.3s',
                          '&:hover': {
                            background: `${iconColor}30`,
                          },
                        }}
                      >
                        <IconComponent sx={{ fontSize: 28 }} />
                      </Box>

                      <Box sx={{ flex: 1 }}>
                        <Box display="flex" justifyContent="space-between" alignItems="baseline">
                          <Typography variant="subtitle2" sx={{ fontWeight: 700, color: modernTheme.textPrimary }}>
                            {item.nature}
                          </Typography>
                          <Typography variant="h6" sx={{ fontWeight: 800, color: iconColor }}>
                            {item.total}
                          </Typography>
                        </Box>

                        <Box sx={{ mt: 1 }}>
                          <LinearProgress
                            variant="determinate"
                            value={percentage}
                            sx={{
                              height: 8,
                              borderRadius: 2,
                              backgroundColor: modernTheme.outline,
                              '& .MuiLinearProgress-bar': {
                                backgroundColor: iconColor,
                              },
                            }}
                          />
                          <Typography variant="caption" color={modernTheme.textSecondary} sx={{ mt: 0.5, display: 'block' }}>
                            {percentage}% du total • Prod: {item.prod} • Hors Prod: {item.hors_prod}
                          </Typography>
                        </Box>
                      </Box>
                    </Box>
                  </Tooltip>
                </Grid>
              );
            })}
          </Grid>

          {allItems.length > 9 && (
            <Box sx={{ display: 'flex', justifyContent: 'center', mt: 3 }}>
              <Button
                variant="outlined"
                onClick={() => setExpanded(!expanded)}
                startIcon={<Refresh />}
                sx={{
                  borderColor: modernTheme.primary,
                  color: modernTheme.primary,
                  '&:hover': {
                    borderColor: modernTheme.primary,
                    backgroundColor: `${modernTheme.primary}10`,
                  },
                  px: 4,
                  py: 1.5,
                  borderRadius: 2,
                  fontWeight: 600,
                }}
              >
                {expanded ? `Afficher moins` : `Afficher plus (+${allItems.length - 9} natures)`}
              </Button>
            </Box>
          )}
        </CardContent>
      </Card>
    </Fade>
  );
};

// Composant principal AitaCockpit
const AitaCockpit: React.FC = () => {
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchDashboardData = async (): Promise<void> => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetchWithAuth(getAitaStatsentiteUrl());

      if (!response.ok) {
        throw `Erreur HTTP: ${response.status}`;
      }

      const data: DashboardData = await response.json();
      setDashboardData(data);

    } catch (err) {
      console.error("Erreur détaillée:", err);
      setError(typeof err === "string" ? err : "Erreur inconnue lors du chargement des données");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const refreshData = async (): Promise<void> => {
    setLoading(true);
    setError(null);
    try {
      const [refreshResponse, dataResponse] = await Promise.all([
        fetchWithAuth(Server_StatsRefresh(), {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
        }),
        fetchWithAuth(getAitaStatsentiteUrl()),
      ]);

      if (!refreshResponse.ok) {
        console.warn(`Erreur lors du rafraîchissement des stats: ${refreshResponse.status}`);
        return; // Ne pas continuer si l'étape 1 échoue
      }

      if (!dataResponse.ok) {
        console.warn(`Erreur HTTP: ${dataResponse.status}`);
        return;
      }

      const data: DashboardData = await dataResponse.json();
      setDashboardData(data);
    } catch (err) {
      console.warn("Erreur silencieuse lors de la récupération des données:", err);
      setError(typeof err === "string" ? err : "Erreur inconnue lors du chargement des données");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        minHeight="100vh"
        sx={{ background: modernTheme.background }}
      >
        <Box textAlign="center">
          <CircularProgress size={60} thickness={4} sx={{ color: modernTheme.primary }} />
          <Typography variant="h6" sx={{ mt: 3, fontWeight: 500, color: modernTheme.textPrimary }}>
            Chargement du cockpit AITA...
          </Typography>
        </Box>
      </Box>
    );
  }

  if (error || !dashboardData) {
    return (
      <Box sx={{ p: 3, background: modernTheme.background, minHeight: '100vh' }}>
        <Alert
          severity="error"
          sx={{ mb: 3, borderRadius: 3 }}
          action={
            <IconButton onClick={refreshData} color="inherit">
              <Refresh />
            </IconButton>
          }
        >
          Erreur lors du chargement des données AITA: {error}
        </Alert>
      </Box>
    );
  }

  return (
    <Box
      sx={{
        p: { xs: 2, md: 4 },
        backgroundColor: modernTheme.background,
        minHeight: "100vh",
        backgroundImage: "radial-gradient(circle at 10% 20%, rgba(200, 200, 255, 0.05) 0%, rgba(200, 255, 200, 0.05) 90%)",
      }}
    >
      {/* Header */}
      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 5 }}>
        <Box>
          <Typography variant="h3" sx={{ fontWeight: "bold", color: modernTheme.primary, mb: 1, display: 'flex', alignItems: 'center' }}>
            <Business sx={{ fontSize: 36, mr: 1.5 }} />
            Cockpit AITA
          </Typography>
          <Typography variant="body1" color={modernTheme.textSecondary}>
            Dernière mise à jour: {new Date(dashboardData.calculated_at).toLocaleString("fr-FR")}
          </Typography>
        </Box>
        <Tooltip title="Actualiser les données">
          <IconButton
            onClick={refreshData}
            sx={{
              bgcolor: modernTheme.primary,
              color: 'white',
              p: 2,
              '&:hover': {
                bgcolor: modernTheme.secondary,
                transform: "rotate(360deg)",
              },
              transition: 'all 0.5s ease',
            }}
          >
            <Refresh sx={{ fontSize: 20 }} />
          </IconButton>
        </Tooltip>
      </Box>

      <Fade in timeout={400}>
        <Alert severity="info" sx={{ mb: 5, borderRadius: 3, py: 2 }}>
          Vue d'ensemble complète de l'inventaire AITA - Données calculées le {new Date(dashboardData.calculated_at).toLocaleString("fr-FR")}
        </Alert>
      </Fade>

      {/* TOUS LES GRAPHIQUES CIRCULAIRES AVEC RATIOS */}
      <StatsOverview dashboardData={dashboardData} />

      {/* Sections détaillées */}
      <AdminsSection admins={dashboardData.list_admins} />
      <ArchitectureAndOSSection
        architecture={dashboardData.architecture_distribution}
        os_ratio={dashboardData.os_ratio}
      />
      <ServerNatureSection serverCountByNature={dashboardData.server_count_by_nature} />
      <DuplicatesSection
        duplicate_ips={dashboardData.duplicate_ips}
        duplicate_hostnames={dashboardData.duplicate_hostnames}
      />

      {/* Footer */}
      <Fade in timeout={1800}>
        <Box sx={{ mt: 4, textAlign: 'center', pb: 4 }}>
          <Typography variant="body2" color={modernTheme.textSecondary}>
            ID du rapport: {dashboardData.id} • Données mises à jour automatiquement
          </Typography>
        </Box>
      </Fade>
    </Box>
  );
};

export default AitaCockpit;