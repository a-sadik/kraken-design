// src/components/basic/CustomSwitchOption
import React from "react";
import { Switch, FormControlLabel, SwitchProps } from "@mui/material";
import CustomTooltip from "../basics/CustomToolTip";

interface CustomSwitchOptionProps {
  title: string;
  checked: boolean;
  onChange: () => void;
  disabled?: boolean;
  color?: SwitchProps["color"];
}

const CustomSwitchOption: React.FC<CustomSwitchOptionProps> = ({
  title,
  checked,
  onChange,
  disabled = false,
  color = "primary",
}) => {
  return (
    <CustomTooltip title={title}>
      <FormControlLabel
        control={
          <Switch
            checked={checked}
            onChange={onChange}
            color={color}
            size="small"
            disabled={disabled}
          />
        }
        label={title}
        sx={{ ".MuiFormControlLabel-label": { fontSize: "0.85rem" } }}
      />
    </CustomTooltip>
  );
};

export default CustomSwitchOption;
