// src/pages/primary-pages/auditadmin/sections/PoleSection.tsx

import React, { useEffect, useMemo, useState } from "react";
import {
  Box,
  Grid,
  Stack,
  Typography,
  IconButton,
  Collapse,
  TextField,
  Snackbar,
  Alert as MuiAlert,
  Button,
  useMediaQuery,
} from "@mui/material";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";
import SearchIcon from "@mui/icons-material/Search";

import WidgetMainContainer from "@/components/containers/WidgetMainContainer";
import { MaterialReactTable, MRT_ColumnDef } from "material-react-table";

import { CreatePoleModal } from "@/components/modals/CreatePoleModal";
import { EditPoleModal } from "@/components/modals/EditPoleModal";
import { InfoModal } from "@/components/modals/InfoModal";

import { getAllPoles } from "@/services/admin/PoleService";
import { PoleShortResponseDTO } from "@/types/dto/PoleDTO";

const PAGE_SIZE = 5;

const PoleSection: React.FC = () => {
  const [poles, setPoles] = useState<PoleShortResponseDTO[]>([]);
  const [loading, setLoading] = useState(false);

  const [collapseOpen, setCollapseOpen] = useState(true);
  const [globalFilter, setGlobalFilter] = useState("");
  const [snack, setSnack] = useState({
    open: false,
    msg: "",
    severity: "success" as "success" | "error",
  });

  const [addOpen, setAddOpen] = useState(false);
  const [selected, setSelected] = useState<PoleShortResponseDTO | null>(null);
  const [editOpen, setEditOpen] = useState(false);
  const [infoOpen, setInfoOpen] = useState(false);

  const isXs = useMediaQuery("(max-width:480px)");

  const fetchPoles = () => {
    setLoading(true);
    getAllPoles()
      // .then(setPoles)
      .then((data) => {
        // ⇢ On place le plus récent (post_id le plus élevé) en tête
        const sorted = [...data].sort((a, b) => b.pole_id - a.pole_id);
        setPoles(sorted);
      })
      .catch(() =>
        setSnack({
          open: true,
          msg: "Erreur de chargement",
          severity: "error",
        }),
      )
      .finally(() => setLoading(false));
  };
  useEffect(fetchPoles, []);

  const columns = useMemo<MRT_ColumnDef<PoleShortResponseDTO>[]>(
    () => [
      {
        header: "Pole",
        accessorKey: "pole_name",
        muiTableBodyCellProps: {
          sx: {
            cursor: "pointer",
            color: "primary.main",
            "&:hover": { textDecoration: "underline" },
          },
        },
        Cell: ({ row }) => (
          <Typography
            onClick={() => {
              setSelected(row.original);
              setInfoOpen(true);
            }}
          >
            {row.original.pole_name}
          </Typography>
        ),
      },
      {
        header: "Actions",
        id: "actions",
        enableSorting: false,
        enableColumnFilter: false,
        muiTableHeadCellProps: { sx: { textAlign: "right" } },
        muiTableBodyCellProps: { sx: { textAlign: "right" } },
        Cell: ({ row }) => (
          <Stack direction="row" justifyContent="flex-end" spacing={1}>
            <Button
              variant="contained"
              color="info"
              size="small"
              onClick={() => {
                setSelected(row.original);
                setEditOpen(true);
              }}
            >
              Modifier
            </Button>
          </Stack>
        ),
      },
    ],
    [],
  );

  const data = useMemo(() => {
    if (!globalFilter) return poles;
    return poles.filter((p) =>
      p.pole_name.toLowerCase().includes(globalFilter.toLowerCase()),
    );
  }, [poles, globalFilter]);

  useEffect(() => {
    if (globalFilter.trim() && !collapseOpen) {
      setCollapseOpen(true);
    }
  }, [globalFilter]);

  return (
    <Grid container spacing={3} sx={{ mb: 3 }}>
      <Grid item xs={12}>
        <WidgetMainContainer>
          {/* Header */}
          <Stack
            direction="row"
            justifyContent="space-between"
            alignItems="center"
            flexWrap="wrap"
          >
            <Stack direction="row" alignItems="center" spacing={1}>
              <Typography variant="h6" fontWeight="bold">
                Pôles
              </Typography>
              <IconButton onClick={() => setAddOpen(true)}>
                <AddCircleOutlineIcon color="primary" />
              </IconButton>
            </Stack>

            <Stack
              direction="row"
              spacing={1}
              alignItems="center"
              flexWrap="wrap"
            >
              {isXs ? (
                <IconButton>
                  <SearchIcon />
                </IconButton>
              ) : (
                <Box sx={{ width: { xs: "120px", sm: "230px" } }}>
                  <TextField
                    size="small"
                    fullWidth
                    placeholder="Rechercher…"
                    value={globalFilter}
                    onChange={(e) => setGlobalFilter(e.target.value)}
                  />
                  {!collapseOpen && globalFilter && (
                    <Typography variant="caption" color="textSecondary">
                      Résultats filtrés — ouvrez la section pour les voir.
                    </Typography>
                  )}
                </Box>
              )}

              <IconButton onClick={() => setCollapseOpen((o) => !o)}>
                {collapseOpen ? <ExpandLessIcon /> : <ExpandMoreIcon />}
              </IconButton>
            </Stack>
          </Stack>

          {/* Table */}
          <Collapse in={collapseOpen}>
            <MaterialReactTable
              columns={columns}
              data={data}
              state={{ isLoading: loading, showProgressBars: loading }}
              enableColumnActions={false}
              enableDensityToggle={false}
              enableHiding={false}
              enableFullScreenToggle={false}
              enableToolbarInternalActions={false}
              enableGlobalFilter={false}
              initialState={{
                pagination: { pageIndex: 0, pageSize: PAGE_SIZE },
              }}
              muiTablePaperProps={{
                elevation: 0,
                sx: { boxShadow: "none", border: "none" },
              }}
              muiTableContainerProps={{
                sx: {
                  border: "none",
                  "& .MuiTableRow-root, & .MuiTableCell-root": {
                    borderBottom: "none",
                  },
                },
              }}
              muiTableHeadProps={{ sx: { display: "none" } }}
              // muiTableBodyProps={{ sx: { paddingTop: '0px !important', marginTop: '0px !important' } }}
              muiTableBodyProps={{ sx: { paddingTop: 0 } }}
              muiTableHeadCellProps={{
                sx: {
                  paddingTop: "0px",
                  paddingBottom: "0px",
                  height: "2px",
                  minHeight: "2px",
                  fontSize: "0.75rem",
                },
              }}
            />
          </Collapse>
        </WidgetMainContainer>
      </Grid>

      {/* Modals */}
      <CreatePoleModal
        open={addOpen}
        onClose={() => setAddOpen(false)}
        onSave={() => {
          fetchPoles();
          setAddOpen(false);
        }}
        initialData={null}
      />

      {selected && (
        <EditPoleModal
          open={editOpen}
          onClose={() => setEditOpen(false)}
          onSave={() => {
            fetchPoles();
            setEditOpen(false);
          }}
          poleId={selected.pole_id}
          currentName={selected.pole_name}
          currentManagerId={selected.pole_manager_id}
          currentEntityId={selected.entity_id}
        />
      )}

      {selected && (
        <InfoModal
          open={infoOpen}
          onClose={() => setInfoOpen(false)}
          kind="pole"
          id={selected.pole_id}
        />
      )}

      {/* Snackbar */}
      <Snackbar
        open={snack.open}
        autoHideDuration={3000}
        onClose={() => setSnack((s) => ({ ...s, open: false }))}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <MuiAlert severity={snack.severity} variant="filled">
          {snack.msg}
        </MuiAlert>
      </Snackbar>
    </Grid>
  );
};

export default PoleSection;
