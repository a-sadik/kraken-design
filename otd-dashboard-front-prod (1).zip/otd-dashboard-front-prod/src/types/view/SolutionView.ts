// src/types/view/SolutionView.ts

// import { DomainResponseDTO } from "../dto/response/DomainResponseDTO";

export default interface SolutionView {
  id: number;
  Nom: string;
  Popularité: string;
  Type: string;
  // "Interne/Externe": string;
  PSI: string | null;
  Rôle: string;
  // "Admin(s) fonctionnel(s)": string[] | null;
  // "Admin(s) technique(s)": string[] | null;
  // "TAM": string | null;
  // "Domaine": DomainResponseDTO | string | null;
}
