// src/components/basics/CustomBadge.tsx

import { FC } from "react";
import { Typography } from "@mui/material";

interface CustomFormLabelProps {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  label: string;
  isRequired: boolean;
}

const CustomFormLabel: FC<CustomFormLabelProps> = ({
  label,
  isRequired = false,
}) => {
  return (
    <Typography
      variant="body1"
      sx={{
        fontWeight: "bold",
        display: "flex",
        alignItems: "center",
        mb: "0.5rem",
        fontSize: "1.2rem",
      }}
    >
      {label}
      {isRequired && (
        <span style={{ color: "var(--error-color)", marginLeft: 2 }}>*</span>
      )}
    </Typography>
  );
};

export default CustomFormLabel;
