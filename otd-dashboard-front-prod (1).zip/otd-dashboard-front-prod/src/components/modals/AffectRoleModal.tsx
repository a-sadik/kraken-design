// src/components/modals/AffectRoleModal.tsx
import React, { useEffect, useState } from "react";
import {
  TextField,
  Button,
  Box,
  CircularProgress,
  Autocomplete,
} from "@mui/material";
import MyModal from "@/components/modals/MyModal";
// import { getAllRoles } from '@/services/admin/RoleService';

interface Option {
  id: string;
  name: string;
}

interface AffectRoleModalProps {
  open: boolean;
  onClose: () => void;
  onSave: (payload: {
    personneIds: string[]; // toujours un seul ID ici
    roleIds: string[];
  }) => void;
  personName: string; // nom à afficher
  personId: string; // id à envoyer
}

export const AffectRoleModal: React.FC<AffectRoleModalProps> = ({
  open,
  onClose,
  onSave,
  personName,
  personId,
}) => {
  const [roles, _] = useState<Option[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedRoles, setSelectedRoles] = useState<Option[]>([]);

  // Charger la liste des rôles à l’ouverture
  useEffect(() => {
    if (!open) return;
    setLoading(true);
    // getAllRoles()
    //   .then(data =>
    //     setRoles(
    //       data.map(r => ({
    //         id:   r.role_id.toString(),
    //         name: r.role_name,
    //       }))
    //     )
    //   )
    //   .catch(console.error)
    //   .finally(() => setLoading(false));

    // Réinitialiser la sélection
    setSelectedRoles([]);
  }, [open]);

  const handleSave = () => {
    onSave({
      personneIds: [personId],
      roleIds: selectedRoles.map((r) => r.id),
    });
    onClose();
  };

  return (
    <MyModal open={open} onClose={onClose} title="Affecter les Rôles">
      <Box sx={{ minWidth: 500, px: 2, pt: 1 }}>
        {/* Affiche uniquement le nom de la personne */}
        <TextField
          label="Personne"
          value={personName}
          fullWidth
          margin="normal"
          disabled
        />

        {/* Sélecteur multiple de rôles */}
        <Autocomplete
          multiple
          options={roles}
          getOptionLabel={(o) => o.name}
          loading={loading}
          value={selectedRoles}
          onChange={(_, vals) => setSelectedRoles(vals)}
          renderInput={(params) => (
            <TextField
              {...params}
              label="Rôles"
              margin="normal"
              InputProps={{
                ...params.InputProps,
                endAdornment: (
                  <>
                    {loading && <CircularProgress size={20} />}
                    {params.InputProps.endAdornment}
                  </>
                ),
              }}
            />
          )}
        />

        {/* Boutons d’action */}
        <Box textAlign="right" mt={3}>
          <Button onClick={onClose} variant="outlined" sx={{ mr: 1 }}>
            Annuler
          </Button>
          <Button onClick={handleSave} variant="contained">
            Enregistrer
          </Button>
        </Box>
      </Box>
    </MyModal>
  );
};
