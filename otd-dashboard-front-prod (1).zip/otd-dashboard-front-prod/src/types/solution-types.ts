export interface Solution {
  id: number;
  solution_name: string;
  solution_type: string;
  solution_role: string;
  psi: string;
  domain: string;
  pole: string;
  entity: string;
  tams: string[];
  technical_admins: string[];
  functional_admins: string[];
  declarted_on_bigfix: boolean;
  declarted_on_itop: boolean;
  fiable: boolean;
  activated: boolean;
  service_type: string;
  tenant: string;
  tenant_details: string;
  solution_popularity?: string;
  count_servers?: number;
  count_namespaces?: number;
  count_pods?: number;
  count_deployments?: number;
  count_request?: number;
  count_cab?: number;
  count_ecab?: number;
  serversByEnv?: any;
  list_admins?: {
    technical_admins: any[];
    functional_admins: any[];
    tams: any[];
  };
}
