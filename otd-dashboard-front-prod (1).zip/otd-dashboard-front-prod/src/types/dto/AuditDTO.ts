import { PersonShortResponseDTO } from "./PersonDTO";

export interface AuditDetailDTO {
  reference: string;
  person: string;
  description: string;
  additionalData: any;
  changes: boolean;
  componentName: string;

  audit_id: number;
  parent_audit_id: number | null;
  audit_ref: string;
  agent: PersonShortResponseDTO;
  firstname: any | null;
  lastname: any | null;
  item_name: string;
  item_ids: number[];
  old_value: any | null;
  new_value: any | null;
  operation_status: string;
  action_type: string;
  reason_failed_operation: string | null;
  action_description: string;
  ip_address: string;
  operation_at: string;
}

export interface AuditShortDTO {
  audit_id: number;
  audit_ref: string;
  agent: string;
  item_name: string;
  operation_status: string;
  action_type: string;
  reason_failed_operation: string | null;
  ip_address: string;
  operation_at: string;
  action_description: string;
}
