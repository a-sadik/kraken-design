// src/components/modals/CreateEntityModal.tsx
import React, { useEffect, useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { z as zod } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Grid,
  TextField,
  Autocomplete,
  CircularProgress,
  Alert,
  Typography,
  Button,
  Box,
  Snackbar,
} from "@mui/material";

import MyModal from "@/components/modals/MyModal";
import { getAllPersons } from "@/services/admin/PersonService";
import { createEntity } from "@/services/admin/EntityService";
import { PersonShortResponseDTO } from "@/types/dto/PersonDTO";

import {
  placeholder_entity_name,
  placeholder_one_person,
  required_hostname,
  required_one_solution,
} from "@/utils/customMessages";

/* ------------------------------------------------------------------ *
 * Validation Zod
 * ------------------------------------------------------------------ */
const getFormSchema = () =>
  zod.object({
    entity_name: zod.string().trim().min(1, required_hostname),
    person: zod
      .object({
        person_id: zod.number(),
        firstname: zod.string(),
        lastname: zod.string(),
      })
      .nullable()
      .refine((val) => val !== null, { message: required_one_solution }),
  });

export type FormCreateEntityData = zod.infer<ReturnType<typeof getFormSchema>>;

/* ------------------------------------------------------------------ *
 * Props
 * ------------------------------------------------------------------ */
interface CreateEntityModalProps {
  open: boolean;
  onClose: () => void;
  onSave: () => void;
  initialData?: Partial<FormCreateEntityData> | null; // optionnel
}

/* ==================================================================
 * Composant
 * ================================================================= */
export const CreateEntityModal: React.FC<CreateEntityModalProps> = ({
  open,
  onClose,
  onSave,
  initialData,
}) => {
  const formSchema = getFormSchema();

  const {
    control,
    register,
    handleSubmit,
    reset,
    setValue,
    formState: { errors, isValid },
  } = useForm<FormCreateEntityData>({
    resolver: zodResolver(formSchema),
    mode: "all",
    defaultValues: { entity_name: "", person: null as any },
  });

  const [persons, setPersons] = useState<PersonShortResponseDTO[]>([]);
  const [loadPersons, setLoadPersons] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successSnackbar, setSuccessSnackbar] = useState(false);

  /* ❶ Remise à zéro à chaque ouverture */
  useEffect(() => {
    if (open) {
      reset({ entity_name: "", person: null as any }); // ← champs vides
      setErrorMessage(null);
    }
  }, [open, reset]);

  /* ❷ Appliquer initialData si présent (mode édition réutilisable) */
  useEffect(() => {
    if (open && initialData) {
      Object.entries(initialData).forEach(([key, value]) =>
        setValue(key as keyof FormCreateEntityData, value as any),
      );
    }
  }, [open, initialData, setValue]);

  /* ❸ Chargement des personnes */
  const fetchPersons = async () => {
    setLoadPersons(true);
    try {
      const data = await getAllPersons();
      setPersons(Array.isArray(data) ? data : []);
    } finally {
      setLoadPersons(false);
    }
  };

  /* ❹ Soumission */
  const onSubmit = async (data: FormCreateEntityData) => {
    setLoading(true);
    setErrorMessage(null);
    try {
      await createEntity({
        entity_name: data.entity_name,
        entity_manager_id: data.person!.person_id,
      });
      onSave(); // parent : refresh + notif
      setSuccessSnackbar(true);
      onClose();
    } catch (err) {
      console.error("Erreur création :", err);
      setErrorMessage("Erreur lors de la création de l'entité.");
    } finally {
      setLoading(false);
    }
  };

  /* ─────────────────────────────── */
  return (
    <>
      <MyModal open={open} onClose={onClose} title="Ajouter une entité">
        <form onSubmit={handleSubmit(onSubmit)}>
          <Grid container spacing={2} sx={{ p: 2 }}>
            {/* Nom de l'entité */}
            <Grid item xs={12} container spacing={2} alignItems="center">
              <Grid item xs={4}>
                <Typography fontWeight="bold">Nom de l'entité</Typography>
              </Grid>
              <Grid item xs={8} width={500}>
                <TextField
                  {...register("entity_name")}
                  error={!!errors.entity_name}
                  helperText={errors.entity_name?.message}
                  fullWidth
                  placeholder={placeholder_entity_name}
                />
              </Grid>
            </Grid>

            {/* Responsable */}
            <Grid item xs={12} container spacing={2} alignItems="center">
              <Grid item xs={4}>
                <Typography fontWeight="bold">Responsable</Typography>
              </Grid>
              <Grid item xs={8}>
                <Controller
                  name="person"
                  control={control}
                  render={({ field }) => (
                    <Autocomplete
                      {...field}
                      options={persons}
                      getOptionLabel={(opt) =>
                        opt ? `${opt.firstname} ${opt.lastname}` : ""
                      }
                      loading={loadPersons}
                      onOpen={fetchPersons}
                      onChange={(_, v) => field.onChange(v)}
                      isOptionEqualToValue={(o, v) =>
                        o.person_id === v?.person_id
                      }
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          placeholder={placeholder_one_person}
                          error={!!errors.person}
                          helperText={
                            errors.person?.message ||
                            (loadPersons ? "Chargement…" : "")
                          }
                          InputProps={{
                            ...params.InputProps,
                            endAdornment: (
                              <>
                                {loadPersons && <CircularProgress size={20} />}
                                {params.InputProps.endAdornment}
                              </>
                            ),
                          }}
                        />
                      )}
                    />
                  )}
                />
              </Grid>
            </Grid>

            {/* Erreur globale */}
            {errorMessage && (
              <Grid item xs={12}>
                <Alert variant="filled" severity="error">
                  {errorMessage}
                </Alert>
              </Grid>
            )}
          </Grid>

          {/* Boutons */}
          <Box textAlign="right" p={2}>
            <Button onClick={onClose} sx={{ mr: 1 }}>
              Annuler
            </Button>
            <Button
              type="submit"
              variant="contained"
              disabled={!isValid || loading}
            >
              {loading ? <CircularProgress size={20} /> : "Ajouter"}
            </Button>
          </Box>
        </form>
      </MyModal>

      {/* Snackbar succès interne */}
      <Snackbar
        open={successSnackbar}
        autoHideDuration={3000}
        onClose={() => setSuccessSnackbar(false)}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <Alert
          onClose={() => setSuccessSnackbar(false)}
          severity="success"
          variant="filled"
        >
          Entité créée avec succès&nbsp;!
        </Alert>
      </Snackbar>
    </>
  );
};

export default CreateEntityModal;
