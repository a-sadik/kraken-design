import { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Chip,
  Stack,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Switch,
  FormControlLabel,
  Alert,
  Snackbar,
  Tooltip,
  Avatar,
  Grid,
  InputAdornment,
  alpha,
} from '@mui/material';
import {
  Edit as EditIcon,
  Delete as DeleteIcon,
  Add as AddIcon,
  Campaign as CampaignIcon,
  Search as SearchIcon,
  Visibility as VisibilityIcon,
  Schedule as ScheduleIcon,
  Person as PersonIcon,
} from '@mui/icons-material';
import { Communications_URL } from '@/config/api.config';

// Interfaces
interface Priority {
  id: number;
  name: string;
}

interface Status {
  id: number;
  name: string;
}

interface Announcement {
  id: number;
  title: string;
  message: string;
  author: string;
  published_at: string;
  expires_at: string | null;
  priority: Priority;
  status: Status;
  priority_id: number;
  status_id: number;
  tags: string[];
  draft: boolean;
}

interface AnnouncementFormData {
  title: string;
  message: string;
  expires_at: string;
  draft: boolean;
  priority_name: string;
  tags: string[];
}

// Couleurs pastel pour le design
const pastelColors = {
  primary: '#A8D5E2',    // Bleu pastel
  secondary: '#FFD6CC',  // Orange pastel
  success: '#D4EDDA',    // Vert pastel
  warning: '#FFF3CD',    // Jaune pastel
  error: '#F8D7DA',      // Rouge pastel
  info: '#D1ECF1',       // Cyan pastel
  background: '#F8F9FA', // Gris très clair
  text: '#2C3E50',       // Texte foncé
  white: '#FFFFFF',
  border: '#E9ECEF'
};

const AnnouncementsAdmin = () => {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingAnnouncement, setEditingAnnouncement] = useState<Announcement | null>(null);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' as 'success' | 'error' });
  const [searchTerm, setSearchTerm] = useState('');

  // Données du formulaire
  const [formData, setFormData] = useState<AnnouncementFormData>({
    title: '',
    message: '',
    expires_at: '',
    draft: false,
    priority_name: 'Basse',
    tags: []
  });

  // Options de priorité
  const priorityOptions = [
    { name: 'Haute', value: 'Haute', color: pastelColors.error },
    { name: 'Moyenne', value: 'Moyenne', color: pastelColors.warning },
    { name: 'Basse', value: 'Basse', color: pastelColors.info }
  ];


  // Charger les annonces
  const fetchAnnouncements = async () => {
    try {
      setLoading(true);
      const response = await fetch(Communications_URL(),
        {
          method: 'GET',
          headers: {
            'accept': 'application/json',
            'X-CSRFTOKEN': 's5KOCOBSgVNM6VUvI3p3zRwRGmtVZDIv'
          }
        }
      );

      if (response.ok) {
        const data = await response.json();
        setAnnouncements(data);
      } else {
        showSnackbar('Erreur lors du chargement des annonces', 'error');
      }
    } catch (error) {
      showSnackbar('Erreur de connexion', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAnnouncements();
  }, []);

  // Filtrer les annonces selon la recherche
  const filteredAnnouncements = announcements.filter(announcement =>
    announcement.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    announcement.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
    announcement.author.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Gestion du snackbar
  const showSnackbar = (message: string, severity: 'success' | 'error') => {
    setSnackbar({ open: true, message, severity });
  };

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  // Ouvrir le dialog pour créer/modifier
  const handleOpenDialog = (announcement?: Announcement) => {
    if (announcement) {
      setEditingAnnouncement(announcement);
      setFormData({
        title: announcement.title,
        message: announcement.message,
        expires_at: announcement.expires_at ? announcement.expires_at.split('T')[0] : '',
        draft: announcement.draft,
        priority_name: announcement.priority.name,
        tags: announcement.tags
      });
    } else {
      setEditingAnnouncement(null);
      setFormData({
        title: '',
        message: '',
        expires_at: '',
        draft: false,
        priority_name: 'Basse',
        tags: []
      });
    }
    setOpenDialog(true);
  };

  // Fermer le dialog
  const handleCloseDialog = () => {
    setOpenDialog(false);
    setEditingAnnouncement(null);
  };

  // Gérer les changements du formulaire
  const handleInputChange = (field: keyof AnnouncementFormData, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // Créer une nouvelle annonce
  const handleCreateAnnouncement = async () => {
    try {
      const token = localStorage.getItem("access_token");
      if (!token) {
        showSnackbar('Token d\'authentification manquant', 'error');
        return;
      }

      const response = await fetch(Communications_URL(),
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'accept': 'application/json',
            'Authorization': `Bearer ${token}`,
            'X-CSRFTOKEN': 's5KOCOBSgVNM6VUvI3p3zRwRGmtVZDIv'
          },
          body: JSON.stringify({
            ...formData,
            expires_at: formData.expires_at ? `${formData.expires_at}T00:00:00.000Z` : null
          })
        }
      );

      if (response.ok) {
        showSnackbar('Annonce créée avec succès', 'success');
        handleCloseDialog();
        fetchAnnouncements();
      } else {
        const errorData = await response.json();
        showSnackbar(`Erreur: ${errorData.detail || 'Erreur lors de la création'}`, 'error');
      }
    } catch (error) {
      showSnackbar('Erreur de connexion', 'error');
    }
  };

  // Modifier une annonce
  const handleUpdateAnnouncement = async () => {
    if (!editingAnnouncement) return;

    try {
      const token = localStorage.getItem("access_token");
      if (!token) {
        showSnackbar('Token d\'authentification manquant', 'error');
        return;
      }

      const response = await fetch(
        `${Communications_URL()}${editingAnnouncement.id}/`,
        {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
            'accept': 'application/json',
            'Authorization': `Bearer ${token}`,
            'X-CSRFTOKEN': 's5KOCOBSgVNM6VUvI3p3zRwRGmtVZDIv'
          },
          body: JSON.stringify({
            ...formData,
            expires_at: formData.expires_at ? `${formData.expires_at}T00:00:00.000Z` : null
          })
        }
      );

      if (response.ok) {
        showSnackbar('Annonce modifiée avec succès', 'success');
        handleCloseDialog();
        fetchAnnouncements();
      } else {
        const errorData = await response.json();
        showSnackbar(`Erreur: ${errorData.detail || 'Erreur lors de la modification'}`, 'error');
      }
    } catch (error) {
      showSnackbar('Erreur de connexion', 'error');
    }
  };

  // Supprimer une annonce
  const handleDeleteAnnouncement = async (id: number) => {
    if (!window.confirm('Êtes-vous sûr de vouloir supprimer cette annonce ?')) {
      return;
    }

    try {
      const token = localStorage.getItem("access_token");
      if (!token) {
        showSnackbar('Token d\'authentification manquant', 'error');
        return;
      }

      const response = await fetch(
        `${Communications_URL()}${id}/`,
        {
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${token}`,
            'X-CSRFTOKEN': 's5KOCOBSgVNM6VUvI3p3zRwRGmtVZDIv'
          }
        }
      );

      if (response.ok) {
        showSnackbar('Annonce supprimée avec succès', 'success');
        fetchAnnouncements();
      } else {
        showSnackbar('Erreur lors de la suppression', 'error');
      }
    } catch (error) {
      showSnackbar('Erreur de connexion', 'error');
    }
  };

  // Soumettre le formulaire
  const handleSubmit = () => {
    if (!formData.title.trim() || !formData.message.trim()) {
      showSnackbar('Le titre et le message sont obligatoires', 'error');
      return;
    }

    if (editingAnnouncement) {
      handleUpdateAnnouncement();
    } else {
      handleCreateAnnouncement();
    }
  };

  // Obtenir la couleur du badge de priorité
  const getPriorityColor = (priorityName: string) => {
    switch (priorityName) {
      case 'Haute': return 'error';
      case 'Moyenne': return 'warning';
      case 'Basse': return 'info';
      default: return 'default';
    }
  };

  // Statistiques
  const stats = {
    total: announcements.length,
    published: announcements.filter(a => !a.draft).length,
    drafts: announcements.filter(a => a.draft).length,
    expired: announcements.filter(a => a.expires_at && new Date(a.expires_at) < new Date()).length
  };

  return (
    <Box sx={{
      p: 3,
      backgroundColor: pastelColors.background,
      minHeight: '100vh'
    }}>
      {/* En-tête */}
      <Card sx={{
        mb: 3,
        background: `linear-gradient(135deg, ${pastelColors.primary} 0%, ${pastelColors.secondary} 100%)`,
        color: pastelColors.text,
        boxShadow: '0 8px 32px rgba(0,0,0,0.1)'
      }}>
        <CardContent>
          <Stack direction="row" justifyContent="space-between" alignItems="center">
            <Stack direction="row" alignItems="center" spacing={2}>
              <Avatar sx={{
                backgroundColor: alpha(pastelColors.white, 0.9),
                width: 56,
                height: 56
              }}>
                <CampaignIcon sx={{ fontSize: 32, color: pastelColors.text }} />
              </Avatar>
              <Box>
                <Typography variant="h3" gutterBottom fontWeight="700">
                  Gestion des Annonces
                </Typography>
                <Typography variant="h6" sx={{ opacity: 0.8 }}>
                  Créez et gérez les communications système
                </Typography>
              </Box>
            </Stack>
            <Button
              variant="contained"
              startIcon={<AddIcon />}
              onClick={() => handleOpenDialog()}
              sx={{
                backgroundColor: pastelColors.white,
                color: pastelColors.text,
                borderRadius: 3,
                px: 4,
                py: 1.5,
                fontWeight: 600,
                fontSize: '1rem',
                boxShadow: '0 4px 16px rgba(0,0,0,0.1)',
                '&:hover': {
                  backgroundColor: alpha(pastelColors.white, 0.9),
                  transform: 'translateY(-2px)',
                  boxShadow: '0 6px 20px rgba(0,0,0,0.15)'
                },
                transition: 'all 0.3s ease'
              }}
            >
              Nouvelle Annonce
            </Button>
          </Stack>
        </CardContent>
      </Card>

      {/* Cartes de statistiques */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{
            backgroundColor: pastelColors.primary,
            color: pastelColors.text,
            borderRadius: 3,
            boxShadow: '0 4px 20px rgba(0,0,0,0.08)'
          }}>
            <CardContent>
              <Stack direction="row" alignItems="center" spacing={2}>
                <Avatar sx={{ backgroundColor: alpha(pastelColors.white, 0.2) }}>
                  <CampaignIcon />
                </Avatar>
                <Box>
                  <Typography variant="h4" fontWeight="700">
                    {stats.total}
                  </Typography>
                  <Typography variant="body2" sx={{ opacity: 0.8 }}>
                    Total Annonces
                  </Typography>
                </Box>
              </Stack>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{
            backgroundColor: pastelColors.success,
            color: pastelColors.text,
            borderRadius: 3,
            boxShadow: '0 4px 20px rgba(0,0,0,0.08)'
          }}>
            <CardContent>
              <Stack direction="row" alignItems="center" spacing={2}>
                <Avatar sx={{ backgroundColor: alpha(pastelColors.white, 0.2) }}>
                  <VisibilityIcon />
                </Avatar>
                <Box>
                  <Typography variant="h4" fontWeight="700">
                    {stats.published}
                  </Typography>
                  <Typography variant="body2" sx={{ opacity: 0.8 }}>
                    Publiées
                  </Typography>
                </Box>
              </Stack>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{
            backgroundColor: pastelColors.warning,
            color: pastelColors.text,
            borderRadius: 3,
            boxShadow: '0 4px 20px rgba(0,0,0,0.08)'
          }}>
            <CardContent>
              <Stack direction="row" alignItems="center" spacing={2}>
                <Avatar sx={{ backgroundColor: alpha(pastelColors.white, 0.2) }}>
                  <EditIcon />
                </Avatar>
                <Box>
                  <Typography variant="h4" fontWeight="700">
                    {stats.drafts}
                  </Typography>
                  <Typography variant="body2" sx={{ opacity: 0.8 }}>
                    Brouillons
                  </Typography>
                </Box>
              </Stack>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{
            backgroundColor: pastelColors.error,
            color: pastelColors.text,
            borderRadius: 3,
            boxShadow: '0 4px 20px rgba(0,0,0,0.08)'
          }}>
            <CardContent>
              <Stack direction="row" alignItems="center" spacing={2}>
                <Avatar sx={{ backgroundColor: alpha(pastelColors.white, 0.2) }}>
                  <ScheduleIcon />
                </Avatar>
                <Box>
                  <Typography variant="h4" fontWeight="700">
                    {stats.expired}
                  </Typography>
                  <Typography variant="body2" sx={{ opacity: 0.8 }}>
                    Expirées
                  </Typography>
                </Box>
              </Stack>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Barre de recherche et filtres */}
      <Card sx={{ mb: 3, borderRadius: 3, boxShadow: '0 4px 20px rgba(0,0,0,0.08)' }}>
        <CardContent>
          <TextField
            fullWidth
            variant="outlined"
            placeholder="Rechercher une annonce..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon sx={{ color: pastelColors.text }} />
                </InputAdornment>
              ),
            }}
            sx={{
              '& .MuiOutlinedInput-root': {
                borderRadius: 3,
                backgroundColor: pastelColors.white
              }
            }}
          />
        </CardContent>
      </Card>

      {/* Tableau des annonces */}
      <Card sx={{ borderRadius: 3, boxShadow: '0 4px 20px rgba(0,0,0,0.08)' }}>
        <CardContent sx={{ p: 0 }}>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow sx={{ backgroundColor: pastelColors.primary }}>
                  <TableCell sx={{ color: pastelColors.text, fontWeight: 700, fontSize: '1rem' }}>Titre</TableCell>
                  <TableCell sx={{ color: pastelColors.text, fontWeight: 700, fontSize: '1rem' }}>Priorité</TableCell>
                  <TableCell sx={{ color: pastelColors.text, fontWeight: 700, fontSize: '1rem' }}>Statut</TableCell>
                  <TableCell sx={{ color: pastelColors.text, fontWeight: 700, fontSize: '1rem' }}>Auteur</TableCell>
                  <TableCell sx={{ color: pastelColors.text, fontWeight: 700, fontSize: '1rem' }}>Dates</TableCell>
                  <TableCell sx={{ color: pastelColors.text, fontWeight: 700, fontSize: '1rem' }}>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredAnnouncements.map((announcement) => (
                  <TableRow
                    key={announcement.id}
                    sx={{
                      '&:hover': {
                        backgroundColor: alpha(pastelColors.primary, 0.05)
                      },
                      transition: 'background-color 0.2s ease'
                    }}
                  >
                    <TableCell>
                      <Typography variant="body1" fontWeight="600" color={pastelColors.text}>
                        {announcement.title}
                      </Typography>
                      <Typography variant="caption" color="textSecondary" sx={{ mt: 0.5, display: 'block' }}>
                        {announcement.message.substring(0, 60)}...
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Chip
                        label={announcement.priority.name}
                        color={getPriorityColor(announcement.priority.name)}
                        size="small"
                        sx={{
                          fontWeight: 600,
                          borderRadius: 2
                        }}
                      />
                    </TableCell>
                    <TableCell>
                      <Chip
                        label={announcement.draft ? 'Brouillon' : 'Publié'}
                        color={announcement.draft ? 'default' : 'success'}
                        variant={announcement.draft ? 'outlined' : 'filled'}
                        size="small"
                        sx={{
                          fontWeight: 600,
                          borderRadius: 2
                        }}
                      />
                    </TableCell>
                    <TableCell>
                      <Stack direction="row" alignItems="center" spacing={1}>
                        <Avatar sx={{ width: 32, height: 32, backgroundColor: pastelColors.secondary }}>
                          <PersonIcon sx={{ fontSize: 18 }} />
                        </Avatar>
                        <Typography variant="body2" fontWeight="500">
                          {announcement.author}
                        </Typography>
                      </Stack>
                    </TableCell>
                    <TableCell>
                      <Box>
                        <Typography variant="caption" display="block" fontWeight="600">
                          Pub: {new Date(announcement.published_at).toLocaleDateString('fr-FR')}
                        </Typography>
                        {announcement.expires_at && (
                          <Typography variant="caption" display="block" color="textSecondary">
                            Exp: {new Date(announcement.expires_at).toLocaleDateString('fr-FR')}
                          </Typography>
                        )}
                      </Box>
                    </TableCell>
                    <TableCell>
                      <Stack direction="row" spacing={1}>
                        <Tooltip title="Modifier">
                          <IconButton
                            size="small"
                            onClick={() => handleOpenDialog(announcement)}
                            sx={{
                              backgroundColor: pastelColors.primary,
                              color: pastelColors.text,
                              '&:hover': {
                                backgroundColor: alpha(pastelColors.primary, 0.8),
                                transform: 'scale(1.1)'
                              },
                              transition: 'all 0.2s ease'
                            }}
                          >
                            <EditIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Supprimer">
                          <IconButton
                            size="small"
                            onClick={() => handleDeleteAnnouncement(announcement.id)}
                            sx={{
                              backgroundColor: pastelColors.error,
                              color: pastelColors.text,
                              '&:hover': {
                                backgroundColor: alpha(pastelColors.error, 0.8),
                                transform: 'scale(1.1)'
                              },
                              transition: 'all 0.2s ease'
                            }}
                          >
                            <DeleteIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      </Stack>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          {filteredAnnouncements.length === 0 && !loading && (
            <Box sx={{ textAlign: 'center', py: 8 }}>
              <CampaignIcon sx={{ fontSize: 64, color: pastelColors.primary, mb: 2, opacity: 0.5 }} />
              <Typography variant="h6" color="textSecondary">
                {searchTerm ? 'Aucune annonce trouvée' : 'Aucune annonce créée'}
              </Typography>
              {!searchTerm && (
                <Button
                  startIcon={<AddIcon />}
                  onClick={() => handleOpenDialog()}
                  sx={{ mt: 2 }}
                >
                  Créer votre première annonce
                </Button>
              )}
            </Box>
          )}
        </CardContent>
      </Card>

      {/* Dialog de création/modification */}
      <Dialog
        open={openDialog}
        onClose={handleCloseDialog}
        maxWidth="md"
        fullWidth
        PaperProps={{
          sx: {
            borderRadius: 3,
            boxShadow: '0 20px 60px rgba(0,0,0,0.2)'
          }
        }}
      >
        <DialogTitle sx={{
          backgroundColor: pastelColors.primary,
          color: pastelColors.text,
          fontWeight: 700,
          fontSize: '1.5rem'
        }}>
          {editingAnnouncement ? '✏️ Modifier l\'annonce' : '📢 Créer une nouvelle annonce'}
        </DialogTitle>
        <DialogContent sx={{ p: 4, backgroundColor: pastelColors.background }}>
          <Stack spacing={3}>
            <TextField
              label="Titre *"
              value={formData.title}
              onChange={(e) => handleInputChange('title', e.target.value)}
              fullWidth
              variant="outlined"
              sx={{
                '& .MuiOutlinedInput-root': {
                  borderRadius: 2,
                  backgroundColor: pastelColors.white
                }
              }}
            />

            <TextField
              label="Message *"
              value={formData.message}
              onChange={(e) => handleInputChange('message', e.target.value)}
              multiline
              rows={4}
              fullWidth
              variant="outlined"
              sx={{
                '& .MuiOutlinedInput-root': {
                  borderRadius: 2,
                  backgroundColor: pastelColors.white
                }
              }}
            />

            <FormControl fullWidth>
              <InputLabel>Priorité</InputLabel>
              <Select
                value={formData.priority_name}
                label="Priorité"
                onChange={(e) => handleInputChange('priority_name', e.target.value)}
                sx={{
                  borderRadius: 2,
                  backgroundColor: pastelColors.white
                }}
              >
                {priorityOptions.map((option) => (
                  <MenuItem
                    key={option.value}
                    value={option.value}
                    sx={{ backgroundColor: option.color }}
                  >
                    {option.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <TextField
              label="Date d'expiration"
              type="date"
              value={formData.expires_at}
              onChange={(e) => handleInputChange('expires_at', e.target.value)}
              InputLabelProps={{ shrink: true }}
              fullWidth
              sx={{
                '& .MuiOutlinedInput-root': {
                  borderRadius: 2,
                  backgroundColor: pastelColors.white
                }
              }}
            />

            <FormControlLabel
              control={
                <Switch
                  checked={formData.draft}
                  onChange={(e) => handleInputChange('draft', e.target.checked)}
                  color="primary"
                />
              }
              label="Marquer comme brouillon"
              sx={{ color: pastelColors.text }}
            />
          </Stack>
        </DialogContent>
        <DialogActions sx={{ p: 3, backgroundColor: pastelColors.white }}>
          <Button
            onClick={handleCloseDialog}
            sx={{
              color: pastelColors.text,
              fontWeight: 600
            }}
          >
            Annuler
          </Button>
          <Button
            onClick={handleSubmit}
            variant="contained"
            sx={{
              backgroundColor: pastelColors.primary,
              color: pastelColors.text,
              borderRadius: 2,
              px: 4,
              py: 1,
              fontWeight: 600,
              fontSize: '1rem',
              '&:hover': {
                backgroundColor: alpha(pastelColors.primary, 0.8),
                transform: 'translateY(-1px)'
              },
              transition: 'all 0.2s ease'
            }}
          >
            {editingAnnouncement ? 'Modifier' : 'Créer'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar pour les notifications */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          sx={{
            borderRadius: 3,
            fontWeight: 600
          }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default AnnouncementsAdmin;