import { useState } from "react";
import { TableCell, Button } from "@mui/material";

type Props = {
  text: string;
};

const ShortTextCell = ({ text }: Props) => {
  const [showFull, setShowFull] = useState(false);
  const shortText = text.length > 30 ? text.slice(0, 30) + "..." : text;

  return (
    <TableCell>
      {showFull ? text : shortText}
      {text.length > 30 && (
        <Button size="small" onClick={() => setShowFull(!showFull)}>
          {showFull ? "Moins" : "Plus"}
        </Button>
      )}
    </TableCell>
  );
};

export default ShortTextCell;
