export const pastelTheme = {
  primary: "#99caff",
  secondary: "#a8e6b1",
  accent: "#f3aebd",
  surface: "#fce38a",
  background: "#F5F7FA",
  surfaceVariant: "#ffb3b3",
  outline: "#D1D5DB",
  shadow: "rgba(0, 0, 0, 0.1)",
  cardBackground: "#FFFFFF",
  textPrimary: "#2D3748",
  textSecondary: "#4A5568",
};

export const colors = {
  entity: "#fce38a",
  pole: "#c6b3ff",
  domain: "#b3ffcc",
  solution: "#b3e6ff",
  namespace: "#a8e6b1",
  deployment: "#f3aebd",
  server: "#99caff",
  pod: "#ffd699",
};

export const darkColors = {
  entity: "#f5d95a",
  pole: "#b399ff",
  domain: "#99e6b3",
  solution: "#99d6ff",
  namespace: "#90d69e",
  deployment: "#e39eae",
  server: "#7fb2e6",
  pod: "#ffc266",
};

export const envColors = {
  Production: "#ffb3b3",
  Préproduction: "#ffd699",
  Intégration: "#b3e6ff",
  Recette: "#c6b3ff",
  Développement: "#a8e6b1",
  TNR: "#f4bfff",
  Technique: "#a9c0d9",
  Formation: "#ffe6cc",
};

export const osColors = {
  Windows: "#99caff",
  Linux: "#a8e6b1",
  MacOS: "#f3aebd",
  Aix: "#fce38a",
  Default: "#7fb2e6",
};
