// src/pages/sub-pages/admin/PolePage.tsx

import { FC } from "react";

import PoleDataTable from "@/components/data-tables/PoleDataTable";

const PolePage: FC = () => {
  return <PoleDataTable />;
};

export default PolePage;
