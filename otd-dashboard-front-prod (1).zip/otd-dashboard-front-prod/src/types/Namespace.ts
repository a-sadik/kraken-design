/* eslint-disable @typescript-eslint/no-empty-object-type */
export interface Namespace {
  [x: string]: any;
  solutions: never[];
  id: number;
  solution: string[];
  solution_name: string;
  name: string;
  environment: string;
}

export interface Pod {
  id: number;
  pod_uid: string;
  pod_name: string;
  nodeName: string;
  creationTimestamp: string;
  labels: Labels;
  restartPolicy: string;
  securityContext: SecurityContext;
  phase: string;
  hostIP: string;
  hostIPs: HostIP[];
  podIP: string;
  podIPs: HostIP[];
  limitCPU: string | null;
  limitRAM: string | null;
  requestCPU: string | null;
  requestRAM: string | null;
  startTime: string;
  containerStatuses: ContainerStatus[];
  namespace: number;
  deployment: number;
}

export interface ContainerStatus {
  name: string;
  image: string;
  ready: boolean;
  state: State;
  imageID: string;
  started: boolean;
  lastState: LastState;
  containerID: string;
  restartCount: number;
}

export type LastState = {};

export interface State {
  running: Running;
}

export interface Running {
  startedAt: string;
}

export interface HostIP {
  ip: string;
}

export interface SecurityContext {
  fsGroup: number;
  seLinuxOptions: SeLinuxOptions;
  seccompProfile: SeccompProfile;
}

export interface SeccompProfile {
  type: string;
}

export interface SeLinuxOptions {
  level: string;
}

export interface Labels {
  app: string;
  "pod-template-hash": string;
}

export interface Solution {
  solutions: string | number | readonly string[] | undefined;
  solution_popularity: string;
  solution_id: number | string | null | undefined;
  solution_name: string | number | readonly string[] | undefined;
}
