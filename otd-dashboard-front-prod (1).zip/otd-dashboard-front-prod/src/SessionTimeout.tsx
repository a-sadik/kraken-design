// src/SessionTimeout.tsx
import React, { useEffect, useRef, useState } from "react";
import { keycloak } from "@/auth/keycloakConnectAdapter";

type Props = {
  /** Délai d'inactivité avant d'afficher le compte à rebours (en ms) */
  idleMs?: number;
  /** Durée du compte à rebours (secondes) */
  countdownSeconds?: number;
  /** Affichage en overlay (true) ou inline (false) */
  overlay?: boolean;
};

const SessionTimeout: React.FC<Props> = ({
  idleMs = 60 * 1000,   // 1 minute d'inactivité avant le prompt
  countdownSeconds = 10, // ⭐ 10 secondes de compte à rebours
  overlay = true,
}) => {
  const [showCountdown, setShowCountdown] = useState(false);
  const [remaining, setRemaining] = useState(countdownSeconds);
  const [progress, setProgress] = useState(0); // 0 → 100 (%)

  const idleTimerRef = useRef<number | null>(null);
  const countdownTimerRef = useRef<number | null>(null);
  const progressTimerRef = useRef<number | null>(null);
  const isLoggingOutRef = useRef(false);
  const lastActivityRef = useRef<number>(Date.now()); // AJOUT

  // ---- Helpers timers
  const clearIdleTimer = () => {
    if (idleTimerRef.current !== null) {
      window.clearTimeout(idleTimerRef.current);
      idleTimerRef.current = null;
    }
  };
  const clearCountdownTimer = () => {
    if (countdownTimerRef.current !== null) {
      window.clearInterval(countdownTimerRef.current);
      countdownTimerRef.current = null;
    }
  };
  const clearProgressTimer = () => {
    if (progressTimerRef.current !== null) {
      window.clearInterval(progressTimerRef.current);
      progressTimerRef.current = null;
    }
  };

  const startIdleTimer = () => {
    clearIdleTimer();
    idleTimerRef.current = window.setTimeout(() => {
      // Inactivité atteinte → on démarre le compte à rebours
      setRemaining(countdownSeconds);
      setProgress(0);
      setShowCountdown(true);
    }, idleMs);
  };

  const stopCountdown = () => {
    setShowCountdown(false);
    setRemaining(countdownSeconds);
    setProgress(0);
    clearCountdownTimer();
    clearProgressTimer();
  };

  const resetAll = () => {
    // Appelé sur activité utilisateur
    lastActivityRef.current = Date.now(); // AJOUT
    stopCountdown();
    startIdleTimer();
  };

  // ---- Listeners d'activité : annule le compte à rebours et relance l'inactivité
  useEffect(() => {
    startIdleTimer();

    const activityEvents: (keyof WindowEventMap)[] = [
      "mousemove",
      "mousedown",
      "keydown",
      "touchstart",
      "scroll",
      "click",
      "wheel",
    ];

    const onActivity = () => {
      resetAll();
    };

    // AJOUT : Fonction pour gérer quand l'utilisateur revient sur l'onglet
    const handleVisibilityChange = () => {
      if (document.hidden) {
        // L'utilisateur quitte la page : on arrête tout
        clearIdleTimer();
        clearCountdownTimer();
        clearProgressTimer();
      } else {
        // L'utilisateur revient sur la page
        const timeInactive = Date.now() - lastActivityRef.current;

        // Si plus d'1h d'inactivité (idleMs), déconnexion IMMÉDIATE
        if (timeInactive >= idleMs) {
          if (!isLoggingOutRef.current) {
            isLoggingOutRef.current = true;
            keycloak.logout().finally(() => {
              window.location.href = window.location.origin;
            });
          }
        } else {
          // Sinon, redémarrer normalement
          resetAll();
        }
      }
    };

    activityEvents.forEach((evt) =>
      window.addEventListener(evt, onActivity, { passive: true })
    );

    // AJOUT : Écouter le changement de visibilité
    document.addEventListener("visibilitychange", handleVisibilityChange);

    return () => {
      clearIdleTimer();
      clearCountdownTimer();
      clearProgressTimer();
      activityEvents.forEach((evt) =>
        window.removeEventListener(evt, onActivity)
      );
      // AJOUT : Retirer l'écouteur
      document.removeEventListener("visibilitychange", handleVisibilityChange);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [idleMs, countdownSeconds]);

  // ---- Démarrage/gestion du compte à rebours
  useEffect(() => {
    if (!showCountdown) return;

    clearCountdownTimer();
    clearProgressTimer();

    // Tique chaque seconde
    countdownTimerRef.current = window.setInterval(() => {
      setRemaining((prev) => prev - 1);
    }, 1000);

    // Progression lissée (par pas de 100ms pour un effet fluide)
    const totalMs = countdownSeconds * 1000;
    const stepMs = 100;
    let elapsed = 0;
    progressTimerRef.current = window.setInterval(() => {
      elapsed += stepMs;
      const pct = Math.min(100, Math.round((elapsed / totalMs) * 100));
      setProgress(pct);
    }, stepMs);

    return () => {
      clearCountdownTimer();
      clearProgressTimer();
    };
  }, [showCountdown, countdownSeconds]);

  // ---- Quand le compte à rebours arrive à 0 → logout + redirection
  useEffect(() => {
    if (!showCountdown) return;
    if (remaining > 0) return;
    if (isLoggingOutRef.current) return;

    isLoggingOutRef.current = true;
    clearCountdownTimer();
    clearProgressTimer();
    clearIdleTimer();

    (async () => {
      try {
        await keycloak.logout(); // appel direct, sans onClick
      } catch (e) {
        console.warn("Logout Keycloak a échoué:", e);
      } finally {
        window.location.href = window.location.origin; // racine de l'app
      }
    })();
  }, [remaining, showCountdown]);

  if (!showCountdown) return null;

  // ---- Styles UI
  const cardStyles: React.CSSProperties = {
    background: "linear-gradient(135deg, #0f172a 0%, #1f2937 100%)", // bleu nuit → gris foncé
    color: "white",
    borderRadius: 14,
    padding: "18px 20px",
    boxShadow: "0 16px 40px rgba(0,0,0,0.35)",
    fontFamily:
      "system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif",
    display: "grid",
    gridTemplateColumns: "56px 1fr auto",
    alignItems: "center",
    gap: 16,
    width: "min(92vw, 540px)",
    border: "1px solid rgba(255,255,255,0.08)",
    backdropFilter: "blur(6px)",
  };

  const badgeStyles: React.CSSProperties = {
    display: "inline-flex",
    width: 56,
    height: 56,
    borderRadius: "50%",
    background:
      "radial-gradient(circle at 30% 30%, #ef4444, #b91c1c)", // rouge dégradé
    alignItems: "center",
    justifyContent: "center",
    fontWeight: 800,
    fontSize: 20,
    boxShadow: "0 6px 16px rgba(239,68,68,0.5)",
  };

  const titleStyles: React.CSSProperties = {
    fontWeight: 700,
    fontSize: 18,
    letterSpacing: 0.2,
  };

  const subtitleStyles: React.CSSProperties = {
    fontSize: 13.5,
    opacity: 0.92,
    marginTop: 4,
    lineHeight: 1.4,
  };

  const buttonStyles: React.CSSProperties = {
    background:
      "linear-gradient(90deg, #10b981 0%, #059669 100%)", // vert
    color: "white",
    border: "none",
    borderRadius: 10,
    padding: "10px 14px",
    cursor: "pointer",
    fontWeight: 700,
    fontSize: 13.5,
    boxShadow: "0 8px 20px rgba(16,185,129,0.35)",
    transition: "transform 120ms ease, filter 120ms ease",
  };

  const progressTrack: React.CSSProperties = {
    gridColumn: "1 / -1",
    marginTop: 12,
    height: 8,
    borderRadius: 999,
    background: "rgba(255,255,255,0.15)",
    overflow: "hidden",
  };

  const progressBar: React.CSSProperties = {
    height: "100%",
    width: `${progress}%`,
    background:
      "linear-gradient(90deg, #f59e0b 0%, #ef4444 50%, #b91c1c 100%)", // amber→rouge
    transition: "width 100ms linear",
  };

  const Content = (
    <div style={cardStyles}>
      <span style={badgeStyles} aria-live="polite">
        {remaining}
      </span>

      <div>
        <div style={titleStyles}>Déconnexion imminente</div>
        <div style={subtitleStyles}>
          Inactivité détectée. Déconnexion dans {remaining} seconde
          {remaining > 1 ? "s" : ""}.

          Bougez la souris ou appuyez sur une touche pour rester connecté.
        </div>

        <div style={progressTrack} aria-hidden>
          <div style={progressBar} />
        </div>
      </div>

      <button
        type="button"
        onClick={resetAll}
        style={buttonStyles}
        onMouseDown={(e) => {
          // effet press
          (e.currentTarget.style.transform = "scale(0.98)");
        }}
        onMouseUp={(e) => {
          (e.currentTarget.style.transform = "scale(1)");
        }}
        onMouseEnter={(e) => {
          (e.currentTarget.style.filter = "brightness(1.05)");
        }}
        onMouseLeave={(e) => {
          (e.currentTarget.style.filter = "brightness(1.0)");
        }}
      >
        Rester connecté
      </button>
    </div>
  );

  if (!overlay) {
    // Inline (s'affiche où <SessionTimeout /> est monté)
    return <>{Content}</>;
  }

  // Overlay centré
  return (
    <div
      role="dialog"
      aria-modal="true"
      style={{
        position: "fixed",
        inset: 0,
        display: "grid",
        placeItems: "center",
        background:
          "linear-gradient(180deg, rgba(0,0,0,0.25), rgba(0,0,0,0.45))",
        zIndex: 9999,
      }}
    >
      {Content}
    </div>
  );
};

export default SessionTimeout;