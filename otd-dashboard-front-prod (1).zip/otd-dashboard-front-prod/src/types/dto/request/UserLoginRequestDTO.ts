// src/types/dto/request/UserLoginRequestDTO.ts

export interface UserLoginRequestDTO {
  nom: string;
  prenom: string;
}
