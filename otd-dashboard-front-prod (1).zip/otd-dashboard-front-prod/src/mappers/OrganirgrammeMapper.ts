// src/mappers/OrganigrammeMapper.ts

import { OrganigrammeResponseDTO } from "@/types/dto/OrganigrammeDTO";
import OrganigrammeView from "@/types/view/OrganigrammeView ";

// mapper from backstage response dto to backstage view
export const organigrammeResToView = (
  data: OrganigrammeResponseDTO[],
): OrganigrammeView[] => {
  return data.map((item) => ({
    name: item.name || item.title || "-",
  }));
};
