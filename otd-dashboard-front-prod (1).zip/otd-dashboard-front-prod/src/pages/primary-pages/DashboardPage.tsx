// src/pages/DashboardPage.tsx

import { useEffect, useState } from "react";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";

// import files
import CustomLoading from "@/components/basics/CustomLoading";
import WidgetMainContainer from "@/components/containers/WidgetMainContainer";
import ProjectAmountsCard from "@/components/cards/ProjectAmountsCard";
import ProjectAmountsModal from "@/components/modals/ProjectAmountsModal";
import CustomTypography from "@/components/basics/CustomTypography";
import { getAWBProjectAmounts } from "@/services/project-amounts/AWBProjectAmountsService";
import { getBDIProjectAmounts } from "@/services/project-amounts/BDIProjectAmountsService";
import { ProjectAmountsResponseDTO } from "@/types/dto/response/ProjectAmountsResponseDTO";

export default function DashboardPage() {
  const [AwbData, setAwbData] = useState<ProjectAmountsResponseDTO[]>([]);
  const [BdiData, setBdiData] = useState<ProjectAmountsResponseDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [collapsedAwb, setCollapsedAwb] = useState(true);
  const [collapsedBdi, setCollapsedBdi] = useState(true);
  const [open, setOpen] = useState(false);
  const [modalContent, setModalContent] = useState<ProjectAmountsResponseDTO>();
  const [selectedEntity, setSelectedEntity] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [AWB, BDI] = await Promise.all([
          getAWBProjectAmounts(),
          getBDIProjectAmounts(),
        ]);
        setAwbData(AWB);
        setBdiData(BDI);
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (loading) {
    return (
      <>
        <CustomLoading />
      </>
    );
  }

  const handleToggleCollapseAwb = () => {
    setCollapsedAwb(!collapsedAwb);
  };

  const handleToggleCollapseBdi = () => {
    setCollapsedBdi(!collapsedBdi);
  };

  const handleOpenModal = (item: ProjectAmountsResponseDTO, entity: string) => {
    setModalContent(item);
    setOpen(true);
    setSelectedEntity(entity);
  };

  const handleCloseModal = () => {
    setOpen(false);
    setModalContent(undefined);
  };

  const maxVisibleCards = collapsedAwb ? 12 : AwbData.length;

  const customTheme = createTheme({
    palette: {
      primary: { main: "#1a1a1a" },
    },
  });

  return (
    <>
      {/* Card list of AWB */}
      <WidgetMainContainer>
        <CustomTypography text="Pôles d'AWB" color="dark" />
        <Box
          sx={{
            display: "grid",
            gap: 2,
            gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
            justifyContent: "center",
            alignItems: "center",
            padding: 2,
          }}
        >
          {AwbData.slice(0, maxVisibleCards).map((item) => (
            <div
              key={1}
              onClick={() => handleOpenModal(item, "Pôle")}
              style={{ cursor: "pointer" }}
            >
              <ProjectAmountsCard project_amounts={item} />
            </div>
          ))}
        </Box>

        {AwbData.length > 12 && (
          <ThemeProvider theme={customTheme}>
            <Button
              onClick={handleToggleCollapseAwb}
              variant="outlined"
              endIcon={
                <ExpandMoreIcon
                  sx={{
                    transform: collapsedAwb ? "rotate(0deg)" : "rotate(180deg)",
                    transition: "transform 0.3s",
                  }}
                />
              }
            >
              {collapsedAwb ? "Afficher tout" : "Masquer"}
            </Button>
          </ThemeProvider>
        )}
      </WidgetMainContainer>

      {/* Card list of BDI */}
      <WidgetMainContainer>
        <CustomTypography text="Filiales de BDI" color="dark" />
        <Box
          sx={{
            display: "grid",
            gap: 2,
            gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
            justifyContent: "center",
            alignItems: "center",
            padding: 2,
          }}
        >
          {BdiData.slice(0, maxVisibleCards).map((item) => (
            <div
              key={2}
              onClick={() => handleOpenModal(item, "Filiale")}
              style={{ cursor: "pointer" }}
            >
              <ProjectAmountsCard project_amounts={item} />
            </div>
          ))}
        </Box>
        {BdiData.length > 12 && (
          <ThemeProvider theme={customTheme}>
            <Button
              onClick={handleToggleCollapseBdi}
              variant="outlined"
              endIcon={
                <ExpandMoreIcon
                  sx={{
                    transform: collapsedBdi ? "rotate(0deg)" : "rotate(180deg)",
                    transition: "transform 0.3s",
                  }}
                />
              }
            >
              {collapsedBdi ? "Afficher tout" : "Masquer"}
            </Button>
          </ThemeProvider>
        )}
      </WidgetMainContainer>

      {/* Modal */}
      <ProjectAmountsModal
        open={open}
        onClose={handleCloseModal}
        modalContent={modalContent!}
        entity={selectedEntity!}
      />
    </>
  );
}
