// src/components/forms/certificates/CreateExternCertificateForm.tsx

import { useEffect, useState } from "react";
import { useForm, Controller, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z as zod } from "zod";
import AddIcon from "@mui/icons-material/Add";
import {
  TextField,
  Button,
  Grid,
  Autocomplete,
  Typography,
  CircularProgress,
  Box,
  Stack,
  Alert,
  InputAdornment,
  IconButton,
  Divider,
  FormControl,
  RadioGroup,
  FormControlLabel,
  Radio,
  Collapse,
  Paper,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";

import KeyIcon from "@mui/icons-material/Key";
import SkipNextIcon from "@mui/icons-material/SkipNext";

// imports files
import { SolutionDetailResponseDTO } from "@/types/dto/response/solution/SolutionDetailResponseDTO";
import { DomainNameResponseDTO } from "@/types/dto/response/DomainNameResponseDTO";
import { getAllSolutions } from "@/services/SolutionService";
import { getAllDomaineNames } from "@/services/DomainNameService";

// import messages
import {
  required_domain_name_select,
  required_certificate_target,
  required_common_name,
  required_dns_max_lenght,
  MAX_DNS_LENGTH,
  required_dns_max_nbr,
  required_dns_min_lenght,
  required_dns_min_nbr,
  required_one_solution,
  required_unique_dns,
} from "@/utils/customMessages";
import {
  placeholder_common_name,
  placeholder_domain_name_select,
  placeholder_one_solution,
} from "@/utils/customMessages";

function formatPrivateKeyForJson(privateKey: string): string {
  if (!privateKey) return "";

  return privateKey
    .trim()
    .replace(/\r\n/g, "\n") // Normaliser les retours à la ligne Windows
    .replace(/\n/g, "\\n"); // Échapper les retours à la ligne pour JSON
}

function formatPrivateKeyForDisplay(privateKey: string): string {
  if (!privateKey) return "";

  return privateKey.replace(/\\n/g, "\n"); // Convertir les \n échappés en vrais retours à la ligne
}

// Types pour les options de clé
type KeyOption = "skip" | "existing";

function isValidCommonName(value: string): boolean {
  const regex = /^[a-zA-Z0-9][a-zA-Z0-9.-]*$/;
  return regex.test(value) && value.length >= 1;
}

function isValidDns(value: string): boolean {
  const regex = /^[a-zA-Z0-9.-]{5,}\.[a-zA-Z]{2,}$/;
  return regex.test(value);
}

// Fonction pour valider le format de la clé privée
function isValidPrivateKey(key: string): boolean {
  const trimmedKey = key.trim();

  // Vérifier les formats de clé privée les plus courants
  const patterns = [
    // RSA Private Key
    /^-----BEGIN RSA PRIVATE KEY-----[\s\S]*-----END RSA PRIVATE KEY-----$/,
    // Private Key (PKCS#8)
    /^-----BEGIN PRIVATE KEY-----[\s\S]*-----END PRIVATE KEY-----$/,
    // Encrypted Private Key
    /^-----BEGIN ENCRYPTED PRIVATE KEY-----[\s\S]*-----END ENCRYPTED PRIVATE KEY-----$/,
    // EC Private Key
    /^-----BEGIN EC PRIVATE KEY-----[\s\S]*-----END EC PRIVATE KEY-----$/,
    // OpenSSH Private Key
    /^-----BEGIN OPENSSH PRIVATE KEY-----[\s\S]*-----END OPENSSH PRIVATE KEY-----$/,
  ];

  const isFormatValid = patterns.some((pattern) => pattern.test(trimmedKey));
  if (!isFormatValid) return false;

  // Vérification de la longueur totale
  const minLength = 800;
  const maxLength = 5000;
  if (trimmedKey.length < minLength || trimmedKey.length > maxLength)
    return false;

  // Vérification des lignes de 64 caractères (hors en-têtes/pieds)
  const lines = trimmedKey.split("\n").map((line) => line.trim());
  const bodyLines = lines.filter(
    (line) =>
      !line.startsWith("-----BEGIN") &&
      !line.startsWith("-----END") &&
      line.length > 0,
  );

  const allLinesValid = bodyLines
    .slice(0, -1)
    .every((line) => line.length === 64);
  const lastLineValid =
    bodyLines.length === 0 || bodyLines[bodyLines.length - 1].length <= 64;

  return allLinesValid && lastLineValid;
}

// Schéma de validation avec Zod
const getFormSchema = (isDeleteMode: boolean, keyOption: KeyOption) =>
  zod.object({
    certificate_target: isDeleteMode
      ? zod.string().optional()
      : zod.string().trim().min(1),
    // Nouveau champ pour l'option de clé
    key_option: zod.enum(["skip", "existing"]),
    // Nouveau champ pour la clé existante
    certificate_key:
      keyOption === "existing"
        ? zod
          .string()
          .min(1, "La clé privée est requise")
          .refine(isValidPrivateKey, {
            message:
              "Format de clé privée invalide. La clé doit être au format PEM valide.",
          })
        : zod.string().optional(),
    // field 1 - Common name modifié pour accepter les nombres
    common_name: isDeleteMode
      ? zod.string().optional()
      : zod
        .string()
        .trim()
        .min(1, required_common_name)
        .refine(isValidCommonName, {
          message:
            "Le nom commun doit contenir uniquement des lettres, chiffres, points et tirets, et commencer par une lettre ou un chiffre",
        }),
    // field 2
    domain_name: isDeleteMode
      ? zod
        .object({
          domain_name_id: zod.number(),
          domain_name_value: zod.string(),
        })
        .optional()
      : zod
        .union([
          zod.object({
            domain_name_id: zod.number(),
            domain_name_value: zod.string(),
          }),
          zod.literal(null),
        ])
        .refine((val) => val !== null, {
          message: required_domain_name_select,
        }),
    // field 3 - DNS modifié pour accepter les nombres
    dns: isDeleteMode
      ? zod.array(zod.string()).optional()
      : zod
        .array(
          zod
            .string()
            .min(1, required_dns_min_lenght)
            .max(MAX_DNS_LENGTH, required_dns_max_lenght)
            .refine(isValidDns, {
              message:
                "Le DNS doit être un nom de domaine valide (ex: test-2.example.com)",
            }),
        )
        .min(1, required_one_solution)
        .min(1, required_dns_min_nbr)
        .max(5, required_dns_max_nbr)
        .refine(
          (values) => {
            // Vérifier les doublons dans les DNS
            const uniqueValues = new Set(values);
            return uniqueValues.size === values.length;
          },
          { message: required_unique_dns },
        ),
    // field 4
    certificate_type: isDeleteMode
      ? zod.string().optional()
      : zod
        .union([zod.string(), zod.literal(null)])
        .refine((val) => val !== null, {
          message: required_certificate_target,
        }),
    // field 5
    description: isDeleteMode
      ? zod.string().optional()
      : zod.string().trim().min(1),
    // field 6
    solution: isDeleteMode
      ? zod
        .object({
          solution_id: zod.number(),
          solution_name: zod.string(),
          solution_popularity: zod.string(),
        })
        .optional()
      : zod
        .union([
          zod.object({
            solution_id: zod.number(),
            solution_name: zod.string(),
            solution_popularity: zod.string(),
          }),
          zod.literal(null),
        ])
        .refine((val) => val !== null, { message: required_one_solution }),
  });

export type ExternCertificateFormData = zod.infer<
  ReturnType<typeof getFormSchema>
>;

const CustomFormLabel = ({
  label,
  isRequired = false,
}: {
  label: string;
  isRequired?: boolean;
}) => (
  <Typography
    variant="body1"
    sx={{
      fontWeight: "bold",
      display: "flex",
      alignItems: "center",
      mb: "0.5rem",
      fontSize: "1.2rem",
    }}
  >
    {label}
    {isRequired && (
      <span style={{ color: "var(--error-color)", marginLeft: 2 }}>*</span>
    )}
  </Typography>
);

interface ExternCertificateFormProps {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  initialData: any;
  onSubmit: (data: ExternCertificateFormData) => void;
  isEditMode: boolean;
  isViewMode: boolean;
  isDeleteMode: boolean;
  errorMessage: string | null;
}

export function ExternCertificateForm({
  initialData,
  onSubmit,
  isEditMode,
  isViewMode,
  isDeleteMode,
  errorMessage,
}: ExternCertificateFormProps) {
  const [keyOption, setKeyOption] = useState<KeyOption>("skip");
  const formSchema = getFormSchema(isDeleteMode, keyOption);

  const {
    control,
    register,
    handleSubmit,
    formState: { errors, isValid },
    setValue,
    watch,
    trigger,
    setError,
    clearErrors,
  } = useForm<ExternCertificateFormData>({
    resolver: zodResolver(formSchema),
    mode: "all",
    defaultValues: initialData || {
      certificate_target: "Externe",
      key_option: "skip",
      certificate_key: "",
      common_name: "",
      domain_name: null,
      dns: [""],
      solution: null,
      description: "",
      certificate_type: "TypeExterne",
    },
  });

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { fields, append, remove } = useFieldArray<any | null>({
    control,
    name: "dns",
  });

  const watchCommonName = watch("common_name");
  const watchDomainName = watch("domain_name");
  const watchDns = watch("dns");
  const watchKeyOption = watch("key_option");
  const watchExistingKey = watch("certificate_key");

  // Mettre à jour keyOption quand la valeur du formulaire change
  useEffect(() => {
    if (watchKeyOption !== keyOption) {
      setKeyOption(watchKeyOption as KeyOption);
    }
  }, [watchKeyOption, keyOption]);

  // État pour suivre si le champ DNS a été touché
  const [dnsTouched, setDnsTouched] = useState<boolean>(false);

  // Auto-populate first DNS with common name and domain name
  useEffect(() => {
    if (watchCommonName && watchDomainName) {
      const firstDNS = `${watchCommonName}${watchDomainName.domain_name_value}`;
      setValue("dns.0", firstDNS);
      trigger("dns");
    }
  }, [watchCommonName, watchDomainName, setValue, trigger]);

  // Validation de la clé existante en temps réel
  useEffect(() => {
    if (keyOption === "existing" && watchExistingKey) {
      if (!isValidPrivateKey(watchExistingKey)) {
        setError("certificate_key", {
          type: "validation",
          message:
            "Format de clé privée invalide. Vérifiez que la clé est au format PEM valide.",
        });
      } else {
        clearErrors("certificate_key");
      }
    }
  }, [watchExistingKey, keyOption, setError, clearErrors]);

  // Vérification de l'unicité des DNS après chaque modification
  useEffect(() => {
    if (dnsTouched && !isDeleteMode && watchDns && watchDns.length > 1) {
      // Vérifier les doublons
      const uniqueDns = new Set(
        watchDns.filter((dns) => dns && dns.trim() !== ""),
      );

      if (
        uniqueDns.size !==
        watchDns.filter((dns) => dns && dns.trim() !== "").length
      ) {
        setError("dns", {
          type: "custom",
          message: "Les DNS doivent être uniques",
        });
      } else {
        // Vérifier que chaque DNS est valide
        const invalidDns = watchDns.filter(
          (dns) => dns && dns.trim() !== "" && !isValidDns(dns),
        );
        if (invalidDns.length > 0) {
          setError("dns", {
            type: "custom",
            message:
              "Chaque DNS doit être un nom de domaine valide (ex: test-2.example.com, api-v1.domain.org)",
          });
        } else {
          clearErrors("dns");
        }
      }
    }
  }, [watchDns, isDeleteMode, setError, clearErrors, dnsTouched]);

  // S'assurer que le tableau DNS a toujours au moins un élément
  useEffect(() => {
    if (fields.length === 0) {
      append("");
    }
  }, [fields.length, append]);

  const controlledFields = fields.map((field, index) => {
    return {
      ...field,
      isFirstfield: index === 0,
      watchFieldArray: watch(`dns.${index}`),
    };
  });

  useEffect(() => {
    if (initialData) {
      Object.keys(initialData).forEach((key) => {
        let value = initialData[key as keyof ExternCertificateFormData];

        // Formatter la clé privée pour l'affichage
        if (key === "certificate_key" && typeof value === "string") {
          value = formatPrivateKeyForDisplay(value);
        }

        setValue(key as keyof ExternCertificateFormData, value);
      });

      if (!initialData.dns || initialData.dns.length === 0) {
        setValue("dns", [""]);
      }
    }
  }, [initialData, setValue]);

  // loading data from api
  const [solutions, setSolutions] = useState<SolutionDetailResponseDTO[]>([]);
  const [loadSolutions, setLoadSolutions] = useState<boolean>(false);
  const [domainNames, setDomainNames] = useState<DomainNameResponseDTO[]>([]);
  const [loadDomainNames, setLoadDomainNames] = useState<boolean>(false);

  const fetchSolutions = async () => {
    setLoadSolutions(true);
    try {
      const solutionData: SolutionDetailResponseDTO[] = await getAllSolutions();

      if (Array.isArray(solutionData)) {
        setSolutions(solutionData);
      } else {
        console.error(
          "Les données reçues ne sont pas un tableau",
          solutionData,
        );
        setSolutions([]);
      }
    } catch (error) {
      console.error("Erreur lors du chargement des solutions :", error);
      setSolutions([]);
    } finally {
      setLoadSolutions(false);
    }
  };

  const fetchDomainNames = async () => {
    setLoadDomainNames(true);
    try {
      const domainNameData: DomainNameResponseDTO[] =
        await getAllDomaineNames();

      if (Array.isArray(domainNameData)) {
        setDomainNames(domainNameData);
      } else {
        console.error(
          "Les données reçues ne sont pas un tableau",
          domainNameData,
        );
        setDomainNames([]);
      }
    } catch (error) {
      console.error("Erreur lors du chargement des domaine names :", error);
      setDomainNames([]);
    } finally {
      setLoadDomainNames(false);
    }
  };

  // Fonction pour valider si on peut ajouter un nouveau DNS

  return (
    <form
      onSubmit={handleSubmit((data) => {
        // Formatter la clé privée avant l'envoi
        if (data.certificate_key) {
          data.certificate_key = formatPrivateKeyForJson(data.certificate_key);
        }
        onSubmit(data);
      })}
    >
      <Grid container spacing={2}>
        {!isDeleteMode ? (
          <>
            {/* Section Clé Privée */}
            <Grid item xs={12}>
              <Paper
                elevation={1}
                sx={{ p: 3, mb: 2, backgroundColor: "#f8f9fa" }}
              >
                <CustomFormLabel label="Gestion de la clé privée" isRequired />
                <FormControl component="fieldset">
                  <Controller
                    name="key_option"
                    control={control}
                    render={({ field }) => (
                      <RadioGroup
                        {...field}
                        row
                        onChange={(e) => {
                          field.onChange(e.target.value);
                          setKeyOption(e.target.value as KeyOption);
                          if (e.target.value === "skip") {
                            setValue("certificate_key", "");
                            clearErrors("certificate_key");
                          }
                        }}
                      >
                        <FormControlLabel
                          value="skip"
                          control={<Radio />}
                          label={
                            <Box
                              sx={{
                                display: "flex",
                                alignItems: "center",
                                gap: 1,
                              }}
                            >
                              <SkipNextIcon />
                              <Typography>Générer une nouvelle clé</Typography>
                            </Box>
                          }
                          disabled={isViewMode}
                        />
                        <FormControlLabel
                          value="existing"
                          control={<Radio />}
                          label={
                            <Box
                              sx={{
                                display: "flex",
                                alignItems: "center",
                                gap: 1,
                              }}
                            >
                              <KeyIcon />
                              <Typography>
                                Utiliser une clé existante
                              </Typography>
                            </Box>
                          }
                          disabled={isViewMode}
                        />
                      </RadioGroup>
                    )}
                  />
                </FormControl>

                {/* Champ pour la clé existante */}
                <Collapse in={keyOption === "existing"}>
                  <Box sx={{ mt: 2 }}>
                    <TextField
                      {...register("certificate_key")}
                      label="Clé privée existante"
                      placeholder="-----BEGIN PRIVATE KEY-----
MIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQC7...
-----END PRIVATE KEY-----"
                      multiline
                      rows={8}
                      fullWidth
                      variant="outlined"
                      error={!!errors.certificate_key}
                      helperText={
                        errors.certificate_key?.message ||
                        "Collez votre clé privée au format PEM. Les formats supportés : RSA, PKCS#8, EC, OpenSSH."
                      }
                      disabled={isViewMode}
                      sx={{
                        "& .MuiInputBase-input": {
                          fontFamily: 'Monaco, Menlo, "Ubuntu Mono", monospace',
                          fontSize: "0.875rem",
                        },
                      }}
                    />
                    {watchExistingKey &&
                      isValidPrivateKey(watchExistingKey) && (
                        <Alert severity="success" sx={{ mt: 1 }}>
                          <Typography variant="body2">
                            ✓ Format de clé privée valide détecté
                          </Typography>
                        </Alert>
                      )}
                  </Box>
                </Collapse>
              </Paper>
            </Grid>

            {/* Champ common_name */}
            <Grid item xs={12} md={12}>
              <CustomFormLabel label="Common name" isRequired />
              <Stack
                direction="row"
                spacing={0}
                sx={{
                  border: "1px solid #ccc",
                  borderRadius: "4px",
                  overflow: "hidden",
                }}
              >
                <Grid item xs={7}>
                  <TextField
                    {...register("common_name")}
                    variant="outlined"
                    placeholder={placeholder_common_name}
                    sx={{
                      width: "100%",
                      flex: 3,
                      "& fieldset": { border: "none" },
                    }}
                    error={!!errors.common_name}
                    helperText={errors.common_name?.message}
                    disabled={isViewMode}
                  />
                </Grid>
                <Divider orientation="vertical" flexItem />
                <Grid item xs={5}>
                  <Controller
                    name="domain_name"
                    control={control}
                    render={({ field }) => (
                      <Autocomplete
                        {...field}
                        options={domainNames || []}
                        getOptionLabel={(option) =>
                          option.domain_name_value
                            ? option.domain_name_value
                            : ""
                        }
                        disabled={isViewMode}
                        loading={loadDomainNames}
                        onOpen={fetchDomainNames}
                        onChange={(_, value) => field.onChange(value || "")}
                        isOptionEqualToValue={(option, value) =>
                          option.domain_name_id === value?.domain_name_id
                        }
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            variant="outlined"
                            sx={{ flex: 1, "& fieldset": { border: "none" } }}
                            placeholder={placeholder_domain_name_select}
                            error={!!errors.domain_name}
                            helperText={
                              (loadDomainNames
                                ? "Chargement des noms de domaine..."
                                : "") || errors.domain_name?.message
                            }
                            InputProps={{
                              ...params.InputProps,
                              endAdornment: (
                                <>
                                  {loadDomainNames && (
                                    <CircularProgress
                                      color="inherit"
                                      size={20}
                                    />
                                  )}
                                  {params.InputProps.endAdornment}
                                </>
                              ),
                            }}
                          />
                        )}
                      />
                    )}
                  />
                </Grid>
              </Stack>
            </Grid>

           {/* DNS Fields */}
<Grid container item xs={12} md={12}>
  <Grid item xs={12}>
    <CustomFormLabel label="DNS" isRequired />
    {dnsTouched && errors.dns && errors.dns.message && (
      <Typography color="error" variant="caption" sx={{ ml: 2 }}>
        {errors.dns.message}
      </Typography>
    )}
  </Grid>

  {controlledFields.map((field, index) => (
    <Grid item xs={12} key={field.id}>
      <Stack
        direction="row"
        spacing={1}
        sx={{
          border: "1px solid #ccc",
          borderRadius: "4px",
          overflow: "hidden",
          mt: index > 0 ? "10px" : 0,
        }}
      >
        {/* Partie gauche : Champ texte pour le préfixe DNS */}
        <Grid item xs={7}>
          <TextField
            {...register(`dns.${index}`)}
            error={
              dnsTouched &&
              (!!errors.dns?.[index] ||
                (errors.dns && !!errors.dns.message))
            }
            fullWidth
            disabled={index === 0 || isViewMode}
            label={`DNS.${index + 1}${index === 0 ? " (généré automatiquement)" : ""}`}
            placeholder={
              index === 0
                ? "Généré à partir du Common Name"
                : "Entrez le préfixe (ex: api, app, test)"
            }
            margin="dense"
            value={
              index === 0
                ? watchCommonName
                : (watch(`dns.${index}`) || '').split('.')[0]
            }
            sx={{
              "& fieldset": { border: "none" },
              backgroundColor:
                index === 0 ? "rgba(0, 0, 0, 0.04)" : "transparent",
            }}
            onChange={(e) => {
              const domainPart = watchDomainName?.domain_name_value || '';
              const fullDns = `${e.target.value}${domainPart}`;
              setValue(`dns.${index}`, fullDns);
              setDnsTouched(true);
              trigger("dns");
            }}
            onBlur={() => {
              setDnsTouched(true);
            }}
          />
        </Grid>

        <Divider orientation="vertical" flexItem />

        {/* Partie droite : Liste déroulante pour le domaine */}
        <Grid item xs={5}>
          <Controller
            name="domain_name"
            control={control}
            render={({ field: domainField }) => (
              <Autocomplete
                {...domainField}
                options={domainNames || []}
                getOptionLabel={(option) =>
                  option.domain_name_value
                    ? option.domain_name_value
                    : ""
                }
                disabled={isViewMode || index === 0}
                loading={loadDomainNames}
                value={watchDomainName}
                onChange={(_, value) => {
                  domainField.onChange(value || "");
                  // Mettre à jour tous les DNS avec le nouveau domaine
                  if (value) {
                    const currentDns = watch("dns") || [];
                    const updatedDns = currentDns.map((dns, i) => {
                      if (i === 0) {
                        return `${watchCommonName}${value.domain_name_value}`;
                      }
                      const prefix = (dns || '').split('.')[0];
                      return `${prefix}${value.domain_name_value}`;
                    });
                    setValue("dns", updatedDns);
                  }
                  trigger("dns");
                }}
                isOptionEqualToValue={(option, value) =>
                  option.domain_name_id === value?.domain_name_id
                }
                renderInput={(params) => (
                  <TextField
                    {...params}
                    variant="outlined"
                    sx={{ 
                      flex: 1, 
                      "& fieldset": { border: "none" },
                      "& .MuiInputBase-root": {
                        height: "100%"
                      }
                    }}
                    placeholder={placeholder_domain_name_select}
                    InputProps={{
                      ...params.InputProps,
                      endAdornment: (
                        <>
                          {loadDomainNames && (
                            <CircularProgress color="inherit" size={20} />
                          )}
                          {params.InputProps.endAdornment}
                          {/* Bouton supprimer pour les DNS supplémentaires */}
                          {index > 0 && (
                            <InputAdornment position="end">
                              <IconButton
                                aria-label="delete"
                                color="error"
                                size="large"
                                onClick={() => remove(index)}
                                disabled={isViewMode}
                                sx={{ ml: 1 }}
                              >
                                <DeleteIcon />
                              </IconButton>
                            </InputAdornment>
                          )}
                        </>
                      ),
                    }}
                  />
                )}
              />
            )}
          />
        </Grid>
      </Stack>

      {/* Message d'erreur sous chaque champ DNS */}
      {dnsTouched && errors.dns?.[index]?.message && (
        <Typography color="error" variant="caption" sx={{ ml: 1, mt: 0.5 }}>
          {errors.dns[index]?.message}
        </Typography>
      )}
    </Grid>
  ))}

  {/* Bouton pour ajouter des DNS supplémentaires - ALIGNÉ À DROITE */}
  {!isViewMode && fields.length < 5 && (
    <Grid item xs={12}>
      <Box sx={{ 
        display: "flex", 
        justifyContent: "flex-end",
        mt: 2,
        mb: 2 
      }}>
        <Button
          variant="outlined"
          startIcon={<AddIcon />}
          onClick={() => {
            const domainPart = watchDomainName?.domain_name_value || '';
            const newDns = `${domainPart}`;
            append(newDns);
            setDnsTouched(true);
          }}
        >
          Ajouter DNS
        </Button>
      </Box>
    </Grid>
  )}
</Grid>

            {/* Bouton pour ajouter un nouveau champ DNS */}
            {!isViewMode && (
              <Grid item xs={12} sx={{ mt: 1 }}>
                <Button
                  variant="outlined"
                  startIcon={<AddIcon />}
                  onClick={() => {
                    append(""); 
                    setDnsTouched(true);
                  }}
                  disabled={fields.length >= 5}
                >
                  Ajouter un DNS supplémentaire
                </Button>
                {fields.length >= 5 && (
                  <Typography variant="caption" color="error" sx={{ ml: 2 }}>
                    Maximum 5 DNS autorisés
                  </Typography>
                )}
              </Grid>
            )}

            {/* Description Field */}
            <Grid item xs={12} md={12}>
              <CustomFormLabel label="Description" isRequired />
              <TextField
                {...register("description")}
                variant="outlined"
                fullWidth
                multiline
                rows={3}
                placeholder="Entrez une description ou un commentaire"
                error={!!errors.description}
                helperText={errors.description?.message}
                disabled={isViewMode}
              />
            </Grid>

            {/* Champ Solution*/}
            <Grid item xs={12} md={12}>
              <CustomFormLabel label="Solution" isRequired />
              <Controller
                name="solution"
                control={control}
                render={({ field }) => (
                  <Autocomplete
                    {...field}
                    options={solutions || []}
                    getOptionLabel={(option) => {
                      return option.solution_name
                        ? `${option.solution_name} (${option.solution_popularity})`
                        : "";
                    }}
                    disabled={isViewMode}
                    loading={loadSolutions}
                    onOpen={fetchSolutions}
                    onChange={(_, value) => field.onChange(value || "")}
                    isOptionEqualToValue={(option, value) =>
                      option.solution_id === value?.solution_id
                    }
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        placeholder={placeholder_one_solution}
                        error={!!errors.solution}
                        helperText={
                          errors.solution?.message ||
                          (loadSolutions ? "Chargement des solutions..." : "")
                        }
                        InputProps={{
                          ...params.InputProps,
                          endAdornment: (
                            <>
                              {loadSolutions && (
                                <CircularProgress color="inherit" size={20} />
                              )}
                              {params.InputProps.endAdornment}
                            </>
                          ),
                        }}
                      />
                    )}
                  />
                )}
              />
            </Grid>
          </>
        ) : (
          <Box margin="2rem">
            Êtes-vous sûr de vouloir supprimer cet certificat.
          </Box>
        )}

        {errorMessage !== null && (
          <Grid item xs={12}>
            <Alert variant="filled" severity="error">
              <Typography variant="body1">{errorMessage}</Typography>
            </Alert>
          </Grid>
        )}

        {/* Bouton Soumettre */}
        {!isViewMode && (
          <Grid
            item
            xs={12}
            sx={{
              alignItems: "center",
              justifyContent: "flex-end",
              display: "flex",
            }}
          >
            <Button
              type="submit"
              variant="contained"
              size="large"
              disabled={isDeleteMode ? false : !isValid}
              onClick={() => {
                setDnsTouched(true);
                trigger();
              }}
              sx={{
                width: "auto",
              }}
            >
              {isEditMode ? "Modifier" : isDeleteMode ? "Supprimer" : "Envoyer"}
            </Button>
          </Grid>
        )}
      </Grid>
    </form>
  );
}
