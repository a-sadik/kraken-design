// src/types/dto/response/CertificateResponseDTO.ts

import { SolutionShortDTO } from "./solution/SolutionShortDTO";

export interface CertificateDetailResponseDTO {
  certificate_id: number;
  certificate_request_ref: string;
  certificate_target: string;
  certificate_state: string;
  common_name: string;
  dns: string[] | null;
  generated_at: string;
  key_file_name: string;
  csr_file_name: string;
  crt_file_name?: string;
  config_file: Configfile;
  exp_date?: string;
  is_renewed: boolean;
  application_comment: string;
  certificate_type: string;
  created_at: string;
  parent_certificate_id: string;
  solution: SolutionShortDTO;
  itop_ticket_num: number;
  itop_ticket_ref: string;
  ticket_state: string;
  applicant: string;
  validator?: string;
  validated_at: string;
  updated_at: string;
}

export interface CertificateResponseDTO {
  certificate_id: number;
  certificate_request_ref: string;
  certificate_target: string;
  certificate_key: string | null;
  certificate_state: string;
  common_name: string;
  dns: string[];
  generated_at: string;
  exp_date: string;
  is_renewed: boolean;
  application_comment: string;
  certificate_type: string;
  archive_password: string;
  created_at: string;
  applicant: string;
  actor: string;
  itop_ticket_num: string;
  itop_ticket_ref: string;
  ticket_state: string;
  solution: string;
}

export interface Configfile {
  prompt: string;
  commonName: string;
  default_md: string;
  postalCode: string;
  countryName: string;
  default_bits: string;
  emailAddress: string;
  localityName: string;
  streetAddress: string;
  req_extensions: string;
  subjectAltName: string;
  organizationName: string;
  distinguished_name: string;
  stateOrProvinceName: string;
  organizationalUnitName: string;
}
