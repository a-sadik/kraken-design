// src/services/HealthService.ts

import axios from "axios";

const PREFIX_PATH = import.meta.env.VITE_PREFIX_SOURCE_PATH;
const SERVER_PORT = import.meta.env.VITE_SOURCE_SERVER_PORT;

// Function to recieve health of backend service
export const getHealthSourceService = async () => {
  const response = await axios.get(`${PREFIX_PATH}:${SERVER_PORT}/health`);
  return response.data;
};
