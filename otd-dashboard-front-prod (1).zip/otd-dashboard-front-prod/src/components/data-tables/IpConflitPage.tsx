import React, { useState, useEffect } from "react";
import {
  Box,
  Card,
  CardContent,
  Typography,
  Grid,
  Paper,
  Chip,
  Alert,
  CircularProgress,
  Stack,
  Divider,
  Tab,
  Tabs,
  Tooltip,
  IconButton,
  Button,
  TextField,
  InputAdornment,
} from "@mui/material";
import {
  RefreshCw,
  AlertTriangle,
  Server,
  Network,
  Eye,
  User,
  Calendar,
  Search,
  Filter,
} from "lucide-react";
import fetchWithAuth from "@/middleware/fetch-auth";
import { getConflit_Ip } from "@/config/api.config";

// Types pour les données de conflit IP
interface ServerData {
  id: number;
  ip_addresses: string[];
  hostname: string;
  os_type: string;
  os_details: string;
  uname: string | null;
  managed_system_name: string | null;
  signed: string | null;
  created_at: string;
  created_by: string;
  updated_at: string;
  updated_by: string;
}

interface IpConflictData {
  vmware: {
    [ip: string]: ServerData[];
  };
  power: {
    [ip: string]: ServerData[];
  };
  bigfix: {
    [ip: string]: ServerData[];
  };
}

const IpConflictPage: React.FC = () => {
  const [data, setData] = useState<IpConflictData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeSource, setActiveSource] = useState<keyof IpConflictData>("vmware");
  const [selectedServers, setSelectedServers] = useState<Set<number>>(new Set());
  const [showOnlySelected, setShowOnlySelected] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState<"ip" | "hostname" | "system" | "all">("all");

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetchWithAuth(getConflit_Ip());
      if (!response.ok) {
        throw new Error(`Erreur HTTP: ${response.status}`);
      }
      const apiData = await response.json();
      setData(apiData);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erreur inconnue");
      console.error("Erreur lors de la récupération des conflits IP:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const refreshData = () => {
    fetchData();
  };

  const getSeverityColor = (count: number) => {
    if (count > 2) return "#ff4444";
    if (count > 1) return "#ffaa00";
    return "#ffdd00";
  };

  const getUnameAlertColor = (uname: string | null, osType: string) => {
    if (uname && !osType.toLowerCase().includes("aix")) {
      return "#ff4444";
    }
    return "inherit";
  };

  const toggleServerSelection = (serverId: number) => {
    const newSelected = new Set(selectedServers);
    if (newSelected.has(serverId)) {
      newSelected.delete(serverId);
    } else {
      newSelected.add(serverId);
    }
    setSelectedServers(newSelected);
  };

  const selectAllServers = () => {
    if (!data || !data[activeSource]) return;

    const allServerIds = new Set<number>();
    Object.values(data[activeSource]).forEach(servers => {
      servers.forEach(server => {
        allServerIds.add(server.id);
      });
    });
    setSelectedServers(allServerIds);
  };

  const clearSelection = () => {
    setSelectedServers(new Set());
  };

  const getFilteredIps = (): [string, ServerData[]][] => {
    if (!data || !data[activeSource]) return [];

    const allIps = Object.entries(data[activeSource]) as [string, ServerData[]][];

    let filtered = allIps;

    // Filtre par sélection si activé
    if (showOnlySelected && selectedServers.size > 0) {
      filtered = filtered
        .map(([ip, servers]): [string, ServerData[]] => [
          ip,
          servers.filter(server => selectedServers.has(server.id))
        ])
        .filter(([, servers]) => servers.length > 0);
    }

    // NOUVELLE LOGIQUE : Si recherche, on garde TOUTES les IPs contenant au moins un serveur qui correspond
    if (searchTerm.trim()) {
      const searchLower = searchTerm.toLowerCase().trim();

      // Étape 1: Trouver tous les serveurs qui correspondent au filtre
      const matchingServerIds = new Set<number>();
      const matchingIps = new Set<string>();

      allIps.forEach(([ip, servers]) => {
        servers.forEach(server => {
          const matchesFilter = checkServerMatch(server, ip, searchLower, filterType);
          if (matchesFilter) {
            matchingServerIds.add(server.id);
            matchingIps.add(ip); // Ajouter l'IP du serveur correspondant
          }
        });
      });

      // Étape 2: Pour chaque IP, garder TOUS les serveurs si l'IP est concernée
      filtered = allIps
        .filter(([ip]) => matchingIps.has(ip)) // Garder seulement les IPs concernées
        .map(([ip, servers]) => [ip, servers] as [string, ServerData[]]); // Garder tous les serveurs de cette IP

      // Trier par nombre de serveurs (comme avant)
      filtered.sort(([, serversA], [, serversB]) => serversB.length - serversA.length);
    } else {
      // Sans recherche, tri normal
      filtered.sort(([, serversA], [, serversB]) => serversB.length - serversA.length);
    }

    return filtered;
  };

  // Fonction helper pour vérifier si un serveur correspond au filtre
  const checkServerMatch = (server: ServerData, ip: string, searchLower: string, filterType: string): boolean => {
    switch (filterType) {
      case "ip":
        return ip.toLowerCase().includes(searchLower);

      case "hostname":
        return server.hostname.toLowerCase().includes(searchLower);

      case "system":
        const systemInfo = `${server.os_type} ${server.os_details || ""} ${server.managed_system_name || ""}`.toLowerCase();
        return systemInfo.includes(searchLower);

      case "all":
      default:
        return (
          ip.toLowerCase().includes(searchLower) ||
          server.hostname.toLowerCase().includes(searchLower) ||
          server.os_type.toLowerCase().includes(searchLower) ||
          (server.os_details ? server.os_details.toLowerCase().includes(searchLower) : false) ||
          (server.managed_system_name ? server.managed_system_name.toLowerCase().includes(searchLower) : false) ||
          (server.uname ? server.uname.toLowerCase().includes(searchLower) : false)
        );
    }
  };


  const clearFilters = () => {
    setSearchTerm("");
    setFilterType("all");
  };

  const filteredIps = getFilteredIps();
  const totalServersInSource = data && data[activeSource]
    ? Object.values(data[activeSource]).reduce((total, servers) => total + servers.length, 0)
    : 0;

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error" sx={{ mb: 2 }}>
          Erreur lors du chargement des conflits IP: {error}
        </Alert>
        <IconButton onClick={refreshData} color="primary">
          <RefreshCw />
        </IconButton>
      </Box>
    );
  }

  if (!data) {
    return (
      <Alert severity="info">
        Aucune donnée de conflit IP disponible.
      </Alert>
    );
  }

  const sourceLabels = {
    vmware: "VMware",
    power: "Power",
    bigfix: "BigFix"
  };

  return (
    <Box sx={{ p: 3, background: "linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)", minHeight: "100vh" }}>
      {/* Header avec style amélioré */}
      <Card sx={{ mb: 3, background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)", color: "white" }}>
        <CardContent>
          <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
              <Network size={32} />
              <Box>
                <Typography variant="h4" sx={{ fontWeight: "bold", mb: 0.5 }}>
                  Conflits d'Adresses IP
                </Typography>
                <Typography variant="subtitle1" sx={{ opacity: 0.9 }}>
                  Surveillance et gestion des serveurs en conflit IP
                </Typography>
              </Box>
            </Box>
            <Tooltip title="Actualiser les données">
              <IconButton onClick={refreshData} sx={{ color: "white", "&:hover": { bgcolor: "rgba(255,255,255,0.1)" } }}>
                <RefreshCw />
              </IconButton>
            </Tooltip>
          </Box>
        </CardContent>
      </Card>

      {/* Carte pour les filtres de recherche - AJOUTÉ */}
      <Card sx={{ mb: 3, background: "rgba(255,255,255,0.95)", backdropFilter: "blur(10px)" }}>
        <CardContent>
          <Typography variant="h6" sx={{ mb: 2, display: "flex", alignItems: "center", gap: 1, color: "primary.main" }}>
            <Filter size={20} />
            Filtres de Recherche
          </Typography>

          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} md={2.5}>
              <TextField
                fullWidth
                variant="outlined"
                placeholder="Rechercher..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <Search size={20} color="#666" />
                    </InputAdornment>
                  ),
                  endAdornment: searchTerm && (
                    <InputAdornment position="end">
                      <IconButton size="medium" onClick={clearFilters}>
                        ×
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            </Grid>

            <Grid item xs={12} md={3}>
              <Box sx={{ display: "flex", gap: 1, flexWrap: "wrap" }}>
                {/* <Button
                  variant="outlined"
                  onClick={clearFilters}
                  disabled={!searchTerm && filterType === "all"}
                  size="small"
                  sx={{ minWidth: "auto", px: 1.5 }}
                >
                  Réinitialiser
                </Button> */}
              </Box>
            </Grid>
          </Grid>

          {/* Indicateur de résultats filtrés - AJOUTÉ */}
          {searchTerm && (
            <Box sx={{ mt: 2, display: "flex", alignItems: "center", gap: 1 }}>
              <Chip
                label={`${filteredIps.length} IP(s) trouvée(s)`}
                color="info"
                variant="outlined"
                size="small"
              />
              <Typography variant="body2" color="text.secondary">
                Filtre: "{searchTerm}" dans {filterType === "all" ? "tous les champs" :
                  filterType === "ip" ? "les adresses IP" :
                    filterType === "hostname" ? "les noms d'hôte" : "les systèmes d'exploitation"}
              </Typography>
            </Box>
          )}
        </CardContent>
      </Card>

      {/* Contrôles de sélection simplifiés */}
      <Card sx={{ mb: 3, background: "rgba(255,255,255,0.95)", backdropFilter: "blur(10px)" }}>
        <CardContent>
          <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 2 }}>
            <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
              <Typography variant="h6" color="primary" sx={{ fontWeight: "bold" }}>
                Gestion des Sélections
              </Typography>
              <Chip
                label={`${selectedServers.size} serveur(s) sélectionné(s)`}
                color="primary"
                variant="outlined"
              />
            </Box>

            <Box sx={{ display: "flex", gap: 1, flexWrap: "wrap" }}>
              <Button
                startIcon={<Eye />}
                variant={showOnlySelected ? "contained" : "outlined"}
                onClick={() => setShowOnlySelected(!showOnlySelected)}
                disabled={selectedServers.size === 0}
                color="primary"
              >
                {showOnlySelected ? "Tout afficher" : "Voir sélection"}
              </Button>

              <Button
                variant="outlined"
                onClick={selectAllServers}
                disabled={!data[activeSource] || totalServersInSource === 0}
                color="secondary"
              >
                Tout sélectionner
              </Button>

              <Button
                variant="outlined"
                onClick={clearSelection}
                disabled={selectedServers.size === 0}
                color="error"
              >
                Tout désélectionner
              </Button>
            </Box>
          </Box>
        </CardContent>
      </Card>

      {/* Tabs pour les sources avec style amélioré */}
      <Card sx={{ mb: 3, background: "rgba(255,255,255,0.95)", backdropFilter: "blur(10px)" }}>
        <CardContent>
          <Tabs
            value={activeSource}
            onChange={(_e, newValue) => {
              setActiveSource(newValue);
              setSelectedServers(new Set());
            }}
            sx={{
              mb: 2,
              "& .MuiTab-root": {
                fontWeight: "bold",
                fontSize: "1rem",
              }
            }}
            TabIndicatorProps={{
              style: {
                background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
                height: 3,
              }
            }}
          >
            {Object.entries(sourceLabels).map(([key, label]) => {
              const serverCount = data[key as keyof IpConflictData]
                ? Object.values(data[key as keyof IpConflictData]).reduce((total, servers) => total + servers.length, 0)
                : 0;

              return (
                <Tab
                  key={key}
                  label={
                    <Box sx={{ display: "flex", alignItems: "center", gap: 1, py: 1 }}>
                      <Server size={18} />
                      <span>{label}</span>
                      <Chip
                        label={serverCount}
                        size="small"
                        color="primary"
                        variant="filled"
                        sx={{
                          fontWeight: "bold",
                          background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
                          color: "white"
                        }}
                      />
                    </Box>
                  }
                  value={key}
                />
              );
            })}
          </Tabs>

          <Divider sx={{ my: 2 }} />

          {/* Contenu des conflits par source */}
          {filteredIps.length > 0 ? (
            <Stack spacing={3}>
              {filteredIps.map(([ip, servers]) => (
                <Paper
                  key={ip}
                  elevation={3}
                  sx={{
                    p: 3,
                    background: "linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%)",
                    border: `2px solid ${getSeverityColor(servers.length)}20`,
                    borderRadius: 3,
                    transition: "all 0.3s ease",
                    "&:hover": {
                      transform: "translateY(-2px)",
                      boxShadow: "0 8px 25px rgba(0,0,0,0.15)",
                    }
                  }}
                >
                  {/* En-tête de l'IP */}
                  <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 3 }}>
                    <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
                      <Box
                        sx={{
                          width: 16,
                          height: 16,
                          borderRadius: "50%",
                          backgroundColor: getSeverityColor(servers.length),
                          boxShadow: `0 0 10px ${getSeverityColor(servers.length)}80`,
                        }}
                      />
                      <Typography variant="h5" fontFamily="monospace" sx={{ fontWeight: "bold", color: "#2c3e50" }}>
                        {ip}
                      </Typography>
                      <Chip
                        label={`${servers.length} serveur(s)`}
                        size="medium"
                        color={servers.length > 2 ? "error" : servers.length > 1 ? "warning" : "info"}
                        variant="filled"
                        sx={{ fontWeight: "bold", fontSize: "0.9rem" }}
                      />
                    </Box>

                    <Chip
                      label={`${servers.filter(s => selectedServers.has(s.id)).length} sélectionné(s)`}
                      variant="outlined"
                      color="primary"
                    />
                  </Box>

                  {/* Serveurs en conflit */}
                  <Grid container spacing={3}>
                    {servers.map((server) => {
                      const isSelected = selectedServers.has(server.id);

                      return (
                        <Grid item xs={12} md={6} lg={4} key={server.id}>
                          <Card
                            variant="outlined"
                            sx={{
                              height: "100%",
                              borderLeft: `4px solid ${isSelected ? "#667eea" : getSeverityColor(servers.length)}`,
                              background: isSelected ? "rgba(102, 126, 234, 0.05)" : "rgba(255,255,255,0.8)",
                              backdropFilter: "blur(5px)",
                              transition: "all 0.3s ease",
                              "&:hover": {
                                transform: "translateY(-2px)",
                                boxShadow: "0 4px 15px rgba(0,0,0,0.1)",
                              }
                            }}
                          >
                            <CardContent>
                              {/* Hostname avec alerte uname */}
                              <Box sx={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", mb: 2 }}>
                                <Box sx={{ display: "flex", alignItems: "flex-start", gap: 1 }}>
                                  <Server size={18} color="#666" />
                                  <Typography
                                    variant="h6"
                                    sx={{
                                      fontWeight: "bold",
                                      color: getUnameAlertColor(server.uname, server.os_type),
                                      fontFamily: "'Courier New', monospace"
                                    }}
                                  >
                                    {server.hostname}
                                  </Typography>
                                </Box>
                                <Button
                                  size="small"
                                  variant={isSelected ? "contained" : "outlined"}
                                  onClick={() => toggleServerSelection(server.id)}
                                  color="primary"
                                >
                                  {isSelected ? "✓" : "Sel"}
                                </Button>
                              </Box>

                              <Stack spacing={1.5}>
                                {/* AFFICHAGE DES ADRESSES IP - NOUVEAU BLOC AJOUTÉ */}
                                <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                                  <Typography variant="body2" color="text.secondary" sx={{ fontWeight: "medium", minWidth: '80px' }}>
                                    IPs:
                                  </Typography>
                                  <Box sx={{ display: "flex", flexDirection: "column", gap: 0.5, flex: 1 }}>
                                    {server.ip_addresses.map((ipAddr, index) => (
                                      <Chip
                                        key={index}
                                        label={ipAddr}
                                        size="small"
                                        variant={ipAddr === ip ? "filled" : "outlined"}
                                        color={ipAddr === ip ? "primary" : "default"}
                                        sx={{
                                          fontFamily: "'Courier New', monospace",
                                          fontSize: '0.75rem',
                                          height: '24px',
                                          mb: 0.5
                                        }}
                                      />
                                    ))}
                                  </Box>
                                </Box>

                                {/* Type OS */}
                                <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                                  <Typography variant="body2" color="text.secondary" sx={{ fontWeight: "medium" }}>
                                    Système:
                                  </Typography>
                                  <Chip
                                    label={`${server.os_type} ${server.os_details || ""}`}
                                    size="small"
                                    variant="outlined"
                                    color={server.os_type.toLowerCase().includes("aix") ? "primary" : "default"}
                                  />
                                </Box>

                                {/* Uname avec alerte */}
                                {server.uname && (
                                  <Box sx={{
                                    display: "flex",
                                    justifyContent: "space-between",
                                    alignItems: "center",
                                    p: 1,
                                    borderRadius: 1,
                                    bgcolor: getUnameAlertColor(server.uname, server.os_type) !== "inherit" ? "#ff444410" : "transparent",
                                    border: getUnameAlertColor(server.uname, server.os_type) !== "inherit" ? "1px solid #ff444430" : "none"
                                  }}>
                                    <Typography variant="body2" color="text.secondary" sx={{ fontWeight: "medium" }}>
                                      Uname:
                                    </Typography>
                                    <Typography
                                      variant="body2"
                                      sx={{
                                        color: getUnameAlertColor(server.uname, server.os_type),
                                        fontWeight: "bold",
                                        fontFamily: "'Courier New', monospace"
                                      }}
                                    >
                                      {server.uname}
                                    </Typography>
                                  </Box>
                                )}

                                {/* Power Physique */}
                                {server.managed_system_name && (
                                  <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                                    <Typography variant="body2" color="text.secondary" sx={{ fontWeight: "medium" }}>
                                      Power Physique:
                                    </Typography>
                                    <Typography variant="body2" sx={{ fontWeight: "medium" }}>
                                      {server.managed_system_name}
                                    </Typography>
                                  </Box>
                                )}

                                {/* Métadonnées améliorées */}
                                <Box sx={{ pt: 1, borderTop: "1px solid #eee" }}>
                                  <Box sx={{ display: "flex", alignItems: "center", gap: 1, mb: 0.5 }}>
                                    <User size={14} color="#666" />
                                    <Typography variant="body2" color="text.secondary" sx={{ fontWeight: "medium" }}>
                                      Créé par: {server.created_by}
                                    </Typography>
                                  </Box>

                                  <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                                    <Calendar size={14} color="#666" />
                                    <Typography variant="body2" color="text.secondary">
                                      Créé le: {new Date(server.created_at).toLocaleDateString('fr-FR')}
                                    </Typography>
                                  </Box>

                                  <Box sx={{ display: "flex", alignItems: "center", gap: 1, mb: 0.5 }}>
                                    <User size={14} color="#666" />
                                    <Typography variant="body2" color="text.secondary" sx={{ fontWeight: "medium" }}>
                                      Modifié par: {server.updated_by}
                                    </Typography>
                                  </Box>
                                  <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                                    <Calendar size={14} color="#666" />
                                    <Typography variant="body2" color="text.secondary">
                                      Mis à jour: {new Date(server.updated_at).toLocaleDateString('fr-FR')}
                                    </Typography>
                                  </Box>
                                </Box>
                              </Stack>
                            </CardContent>
                          </Card>
                        </Grid>
                      );
                    })}
                  </Grid>
                </Paper>
              ))}
            </Stack>
          ) : (
            <Alert
              severity="info"
              sx={{
                background: "linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%)",
                fontSize: "1.1rem",
                "& .MuiAlert-icon": { fontSize: "1.5rem" }
              }}
            >
              {showOnlySelected ?
                "Aucun serveur sélectionné à afficher." :
                `Aucun conflit IP détecté pour ${sourceLabels[activeSource]}.`}
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Résumé global avec style amélioré */}
      <Card sx={{ background: "rgba(255,255,255,0.95)", backdropFilter: "blur(10px)" }}>
        <CardContent>
          <Typography variant="h6" sx={{ display: "flex", alignItems: "center", gap: 1, mb: 3, color: "#2c3e50" }}>
            <AlertTriangle color="#e74c3c" />
            Résumé des Conflits
          </Typography>
          <Grid container spacing={3}>
            {Object.entries(sourceLabels).map(([key, label]) => {
              const ipCount = data[key as keyof IpConflictData] ?
                Object.keys(data[key as keyof IpConflictData]).length : 0;
              const serverCount = data[key as keyof IpConflictData]
                ? Object.values(data[key as keyof IpConflictData]).reduce((total, servers) => total + servers.length, 0)
                : 0;

              return (
                <Grid item xs={12} md={4} key={key}>
                  <Paper
                    sx={{
                      p: 3,
                      textAlign: "center",
                      background: ipCount > 0 ?
                        "linear-gradient(135deg, #ffeaa7 0%, #fab1a0 100%)" :
                        "linear-gradient(135deg, #55efc4 0%, #81ecec 100%)",
                      color: ipCount > 0 ? "#2d3436" : "#2d3436",
                      borderRadius: 3,
                      transition: "all 0.3s ease",
                      "&:hover": {
                        transform: "translateY(-3px)",
                        boxShadow: "0 6px 20px rgba(0,0,0,0.15)",
                      }
                    }}
                  >
                    <Typography variant="h6" sx={{ fontWeight: "bold", mb: 1 }}>
                      {label}
                    </Typography>
                    <Typography variant="h2" sx={{ fontWeight: "bold", mb: 1 }}>
                      {ipCount}
                    </Typography>
                    <Typography variant="body2" sx={{ fontWeight: "medium", mb: 1 }}>
                      IP(s) en conflit
                    </Typography>
                    <Typography variant="body2" sx={{ fontWeight: "medium", opacity: 0.8 }}>
                      {serverCount} serveur(s) total
                    </Typography>
                  </Paper>
                </Grid>
              );
            })}
          </Grid>
        </CardContent>
      </Card>
    </Box>
  );
};

export default IpConflictPage;