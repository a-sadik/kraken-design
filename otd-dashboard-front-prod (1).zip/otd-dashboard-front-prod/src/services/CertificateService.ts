// src/services/CertificateService.ts

import { AxiosError } from "axios";

// import files
import {
  CertificateDetailResponseDTO,
  CertificateResponseDTO,
} from "@/types/dto/response/CertificateResponseDTO";
import { certificateResToView } from "@/mappers/CertificateMapper";
import CertificateView from "@/types/view/CertificateView";
import { ErrorResponse } from "@/exceptions/ErrorResponse";
import {
  InternCertificateRequestDTO,
  CertificateAfterCreatingRequestDTO,
  ExternCertificateRequestDTO,
} from "@/types/dto/request/CertificateRequestDTO";
import apiClient from "./apiClientHttp";
// import { ExternCertificateFormData } from '@/components/forms/certificate/CreateExternCertificateForm';

const path = `/certificates`;

// Function to recieve all certificates
export const getAllCertificates = async (): Promise<CertificateView[]> => {
  try {
    const response = await apiClient.dataApiClient.get<
      CertificateResponseDTO[]
    >(`${path}`);

    const mappedData: CertificateView[] = certificateResToView(response.data);

    return mappedData;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error(
      "Error fetching all certificates data:",
      err.response?.data.message,
    );
    throw err;
  }
};

// Function to recieve one certificate by id
export const getCertificateById = async (
  id: number,
): Promise<CertificateDetailResponseDTO | null> => {
  try {
    const response =
      await apiClient.dataApiClient.get<CertificateDetailResponseDTO | null>(
        `${path}/${id}`,
      );
    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error("Error fetching certificate data by id:", err.response?.data);
    throw error;
  }
};

// Function for create one intern certificate
export const createOneInternCertificate = async (
  reqBody: InternCertificateRequestDTO,
): Promise<CertificateResponseDTO | null> => {
  try {
    const response =
      await apiClient.dataApiClient.post<CertificateResponseDTO | null>(
        `${path}/internal`,
        reqBody,
      );
    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error(
      "Error create one intern certificate data:",
      err.response?.data.message,
    );
    throw err;
  }
};

// Function for create one extern certificate
export const createOneExternCertificate = async (
  reqBody: ExternCertificateRequestDTO,
): Promise<CertificateResponseDTO | null> => {
  try {
    const response =
      await apiClient.dataApiClient.post<CertificateResponseDTO | null>(
        `${path}/external`,
        reqBody,
      );
    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error(
      "Error create one extern certificate data:",
      err.response?.data.message,
    );
    throw err;
  }
};

// Fonction pour la validation en groupe
export const bulkValidateCertificates = async (
  ids: number[],
  data: CertificateAfterCreatingRequestDTO,
) => {
  const response = await apiClient.dataApiClient.put(
    `${path}/validate-many`,
    {
      certificateIds: ids,
      data: data,
    },
    { timeout: 120000 },
  ); // 2min
  return response.data;
};

// Function for validate one Certificate
export const validateCertificate = async (
  id: number,
  reqBody: CertificateAfterCreatingRequestDTO,
): Promise<CertificateResponseDTO | null> => {
  try {
    const response =
      await apiClient.dataApiClient.put<CertificateResponseDTO | null>(
        `${path}/validate/${id}`,
        reqBody,
      );
    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error(
      "Error validate a Certificate data:",
      err.response?.data.message,
    );
    throw err;
  }
};

// Function for validate extern Certificate
export const updateCertificateStatus = async (
  id: number,
  status: "EN_ATTENTE" | "EN_COURS" | "VALIDE" | "REFUSE",
  action_comment?: string,
): Promise<any> => {
  try {
    const response = await apiClient.dataApiClient.put(`${path}/${id}/status`, {
      status,
      action_comment,
    });
    return response.data;
  } catch (error) {
    const err = error as AxiosError;
    console.error("Erreur mise à jour statut :");
    throw err;
  }
};

// Function to hold one Certificate
export const holdCertificate = async (
  id: number,
  reqBody: CertificateAfterCreatingRequestDTO,
): Promise<CertificateResponseDTO | null> => {
  try {
    const response =
      await apiClient.dataApiClient.put<CertificateResponseDTO | null>(
        `${path}/hold/${id}`,
        reqBody,
      );
    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error("Error hold a Certificate data:", err.response?.data.message);
    throw err;
  }
};

// Function for reject one Certificate
export const rejectCertificate = async (
  id: number,
  reqBody: CertificateAfterCreatingRequestDTO,
): Promise<CertificateResponseDTO | null> => {
  try {
    const response =
      await apiClient.dataApiClient.put<CertificateResponseDTO | null>(
        `${path}/reject/${id}`,
        reqBody,
      );
    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error(
      "Error reject a Certificate data:",
      err.response?.data.message,
    );
    throw err;
  }
};

// Function for renew one Certificate with old key
export const renewCertificateWithOldKey = async (
  id: number,
): Promise<CertificateResponseDTO | null> => {
  try {
    const response =
      await apiClient.dataApiClient.post<CertificateResponseDTO | null>(
        `${path}/renew-old-key/${id}`,
      );
    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error(
      "Error renew a Certificate data:",
      err.response?.data.message,
    );
    throw err;
  }
};

// Function for renew one Certificate with new key
export const renewCertificateWithNewKey = async (
  id: number,
): Promise<CertificateResponseDTO | null> => {
  try {
    const response =
      await apiClient.dataApiClient.post<CertificateResponseDTO | null>(
        `${path}/renew-new-key/${id}`,
      );
    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error(
      "Error renew a Certificate data:",
      err.response?.data.message,
    );
    throw err;
  }
};

// Function for delete one certificate by id
export const deleteCertificate = async (sereverId: number) => {
  try {
    await apiClient.dataApiClient.delete(`${path}/${sereverId}`);
  } catch (error) {
    console.error("Error delete certificate by id:", error);
    throw error;
  }
};

// Function to recieve all Certificate Types
export const getAllCertificateTypes = async (): Promise<string[]> => {
  try {
    const response = await apiClient.dataApiClient.get<string[]>(
      `${path}/enums/types`,
    );

    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error(
      "Error fetching all certificate types data:",
      err.response?.data.message,
    );
    throw err;
  }
};

// Function to download files for one certificate by id from nexus repository
export const downloadCertificateFilesById = async (
  id: number,
  solutionName: string,
): Promise<void> => {
  try {
    const certificate = getCertificateById(id);
    let timestamp;
    let common_name;
    certificate.then((certificate) => {
      timestamp = certificate?.generated_at;
      common_name = certificate?.common_name;
    });
    const response = await apiClient.dataApiClient.get(
      `${path}/download/${id}`,
      { responseType: "blob" },
    );

    // Crée un URL objet pour le téléchargement
    const url = window.URL.createObjectURL(new Blob([response.data]));
    const link = document.createElement("a");
    link.href = url;

    link.setAttribute(
      "download",
      `${common_name}_${solutionName}_${timestamp}.zip`,
    );
    document.body.appendChild(link);
    link.click();
    // Nettoie les ressources
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error(
      "Error download files of certificate by id:",
      err.response?.data,
    );
    throw error;
  }
};

// Function to download key file for one certificate by id from nexus repository
export const downloadCertificateKeyFileById = async (
  id: number,
  password: string,
  certificateData: CertificateView,
): Promise<void> => {
  try {
    const response = await apiClient.dataApiClient.post(
      `${path}/download-key/${id}`,
      { archive_password: password },
      { responseType: "blob" },
    );

    // Créer un lien de téléchargement
    const url = window.URL.createObjectURL(new Blob([response.data]));
    const link = document.createElement("a");
    link.href = url;

    link.setAttribute(
      "download",
      `${certificateData.Solution}_${certificateData.Demandeur}_${certificateData["Common Name"]}_${certificateData["Date de création"]}.key`,
    );
    document.body.appendChild(link);
    link.click();
    link.remove();
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error(
      "Error download key file of certificate by id:",
      err.response?.data,
    );
    throw error;
  }
};

// Function to recover password for download decoder key file by id
export const recoverPasswordForKeyFile = async (id: number): Promise<void> => {
  try {
    await apiClient.dataApiClient.get(`${path}/recover/${id}`);
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error(
      "Error recover password for key file of certificate by id:",
      err.response?.data,
    );
    throw error;
  }
};

// // Fonction de transformation des données du formulaire vers le DTO backend
// export function transformFormDataToBackendDTO(formData: ExternCertificateFormData): ExterneCertificateRequestDTO {
//   const backendData: ExterneCertificateRequestDTO = {
//     certificate_target: formData.certificate_target,
//     dns: formData.dns.filter(dns => dns && dns.trim() !== ""), // Filtrer les DNS vides
//     common_name: formData.common_name,
//     solution_id: formData.solution?.solution_id || 0,
//     certificate_type: formData.certificate_type || "",
//     application_comment: formData.description || undefined,
//   };

//   // Ajouter la clé privée seulement si l'utilisateur en a fourni une
//   if (formData.key_option === 'existing' && formData.existing_key && formData.existing_key.trim() !== '') {
//     backendData.certificate_key = formData.existing_key;
//   }
//   // Si key_option === 'skip' ou si existing_key est vide, on n'envoie pas certificate_key
//   // Le backend générera automatiquement une clé

//   return backendData;
// }

// // Service pour créer un certificat externe
// export async function createExternCertificate(formData: ExternCertificateFormData): Promise<any> {
//   try {
//     const backendData = transformFormDataToBackendDTO(formData);

//     console.log('Données envoyées au backend:', {
//       ...backendData,
//       certificate_key: backendData.certificate_key ? '[CLÉ_PRIVÉE_FOURNIE]' : 'NON_FOURNIE'
//     });

//     const response = await fetch('/api/certificates/extern', {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//       },
//       body: JSON.stringify(backendData),
//     });

//     if (!response.ok) {
//       throw new Error(`Erreur HTTP: ${response.status}`);
//     }

//     return await response.json();
//   } catch (error) {
//     console.error('Erreur lors de la création du certificat:', error);
//     throw error;
//   }
// }

// // Service pour mettre à jour un certificat externe
// export async function updateExternCertificate(id: number, formData: ExternCertificateFormData): Promise<any> {
//   try {
//     const backendData = transformFormDataToBackendDTO(formData);

//     const response = await fetch(`/api/certificates/extern/${id}`, {
//       method: 'PUT',
//       headers: {
//         'Content-Type': 'application/json',
//       },
//       body: JSON.stringify(backendData),
//     });

//     if (!response.ok) {
//       throw new Error(`Erreur HTTP: ${response.status}`);
//     }

//     return await response.json();
//   } catch (error) {
//     console.error('Erreur lors de la mise à jour du certificat:', error);
//     throw error;
//   }
