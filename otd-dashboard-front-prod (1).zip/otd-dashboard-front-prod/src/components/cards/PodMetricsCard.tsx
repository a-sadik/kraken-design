import type React from "react";
import { Card, CardContent, Typography, Box, Grid } from "@mui/material";
import {
  Memory as MemoryIcon,
  Speed as CpuIcon,
  TrendingUp as RequestIcon,
  Security as LimitIcon,
  RestartAlt as RestartIcon,
  Schedule as TimeIcon,
  Computer as NodeIcon,
  NetworkCheck as NetworkIcon,
} from "@mui/icons-material";
import type { Pod } from "@/types/Namespace";
import CustomBadge from "@/components/basics/CustomBadge";
import CustomTooltip from "@/components/basics/CustomToolTip";
import { getCssVariableValue } from "@/utils/getDynamicColor";

interface PodMetricsCardProps {
  pod: Pod;
}

const formatResource = (value: string | null): string => {
  if (!value) return "N/A";
  return value;
};

const formatDate = (dateString: string): string => {
  const date = new Date(dateString);
  return date.toLocaleString();
};

const PodMetricsCard: React.FC<PodMetricsCardProps> = ({ pod }) => {
  const restartCount = pod.containerStatuses?.[0]?.restartCount || 0;

  return (
    <Card
      sx={{
        mb: 2,
        borderRadius: 3,
        boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
        border: `2px solid ${getCssVariableValue("--primary-color")}20`,
        transition: "all 0.3s ease",
        "&:hover": {
          boxShadow: "0 8px 24px rgba(0,0,0,0.15)",
          transform: "translateY(-2px)",
        },
      }}
    >
      <CardContent sx={{ p: 3 }}>
        {/* Header */}
        <Box
          display="flex"
          justifyContent="space-between"
          alignItems="center"
          mb={3}
        >
          <Box>
            <Typography
              variant="h6"
              component="div"
              fontWeight="bold"
              color="primary"
            >
              {pod.pod_name}
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
              UID: {pod.pod_uid}
            </Typography>
          </Box>
          <Box display="flex" gap={1} alignItems="center">
            <CustomBadge
              text={pod.phase}
              backgroundColor={
                pod.phase === "Running"
                  ? "#4caf50"
                  : pod.phase === "Pending"
                    ? "#ff9800"
                    : "#f44336"
              }
              textColor="white"
              textSize="0.8rem"
            />
            {restartCount > 0 && (
              <CustomTooltip title={`${restartCount} redémarrage(s)`}>
                <CustomBadge
                  text={`${restartCount} ↻`}
                  backgroundColor={restartCount < 5 ? "#ff9800" : "#f44336"}
                  textColor="white"
                  textSize="1.4rem"
                />
              </CustomTooltip>
            )}
          </Box>
        </Box>

        {/* Info Grid */}
        <Grid container spacing={2} mb={3}>
          <Grid item xs={12} sm={6}>
            <Box display="flex" alignItems="center" gap={1}>
              <NodeIcon color="action" sx={{ fontSize: 18 }} />
              <Typography variant="body2" color="text.secondary">
                Nœud:
              </Typography>
              <Typography variant="body2" fontWeight="medium">
                {pod.nodeName}
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={12} sm={6}>
            <Box display="flex" alignItems="center" gap={1}>
              <NetworkIcon color="action" sx={{ fontSize: 18 }} />
              <Typography variant="body2" color="text.secondary">
                IP Host:
              </Typography>
              <Typography variant="body2" fontWeight="medium">
                {pod.hostIP}
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={12} sm={6}>
            <Box display="flex" alignItems="center" gap={1}>
              <TimeIcon color="action" sx={{ fontSize: 18 }} />
              <Typography variant="body2" color="text.secondary">
                Créé:
              </Typography>
              <CustomTooltip title={formatDate(pod.creationTimestamp)}>
                <Typography variant="body2" fontWeight="medium">
                  {new Date(pod.creationTimestamp).toLocaleDateString()}
                </Typography>
              </CustomTooltip>
            </Box>
          </Grid>
          <Grid item xs={12} sm={6}>
            <Box display="flex" alignItems="center" gap={1}>
              <RestartIcon color="action" sx={{ fontSize: 18 }} />
              <Typography variant="body2" color="text.secondary">
                Politique:
              </Typography>
              <Typography variant="body2" fontWeight="medium">
                {pod.restartPolicy}
              </Typography>
            </Box>
          </Grid>
        </Grid>

        {/* Metrics Grid */}
        <Grid container spacing={3}>
          {/* CPU Metrics */}
          <Grid item xs={12} md={6}>
            <Card
              variant="outlined"
              sx={{
                p: 2.5,
                bgcolor: "rgba(33, 150, 243, 0.05)",
                border: "1px solid rgba(33, 150, 243, 0.2)",
                borderRadius: 2,
              }}
            >
              <Box display="flex" alignItems="center" mb={2}>
                <Box
                  sx={{
                    p: 1,
                    borderRadius: "50%",
                    bgcolor: "primary.main",
                    color: "white",
                    mr: 1.5,
                  }}
                >
                  <CpuIcon sx={{ fontSize: 20 }} />
                </Box>
                <Typography
                  variant="subtitle1"
                  fontWeight="bold"
                  color="primary"
                >
                  CPU
                </Typography>
              </Box>

              <Box mb={2}>
                <Box
                  display="flex"
                  justifyContent="space-between"
                  alignItems="center"
                  mb={1}
                >
                  <Box display="flex" alignItems="center">
                    <RequestIcon
                      sx={{ fontSize: 16, mr: 0.5, color: "success.main" }}
                    />
                    <Typography variant="body2" color="text.secondary">
                      Demande
                    </Typography>
                  </Box>
                  <CustomBadge
                    text={formatResource(pod.requestCPU)}
                    backgroundColor="#e8f5e8"
                    textColor="#2e7d32"
                    textSize="0.8rem"
                  />
                </Box>

                <Box
                  display="flex"
                  justifyContent="space-between"
                  alignItems="center"
                >
                  <Box display="flex" alignItems="center">
                    <LimitIcon
                      sx={{ fontSize: 16, mr: 0.5, color: "error.main" }}
                    />
                    <Typography variant="body2" color="text.secondary">
                      Limite
                    </Typography>
                  </Box>
                  <CustomBadge
                    text={formatResource(pod.limitCPU)}
                    backgroundColor="#ffebee"
                    textColor="#c62828"
                    textSize="0.8rem"
                  />
                </Box>
              </Box>
            </Card>
          </Grid>

          {/* RAM Metrics */}
          <Grid item xs={12} md={6}>
            <Card
              variant="outlined"
              sx={{
                p: 2.5,
                bgcolor: "rgba(156, 39, 176, 0.05)",
                border: "1px solid rgba(156, 39, 176, 0.2)",
                borderRadius: 2,
              }}
            >
              <Box display="flex" alignItems="center" mb={2}>
                <Box
                  sx={{
                    p: 1,
                    borderRadius: "50%",
                    bgcolor: "secondary.main",
                    color: "white",
                    mr: 1.5,
                  }}
                >
                  <MemoryIcon sx={{ fontSize: 20 }} />
                </Box>
                <Typography
                  variant="subtitle1"
                  fontWeight="bold"
                  color="secondary"
                >
                  Mémoire
                </Typography>
              </Box>

              <Box mb={2}>
                <Box
                  display="flex"
                  justifyContent="space-between"
                  alignItems="center"
                  mb={1}
                >
                  <Box display="flex" alignItems="center">
                    <RequestIcon
                      sx={{ fontSize: 16, mr: 0.5, color: "success.main" }}
                    />
                    <Typography variant="body2" color="text.secondary">
                      Demande
                    </Typography>
                  </Box>
                  <CustomBadge
                    text={formatResource(pod.requestRAM)}
                    backgroundColor="#e8f5e8"
                    textColor="#2e7d32"
                    textSize="0.8rem"
                  />
                </Box>

                <Box
                  display="flex"
                  justifyContent="space-between"
                  alignItems="center"
                >
                  <Box display="flex" alignItems="center">
                    <LimitIcon
                      sx={{ fontSize: 16, mr: 0.5, color: "error.main" }}
                    />
                    <Typography variant="body2" color="text.secondary">
                      Limite
                    </Typography>
                  </Box>
                  <CustomBadge
                    text={formatResource(pod.limitRAM)}
                    backgroundColor="#ffebee"
                    textColor="#c62828"
                    textSize="0.8rem"
                  />
                </Box>
              </Box>
            </Card>
          </Grid>
        </Grid>

        {/* Labels */}
        {pod.labels && Object.keys(pod.labels).length > 0 && (
          <Box mt={3}>
            <Typography variant="subtitle2" color="text.secondary" mb={1}>
              Labels:
            </Typography>
            <Box display="flex" flexWrap="wrap" gap={1}>
              {Object.entries(pod.labels).map(([key, value], index) => (
                <CustomBadge
                  key={index}
                  text={`${key}: ${value}`}
                  backgroundColor={getCssVariableValue(
                    "--action-icon-button-background-color",
                  )}
                  textColor="text.primary"
                  textSize="1rem"
                />
              ))}
            </Box>
          </Box>
        )}

        {/* Container Status */}
        {pod.containerStatuses && pod.containerStatuses.length > 0 && (
          <Box mt={3}>
            <Typography variant="subtitle2" color="text.secondary" mb={1}>
              Conteneurs:
            </Typography>
            <Box display="flex" flexWrap="wrap" gap={1}>
              {pod.containerStatuses.map((container, index) => (
                <CustomTooltip key={index} title={`Image: ${container.image}`}>
                  <Box>
                    <CustomBadge
                      text={container.name}
                      backgroundColor={container.ready ? "#e8f5e8" : "#ffebee"}
                      textColor={container.ready ? "#2e7d32" : "#c62828"}
                      textSize="0.75rem"
                    />
                  </Box>
                </CustomTooltip>
              ))}
            </Box>
          </Box>
        )}
      </CardContent>
    </Card>
  );
};

export default PodMetricsCard;
