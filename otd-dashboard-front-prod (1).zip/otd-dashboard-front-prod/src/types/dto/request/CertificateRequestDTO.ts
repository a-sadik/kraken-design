// src/types/dto/request/CertificateRequestDTO.ts

export interface InternCertificateRequestDTO {
  certificate_target: string;
  dns: string[] | null;
  common_name: string;
  solution_id: number;
  certificate_type: string;
  application_comment: string | null;
}

export interface ExternCertificateRequestDTO {
  certificate_target: string;
  certificate_key: string | null;
  dns: string[] | null;
  common_name: string;
  solution_id: number;
  certificate_type: string | null;
  application_comment: string | null;
}

export interface CertificateAfterCreatingRequestDTO {
  action_comment: string;
}
