// import React from 'react';
// import { Button, Paper, Stack } from '@mui/material';
// import { Business, AccountTree,  Apps } from '@mui/icons-material';
// import { colors, darkColors, pastelTheme } from './utils/colors';
// import { TbBuildingBank } from 'react-icons/tb';

// interface GlobalNavButtonsProps {
//   fetchGlobalData: (type: string) => void;
// }

// const GlobalNavButtons = () => (
//     <Paper
//       elevation={0}
//       sx={{
//         background: `linear-gradient(135deg, ${pastelTheme.surface} 0%, ${pastelTheme.surface} 100%)`,
//         borderBottom: `2px solid ${pastelTheme.outline}`,
//         py: 2,
//         px: 3,
//         boxShadow: `0 2px 8px ${pastelTheme.shadow}`,
//         borderRadius: 0,
//       }}
//     >
//       <Stack direction="row" spacing={2} justifyContent="center" flexWrap="wrap">
//         <Button
//           variant="contained"
//           startIcon={<Business />}
//           onClick={() => fetchGlobalData("entities")}
//           sx={{
//             backgroundColor: colors.entity,
//             color: pastelTheme.textPrimary,
//             fontWeight: 700,
//             borderRadius: 3,
//             px: 3,
//             py: 1,
//             "&:hover": {
//               backgroundColor: darkColors.entity,
//             },
//           }}
//         >
//           Toutes les Entités
//         </Button>
//         <Button
//           variant="contained"
//           startIcon={<AccountTree />}
//           onClick={() => fetchGlobalData("poles")}
//           sx={{
//             backgroundColor: colors.pole,
//             color: pastelTheme.textPrimary,
//             fontWeight: 700,
//             borderRadius: 3,
//             px: 3,
//             py: 1,
//             "&:hover": {
//               backgroundColor: darkColors.pole,
//             },
//           }}
//         >
//           Tous les Pôles
//         </Button>
//         <Button
//           variant="contained"
//           startIcon={<TbBuildingBank />}
//           onClick={() => fetchGlobalData("domains")}
//           sx={{
//             backgroundColor: colors.domain,
//             color: pastelTheme.textPrimary,
//             fontWeight: 700,
//             borderRadius: 3,
//             px: 3,
//             py: 1,
//             "&:hover": {
//               backgroundColor: darkColors.domain,
//             },
//           }}
//         >
//           Tous les Domaines
//         </Button>
//         <Button
//           variant="contained"
//           startIcon={<Apps />}
//           onClick={() => fetchGlobalData("solutions")}
//           sx={{
//             backgroundColor: colors.deployment,
//             color: pastelTheme.textPrimary,
//             fontWeight: 700,
//             borderRadius: 3,
//             px: 3,
//             py: 1,
//             "&:hover": {
//               backgroundColor: darkColors.solution,
//             },
//           }}
//         >
//           Toutes les Solutions
//         </Button>
//       </Stack>
//     </Paper>

//   )

// export default GlobalNavButtons;

// function fetchGlobalData(arg0: string): void {
//     throw new Error('Function not implemented.');
// }
