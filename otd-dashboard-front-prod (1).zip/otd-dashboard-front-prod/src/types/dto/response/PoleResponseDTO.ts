// src/types/dto/response/PoleResponseDTO.ts

export interface PoleResponseDTO {
  pole_id: number;
  pole_name: string;
  pole_manager: string;
  created_at: Date;
  updated_at?: Date;
  created_by: string;
  updated_by?: string;
}
