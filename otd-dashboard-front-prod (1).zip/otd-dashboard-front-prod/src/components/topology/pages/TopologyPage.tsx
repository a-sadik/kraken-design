// import React, { useState, useEffect } from 'react';
// import { Box, Container } from '@mui/material';
// import BreadcrumbNav from '../BreadcrumbNav';
// import GlobalNavButtons from '../GlobalNavButtons';
// import StatsNavBar from '../StatsNavBar';
// import DataGrid from '../DataGrid';
// import { getTopologyRootApiUrl, getAllTopology } from '@/config/api.config';
// import { colors, darkColors, envColors, osColors, pastelTheme, modernTheme } from '../utils/colors';
// import { Business, AccountTree, Apps, Person, NavigateNext, Home, KeyboardArrowRight, VisibilityOff, Visibility } from '@mui/icons-material';
// import { DiOpenshift } from 'react-icons/di';
// import { PiCubeBold } from 'react-icons/pi';
// import { VscSymbolNamespace } from 'react-icons/vsc';
// import { LuRocket } from 'react-icons/lu';
// import { TbBuildingBank } from 'react-icons/tb';
// import { FiServer } from 'react-icons/fi';
// import { MdAdminPanelSettings, MdOutlineAdminPanelSettings } from 'react-icons/md';

// interface NavigationState {
//   currentLevel: "entity" | "pole" | "domain" | "solution" | "namespace" | "deployment" | "server" | "pod"
//   currentItem: any
//   breadcrumb: any[]
//   history: any[]
// }

// const TopologyPage: React.FC = () => {
//   const [navigation, setNavigation] = useState<NavigationState>({
//     currentLevel: "entity",
//     currentItem: null,
//     breadcrumb: [],
//     history: [],
//   });

//   const [entities, setEntities] = useState<any[]>([]);
//   const [loadedData, setLoadedData] = useState<Map<string, any[]>>(new Map());
//   const [loading, setLoading] = useState<Set<string>>(new Set());
//   const [errors, setErrors] = useState<Map<string, string>>(new Map());
//   const [currentData, setCurrentData] = useState<any[]>([]);
//   const [dataLoaded, setDataLoaded] = useState(false);

//   useEffect(() => {
//     fetchEntities();
//   }, []);

//   const fetchEntities = async () => {
//     setLoading((prev) => new Set(prev).add("entities"));
//     try {
//       const response = await fetch(getTopologyRootApiUrl());
//       if (!response.ok) throw new Error("Failed to fetch entities");
//       const data = await response.json();
//       setEntities(data);
//       setCurrentData(data);
//     } catch (error) {
//       setErrors((prev) => new Map(prev).set("entities", "Erreur lors du chargement des entités"));
//     } finally {
//       setLoading((prev) => {
//         const newSet = new Set(prev);
//         newSet.delete("entities");
//         return newSet;
//       });
//     }
//   };

//   const fetchGlobalData = async (type: string) => {
//     setLoading((prev) => new Set(prev).add(type));
//     try {
//       const response = await fetch(getAllTopology(type));
//       if (!response.ok) throw new Error(`Failed to fetch ${type}`);
//       const data = await response.json();
//       setCurrentData(data);
//     } catch (error) {
//       setErrors((prev) => new Map(prev).set(type, `Erreur lors du chargement de ${type}`));
//     } finally {
//       setLoading((prev) => {
//         const newSet = new Set(prev);
//         newSet.delete(type);
//         return newSet;
//       });
//     }
//   };

//   const navigateToChild = async (item: any, level: string) => {
//     const newBreadcrumbItem: BreadcrumbItem = {
//       name: item[`${level}_name`] || item.name || item.hostname || item.pod_name,
//       level: level as any,
//       data: item,
//       elementId: `${level}-${item[`${level}_id`] || item.id}`,
//     }

//     // Sauvegarder l'état actuel dans l'historique
//     const historyItem = {
//       level: navigation.currentLevel,
//       item: navigation.currentItem,
//       data: [...currentData], // Copie des données actuelles
//     }

//     // Charger les données enfants
//     let childData: any[] = []
//     let childKey = ""

//     if (level === "entity" && item.child) {
//       childKey = `entity-${item.entity_id}-poles`
//       childData = (await fetchChildData(item.child, childKey)) || []
//     } else if (level === "pole" && item.child) {
//       childKey = `pole-${item.pole_id}-domains`
//       childData = (await fetchChildData(item.child, childKey)) || []
//     } else if (level === "domain" && item.child) {
//       childKey = `domain-${item.domain_id}-solutions`
//       childData = (await fetchChildData(item.child, childKey)) || []
//       if (childData.length > 0) {
//         await fetchSolutionWithChildren(childKey, childData)
//       }
//     } else if (level === "solution") {
//       // Pour les solutions, on garde la solution elle-même comme donnée
//       childData = [item]
//     }

//     setNavigation((prev) => ({
//       currentLevel: getNextLevel(level),
//       currentItem: item,
//       breadcrumb: [...prev.breadcrumb, newBreadcrumbItem],
//       history: [...prev.history, historyItem],
//     }))

//     setCurrentData(childData)
//   }

//   const navigateToBreadcrumb = (index: number) => {
//     if (index === -1) {
//       // Retour à l'accueil
//       setNavigation({
//         currentLevel: "entity",
//         currentItem: null,
//         breadcrumb: [],
//         history: [],
//       })
//       setCurrentData(entities)
//     } else {
//       // Récupérer les données depuis l'historique
//       const targetHistoryIndex = index
//       const targetHistory = navigation.history[targetHistoryIndex]

//       if (targetHistory) {
//         setNavigation({
//           currentLevel: targetHistory.level as NavigationState["currentLevel"],
//           currentItem: targetHistory.item,
//           breadcrumb: navigation.breadcrumb.slice(0, index + 1),
//           history: navigation.history.slice(0, index + 1),
//         })
//         setCurrentData(targetHistory.data)
//       }
//     }
//   }

//   return (
//     <Box sx={{ minHeight: "100vh", backgroundColor: pastelTheme.background }}>
//       <BreadcrumbNav navigation={navigation} navigateToBreadcrumb={navigateToBreadcrumb} />
//       <GlobalNavButtons fetchGlobalData={fetchGlobalData} />
//       <StatsNavBar navigation={navigation} />
//       <Container maxWidth="xl" sx={{ py: 4 }}>
//         <DataGrid currentData={currentData} navigation={navigation} navigateToChild={navigateToChild} />
//       </Container>
//     </Box>
//   );
// };

// export default TopologyPage;
