import React, { useState, useEffect } from "react";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  IconButton,
  Typography,
  Divider,
  Box,
  CircularProgress,
  Card,
  CardHeader,
  CardContent,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import AttachMoneyIcon from "@mui/icons-material/AttachMoney";
import ShowChartIcon from "@mui/icons-material/ShowChart";
import SolutionIcon from "@mui/icons-material/Apps";
import StorageIcon from "@mui/icons-material/Storage";
import AccessTimeIcon from "@mui/icons-material/AccessTime";

// Imports file
import { ProjectAmountsResponseDTO } from "@/types/dto/response/ProjectAmountsResponseDTO";
import { getAllServers } from "@/services/ServerService";
import { getAllSolutions } from "@/services/SolutionService";
import DataTable from "../data-tables/DataTable";
import ServerView from "@/types/view/ServerView";
import SolutionView from "@/types/view/SolutionView";
import { SolutionDetailResponseDTO } from "@/types/dto/response/solution/SolutionDetailResponseDTO";
import { solutionResToView } from "@/mappers/SolutionMapper";

interface ProjectAmountsModalProps {
  open: boolean;
  onClose: () => void;
  modalContent: ProjectAmountsResponseDTO;
  entity: string;
}

interface InfoRowProps {
  icon: React.ReactNode;
  label: string;
  value: any;
  colorBackgroundIcon: string;
}

const InfoRow: React.FC<InfoRowProps> = ({
  icon,
  label,
  value,
  colorBackgroundIcon,
}) => (
  <Box sx={{ display: "flex", alignItems: "center", gap: 1, marginY: 1 }}>
    <Box
      sx={{
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        width: 36,
        height: 36,
        borderRadius: "50%",
        backgroundColor: colorBackgroundIcon,
      }}
    >
      {icon}
    </Box>
    <Typography
      variant="body1"
      sx={{ fontWeight: "bold", fontSize: "1.25rem" }}
    >
      {label}:
    </Typography>
    <Typography sx={{ fontSize: "1.25rem" }}>{value}</Typography>
  </Box>
);

const ProjectAmountsModal: React.FC<ProjectAmountsModalProps> = ({
  open,
  onClose,
  modalContent,
  entity,
}) => {
  const [servers, setServers] = useState<ServerView[]>([]);
  const [solutions, setSolutions] = useState<SolutionView[]>([]);
  const [loadingServers, setLoadingServers] = useState<boolean>(false);
  const [loadingSolutions, setLoadingSolutions] = useState<boolean>(false);
  const [showServers, setShowServers] = useState<boolean>(false);
  const [showSolutions, setShowSolutions] = useState<boolean>(false);

  const backgroundColors: Record<string, string> = {
    green: "#DCFFB7",
    red: "#FF6868",
    orange: "#FFBB64",
    default: "#FFFFFF",
  };
  const backgroundColor = backgroundColors[modalContent?.etat] || "#FFFFFF";

  const customTheme = createTheme({
    palette: {
      primary: { main: backgroundColor },
    },
  });

  const fetchServers = async () => {
    setShowSolutions(false);
    setLoadingServers(true);
    try {
      const serverData = await getAllServers();
      setServers(serverData as any);
    } catch (error) {
      console.error("Erreur lors de la récupération des serveurs:", error);
    } finally {
      setLoadingServers(false);
      setShowServers(true);
    }
  };

  const fetchSolutions = async () => {
    setShowServers(false);
    setLoadingSolutions(true);
    try {
      const data: SolutionDetailResponseDTO[] = await getAllSolutions();
      const solutionData: SolutionView[] = solutionResToView(data);

      setSolutions(solutionData);
    } catch (error) {
      console.error("Erreur lors de la récupération des solutions:", error);
    } finally {
      setLoadingSolutions(false);
      setShowSolutions(true);
    }
  };

  useEffect(() => {
    if (!open) {
      setServers([]);
      setSolutions([]);
      setShowServers(false);
      setShowSolutions(false);
    }
  }, [open]);

  const infoRows = [
    {
      icon: <AttachMoneyIcon />,
      label: "Budget",
      value: `${modalContent?.budget} Dhs`,
    },
    {
      icon: <ShowChartIcon />,
      label: "Consommation",
      value: `${modalContent?.consumption} Dhs`,
    },
    {
      icon: <SolutionIcon />,
      label: "Solutions",
      value: (
        <span
          style={{ cursor: "pointer", color: "blue" }}
          onClick={fetchSolutions}
        >
          {modalContent?.statistic?.apps}
        </span>
      ),
    },
    {
      icon: <StorageIcon />,
      label: "Serveurs",
      value: (
        <span
          style={{ cursor: "pointer", color: "blue" }}
          onClick={fetchServers}
        >
          {modalContent?.statistic?.servers}
        </span>
      ),
    },
    {
      icon: <AccessTimeIcon />,
      label: "Intervention (j/h)",
      value: modalContent?.statistic?.interval,
    },
  ];

  return (
    <Dialog open={open} onClose={onClose}>
      <DialogTitle
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          position: "relative",
          background: backgroundColor,
          padding: "16px",
        }}
      >
        <Typography
          sx={{
            fontWeight: "bold",
            fontSize: { xs: "1.5rem", sm: "2rem", md: "2.5rem", lg: "1.5rem" },
            mx: "3rem",
            width: "30rem",
          }}
        >
          {modalContent?.name}
        </Typography>
        <IconButton
          aria-label="close"
          onClick={onClose}
          sx={{ position: "absolute", right: 8, top: 8, padding: 0 }}
        >
          <CloseIcon />
        </IconButton>
      </DialogTitle>

      <Divider />

      <DialogContent>
        <ThemeProvider theme={customTheme}>
          <Box sx={{ display: "grid", gap: 2, marginTop: 2 }}>
            <Box
              sx={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 2 }}
            >
              {/* Premier InfoRow centré à gauche */}
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                {infoRows.slice(0, 1).map((row, idx) => (
                  <InfoRow
                    key={idx}
                    icon={row.icon}
                    label={row.label}
                    value={row.value}
                    colorBackgroundIcon={backgroundColor}
                  />
                ))}
              </Box>
              {/* Deuxième InfoRow centré à droite */}
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                {infoRows.slice(1, 2).map((row, idx) => (
                  <InfoRow
                    key={idx}
                    icon={row.icon}
                    label={row.label}
                    value={row.value}
                    colorBackgroundIcon={backgroundColor}
                  />
                ))}
              </Box>
            </Box>

            <Box
              sx={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr 1fr",
                gap: 2,
                marginTop: 2,
              }}
            >
              {infoRows.slice(2).map((row, idx) => (
                <InfoRow
                  key={idx}
                  icon={row.icon}
                  label={row.label}
                  value={row.value}
                  colorBackgroundIcon={backgroundColor}
                />
              ))}
            </Box>
          </Box>

          {loadingServers ? (
            <Box
              sx={{ display: "flex", justifyContent: "center", marginTop: 2 }}
            >
              <CircularProgress />
            </Box>
          ) : (
            showServers &&
            servers.length > 0 && (
              <Card sx={{ mt: "3rem" }}>
                <CardHeader
                  title="Serveurs"
                  sx={{
                    backgroundColor: "#343a40",
                    color: "white",
                    fontWeight: "bold",
                    padding: "1rem",
                  }}
                />
                <CardContent>
                  <DataTable
                    fileName={`Serveurs de ${entity} ${modalContent?.name}`}
                    rows={servers.map(({ ...serverData }) => serverData)}
                    color={backgroundColor}
                  />
                </CardContent>
              </Card>
            )
          )}

          {loadingSolutions ? (
            <Box
              sx={{ display: "flex", justifyContent: "center", marginTop: 2 }}
            >
              <CircularProgress />
            </Box>
          ) : (
            showSolutions &&
            solutions.length > 0 && (
              <Card sx={{ mt: "3rem" }}>
                <CardHeader
                  title="Solutions"
                  sx={{
                    backgroundColor: "#343a40",
                    color: "white",
                    fontWeight: "bold",
                    padding: "1rem",
                  }}
                />
                <CardContent>
                  <DataTable
                    fileName={`Solutions de ${entity} ${modalContent?.name}`}
                    rows={solutions.map(({ ...solutionData }) => ({
                      ...solutionData,
                      // "Critical": pci ? 'Oui' : 'Non'
                    }))}
                    color={backgroundColor}
                  />
                </CardContent>
              </Card>
            )
          )}
        </ThemeProvider>
      </DialogContent>
    </Dialog>
  );
};

export default ProjectAmountsModal;
