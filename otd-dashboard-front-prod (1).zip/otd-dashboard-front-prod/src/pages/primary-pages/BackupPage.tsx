// src/pages/primary-pages/AactionsPage.tsx
import React, { useState, useEffect, useMemo, useCallback } from "react";
import { Box, Typography, Paper, Container, TextField, InputAdornment, Chip, Stack, Grid, Card, CardContent, CardHeader, Button, Collapse, Zoom, IconButton, Avatar, Alert, CircularProgress, Dialog, DialogTitle, DialogContent, DialogActions, Checkbox, FormControlLabel, FormGroup, LinearProgress, Snackbar,
} from "@mui/material";
import { FiSearch, FiDownloadCloud, FiPackage, FiChevronDown, FiChevronUp, FiServer, FiShield,
} from "react-icons/fi";
import { alpha } from "@mui/material/styles";
import fetchWithAuth from "@/middleware/fetch-auth";
import { getMyViewApiUrl } from "@/config/api.config";

// Import des couleurs des environnements depuis TopologyPage
import { envColors, colors } from "@/pages/primary-pages/TopologyPage";

interface Server {
  id: number;
  hostname: string;
  ip_addresses: string[];
  os_type: string;
}

interface Solution {
  id: number;
  solution_name: string;
  list_environnements: string[];
  child_servers: Array<{ [env: string]: string }>;
  count_servers?: number;
}

// Type pour stocker les données par environnement
interface AppDataByEnv {
  [env: string]: {
    servers: Server[];
    loading: boolean;
    loaded: boolean;
  };
}

// Fonction pour obtenir la couleur d'un environnement
const getEnvColor = (environment: string): string => {
  const envMap: Record<string, keyof typeof envColors> = {
    "Production": "Production",
    "Préproduction": "Préproduction",
    "Recette": "Recette",
    "Développement": "Développement",
    "Technique": "Technique",
    "Intégration": "Intégration",
    "Formation": "Formation",
  };

  const envKey = envMap[environment] || "Production";
  return envColors[envKey];
};

// Fonction pour obtenir la couleur de fond d'un environnement
const getEnvBackgroundColor = (environment: string): string => {
  const color = getEnvColor(environment);
  return alpha(color, 0.15);
};

// Fonction pour obtenir la couleur du texte selon le fond
const getEnvTextColor = (environment: string): string => {
  if (environment === "Préproduction" || environment === "Recette" || environment === "Développement") {
    return "#333333";
  }

  return "#ffffff";
};

// Constante pour l'environnement Production
const PRODUCTION_ENV = "Production";

const AactionsPage: React.FC = () => {
  const [solutions, setSolutions] = useState<Solution[]>([]);
  const [appDataByEnv, setAppDataByEnv] = useState<Map<number, AppDataByEnv>>(new Map());
  const [expandedApps, setExpandedApps] = useState<Set<number>>(new Set());
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);

  // NetBackup modal
  const [openNetBackup, setOpenNetBackup] = useState(false);
  const [selectedApps, setSelectedApps] = useState<number[]>([]);
  const [selectedServers, setSelectedServers] = useState<{ appId: number; serverId: number; env: string }[]>([]);
  const [sending, setSending] = useState(false);
  const [snackbar, setSnackbar] = useState<{ open: boolean; message: string; severity: "success" | "error" }>({
    open: false,
    message: "",
    severity: "success",
  });

  // Chargement initial des applications - SEULEMENT celles qui ont l'environnement Production
  useEffect(() => {
    const loadMyApps = async () => {
      try {
        const res = await fetchWithAuth(getMyViewApiUrl());
        if (!res.ok) throw new Error("my-view failed");
        const json = await res.json();
        const apps = json.applications || [];

        // Filtrer uniquement les applications qui ont l'environnement Production
        const formatted: Solution[] = apps
          .filter((app: any) => {
            // Vérifier si l'application a l'environnement Production
            return app.list_environnements?.includes(PRODUCTION_ENV);
          })
          .map((app: any) => ({
            id: app.id,
            solution_name: app.solution_name,
            list_environnements: app.list_environnements || [],
            child_servers: app.child_servers || [],
            count_servers: app.count_servers,
          }));

        setSolutions(formatted);

      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    loadMyApps();
  }, []);

  // Chargement lazy des données d'une app pour l'environnement Production
  const loadAppDataForProduction = useCallback(async (sol: Solution) => {
    const appEnvData = appDataByEnv.get(sol.id);
    if (appEnvData?.[PRODUCTION_ENV]?.loaded) return;

    // Initialiser les données pour l'environnement Production
    setAppDataByEnv(prev => {
      const newMap = new Map(prev);
      const currentAppData = newMap.get(sol.id) || {};
      newMap.set(sol.id, {
        ...currentAppData,
        [PRODUCTION_ENV]: {
          servers: [],
          loading: true,
          loaded: false
        }
      });
      return newMap;
    });

    const servers: Server[] = [];

    // Charger les serveurs pour l'environnement Production
    const serverEntry = sol.child_servers.find(obj => {
      const key = Object.keys(obj)[0];
      return key === PRODUCTION_ENV;
    });

    if (serverEntry && serverEntry[PRODUCTION_ENV]) {
      try {
        const res = await fetchWithAuth(serverEntry[PRODUCTION_ENV]);
        if (res.ok) {
          const serverData = await res.json();
          servers.push(...serverData);
        }
      } catch (e) {
        console.warn(`Serveurs failed for ${PRODUCTION_ENV}`, e);
      }
    }

    // Mettre à jour les données
    setAppDataByEnv(prev => {
      const newMap = new Map(prev);
      const currentAppData = newMap.get(sol.id) || {};
      newMap.set(sol.id, {
        ...currentAppData,
        [PRODUCTION_ENV]: {
          servers,
          loading: false,
          loaded: true
        }
      });
      return newMap;
    });
  }, [appDataByEnv]);

  // Charger les données quand on expand une application
  const toggleExpand = (sol: Solution) => {
    const newSet = new Set(expandedApps);
    if (newSet.has(sol.id)) {
      newSet.delete(sol.id);
    } else {
      newSet.add(sol.id);
      loadAppDataForProduction(sol);
    }
    setExpandedApps(newSet);
  };

  const filteredSolutions = useMemo(() => {
    // Déjà filtrées pour n'avoir que les applications avec Production
    if (!searchTerm) return solutions;

    const lower = searchTerm.toLowerCase();
    return solutions.filter(sol => {
      if (sol.solution_name.toLowerCase().includes(lower)) return true;

      const appData = appDataByEnv.get(sol.id);
      if (!appData) return false;

      const data = appData[PRODUCTION_ENV];
      if (!data?.loaded) return false;
      return data.servers.some(s => s.hostname.toLowerCase().includes(lower));
    });
  }, [solutions, appDataByEnv, searchTerm]);

  // Fonction pour obtenir les données d'une application pour l'environnement Production
  const getAppData = (solId: number) => {
    const appData = appDataByEnv.get(solId);
    if (!appData) return null;

    return appData[PRODUCTION_ENV] || { servers: [], loading: false, loaded: false };
  };

  // Export CSV global - UNIQUEMENT Production
  const exportGlobalToCSV = useCallback(async () => {
    const rows: string[] = [];
    const headers = ["Application", "Environnement", "Serveur", "IP", "OS"];

    solutions.forEach(sol => {
      const data = getAppData(sol.id);
      if (!data?.loaded) return;

      const appName = sol.solution_name;

      data.servers.forEach(s => {
        s.ip_addresses.forEach(ip => {
          rows.push([
            appName,
            PRODUCTION_ENV,
            s.hostname,
            ip,
            s.os_type
          ].map(v => `"${v}"`).join(";"));
        });
      });
    });

    const csv = "\uFEFF" + [headers.join(";"), ...rows].join("\r\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `KRAKEN_Production_Serveurs_${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }, [solutions, appDataByEnv]);

  const exportAppToCSV = (sol: Solution) => {
    const data = getAppData(sol.id);
    if (!data?.loaded) {
      setSnackbar({
        open: true,
        message: "Chargement des données requis avant l'export",
        severity: "error"
      });
      return;
    }

    const rows: string[] = [];
    const appName = sol.solution_name;
    const headers = ["Application", "Environnement", "Serveur", "IP", "OS"];

    data.servers.forEach(s => {
      s.ip_addresses.forEach(ip => {
        rows.push([appName, PRODUCTION_ENV, s.hostname, ip, s.os_type].map(v => `"${v}"`).join(";"));
      });
    });

    const csv = "\uFEFF" + [headers.join(";"), ...rows].join("\r\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${appName.replace(/[^a-zA-Z0-9]/g, "_")}_Production_Serveurs.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // NetBackup logic
  const toggleAppSelection = (appId: number) => {
    setSelectedApps(prev => {
      const willBeSelected = !prev.includes(appId);
      if (willBeSelected) {
        const sol = solutions.find(s => s.id === appId);
        if (sol) {
          loadAppDataForProduction(sol);
        }
      } else {
        setSelectedServers(s => s.filter(x => x.appId !== appId));
      }
      return willBeSelected ? [...prev, appId] : prev.filter(id => id !== appId);
    });
  };

  const toggleServer = (appId: number, serverId: number) => {
    setSelectedServers(prev => {
      const exists = prev.some(s => s.appId === appId && s.serverId === serverId && s.env === PRODUCTION_ENV);
      return exists
        ? prev.filter(s => !(s.appId === appId && s.serverId === serverId && s.env === PRODUCTION_ENV))
        : [...prev, { appId, serverId, env: PRODUCTION_ENV }];
    });
  };

  const sendToNetBackup = async () => {
    if (selectedServers.length === 0) {
      setSnackbar({ open: true, message: "Sélectionne au moins un serveur", severity: "error" });
      return;
    }

    setSending(true);

    const payload = {
      environment: PRODUCTION_ENV,
      servers: selectedServers.map(s => {
        const app = solutions.find(a => a.id === s.appId);
        const appData = appDataByEnv.get(s.appId);
        const server = appData?.[PRODUCTION_ENV]?.servers.find(srv => srv.id === s.serverId);
        return {
          application: app?.solution_name,
          hostname: server?.hostname,
          ip: server?.ip_addresses[0],
          environment: PRODUCTION_ENV
        };
      }),
    };

    try {
      const res = await fetchWithAuth("/api/net_backup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        setSnackbar({ open: true, message: "Demande NetBackup envoyée avec succès !", severity: "success" });
        setOpenNetBackup(false);
        setSelectedApps([]);
        setSelectedServers([]);
      } else {
        throw new Error(await res.text() || "Erreur serveur");
      }
    } catch (e: any) {
      setSnackbar({ open: true, message: "Échec : " + e.message, severity: "error" });
    } finally {
      setSending(false);
    }
  };

  if (loading) {
    return (
      <Container maxWidth="xl" sx={{ py: 20, textAlign: "center" }}>
        <CircularProgress size={80} thickness={5} />
        <Typography variant="h5" sx={{ mt: 4, color: "#1e40af" }}>
          Chargement des applications Production...
        </Typography>
      </Container>
    );
  }

  if (solutions.length === 0) {
    return (
      <Container maxWidth="xl" sx={{ py: 20 }}>
        <Alert severity="info">Aucune application en Production trouvée.</Alert>
      </Container>
    );
  }

  return (
    <Box sx={{ minHeight: "100vh", bgcolor: "#f8faff" }}>
      {/* Header */}
      <Box sx={{ background: "linear-gradient(135deg, #1e40af 0%, #1e3a8a 100%)", py: 6 }}>
        <Container maxWidth="xl">
          <Stack direction="row" justifyContent="space-between" alignItems="center">
            <Stack direction="row" alignItems="center" spacing={4}>
              <Box
                sx={{
                  width: 110,
                  height: 110,
                  bgcolor: "rgba(255,255,255,0.15)",
                  borderRadius: "50%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <FiPackage size={55} color="#fff" />
              </Box>
              <Box>
                <Typography variant="h2" sx={{ color: "#fff", fontWeight: 900 }}>
                  Backup
                </Typography>
                <Typography variant="h5" sx={{ color: "#c3dafe", mt: 1 }}>
                  Mes applications • Production
                </Typography>
              </Box>
            </Stack>

            <Button
              variant="contained"
              size="large"
              startIcon={<FiShield />}
              onClick={() => setOpenNetBackup(true)}
              sx={{
                bgcolor: "#dc2626",
                "&:hover": { bgcolor: "#b91c1c" },
                boxShadow: 6,
                px: 4,
                py: 1.8,
                borderRadius: 3,
              }}
            >
              Récupération NetBackup
            </Button>
          </Stack>
        </Container>
      </Box>

      <Container maxWidth="xl" sx={{ py: 6 }}>
        <Paper elevation={8} sx={{ p: 3, borderRadius: 4, mb: 5, bgcolor: "rgba(255,255,255,0.98)" }}>
          <Stack direction={{ xs: "column", md: "row" }} spacing={3} alignItems="center">
            <TextField
              fullWidth
              placeholder="Rechercher application, serveur..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <FiSearch size={22} />
                  </InputAdornment>
                ),
              }}
              sx={{ "& .MuiOutlinedInput-root": { borderRadius: 3, bgcolor: "rgba(59,130,246,0.05)" } }}
            />

            <Button
              variant="contained"
              size="large"
              startIcon={<FiDownloadCloud />}
              onClick={exportGlobalToCSV}
              sx={{ px: 4, py: 1.5, borderRadius: 3, bgcolor: "#1e40af", boxShadow: 6 }}
            >
              Exporter tout
            </Button>
          </Stack>
        </Paper>

        {filteredSolutions.length === 0 ? (
          <Paper elevation={3} sx={{ p: 6, textAlign: "center", borderRadius: 4 }}>
            <FiPackage size={64} color="#9ca3af" />
            <Typography variant="h6" sx={{ mt: 2, color: "#6b7280" }}>
              Aucune application trouvée en Production
              {searchTerm && ` avec le terme "${searchTerm}"`}
            </Typography>
          </Paper>
        ) : (
          <Grid container spacing={4}>
            {filteredSolutions.map((sol, i) => {
              const isExpanded = expandedApps.has(sol.id);
              const data = getAppData(sol.id);

              return (
                <Grid item xs={12} key={sol.id}>
                  <Zoom in style={{ transitionDelay: `${i * 80}ms` }}>
                    <Card
                      sx={{
                        borderRadius: 5,
                        overflow: "hidden",
                        boxShadow: "0 20px 40px rgba(30,64,175,0.12)",
                        border: "1px solid rgba(59,130,246,0.2)",
                        bgcolor: "rgba(255,255,255,0.98)",
                        transition: "all 0.4s",
                        "&:hover": { transform: "translateY(-8px)", boxShadow: "0 32px 60px rgba(30,64,175,0.2)" },
                      }}
                    >
                      <CardHeader
                        avatar={
                          <Avatar sx={{ bgcolor: "#1e40af", width: 60, height: 60 }}>
                            <FiPackage size={30} />
                          </Avatar>
                        }
                        title={
                          <Typography variant="h5" sx={{ fontWeight: 800, color: "#1e40af" }}>
                            {sol.solution_name}
                          </Typography>
                        }
                        subheader={
                          <Stack direction="row" spacing={1} mt={2} flexWrap="wrap" gap={1}>
                            {data?.loaded ? (
                              data.servers.length > 0 && (
                                <Chip
                                  label={`${data.servers.length} serveurs Production`}
                                  icon={<FiServer />}
                                  sx={{
                                    bgcolor: alpha(colors.server || "#b91c1c", 0.1),
                                    color: colors.server || "#b91c1c",
                                    border: `1px solid ${alpha(colors.server || "#b91c1c", 0.3)}`,
                                  }}
                                  variant="outlined"
                                />
                              )
                            ) : (
                              sol.count_servers && (
                                <Chip
                                  label={`${sol.count_servers} serveurs`}
                                  icon={<FiServer />}
                                  sx={{
                                    bgcolor: alpha(colors.server || "#b91c1c", 0.1),
                                    color: colors.server || "#b91c1c",
                                    border: `1px solid ${alpha(colors.server || "#b91c1c", 0.3)}`,
                                  }}
                                  variant="outlined"
                                />
                              )
                            )}

                            {/* Badge Production */}
                            <Chip
                              label="PRODUCTION"
                              size="small"
                              sx={{
                                bgcolor: getEnvColor(PRODUCTION_ENV),
                                color: getEnvTextColor(PRODUCTION_ENV),
                                fontWeight: 700,
                                fontSize: '0.75rem',
                                border: `1px solid ${alpha(getEnvColor(PRODUCTION_ENV), 0.7)}`,
                                borderRadius: "8px",
                                height: "24px",
                                lineHeight: "24px",
                              }}
                            />
                          </Stack>
                        }
                        action={
                          <Stack direction="row" spacing={1} alignItems="center">
                            {data?.loaded && (
                              <Button
                                variant="outlined"
                                size="small"
                                startIcon={<FiDownloadCloud />}
                                onClick={() => exportAppToCSV(sol)}
                                sx={{
                                  borderColor: alpha("#1e40af", 0.3),
                                  color: "#1e40af",
                                  '&:hover': {
                                    borderColor: "#1e40af",
                                    bgcolor: alpha("#1e40af", 0.05),
                                  }
                                }}
                              >
                                Exporter
                              </Button>
                            )}
                            <IconButton onClick={() => toggleExpand(sol)}>
                              {isExpanded ? <FiChevronUp size={28} /> : <FiChevronDown size={28} />}
                            </IconButton>
                          </Stack>
                        }
                      />

                      <Collapse in={isExpanded} timeout={600}>
                        <CardContent sx={{ pt: 3 }}>
                          {data?.loading ? (
                            <Box textAlign="center" py={6}>
                              <CircularProgress size={50} />
                              <Typography sx={{ mt: 2 }}>
                                Chargement des serveurs Production...
                              </Typography>
                            </Box>
                          ) : data?.loaded ? (
                            <>
                              {/* SERVEURS PRODUCTION */}
                              {data.servers.length > 0 && (
                                <Box sx={{ mb: 6 }}>
                                  <Typography variant="h6" sx={{
                                    color: colors.server || "#b91c1c",
                                    fontWeight: 700,
                                    mb: 3,
                                    display: "flex",
                                    alignItems: "center",
                                    gap: 1,
                                  }}>
                                    <FiServer size={20} />
                                    Serveurs Production ({data.servers.length})
                                  </Typography>

                                  <Grid container spacing={3}>
                                    {data.servers.map(s => (
                                      <Grid item xs={12} sm={6} md={4} key={s.id}>
                                        <Paper
                                          sx={{
                                            p: 3,
                                            borderRadius: 3,
                                            bgcolor: getEnvBackgroundColor(PRODUCTION_ENV),
                                            border: `1px solid ${alpha(getEnvColor(PRODUCTION_ENV), 0.3)}`,
                                            transition: 'all 0.3s ease',
                                            '&:hover': {
                                              transform: 'translateY(-2px)',
                                              boxShadow: `0 8px 16px ${alpha(getEnvColor(PRODUCTION_ENV), 0.15)}`,
                                            }
                                          }}
                                        >
                                          <Box sx={{ display: "flex", alignItems: "center", gap: 2, mb: 1 }}>
                                            <FiServer color={getEnvColor(PRODUCTION_ENV)} size={22} />
                                            <Typography fontWeight={700}>{s.hostname}</Typography>
                                          </Box>
                                          <Typography variant="body2" color="text.secondary" sx={{ mt: 1, display: 'flex', alignItems: 'center', gap: 0.5 }}>
                                            <Box component="span" sx={{ fontFamily: 'monospace' }}>{s.ip_addresses[0]}</Box>
                                            <Box component="span">•</Box>
                                            <Box component="span">{s.os_type}</Box>
                                          </Typography>

                                          {/* Badge Production dans la carte */}
                                          <Box sx={{ mt: 2, display: 'flex', justifyContent: 'flex-end' }}>
                                            <Chip
                                              label="PRODUCTION"
                                              size="small"
                                              sx={{
                                                bgcolor: getEnvColor(PRODUCTION_ENV),
                                                color: getEnvTextColor(PRODUCTION_ENV),
                                                fontWeight: 600,
                                                fontSize: '0.7rem',
                                                height: 20,
                                              }}
                                            />
                                          </Box>
                                        </Paper>
                                      </Grid>
                                    ))}
                                  </Grid>
                                </Box>
                              )}

                              {data.servers.length === 0 && (
                                <Alert severity="info" sx={{ borderRadius: 2 }}>
                                  Aucun serveur trouvé en Production.
                                </Alert>
                              )}
                            </>
                          ) : (
                            <Box textAlign="center" py={6}>
                              <Typography sx={{ mt: 2 }}>
                                Cliquez pour charger les serveurs Production
                              </Typography>
                            </Box>
                          )}
                        </CardContent>
                      </Collapse>
                    </Card>
                  </Zoom>
                </Grid>
              );
            })}
          </Grid>
        )}
      </Container>

      {/* MODALE NETBACKUP */}
      <Dialog open={openNetBackup} onClose={() => !sending && setOpenNetBackup(false)} maxWidth="md" fullWidth>
        <DialogTitle sx={{
          bgcolor: getEnvColor("Recette"),
          color: getEnvTextColor(PRODUCTION_ENV),
          py: 3
        }}>
          <Stack direction="row" alignItems="center" spacing={2}>
            <FiShield size={28} />
            <Typography variant="h5">Récupération NetBackup</Typography>
          </Stack>
          <Typography variant="subtitle1" sx={{ mt: 1, color: "rgba(255,255,255,0.9)" }}>
            Environnement: Production
          </Typography>
        </DialogTitle>
        {sending && <LinearProgress />}

        <DialogContent dividers sx={{ maxHeight: "70vh" }}>
          <Typography variant="body1" gutterBottom>
            Cochez les applications puis sélectionnez les serveurs Production à inclure.
          </Typography>

          <Stack spacing={3} mt={3}>
            {filteredSolutions.map(app => {
              const data = getAppData(app.id);
              const checked = selectedApps.includes(app.id);

              return (
                <Paper
                  key={app.id}
                  variant="outlined"
                  sx={{
                    p: 3,
                    borderRadius: 3,
                    border: `1px solid ${alpha(getEnvColor(PRODUCTION_ENV), 0.2)}`,
                    bgcolor: checked ? alpha(getEnvColor(PRODUCTION_ENV), 0.05) : 'inherit',
                  }}
                >
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={checked}
                        onChange={() => toggleAppSelection(app.id)}
                        sx={{
                          color: getEnvColor("Recette"),
                          '&.Mui-checked': {
                            color: getEnvColor("Recette"),
                          },
                        }}
                      />
                    }
                    label={
                      <Typography fontWeight={600} sx={{ color: getEnvColor("Recette") }}>
                        {app.solution_name}
                      </Typography>
                    }
                  />

                  <Collapse in={checked}>
                    <Box sx={{ mt: 3, pl: 4 }}>
                      {data?.loading && (
                        <Box textAlign="center" py={4}>
                          <CircularProgress size={30} sx={{ color: getEnvColor("Recette") }} />
                          <Typography variant="body2" color="text.secondary">
                            Chargement des serveurs Production...
                          </Typography>
                        </Box>
                      )}

                      {data?.loaded && data.servers.length > 0 && (
                        <>
                          <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                            Serveurs Production ({data.servers.length} serveurs)
                          </Typography>
                          <FormGroup>
                            {data.servers.map(srv => (
                              <FormControlLabel
                                key={srv.id}
                                control={
                                  <Checkbox
                                    checked={selectedServers.some(s => s.appId === app.id && s.serverId === srv.id && s.env === PRODUCTION_ENV)}
                                    onChange={() => toggleServer(app.id, srv.id)}
                                    sx={{
                                      color: getEnvColor("Recette"),
                                      '&.Mui-checked': {
                                        color: getEnvColor("Recette"),
                                      },
                                    }}
                                  />
                                }
                                label={`${srv.hostname} (${srv.ip_addresses[0]})`}
                              />
                            ))}
                          </FormGroup>
                        </>
                      )}

                      {data?.loaded && data.servers.length === 0 && (
                        <Typography color="text.secondary" fontStyle="italic">
                          Aucun serveur en Production.
                        </Typography>
                      )}
                    </Box>
                  </Collapse>
                </Paper>
              );
            })}
          </Stack>
        </DialogContent>

        <DialogActions sx={{ p: 3 }}>
          <Button
            onClick={() => setOpenNetBackup(false)}
            disabled={sending}
            sx={{ color: getEnvColor("Recette") }}
          >
            Annuler
          </Button>
          <Button
            variant="contained"
            onClick={sendToNetBackup}
            disabled={sending || selectedServers.length === 0}
            sx={{
              bgcolor: getEnvColor("Recette"),
              color: getEnvTextColor("Recette"),
              '&:hover': {
                bgcolor: alpha(getEnvColor("Recette"), 0.8),
              }
            }}
          >
            {sending ? "Envoi..." : "Envoyer la demande"}
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar(prev => ({ ...prev, open: false }))}
      >
        <Alert severity={snackbar.severity}>{snackbar.message}</Alert>
      </Snackbar>
    </Box>
  );
};

export default AactionsPage;