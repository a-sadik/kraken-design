import { ServerConformityType } from "@/enums/ServerConformityView";

export interface ServerComparisonRequestDto {
  conformityType: ServerConformityType;
  page?: number;
  limit?: number;
  search?: string;
}

export interface ServerUpdateRequestDto {
  serverId: number;
  updates: {
    [field: string]: string | string[] | null;
  };
}

export interface DropdownOptionsRequestDto {
  fieldName: string;
  endpoint: string;
}
