// src/pages/sub-pages/admin/BackstageOrganigrammePage.tsx

import React, { useEffect, useState, useCallback, useRef, FC } from "react";
import ReactFlow, {
  ReactFlowProvider,
  useNodesState,
  useEdgesState,
  Node,
  Edge,
  ReactFlowInstance,
  NodeChange,
  applyNodeChanges,
} from "reactflow";
import { AxiosError } from "axios";
import "reactflow/dist/style.css";
import {
  Box,
  Typography,
  Button,
  Select,
  MenuItem,
  Paper,
  Dialog,
  DialogTitle,
  DialogContent,
  List,
  ListItem,
  Divider,
} from "@mui/material";
import { APIEntity } from "@/types/dto/BackStageDTO";
import { getHealthBackendData } from "@/services/ServerService";
import {
  getBackStageData,
  getBackStageUsers,
} from "@/services/OrganigrammeService";
import {
  service_data,
  service_failure,
  service_unavailable,
} from "@/utils/customMessages";
import CustomLoading from "@/components/basics/CustomLoading";

interface NodeData {
  label: string;
  parentId?: string;
  level: number;
}

const nodeStyle: React.CSSProperties = {
  minWidth: "120px",
  minHeight: "50px",
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  justifyContent: "space",
  borderRadius: "10px",
  padding: "8px",
  color: "#fff",
  fontSize: "13px",
  textAlign: "center",
  cursor: "pointer",
  boxShadow: "2px 2px 10px rgba(0,0,0,0.2)",
  overflowWrap: "break-word",
  whiteSpace: "normal",
  wordBreak: "break-word",
};

const DEFAULT_POSITION = { x: 750, y: 100 };
const DEFAULT_ZOOM = 0.75;

const OrganigrammePage: FC = () => {
  const [loading, setLoading] = useState(false);
  // const [errorOperationMsg, setErrorOperationMsg] = useState<string | null>(null);
  const [_, setErrorOperationMsg] = useState<string | null>(null);
  const [errorServiceMsg, setErrorServiceMsg] = useState<string | null>(null);

  const [allGroups, setAllGroups] = useState<APIEntity[]>([]);
  const [departments, setDepartments] = useState<APIEntity[]>([]);
  // const [nodes, setNodes, onNodesChange] = useNodesState<NodeData>([]);
  const [nodes, setNodes] = useNodesState<NodeData>([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState<Edge>([]);
  const [selectedDept, setSelectedDept] = useState<string>("");
  const [modalData, setModalData] = useState<APIEntity | null>(null);
  const [users, setUsers] = useState<
    { name: string; displayName?: string; email?: string }[]
  >([]);
  const reactFlowWrapper = useRef<HTMLDivElement | null>(null);
  const reactFlowInstance = useRef<ReactFlowInstance | null>(null);

  const fetchGroupsAndDepartements = async () => {
    setLoading(true);
    setErrorOperationMsg(null);
    setErrorServiceMsg(null);

    try {
      await getHealthBackendData();

      const data = await getBackStageData();

      setAllGroups(data.groups);
      setDepartments(data.departements);
    } catch (err) {
      const error = err as AxiosError;
      console.error(
        "Erreur lors de la récupération des groupes et des départements :",
        err,
      );
      if (error.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    } finally {
      setLoading(false);
    }
  };

  const fetchUsers = async () => {
    setLoading(true);
    setErrorOperationMsg(null);
    setErrorServiceMsg(null);
    try {
      const data = await getBackStageUsers();
      setUsers(data);
    } catch (err) {
      const error = err as AxiosError;
      console.error("Erreur lors de la récupération des users :", err);
      if (error.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchGroupsAndDepartements();
    fetchUsers();
  }, []);

  const centerView = useCallback(() => {
    setNodes((prevNodes) => {
      const root = prevNodes.find((n) => n.data.level === 0);
      if (!root) return prevNodes;
      const offsetX = DEFAULT_POSITION.x - root.position.x;
      const offsetY = DEFAULT_POSITION.y - root.position.y;
      const getDescendants = (id: string): string[] => {
        return prevNodes
          .filter((n) => n.data.parentId === id)
          .flatMap((n) => [n.id, ...getDescendants(n.id)]);
      };
      const descendants = getDescendants(root.id);
      return prevNodes.map((n) => {
        if (n.id === root.id || descendants.includes(n.id)) {
          return {
            ...n,
            position: {
              x: n.position.x + offsetX,
              y: n.position.y + offsetY,
            },
          };
        }
        return n;
      });
    });
    if (reactFlowInstance.current && reactFlowWrapper.current) {
      const { clientWidth } = reactFlowWrapper.current;
      const centerX = clientWidth / 1.7;
      reactFlowInstance.current.setCenter(centerX, 250, {
        zoom: DEFAULT_ZOOM,
        duration: 800,
      });
    }
  }, []);

  const collectChildrenRecursively = (parentId: string): string[] => {
    const result: string[] = [];
    const collect = (id: string) => {
      const children = nodes.filter((n) => n.data.parentId === id);
      for (const child of children) {
        result.push(child.id);
        collect(child.id);
      }
    };
    collect(parentId);
    return result;
  };

  const zoomIn = () => {
    if (reactFlowInstance.current) {
      reactFlowInstance.current.zoomIn();
    }
  };

  const zoomOut = () => {
    if (reactFlowInstance.current) {
      reactFlowInstance.current.zoomOut();
    }
  };

  const displayDepartment = (deptName: string) => {
    setSelectedDept(deptName);
    const dept = departments.find((d) => d.name === deptName);
    if (!dept) return;
    const deptNode: Node<NodeData> = {
      id: dept.name,
      data: { label: dept.title || dept.name, level: 0 },
      position: DEFAULT_POSITION,
      style: { ...nodeStyle, backgroundColor: "#007BFF" },
    };
    setNodes([deptNode]);
    setEdges([]);
    setTimeout(() => centerView(), 100);
  };

  const handleNodeClick = (node: Node<NodeData>) => {
    const parentName = node.id;
    const parentLevel = node.data.level;
    const children = allGroups.filter((e) => e.parent === parentName);
    if (children.length === 0) {
      const entity = allGroups.find((e) => e.name === parentName);
      if (entity) setModalData(entity);
      return;
    }

    const existing = nodes.filter((n) => children.some((c) => c.name === n.id));
    if (existing.length > 0) {
      const toRemove = collectChildrenRecursively(parentName);
      setNodes((prev) => prev.filter((n) => !toRemove.includes(n.id)));
      setEdges((prev) => prev.filter((e) => !toRemove.includes(e.target)));
      return;
    }

    const spacing = 160;
    const total = children.length;
    const startX = node.position.x - ((total - 1) * spacing) / 2;
    const y = node.position.y + 150;

    const newNodes: Node<NodeData>[] = children.map((item, i) => {
      const level = parentLevel + 1;
      const color = level === 1 ? "#28A745" : "#DC3545";
      return {
        id: item.name,
        data: {
          label: `${item.title || item.name} (${allGroups.filter((g) => g.parent === item.name).length})`,
          parentId: parentName,
          level,
        },
        position: { x: startX + i * spacing, y },
        style: {
          ...nodeStyle,
          backgroundColor: color,
        },
      };
    });

    const newEdges: Edge[] = children.map((item) => ({
      id: `${parentName}-${item.name}`,
      source: parentName,
      target: item.name,
      animated: true,
      style: { stroke: "#FF5733", strokeWidth: 2 },
    }));

    setNodes((prev) => [...prev, ...newNodes]);
    setEdges((prev) => [...prev, ...newEdges]);
  };

  const onCustomNodesChange = (changes: NodeChange[]) => {
    setNodes((nds) => {
      let nextNodes = applyNodeChanges(changes, nds);
      for (const change of changes) {
        if (change.type === "position" && change.dragging && change.id) {
          const draggedNode = nds.find((n) => n.id === change.id);
          if (!draggedNode) continue;

          const getDescendants = (id: string): string[] => {
            return nds
              .filter((n) => n.data.parentId === id)
              .flatMap((n) => [n.id, ...getDescendants(n.id)]);
          };

          const descendants = getDescendants(change.id);
          nextNodes = nextNodes.map((n) => {
            if (descendants.includes(n.id)) {
              const offsetX = n.position.x - draggedNode.position.x;
              const offsetY = n.position.y - draggedNode.position.y;
              return {
                ...n,
                position: {
                  x: change.position!.x + offsetX,
                  y: change.position!.y + offsetY,
                },
              };
            }
            return n;
          });
        }
      }
      return nextNodes;
    });
  };

  if (loading) return <CustomLoading />;
  else if (errorServiceMsg !== null) {
    return (
      <>
        <Box
          color="error.main"
          sx={{ textAlign: "center", marginTop: 2, fontWeight: "bold" }}
        >
          {errorServiceMsg}
        </Box>
      </>
    );
  } else
    return (
      <ReactFlowProvider>
        <Box display="flex" height="100vh">
          <Paper elevation={3} sx={{ width: 250, m: 2, p: 2, borderRadius: 2 }}>
            <Typography variant="h6" gutterBottom>
              Choisir un département
            </Typography>
            <Select
              fullWidth
              value={selectedDept}
              size="small"
              displayEmpty
              onChange={(e) => displayDepartment(e.target.value)}
            >
              <MenuItem value="" disabled>
                Sélectionner...
              </MenuItem>
              {departments.map((dept) => (
                <MenuItem key={dept.name} value={dept.name}>
                  {dept.title || dept.name}
                </MenuItem>
              ))}
            </Select>
            <Typography variant="h6" mt={3} mb={1}>
              Contrôles
            </Typography>
            <Box display="flex" flexDirection="column" gap={1}>
              <Button variant="contained" onClick={zoomIn}>
                Zoom avant +
              </Button>
              <Button variant="contained" onClick={zoomOut}>
                Zoom arrière -
              </Button>
              <Button variant="outlined" onClick={centerView}>
                Centrer la vue
              </Button>
            </Box>
          </Paper>

          <Box
            ref={reactFlowWrapper}
            flex={1}
            bgcolor="#fff"
            m={2}
            p={2}
            borderRadius={2}
            boxShadow={2}
          >
            <ReactFlow
              nodes={nodes}
              edges={edges}
              onNodesChange={onCustomNodesChange}
              onEdgesChange={onEdgesChange}
              onNodeClick={(_, node) => handleNodeClick(node)}
              onInit={(instance) => {
                reactFlowInstance.current = instance;
              }}
              fitView
            />
          </Box>

          <Dialog
            open={!!modalData}
            onClose={() => setModalData(null)}
            maxWidth="sm"
            fullWidth
          >
            <DialogTitle
              sx={{
                backgroundColor: "#1976d2",
                color: "#fff",
                fontWeight: "bold",
                fontSize: 18,
                px: 3,
                py: 2,
              }}
            >
              Détails de l'entité
            </DialogTitle>
            <DialogContent sx={{ backgroundColor: "#f4f6f8", px: 3, py: 2 }}>
              <Paper elevation={1} sx={{ p: 2, borderRadius: 2, mb: 2, mt: 2 }}>
                <Typography variant="subtitle2" color="text.secondary">
                  Nom
                </Typography>
                <Typography variant="h5">
                  {modalData?.title || modalData?.name}
                </Typography>
                <Divider sx={{ my: 1 }} />
                <Typography variant="subtitle2" color="text.secondary">
                  Type
                </Typography>
                <Typography variant="h6">{modalData?.type}</Typography>
              </Paper>
              <Paper elevation={1} sx={{ p: 2, borderRadius: 2, mb: 2 }}>
                <Typography variant="subtitle2" color="text.secondary">
                  Parent
                </Typography>
                <List dense>
                  {modalData?.relations?.filter((rel) => rel.type === "childOf")
                    .length ? (
                    modalData.relations
                      .filter((rel) => rel.type === "childOf")
                      .map((rel, i) => (
                        <ListItem key={`childof-${i}`} sx={{ pl: 1 }}>
                          🔗 {rel.target?.kind}:{" "}
                          <strong style={{ marginLeft: 4 }}>
                            {modalData?.parent || "N/A"}
                          </strong>
                        </ListItem>
                      ))
                  ) : (
                    <ListItem>Aucun parent trouvé</ListItem>
                  )}
                </List>
              </Paper>
              <Paper
                elevation={1}
                sx={{
                  p: 2,
                  borderRadius: 2,
                  mb: 1,
                  maxHeight: 300,
                  overflowY: "auto",
                }}
              >
                <Typography
                  variant="subtitle2"
                  color="text.secondary"
                  gutterBottom
                >
                  Membres
                </Typography>
                <List dense>
                  {modalData?.relations?.filter(
                    (rel) => rel.type === "hasMember",
                  ).length ? (
                    modalData.relations
                      .filter((rel) => rel.type === "hasMember")
                      .map((rel, i) => {
                        const user = users.find(
                          (u) => u.name === rel.target?.name,
                        );
                        return (
                          <ListItem key={`member-${i}`} sx={{ pl: 1 }}>
                            👤{" "}
                            {user?.displayName ||
                              rel.target?.name ||
                              "Nom Inconnu"}
                            {user?.email && (
                              <Typography
                                component="span"
                                sx={{
                                  ml: 1,
                                  fontSize: 12,
                                  color: "text.secondary",
                                }}
                              >
                                ({user.email})
                              </Typography>
                            )}
                          </ListItem>
                        );
                      })
                  ) : (
                    <ListItem>Aucun membre trouvé</ListItem>
                  )}
                </List>
              </Paper>
            </DialogContent>
          </Dialog>
        </Box>
      </ReactFlowProvider>
    );
};

export default OrganigrammePage;
