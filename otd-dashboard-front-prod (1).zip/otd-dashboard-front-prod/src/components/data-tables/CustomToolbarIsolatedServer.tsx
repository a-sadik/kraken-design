import {
  Box,
  Button,
  TextField,
  Typography,
} from "@mui/material";
import {
  GridToolbarContainer,
  GridToolbar,
} from "@mui/x-data-grid";
import AddToPhotosIcon from "@mui/icons-material/AddToPhotos";
import SearchIcon from "@mui/icons-material/Search";
import { keycloak } from "@/auth/keycloakConnectAdapter";
import { useState, useEffect } from "react";

export interface ExternalFilters {
  globalSearch: string;
}

interface CustomToolbarIsolatedServerProps {
  tabName: string;
  selectedCount: number;
  showFilters: boolean;
  externalFilters: ExternalFilters;
  filteredCount: number;
  onShowFiltersToggle: () => void;
  onFiltersChange: (filters: ExternalFilters) => void;
  onFiltersReset: () => void;
  onInventorize: () => void;
}

const CustomToolbarIsolatedServer = ({
  tabName,
  selectedCount,
  externalFilters,
  filteredCount,
  onFiltersChange,
  onInventorize,
}: CustomToolbarIsolatedServerProps) => {
  // État local pour le filtre global
  const [localGlobalSearch, setLocalGlobalSearch] = useState(externalFilters.globalSearch);

  // Synchroniser l'état local quand les props changent
  useEffect(() => {
    setLocalGlobalSearch(externalFilters.globalSearch);
  }, [externalFilters.globalSearch]);

  const handleFilterChange = (field: keyof ExternalFilters, value: string) => {
    onFiltersChange({
      ...externalFilters,
      [field]: value
    });
  };

  // Gestionnaire pour le filtre global avec validation par Entrée
  const handleGlobalSearchChange = (value: string) => {
    setLocalGlobalSearch(value);
  };

  const handleGlobalSearchKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleFilterChange('globalSearch', localGlobalSearch);
    }
  };

  const handleGlobalSearchBlur = () => {
    handleFilterChange('globalSearch', localGlobalSearch);
  };

  return (
    <GridToolbarContainer sx={{ p: 2, gap: 2, alignItems: "center" }}>
      {/* Filtre global toujours visible à gauche */}
      <Box sx={{ display: "flex", alignItems: "center", gap: 2, flex: 1 }}>
        <TextField
          size="small"
          label="Recherche globale"
          value={localGlobalSearch}
          onChange={(e) => handleGlobalSearchChange(e.target.value)}
          onKeyPress={handleGlobalSearchKeyPress}
          onBlur={handleGlobalSearchBlur}
          placeholder="Hostname, IP, OS, Environnement, Créé par, Uname, Power Physique..."
          sx={{
            minWidth: 500,
            "& .MuiOutlinedInput-root": {
              backgroundColor: "white",
            }
          }}
          InputProps={{
            startAdornment: <SearchIcon sx={{ color: 'text.secondary', mr: 1 }} />,
          }}
        />

        <Typography variant="caption" sx={{ color: "text.secondary", whiteSpace: 'nowrap' }}>
          {filteredCount} résultat(s)
        </Typography>
      </Box>

      {/* Toolbar standard et boutons à droite */}
      <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
        <GridToolbar />
        {/* Condition pour cacher le bouton Inventoriser dans l'onglet inventory */}
        {tabName !== "inventory" && (
          <Button
            variant="contained"
            color="primary"
            startIcon={<AddToPhotosIcon />}
            onClick={onInventorize}
            disabled={
              selectedCount === 0 ||
              !keycloak.hasRoles(["admin_role", "tam_role"])
            }
            sx={{ ml: 2 }}
          >
            Inventoriser ({selectedCount})
          </Button>
        )}
      </Box>

      {/* Aide des champs de recherche (optionnel) */}

    </GridToolbarContainer>
  );
};

export default CustomToolbarIsolatedServer;