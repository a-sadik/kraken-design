// src/pages/sub-pages/admin/DomainNamePage.tsx

import { FC } from "react";

// import files
import DomainExterneDataTable from "@/components/data-tables/DomainExterneDataTable";

const DomainExternePage: FC = () => {
  return <DomainExterneDataTable />;
};

export default DomainExternePage;
