// src/services/DomainService.ts

import { AxiosError } from "axios";

// import files
import { ErrorResponse } from "@/exceptions/ErrorResponse";
import {
  DomainDetailtResponseDTO,
  DomainRequestDTO,
  DomainShortResponseDTO,
} from "@/types/dto/DomainDTO";
import apiClient from "../apiClientHttp";

const path = `/domains`;

// Function to recieve all domains
export const getAllDomains = async (): Promise<DomainShortResponseDTO[]> => {
  try {
    console.log(path);
    const response =
      await apiClient.dataApiClient.get<DomainShortResponseDTO[]>(path);
    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error(
      "Error fetching all domains data:",
      err.response?.data.message,
    );
    throw err;
  }
};

// Function to recieve one domains by id
export const getDomainById = async (
  id: number,
): Promise<DomainShortResponseDTO | null> => {
  try {
    const response =
      await apiClient.dataApiClient.get<DomainShortResponseDTO | null>(
        `${path}/${id}`,
      );
    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error("Error fetching domain data by id:", err.response?.data);
    throw error;
  }
};

// Function to create domain
export const createDomain = async (
  reqBody: DomainRequestDTO,
): Promise<DomainRequestDTO | null> => {
  try {
    const response =
      await apiClient.dataApiClient.post<DomainDetailtResponseDTO | null>(
        `${path}`,
        reqBody,
      );
    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error("Error creating new domain:", err.response?.data);
    throw error;
  }
};

// Function to update domain
export const updateDomain = async (
  id: number,
  reqBody: DomainRequestDTO,
): Promise<DomainRequestDTO | null> => {
  try {
    const response =
      await apiClient.dataApiClient.put<DomainDetailtResponseDTO | null>(
        `${path}/${id}`,
        reqBody,
      );
    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error("Error updating new domain:", err.response?.data);
    throw error;
  }
};
