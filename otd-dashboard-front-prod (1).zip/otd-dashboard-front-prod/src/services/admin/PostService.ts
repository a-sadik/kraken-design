// src/services/PostService.ts

import { AxiosError } from "axios";

// import files
import apiClient from "../apiClientHttp";
import { ErrorResponse } from "@/exceptions/ErrorResponse";
import {
  PostDetailResponseDTO,
  PostRequestDTO,
  PostShortResponseDTO,
} from "@/types/dto/PostDTO";

const path = "/posts";

// Function to get all roles
export const getAllPosts = async (): Promise<PostShortResponseDTO[]> => {
  try {
    const response =
      await apiClient.dataApiClient.get<PostShortResponseDTO[]>(path);

    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error("Error to get all posts:", err.response?.data.message);
    throw err;
  }
};

// Function to create post
export const createPost = async (
  reqBody: PostRequestDTO,
): Promise<PostRequestDTO | null> => {
  try {
    const response =
      await apiClient.dataApiClient.post<PostDetailResponseDTO | null>(
        `${path}`,
        reqBody,
      );
    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error("Error creating new entity:", err.response?.data);
    throw error;
  }
};

// Function to update post
export const updatePost = async (
  id: number,
  reqBody: PostRequestDTO,
): Promise<PostRequestDTO | null> => {
  try {
    const response =
      await apiClient.dataApiClient.put<PostDetailResponseDTO | null>(
        `${path}/${id}`,
        reqBody,
      );
    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error("Error updating new post:", err.response?.data);
    throw error;
  }
};
