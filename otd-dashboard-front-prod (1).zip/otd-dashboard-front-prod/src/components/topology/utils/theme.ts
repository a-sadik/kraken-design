export const pastelTheme = {
  primary: "#99caff",
  secondary: "#a8e6b1",
  accent: "#f3aebd",
  surface: "#fce38a",
  background: "#F5F7FA",
  surfaceVariant: "#ffb3b3",
  outline: "#D1D5DB",
  shadow: "rgba(0, 0, 0, 0.1)",
  cardBackground: "#FFFFFF",
  textPrimary: "#2D3748",
  textSecondary: "#4A5568",
};

export const modernTheme = {
  primary: "#2563EB",
  secondary: "#7C3AED",
  accent: "#059669",
  surface: "#FFCE14",
  background: "#F1F5F9",
  surfaceVariant: "#e04434",
  outline: "#CBD5E1",
  shadow: "rgba(15, 23, 42, 0.12)",
  cardBackground: "#FFFFFF",
  textPrimary: "#1E293B",
  textSecondary: "#475569",
};
