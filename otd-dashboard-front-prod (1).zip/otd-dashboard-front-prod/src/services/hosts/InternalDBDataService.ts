// src/services/hosts/InternDBDataService.ts

import axios from "axios";

// import files
import { HostView } from "@/types/view/HostView";
import DataResponseDTO from "@/types/dto/response/DataResponseDTO";
import { mapData } from "@/mappers/DataMapper";
import DataView from "@/types/view/DataView";

const PREFIX_PATH = import.meta.env.VITE_PREFIX_DATA_PATH;
const SUFFIX_PATH = import.meta.env.VITE_SUFFIX_DATA_PATH;
const SERVER_PORT = import.meta.env.VITE_DATA_SERVER_PORT;
const path = `${PREFIX_PATH}:${SERVER_PORT}/${SUFFIX_PATH}`;

export const getInternalDBData = async (): Promise<HostView> => {
  try {
    const response = await axios.get<DataResponseDTO[]>(
      `${path}/solutions-servers`,
    );

    // Mapper les données
    const mappedData: DataView[] = mapData(response.data);

    // Construire l'objet HostView
    const hostData: HostView = {
      source: "BD Interne",
      number: mappedData.length,
      data: mappedData,
      primaryColor: "#F0423E",
      secondaryColor: "#FFF0DC",
    };

    return hostData;
  } catch (error) {
    console.error("Error fetching intern data base data:", error);
    throw error;
  }
};
