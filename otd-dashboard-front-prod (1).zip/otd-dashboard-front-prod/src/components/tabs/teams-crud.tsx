/* eslint-disable @typescript-eslint/no-explicit-any */
import { useState, useEffect, useCallback } from "react";
import {
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Paper,
  TableContainer,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  IconButton,
  CircularProgress,
  Snackbar,
  Alert,
  Box,
  Stack,
  Autocomplete,
  Chip,
} from "@mui/material";
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
} from "@mui/icons-material";
import { getAdminCRUD_BaseUrl, getTeams_BaseUrl } from "@/config/api.config";
import { useSnackbar } from "@/hooks/useSnackbar"; // Import the new hook
import fetchWithAuth from "@/middleware/fetch-auth";

const API_BASE_URL = getTeams_BaseUrl();

type Team = {
  id?: number;
  name: string;
  default_emails: string[];
};

export default function TeamsCRUD() {
  const [teams, setTeams] = useState<Team[]>([]);
  const [currentTeam, setCurrentTeam] = useState<Team | null>(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const { snackbar, showSnackbar, handleCloseSnackbar } = useSnackbar();

  // modification 1
  const [emailOptions, setEmailOptions] = useState<string[]>([]);
  const [emailsLoading, setEmailsLoading] = useState(false);

  // Charger toutes les équipes
  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      const res = await fetchWithAuth(`${API_BASE_URL}`);
      if (!res.ok) throw new Error(`Erreur API ${res.status}`);
      const data = await res.json();
      setTeams(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error(error);
      showSnackbar("Erreur lors du chargement des équipes", "error");
      setTeams([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // modification 2 charger les emails
  useEffect(() => {
    const loadEmails = async () => {
      try {
        setEmailsLoading(true);
        const res = await fetchWithAuth(`${getAdminCRUD_BaseUrl()}/persons/`);
        if (!res.ok) throw new Error(`Erreur API emails ${res.status}`);
        const raw = await res.json();

        const list = Array.isArray(raw)
          ? raw
              .map((item: any) =>
                typeof item === "string" ? item : item?.email,
              )
              .filter(Boolean)
          : [];

        setEmailOptions(Array.from(new Set(list)).sort());
      } catch (e) {
        console.error(e);
        showSnackbar("Impossible de charger la liste des emails", "error");
        setEmailOptions([]);
      } finally {
        setEmailsLoading(false);
      }
    };
    loadEmails();
  }, [showSnackbar]);

  const handleInputChange = (field: keyof Team, value: any) => {
    setCurrentTeam((prev) => ({ ...prev!, [field]: value }));
  };

  const handleCreate = () => {
    setCurrentTeam({ name: "", default_emails: [] });
    setIsEditing(false);
    setOpenDialog(true);
  };

  const handleEdit = (team: Team) => {
    setCurrentTeam(team);
    setIsEditing(true);
    setOpenDialog(true);
  };

  const handleDelete = async (id?: number) => {
    if (!id) return;
    if (window.confirm("Confirmer la suppression de l'équipe ?")) {
      try {
        const res = await fetchWithAuth(`${API_BASE_URL}${id}/`, {
          method: "DELETE",
        });
        if (!res.ok) throw new Error(`Erreur API ${res.status}`);
        setTeams((arr) => arr.filter((t) => t.id !== id));
        showSnackbar("Équipe supprimée avec succès", "success");
      } catch (error) {
        console.error(error);
        showSnackbar("Erreur lors de la suppression", "error");
      }
    }
  };

  const handleSubmit = async () => {
    try {
      const method = isEditing ? "PATCH" : "POST";
      const url = isEditing
        ? `${API_BASE_URL}${currentTeam!.id}/`
        : `${API_BASE_URL}`;

      const res = await fetchWithAuth(url, {
        method,
        body: JSON.stringify(currentTeam),
      });

      if (!res.ok) throw new Error(`${method} team failed (${res.status})`);

      const result: Team = await res.json();

      if (isEditing) {
        setTeams((arr) => arr.map((t) => (t.id === result.id ? result : t)));
        showSnackbar("Équipe modifiée avec succès", "success");
      } else {
        setTeams((arr) => [...arr, result]);
        showSnackbar("Équipe ajoutée avec succès", "success");
      }
      setOpenDialog(false);
    } catch (error) {
      console.error(error);
      showSnackbar("Erreur lors de l'opération", "error");
    }
  };

  return (
    <Paper sx={{ p: 4, borderRadius: 2, boxShadow: 3 }}>
      {}
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          mb: 3,
        }}
      >
        <Typography
          variant="h5"
          sx={{ fontWeight: "bold", color: "text.primary" }}
        >
          Gestion des Équipes
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={handleCreate}
          sx={{
            bgcolor: "primary.main",
            "&:hover": { bgcolor: "primary.dark" },
            borderRadius: 1,
            px: 3,
            py: 1.2,
          }}
        >
          Ajouter une Équipe
        </Button>
      </Box>

      {}
      {loading ? (
        <Box sx={{ display: "flex", justifyContent: "center", py: 4 }}>
          <CircularProgress />
        </Box>
      ) : (
        <TableContainer
          component={Paper}
          sx={{ borderRadius: 2, boxShadow: 1 }}
        >
          <Table sx={{ minWidth: 600 }}>
            <TableHead sx={{ bgcolor: "grey.100" }}>
              <TableRow>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Nom
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Emails par défaut
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", color: "text.secondary" }}>
                  Actions
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {teams.map((team) => (
                <TableRow
                  key={team.id}
                  sx={{ "&:nth-of-type(odd)": { bgcolor: "action.hover" } }}
                >
                  <TableCell>{team.name}</TableCell>
                  <TableCell>
                    <Stack direction="row" spacing={0.5} flexWrap="wrap">
                      {team.default_emails.map((em) => (
                        <Chip key={em} label={em} size="small" />
                      ))}
                    </Stack>
                  </TableCell>
                  <TableCell>
                    <Stack direction="row" spacing={0.5}>
                      <IconButton
                        color="primary"
                        size="small"
                        onClick={() => handleEdit(team)}
                      >
                        <EditIcon sx={{ fontSize: 20 }} />
                      </IconButton>
                      <IconButton
                        color="error"
                        size="small"
                        onClick={() => handleDelete(team.id)}
                      >
                        <DeleteIcon sx={{ fontSize: 20 }} />
                      </IconButton>
                    </Stack>
                  </TableCell>
                </TableRow>
              ))}
              {teams.length === 0 && (
                <TableRow>
                  <TableCell colSpan={3} align="center">
                    <Typography>Aucune équipe trouvée</Typography>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {}
      <Dialog
        open={openDialog}
        onClose={() => setOpenDialog(false)}
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle
          sx={{ bgcolor: "primary.main", color: "white", py: 2, px: 3 }}
        >
          <Typography variant="h6" sx={{ fontWeight: "bold" }}>
            {isEditing ? "Modifier l'équipe" : "Créer une nouvelle équipe"}
          </Typography>
        </DialogTitle>
        <DialogContent dividers sx={{ p: 3 }}>
          {currentTeam && (
            <Stack spacing={2}>
              <TextField
                label="Nom"
                fullWidth
                value={currentTeam.name}
                onChange={(e) => handleInputChange("name", e.target.value)}
                required
                variant="outlined"
                size="small"
              />
              <Autocomplete
                multiple
                freeSolo
                options={emailOptions}
                loading={emailsLoading} // modification 3
                value={currentTeam.default_emails}
                onChange={(_, newValue) =>
                  handleInputChange("default_emails", newValue)
                }
                renderTags={(value: readonly string[], getTagProps) =>
                  value.map((option: string, index: number) => (
                    <Chip
                      variant="outlined"
                      label={option}
                      size="small"
                      {...getTagProps({ index })}
                    />
                  ))
                }
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Emails par défaut"
                    variant="outlined"
                    size="small"
                    fullWidth
                  />
                )}
              />
            </Stack>
          )}
        </DialogContent>
        <DialogActions sx={{ p: 2, borderTop: "1px solid #eee" }}>
          <Button
            onClick={() => setOpenDialog(false)}
            variant="outlined"
            sx={{ borderRadius: 1 }}
          >
            Annuler
          </Button>
          <Button
            variant="contained"
            onClick={handleSubmit}
            disabled={!currentTeam?.name}
            sx={{
              bgcolor: "primary.main",
              "&:hover": { bgcolor: "primary.dark" },
              borderRadius: 1,
            }}
          >
            {isEditing ? "Modifier" : "Créer"}
          </Button>
        </DialogActions>
      </Dialog>

      {}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          sx={{ width: "100%", boxShadow: 3 }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Paper>
  );
}
