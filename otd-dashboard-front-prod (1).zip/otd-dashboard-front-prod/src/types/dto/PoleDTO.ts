// src/types/dto/PoleDTO.ts

export interface PoleRequestDTO {
  pole_name: string;
  manager_id: number | null;
  entity_id: number | null;
}

export interface PoleShortResponseDTO {
  pole_id: number;
  pole_name: string;
  pole_manager_id: number;
  created_at?: string;
  updated_at?: string;
  entity_id: number;
}

export interface PoleDetailtResponseDTO {
  pole_id: number;
  pole_name: string;
  manager_id: number;
  entity_id: number;
  created_at?: string;
  updated_at?: string;
}
