import type React from "react";

import { Search as SearchIcon } from "@mui/icons-material";
import { InputAdornment, TextField } from "@mui/material";

interface SearchBarProps {
  searchTerm: string;
  onSearchChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

export const SearchBar = ({ searchTerm, onSearchChange }: SearchBarProps) => (
  <TextField
    fullWidth
    variant="outlined"
    placeholder="Chercher par IP ou hostname"
    value={searchTerm}
    onChange={onSearchChange}
    InputProps={{
      startAdornment: (
        <InputAdornment position="start">
          <SearchIcon />
        </InputAdornment>
      ),
    }}
  />
);
