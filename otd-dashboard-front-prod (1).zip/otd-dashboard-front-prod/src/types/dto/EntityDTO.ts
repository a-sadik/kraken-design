// src/types/dto/EntityDTO.ts

export interface EntityRequestDTO {
  entity_name: string;
  entity_manager_id: number | null;
}

export interface EntityShortResponseDTO {
  entity_id: number;
  entity_name: string;
  entity_manager_id: number;
  created_at?: string;
  updated_at?: string;
}

export interface EntityDetailtResponseDTO {
  entity_id: number;
  entity_name: string;
  entity_manager_id: number;
  created_at?: string;
  updated_at?: string;
}
