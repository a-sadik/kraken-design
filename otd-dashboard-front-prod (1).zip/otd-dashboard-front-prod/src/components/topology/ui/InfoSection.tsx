// import React from "react";
// import { Box, Typography, Breadcrumbs, IconButton, Paper, Stack, alpha } from "@mui/material";
// import { Home, NavigateNext, KeyboardArrowRight } from "@mui/icons-material";
// import { pastelTheme } from "../config/topology-theme";

// interface BreadcrumbItem {
//   name: string;
//   level: string;
//   data: any;
//   elementId: string;
// }

// interface BreadcrumbNavProps {
//   navigation: {
//     currentLevel: string;
//     breadcrumb: BreadcrumbItem[];
//   };
//   navigateToBreadcrumb: (index: number) => void;
//   getLevelColor: (level: string) => string;
//   getLevelIcon: (level: string) => React.ReactElement;
// }

// const BreadcrumbNav: React.FC<BreadcrumbNavProps> = ({
//   navigation,
//   navigateToBreadcrumb,
//   getLevelColor,
//   getLevelIcon,
// }) => {
//   const currentLevelColor = getLevelColor(navigation.currentLevel);

//   return (
//     <Paper elevation={0} sx={{
//       background: `linear-gradient(135deg, ${alpha(currentLevelColor, 0.1)} 0%, ${alpha(currentLevelColor, 0.05)} 100%)`,
//       py: 2,
//       px: 3,
//       borderRadius: 0,
//     }}>
//       <Stack direction="row" alignItems="center" spacing={2}>
//         <IconButton onClick={() => navigateToBreadcrumb(-1)} sx={{/* styles */}}>
//           <Home />
//         </IconButton>

//         {navigation.breadcrumb.length > 0 && (
//           <>
//             <KeyboardArrowRight sx={{ color: alpha(currentLevelColor, 0.8) }} />
//             <Breadcrumbs separator={<NavigateNext fontSize="small" />}>
//               {navigation.breadcrumb.map((item, index) => (
//                 <Box key={index} onClick={() => navigateToBreadcrumb(index)} sx={{/* styles */}}>
//                   {React.cloneElement(getLevelIcon(item.level), {/* props */}}
//                   <Typography variant="body2">{item.name}</Typography>
//                 </Box>
//               ))}
//             </Breadcrumbs>
//           </>
//         )}
//       </Stack>
//     </Paper>
//   );
// };

// export default BreadcrumbNav;
