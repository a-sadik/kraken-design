// src/pages/primary/CertifcatesPage.tsx

import { FC, useState } from "react";

export const WEB_SERVEUR_3 = "ServeurWeb.3";

// import files
import CertificateDataTable from "@/components/data-tables/CertificateDataTable";

const CertifcatesPage: FC = () => {
  const [openModal, setOpenModal] = useState(false);

  return (
    <CertificateDataTable
      openModalCreate={openModal}
      setOpenModalCreate={setOpenModal}
    />
  );
};

export default CertifcatesPage;
