// src/pages/SignatureSheetPage.tsx

import React, { useEffect, useState } from "react";
import { AxiosError } from "axios";

import Stack from "@mui/material/Stack";
import Divider from "@mui/material/Divider";
import Box from "@mui/material/Box";

// import files
import CustomLoading from "@/components/basics/CustomLoading";
import WidgetMainContainer from "@/components/containers/WidgetMainContainer";
import TotalCard from "@/components/cards/TotalCard";
import SignatureSheetTable from "@/components/data-tables/SignatureSheetDataTable";
import { useData } from "@/hooks/DataContext";
import { HostView } from "@/types/view/HostView";
import { getBigFixData } from "@/services/hosts/BigFixDataService";
import { getInventoryData } from "@/services/hosts/CmdbDataService";
import { getInternalDBData } from "@/services/hosts/InternalDBDataService";

// import logos
import BigFixImg from "/logos/sources/pige-fix.png";
// import CMDBImg from '/logos/sources/cmdb.png';
import InternalDBImg from "/logos/sources/internal-db.png";

// import messages
import { service_unavailable, service_failure } from "@/utils/customMessages";

export default function SignatureSheetPage() {
  const { setBigFixData, setInventoryData } = useData();
  const [loading, setLoading] = React.useState(true);

  const [data, setData] = useState<{ source: HostView; img: string }[]>([]);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [dbIntern, bigFix, inventory] = await Promise.all([
          getInternalDBData(),
          getBigFixData(),
          getInventoryData(),
        ]);
        setBigFixData(bigFix);
        setInventoryData(inventory);
        setErrorMsg(null);
        setData([
          { source: dbIntern, img: InternalDBImg },
          { source: bigFix, img: BigFixImg },
          // { source: inventory, img: CMDBImg },
        ]);
      } catch (err) {
        const error = err as AxiosError;
        console.error("Error fetching data:", error);
        if (error.code === "ERR_NETWORK") setErrorMsg(`${service_unavailable}`);
        else setErrorMsg(`${service_failure}`);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [setBigFixData, setInventoryData]);

  if (loading) return <CustomLoading />;
  else if (errorMsg !== null) {
    return (
      <>
        {errorMsg && (
          <Box
            color="error.main"
            sx={{ textAlign: "center", marginTop: 2, fontWeight: "bold" }}
          >
            {errorMsg}
          </Box>
        )}
      </>
    );
  } else
    return (
      <>
        <WidgetMainContainer
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Stack
            direction="row"
            divider={
              <Divider
                orientation="vertical"
                flexItem
                sx={{ bgcolor: "white", height: "10rem" }}
              />
            }
            spacing={{ xs: 2, sm: 5, md: 10 }}
            justifyContent="center"
            alignItems="center"
          >
            {data.map((item, index) => (
              <TotalCard
                key={index}
                source={item.source?.source || ""}
                total={item.source?.number || 0}
                img={item.img}
                backgroundColor={item.source?.secondaryColor || ""}
                textSourceColor={item.source?.primaryColor || ""}
              />
            ))}
          </Stack>
        </WidgetMainContainer>

        <>
          {data.map((item, index) => (
            <SignatureSheetTable
              key={index}
              color={item.source?.primaryColor}
              title={`Actifs en ${item.source?.source || ""}`}
              rows={item.source?.data || []}
            />
          ))}
        </>
      </>
    );
}
