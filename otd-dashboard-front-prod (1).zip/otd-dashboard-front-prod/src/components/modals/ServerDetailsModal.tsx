//src/components/modals/ServerDetailsModal.tsx

import React, { useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  Box,
  Grid,
  Card,
  CardContent,
  Chip,
  IconButton,
  Popover,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  Avatar,
  Paper,
  Divider,
  useTheme,
  useMediaQuery,
  Slide,
} from "@mui/material";
import {
  Close as CloseIcon,
  Computer as ComputerIcon,
  Group as GroupIcon,
  Person as PersonIcon,
  Speed, Memory, Storage
} from "@mui/icons-material";
import type { TransitionProps } from "@mui/material/transitions";
import {
  getPastelColorSignature,
  getBadgeColorEnvironment,
  getPastelColorOS,
} from "@/utils/getDynamicColor";

// Transition personnalisée pour le modal
const Transition = React.forwardRef(function Transition(
  props: TransitionProps & {
    children: React.ReactElement;
  },
  ref: React.Ref<unknown>,
) {
  return <Slide direction="up" ref={ref} {...props} />;
});

// Types
type Admin = {
  email: string;
  name: string;
};

type BlockSection = {
  title: string;
  items: {
    label: string;
    value: string | number | React.ReactNode;
    chip?: boolean;
    colorType?:
    | "environment"
    | "os"
    | "signature"
    | "solution"
    | "bigfix"
    | "inventory"
    | "fiabilite";
    bgColor?: string;
    textColor?: string;
    admins?: Admin[];
    type?: string;
    icon?: React.ReactNode;
  }[];
};

interface ServerDetailsModalProps {
  open: boolean;
  onClose: () => void;
  serverData: any;
  rowData: any;
}

const ServerDetailsModal: React.FC<ServerDetailsModalProps> = ({
  open,
  onClose,
  serverData,
  rowData,
}) => {
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down("md"));

  const [currentAdmins, setCurrentAdmins] = useState<{
    type: string;
    admins: Admin[];
  } | null>(null);
  const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);

  // Fonctions de dédoublons
  const deduplicateAdmins = (admins: Admin[]): Admin[] => {
    const uniqueAdmins = new Map();
    admins.forEach(admin => {
      const key = admin.email?.toLowerCase().trim() || admin.name?.toLowerCase().trim();
      if (key && !uniqueAdmins.has(key)) {
        uniqueAdmins.set(key, admin);
      }
    });
    return Array.from(uniqueAdmins.values());
  };

  const deduplicateSimpleData = (items: any[]): any[] => {
    const uniqueItems = new Map();
    items.forEach(item => {
      const name = typeof item === 'object' ? item.name : item;
      const key = name?.toLowerCase().trim();
      if (key && !uniqueItems.has(key)) {
        uniqueItems.set(key, item);
      }
    });
    return Array.from(uniqueItems.values());
  };

  if (!rowData && !serverData) return null;

  console.log("serverData", serverData);
  console.log("rowData", rowData);

  // Fonction pour obtenir la couleur en fonction du type
  const getItemColor = (value: string, colorType?: string) => {
    if (typeof value !== "string")
      return { bgColor: "#e0e0e0", textColor: "#000000" };

    switch (colorType) {
      case "environment":
        return {
          bgColor: getBadgeColorEnvironment(value),
          textColor: "#000000",
        };
      case "os":
        return getPastelColorOS(value);
      case "signature":
        return getPastelColorSignature(value);
      case "solution":
        return { bgColor: "#f3e5f5", textColor: "#6a1b9a" };
      case "bigfix":
        return { bgColor: "#e8f5e8", textColor: "#2e7d32" };
      case "inventory":
        return { bgColor: "#fff3e0", textColor: "#ef6c00" };
      case "fiabilite":
        return value === "Fiable"
          ? { bgColor: "#D1FAE5", textColor: "#065F46" }
          : { bgColor: "#FEE2E2", textColor: "#991B1B" };
      default:
        return { bgColor: "#e0e0e0", textColor: "#000000" };
    }
  };

  // Gestion de l'ouverture du popover
  const handleAdminsClick = (
    event: React.MouseEvent<HTMLButtonElement>,
    type: string,
    admins: Admin[],
  ) => {
    console.log("admins", admins);
    setAnchorEl(event.currentTarget);
    setCurrentAdmins({ type, admins });
  };

  const handlePopoverClose = () => {
    setAnchorEl(null);
    setCurrentAdmins(null);
  };

  // Récupérer les données d'administration depuis rowData (tableau)
  const getAdminsData = () => {
    // === CAS 1 : rowData existe (ancien use case) ===
    if (rowData) {
      return {
        techAdmins: deduplicateAdmins(
          Array.isArray(rowData["Admin Technique"])
            ? rowData["Admin Technique"]
            : []
        ),
        funcAdmins: deduplicateAdmins(
          Array.isArray(rowData["Admin Fonctionnel"])
            ? rowData["Admin Fonctionnel"]
            : []
        ),
        tam: deduplicateAdmins(
          Array.isArray(rowData["TAM"]) ? rowData["TAM"] : []
        ),
        domains: deduplicateSimpleData(
          Array.isArray(rowData["Domaine"]) ? rowData["Domaine"] : []
        ),
        poles: deduplicateSimpleData(
          Array.isArray(rowData["Pôle"]) ? rowData["Pôle"] : []
        ),
        entities: deduplicateSimpleData(
          Array.isArray(rowData["Entities"]) ? rowData["Entities"] : []
        ),
        source: "table",
      };
    }

    // === CAS 2 : rowData null → utiliser serverData (getserverbyid) ===
    if (!serverData) {
      return {
        techAdmins: [],
        funcAdmins: [],
        tam: [],
        domains: [],
        poles: [],
        entities: [],
        source: "none",
      };
    }

    // Extraire les admins depuis serverData.solutions[0]?.list_admins
    const listAdmins = serverData.solutions?.[0]?.list_admins || {};

    const techAdmins = (listAdmins.technical_admins || []).map((a: any) => ({
      email: a.email,
      name: a.name,
    }));

    const funcAdmins = (listAdmins.functional_admins || []).map((a: any) => ({
      email: a.email,
      name: a.name,
    }));

    const tamAdmins = (listAdmins.tams || []).map((a: any) => ({
      email: a.email,
      name: a.name,
    }));

    return {
      techAdmins: deduplicateAdmins(techAdmins),
      funcAdmins: deduplicateAdmins(funcAdmins),
      tam: deduplicateAdmins(tamAdmins),
      domains: deduplicateSimpleData(serverData.domains || []),
      poles: deduplicateSimpleData(serverData.poles || []),
      entities: deduplicateSimpleData(serverData.entities || []),
      source: "api",
    };
  };

  // Récupérer les données d'administration
  const adminsData = getAdminsData();

  // Préparer les données pour l'affichage
  const domaineAdmin = adminsData.domains.map((domain: any) => ({
    name: domain,
  }));
  const polesAdmin = adminsData.poles.map((pole: any) => ({ name: pole }));
  const entiteAdmin = adminsData.entities.map((entity: any) => ({
    name: entity,
  }));

  // Vérifier si le système d'exploitation est AIX
  const osType = rowData?.["Type OS"] || serverData?.os_type || "";
  const isAixSystem = osType.toLowerCase() === "aix";

  // Préparer les éléments d'information principale avec ou sans uname
  const mainInfoItems = [
    {
      label: "Hostname",
      value: rowData?.Hostname || serverData?.hostname || "Non spécifié",
    },
    {
      label: "Type OS",
      value: osType || "Non spécifié",
      chip: true,
      colorType: "os" as const,
    },
    {
      label: "Détail OS",
      value: rowData?.os_detail || serverData?.os_detail || "Non spécifié",
    },
  ];

  // Ajouter uname seulement si c'est un système AIX
  if (isAixSystem) {
    mainInfoItems.push({
      label: "Uname",
      value: rowData?.Uname || serverData?.uname || "Non spécifié",
    });
  }

  mainInfoItems.push(
    {
      label: "Signature",
      value: rowData?.Signature || serverData?.signed || "Non spécifié",
      chip: true,
      colorType: "signature" as "os",
    },
    {
      label: "Adresses IP",
      value: (
        <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1 }}>
          {(Array.isArray(rowData?.["Adresses IP"])
            ? rowData["Adresses IP"]
            : Array.isArray(serverData?.ip_addresses)
              ? serverData.ip_addresses
              : [
                rowData?.["Adresses IP"] ||
                serverData?.ip_addresses ||
                "Non spécifié",
              ]
          ).map(
            (
              ip:
                | string
                | number
                | boolean
                | React.ReactElement<
                  any,
                  string | React.JSXElementConstructor<any>
                >
                | Iterable<React.ReactNode>
                | React.ReactPortal
                | null
                | undefined,
              index: React.Key | null | undefined,
            ) => (
              <Chip
                key={index}
                label={ip}
                variant="outlined"
                size="small"
                sx={{
                  backgroundColor: "#EEF2FF",
                  color: "#141414ff",
                  fontWeight: 500,
                  fontSize: "0.875rem",
                }}
              />
            ),
          )}
        </Box>
      ),
    },
    {
      label: "Fiabilité",
      value: (() => {
        // IGNORER rowData, utiliser seulement serverData
        if (serverData && serverData.hasOwnProperty('fiable')) {
          return serverData.fiable ? "Fiable" : "Non fiable";
        }

        // Par défaut si pas de propriété fiable dans serverData
        return "Fiable";
      })(),
      chip: true,
      colorType: "fiabilite" as "os",
    },
  );

  // Données organisées
  const leftBlock: BlockSection[] = [
    {
      title: "Informations principales",
      items: mainInfoItems,
    },

    {
      title: "Environnement",
      items: [
        {
          label: "Environnements",
          value: (
            <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1 }}>
              {(Array.isArray(rowData?.Environnements)
                ? rowData.Environnements
                : Array.isArray(serverData?.environments)
                  ? serverData.environments
                  : [
                    rowData?.Environnements ||
                    serverData?.environments ||
                    "Non spécifié",
                  ]
              ).map((env: string, index: number) => {
                const bgColor = getBadgeColorEnvironment(env);
                return (
                  <Chip
                    key={index}
                    label={env}
                    size="small"
                    sx={{
                      backgroundColor: bgColor,
                      color: "#000000",
                      fontWeight: 500,
                      fontSize: "0.875rem",
                    }}
                  />
                );
              })}
            </Box>
          ),
        },

        {
          label: "Nature du serveur dans l'inventaire",
          value: (
            <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1 }}>
              {(Array.isArray(
                rowData?.["Nature du serveur dans L'inventaire"],
              ) && rowData["Nature du serveur dans L'inventaire"].length > 0
                ? rowData["Nature du serveur dans L'inventaire"]
                : ["Non spécifié"]
              ).map((nature: string, index: number) => (
                <Chip
                  key={index}
                  label={nature}
                  variant="outlined"
                  size="small"
                  sx={{
                    backgroundColor: "#EEF2FF",
                    borderColor: "#C7D2FE",
                    color: "#141320ff",
                    fontWeight: 500,
                    "& .MuiChip-label": {
                      fontSize: "0.875rem",
                    },
                  }}
                />
              ))}
            </Box>
          ),
        },
        {
          label: "Nature du serveur dans BigFix",
          value: (
            <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1 }}>
              {(Array.isArray(rowData?.["Nature du serveur dans BigFix"])
                ? rowData["Nature du serveur dans BigFix"]
                : serverData?.nature_detail
                  ? [serverData.nature_detail]
                  : ["Non spécifié"]
              ).map((nature: string, index: number) => (
                <Chip
                  key={index}
                  label={nature}
                  variant="outlined"
                  sx={{
                    backgroundColor: "#E8F5E8",
                    borderColor: "#A5D6A7",
                    color: "#1B5E20",
                    fontWeight: 500,
                    "& .MuiChip-label": {
                      fontSize: "0.875rem",
                    },
                  }}
                />
              ))}
            </Box>
          ),
        },

        {
          label: "Détails de la nature",
          value:
            rowData?.nature_detail ||
            serverData?.nature_detail ||
            "Non spécifié",
        },
      ],
    },
    {
      title: "Solutions",
      items: [
        {
          label: "Big Fix",
          value: (
            <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1 }}>
              {(Array.isArray(rowData?.["Solutions dans Bigfix"]) &&
                rowData["Solutions dans Bigfix"].length > 0
                ? rowData["Solutions dans Bigfix"].map((sol: any) =>
                  typeof sol === "object" && sol.solution_name
                    ? sol.solution_name
                    : sol,
                )
                : ["Non défini"]
              ).map((solution: string, index: number) => (
                <Chip
                  key={index}
                  label={solution}
                  size="small"
                  sx={{
                    backgroundColor: "#e8f5e8",
                    color: "#2e7d32",
                    fontWeight: 500,
                    fontSize: "0.875rem",
                  }}
                />
              ))}
            </Box>
          ),
        },
        {
          label: "Inventaire",
          value: (
            <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1 }}>
              {(Array.isArray(rowData?.["Solutions dans l'inventaire"]) &&
                rowData["Solutions dans l'inventaire"].length > 0
                ? rowData["Solutions dans l'inventaire"]
                : ["Non défini"]
              ).map((solution: string, index: number) => (
                <Chip
                  key={index}
                  label={solution}
                  size="small"
                  sx={{
                    backgroundColor: "#fff3e0",
                    color: "#ef6c00",
                    fontWeight: 500,
                    fontSize: "0.875rem",
                  }}
                />
              ))}
            </Box>
          ),
        },
      ],
    },


    {
      title: "Ressources Hardware",
      items: [
        {
          label: "CPU",
          value: serverData?.specs?.cpu ? (
            <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
              <Speed sx={{ fontSize: "18px", color: "#FF6B6B" }} />
              {isAixSystem && serverData.specs.cpu.limit && serverData.specs.cpu.request ? (
                // Format AIX spécifique
                <Typography sx={{ fontSize: "0.9rem", fontWeight: 600 }}>
                  Limit: {serverData.specs.cpu.limit},
                  Request: {serverData.specs.cpu.request}
                </Typography>
              ) : serverData.specs.cpu.count ? (
                // Format standard pour les autres OS
                <Typography sx={{ fontSize: "0.9rem", fontWeight: 600 }}>
                  {serverData.specs.cpu.count} cores
                </Typography>
              ) : (
                // Format de secours
                <Typography sx={{ fontSize: "0.9rem", fontWeight: 600 }}>
                  {JSON.stringify(serverData.specs.cpu)}
                </Typography>
              )}
            </Box>
          ) : (
            <Typography sx={{ fontSize: "0.9rem", color: "text.secondary", fontStyle: "italic" }}>
              Non disponible
            </Typography>
          ),
        },
        {
          label: "RAM",
          value: serverData?.specs?.memory ? (
            <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
              <Memory sx={{ fontSize: "18px", color: "#4ECDC4" }} />
              {isAixSystem ? (
                // Format AIX spécifique (mémoire en Mo)
                <Typography sx={{ fontSize: "0.9rem", fontWeight: 600 }}>
                  {(() => {
                    const memValue = Number(serverData.specs.memory);
                    return memValue > 1024
                      ? `${Math.round(memValue / 1024)} Go`
                      : `${memValue} Mo`;
                  })()}
                </Typography>
              ) : serverData.specs.memory?.size_MiB ? (
                // Format standard pour les autres OS
                <Typography sx={{ fontSize: "0.9rem", fontWeight: 600 }}>
                  {Math.round(serverData.specs.memory.size_MiB / 1024)} Go
                </Typography>
              ) : (
                // Format de secours (cas où memory est un string/number)
                <Typography sx={{ fontSize: "0.9rem", fontWeight: 600 }}>
                  {(() => {
                    const memValue = Number(serverData.specs.memory);
                    return isNaN(memValue)
                      ? String(serverData.specs.memory)
                      : memValue > 1024
                        ? `${Math.round(memValue / 1024)} Go`
                        : `${memValue} Mo`;
                  })()}
                </Typography>
              )}
            </Box>
          ) : (
            <Typography sx={{ fontSize: "0.9rem", color: "text.secondary", fontStyle: "italic" }}>
              Non disponible
            </Typography>
          ),
        },
        // Affichage du stockage seulement pour les non-AIX
        ...(isAixSystem ? [] : [
          {
            label: "Stockage",
            value: serverData?.specs?.storage ? (
              <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                <Storage sx={{ fontSize: "18px", color: "#45B7D1" }} />
                <Typography sx={{ fontSize: "0.9rem", fontWeight: 600 }}>
                  {Math.round(serverData.specs.storage / 1024 / 1024 / 1024)} Go
                </Typography>
              </Box>
            ) : (
              <Typography sx={{ fontSize: "0.9rem", color: "text.secondary", fontStyle: "italic" }}>
                {isAixSystem ? "Non spécifié pour AIX" : "Non disponible"}
              </Typography>
            ),
          },
        ]),
        // Affichage des disques seulement pour les non-AIX
        ...(isAixSystem ? [] : [
          {
            label: "Disques",
            value: serverData?.specs?.disks ? (
              <Box sx={{ display: "flex", flexDirection: "column", gap: 1 }}>
                {serverData.specs.disks.map((disk: any, index: number) => (
                  <Box key={index} sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                    <Storage sx={{ fontSize: "16px", color: "#45B7D1" }} />
                    <Typography sx={{ fontSize: "0.85rem", fontWeight: 500 }}>
                      {disk.label}: {Math.round(disk.capacity / 1024 / 1024 / 1024)} Go
                    </Typography>
                  </Box>
                ))}
              </Box>
            ) : (
              <Typography sx={{ fontSize: "0.9rem", color: "text.secondary", fontStyle: "italic" }}>
                Non disponible
              </Typography>
            ),
          },
        ]),

        {
          label: "Source",
          value: serverData?.specs?.HMC_SOURCE || serverData?.specs?.vmware_source ? (
            <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
              <Typography sx={{ fontSize: "0.9rem", fontWeight: 600 }}>
                {serverData.specs.HMC_SOURCE || serverData.specs.vmware_source}
              </Typography>
            </Box>
          ) : (
            <Typography sx={{ fontSize: "0.9rem", color: "text.secondary", fontStyle: "italic" }}>
              Non disponible
            </Typography>
          ),
        },
      ],
    }


  ];

  const rightBlock: BlockSection[] = [
    {
      title: `Administration `,
      items: [
        {
          label: "Admin fonctionnel",
          value:
            adminsData.funcAdmins.length > 3
              ? `${adminsData.funcAdmins
                .slice(0, 3)
                .map(
                  (admin: { name: any; email: any }) =>
                    `${admin.name} (${admin.email})`,
                )
                .join(", ")}...`
              : adminsData.funcAdmins
                .map(
                  (admin: { name: any; email: any }) =>
                    `${admin.name} (${admin.email})`,
                )
                .join(", ") || "Non spécifié",
          admins: adminsData.funcAdmins,
          type: "fonctionnels",
        },
        {
          label: "Admin technique",
          value:
            adminsData.techAdmins.length > 3
              ? `${adminsData.techAdmins
                .slice(0, 3)
                .map(
                  (admin: { name: any; email: any }) =>
                    `${admin.name} (${admin.email})`,
                )
                .join(", ")}...`
              : adminsData.techAdmins
                .map(
                  (admin: { name: any; email: any }) =>
                    `${admin.name} (${admin.email})`,
                )
                .join(", ") || "Non spécifié",
          admins: adminsData.techAdmins,
          type: "techniques",
        },
        {
          label: "TAM",
          value:
            adminsData.tam.length > 3
              ? `${adminsData.tam
                .slice(0, 3)
                .map(
                  (admin: { name: any; email: any }) =>
                    `${admin.name} (${admin.email})`,
                )
                .join(", ")}...`
              : adminsData.tam
                .map(
                  (admin: { name: any; email: any }) =>
                    `${admin.name} (${admin.email})`,
                )
                .join(", ") || "Non spécifié",
          admins: adminsData.tam,
          type: "TAM",
        },
      ],
    },
    {
      title: `Organisation `,
      items: [
        {
          label: "Domaine",
          value:
            domaineAdmin.length > 3
              ? `${domaineAdmin
                .slice(0, 3)
                .map((admin: { name: any }) => admin.name)
                .join(", ")}...`
              : domaineAdmin
                .map((admin: { name: any }) => admin.name)
                .join(", ") || "Non spécifié",
          type: "domaine",
        },
        {
          label: "Pôle",
          value:
            polesAdmin.length > 3
              ? `${polesAdmin
                .slice(0, 3)
                .map((admin: { name: any }) => admin.name)
                .join(", ")}...`
              : polesAdmin
                .map((admin: { name: any }) => admin.name)
                .join(", ") || "Non spécifié",
          type: "poles",
        },
        {
          label: "Entité",
          value:
            entiteAdmin.length > 3
              ? `${entiteAdmin
                .slice(0, 3)
                .map((admin: { name: any }) => admin.name)
                .join(", ")}...`
              : entiteAdmin
                .map((admin: { name: any }) => admin.name)
                .join(", ") || "Non spécifié",
          type: "entites",
        },
      ],
    },
    {
      title: "Métadonnées",
      items: [
        { label: "Créé par", value: serverData?.created_by || "Non spécifié" },
        {
          label: "Créé le",
          value: serverData?.created_at
            ? new Date(serverData.created_at).toLocaleString()
            : "Non spécifié",
        },
        {
          label: "Mis à jour par",
          value: serverData?.updated_by || "Non spécifié",
        },
        {
          label: "Mis à jour le",
          value: serverData?.updated_at
            ? new Date(serverData.updated_at).toLocaleString()
            : "Non spécifié",
        },
      ],
    },
  ];

  const renderSection = (section: BlockSection) => (
    <Card
      key={section.title}
      variant="outlined"
      sx={{
        mb: 1,
        backgroundColor: "#f9fbfd",
        borderColor: "#e0e0e0",
        borderRadius: 0.3,
      }}
    >
      <CardContent sx={{ pb: "16px !important" }}>
        <Typography
          variant="h6"
          component="h3"
          sx={{
            color: "#1976d2",
            fontSize: "1.1rem",
            fontWeight: 600,
            mb: 1.2,
            display: "flex",
            alignItems: "center",
            gap: 1,
          }}
        >
          {section.title}
        </Typography>

        <Box sx={{ display: "flex", flexDirection: "column", gap: 0.3 }}>
          {section.items.map((item, itemIndex) => {
            // Utiliser une valeur string pour la fonction getItemColor si nécessaire
            const colorValue = typeof item.value === "string" ? item.value : "";
            const colors = getItemColor(colorValue, item.colorType);

            return (
              <Box
                key={itemIndex}
                sx={{
                  display: "flex",
                  alignItems: "center", // Alignement en bas
                  minHeight: "40px",
                  py: 0.5,
                  gap: 2,
                }}
              >
                <Typography
                  variant="body2"
                  sx={{
                    fontWeight: 600,
                    color: "#555",
                    minWidth: { xs: "100%", sm: "160px" },
                    fontSize: "0.9rem",
                    display: "flex",
                    alignItems: "center", // Alignement du label en bas
                    lineHeight: 1.2,
                  }}
                >
                  {item.label}:
                </Typography>

                <Box
                  sx={{
                    display: "flex",
                    alignItems: "center", // Alignement du contenu en bas
                    gap: 1,
                    flex: 1,
                    minWidth: 0,
                    flexWrap: "wrap", // Permettre le retour à la ligne
                  }}
                >
                  {item.chip && typeof item.value === "string" ? (
                    <Chip
                      label={item.value}
                      size="small"
                      sx={{
                        backgroundColor: item.bgColor
                          ? item.bgColor
                          : colors.bgColor,
                        color: item.textColor
                          ? item.textColor
                          : colors.textColor,
                        fontSize: "0.8rem",
                        fontWeight: 500,
                        height: "28px",
                        alignSelf: "center", // Alignement individuel en bas
                        "& .MuiChip-label": {
                          px: 1,
                        },
                        "& .MuiChip-icon": {
                          color: item.textColor
                            ? item.textColor
                            : colors.textColor,
                          marginLeft: "8px",
                        },
                      }}
                    />
                  ) : (
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center", // Alignement en bas pour le contenu complexe
                        flexWrap: "wrap",
                        gap: 0.5,
                      }}
                    >
                      <Typography
                        variant="body2"
                        sx={{
                          wordBreak: "break-word",
                          fontSize: "0.85rem",
                          color: "#333",
                          alignSelf: "center", // Alignement du texte en bas
                          lineHeight: 1.2,
                        }}
                        component="div"
                      >
                        {item.value || "Non spécifié"}
                      </Typography>
                      {item.admins && item.admins.length > 0 && (
                        <IconButton
                          size="small"
                          onClick={(e) =>
                            handleAdminsClick(
                              e,
                              item.type || "",
                              item.admins || [],
                            )
                          }
                          sx={{
                            p: 0.5,
                            color: "#1976d2",
                            alignSelf: "center", // Alignement de l'icône en bas
                            "&:hover": {
                              backgroundColor: "rgba(25, 118, 210, 0.04)",
                            },
                          }}
                        >
                          <GroupIcon fontSize="small" />
                        </IconButton>
                      )}
                    </Box>
                  )}
                </Box>
              </Box>
            );
          })}
        </Box>
      </CardContent>
    </Card>
  );

  const renderBlock = (block: BlockSection[]) => (
    <Box>{block.map(renderSection)}</Box>
  );

  return (
    <>
      <Dialog
        open={open}
        onClose={onClose}
        TransitionComponent={Transition}
        keepMounted
        fullScreen={fullScreen}
        maxWidth="lg"
        fullWidth
        PaperProps={{
          sx: {
            borderRadius: fullScreen ? 0 : 1,
            maxHeight: "90vh",
          },
        }}
      >
        {/* En-tête avec gradient */}
        <DialogTitle
          sx={{
            background: "linear-gradient(135deg, #1976d2 0%, #0d47a1 100%)",
            color: "white",
            p: 2.5,
            display: "flex",
            alignItems: "center",
            gap: 2,
            position: "relative",
            marginBottom: 2,
          }}
        >
          <Avatar
            sx={{
              bgcolor: "white",
              color: "#1976d2",
              width: 50,
              height: 50,
            }}
          >
            <ComputerIcon />
          </Avatar>

          <Box sx={{ flex: 1 }}>
            <Typography
              variant="h5"
              component="h2"
              sx={{ fontWeight: 600, mb: 0.5 }}
            >
              Détails du serveur
            </Typography>
            <Typography variant="body1" sx={{ opacity: 0.9, fontWeight: 400 }}>
              {rowData?.Hostname || serverData?.hostname || "Serveur"}
            </Typography>
          </Box>

          <IconButton
            onClick={onClose}
            sx={{
              color: "white",
              position: "absolute",
              right: 8,
              top: 8,
              "&:hover": {
                backgroundColor: "rgba(255, 255, 255, 0.1)",
              },
            }}
          >
            <CloseIcon />
          </IconButton>
        </DialogTitle>

        {/* Contenu */}
        <DialogContent sx={{ p: 2.5, overflow: "auto" }}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              {renderBlock(leftBlock)}
            </Grid>
            <Grid item xs={12} md={6}>
              {renderBlock(rightBlock)}
            </Grid>
          </Grid>
        </DialogContent>

        {/* Pied de page */}
        <DialogActions sx={{ p: 2.5, pt: 1, borderTop: "1px solid #e0e0e0" }}>
          <Button
            onClick={onClose}
            variant="contained"
            sx={{
              backgroundColor: "#1976d2",
              "&:hover": {
                backgroundColor: "#1565c0",
              },
            }}
          >
            Fermer
          </Button>
        </DialogActions>
      </Dialog>

      {/* Popover pour les admins */}
      <Popover
        open={Boolean(anchorEl)}
        anchorEl={anchorEl}
        onClose={handlePopoverClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "left",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "left",
        }}
        PaperProps={{
          sx: {
            maxWidth: 320,
            maxHeight: 400,
            overflow: "auto",
          },
        }}
      >
        <Paper sx={{ p: 2 }}>
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              mb: 1,
            }}
          >
            <Typography
              variant="h6"
              component="h4"
              sx={{ fontSize: "1rem", fontWeight: 600 }}
            >
              Liste des {currentAdmins?.type} (
              {currentAdmins?.admins?.length || 0})
            </Typography>
            <IconButton size="small" onClick={handlePopoverClose}>
              <CloseIcon fontSize="small" />
            </IconButton>
          </Box>

          <Divider sx={{ mb: 1 }} />

          <List dense sx={{ p: 0 }}>
            {currentAdmins?.admins?.map((admin, index) => (
              <ListItem key={index} sx={{ px: 0, py: 0.5 }}>
                <ListItemAvatar>
                  <Avatar
                    sx={{
                      width: 32,
                      height: 32,
                      bgcolor: "#f0f0f0",
                      color: "#666",
                    }}
                  >
                    <PersonIcon fontSize="small" />
                  </Avatar>
                </ListItemAvatar>
                <ListItemText
                  primary={
                    <Typography
                      variant="body2"
                      sx={{ fontWeight: 500, fontSize: "0.875rem" }}
                    >
                      {admin.name || "Nom non disponible"}
                    </Typography>
                  }
                  secondary={
                    <Typography
                      variant="caption"
                      sx={{ color: "#666", fontSize: "0.75rem" }}
                    >
                      {admin.email || "Email non disponible"}
                    </Typography>
                  }
                />
              </ListItem>
            ))}
          </List>
        </Paper>
      </Popover>
    </>
  );
};

export default ServerDetailsModal;
