// src/pages/sub-pages/admin/SolutionPage.tsx

import { FC } from "react";

// import files
import SolutionDataTable from "@/components/data-tables/SolutionDataTable";

const SolutionPage: FC = () => {
  return <SolutionDataTable />;
};

export default SolutionPage;
