// src/components/basics/CustomBadge.tsx

import { FC } from "react";
import Box from "@mui/material/Box";

interface CustomBadgeProps {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  text: any;
  textColor?: string;
  backgroundColor?: string;
  textSize?: string;
  withBorder?: boolean;
  borderColor?: string;
}

const CustomBadge: FC<CustomBadgeProps> = ({
  text,
  textColor = "white",
  backgroundColor = "primary.main",
  textSize = "0.9rem",
  withBorder = false,
  borderColor = "#909090",
}) => {
  return (
    <Box
      sx={{
        bgcolor: backgroundColor,
        marginRight: 1,
        padding: "0.25rem 0.5rem",
        borderRadius: "4px",
        display: "inline-flex",
        alignItems: "center",
        height: "1.5rem",
        border: withBorder ? `0.3px solid ${borderColor}` : "none",
      }}
    >
      <span
        style={{ fontSize: textSize, color: textColor, fontWeight: "bold" }}
      >
        {text}
      </span>
    </Box>
  );
};

export default CustomBadge;
