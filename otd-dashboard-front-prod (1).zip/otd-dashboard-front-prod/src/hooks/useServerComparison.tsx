/* eslint-disable @typescript-eslint/no-explicit-any */
import type React from "react";

import { ServerConformityType } from "@/enums/ServerConformityView";
import { serverComparisonService } from "@/services/ServerComparisonService";
import { ServerComparisonState, TabLabels } from "@/types/ReliabilityTypes";
import { useCallback, useEffect, useMemo, useState } from "react";

const initialState: ServerComparisonState = {
  data: [],
  loading: true,
  error: null,
  page: 0,
  rowsPerPage: 10,
  searchTerm: "",
  totalCount: 0,
  selectedTab: ServerConformityType.NON_CONFORMES,
  editableValues: {},
  apiDropdownOptions: {},
};

export const useServerComparison = () => {
  const [state, setState] = useState<ServerComparisonState>(initialState);

  const tabLabels: TabLabels = {
    [ServerConformityType.CONFORMES]: "Conformes",
    [ServerConformityType.NON_CONFORMES]: "Non-Conformes",
    [ServerConformityType.NON_DECLARED]: "Non-declare",
  };

  const fetchDropdownOptions = useCallback(async () => {
    try {
      const options = await serverComparisonService.getAllDropdownOptions();
      setState((prev) => ({
        ...prev,
        apiDropdownOptions: options,
      }));
    } catch (error) {
      console.error("Error fetching dropdown options:", error);
    }
  }, []);

  const fetchData = useCallback(async () => {
    setState((prev) => ({ ...prev, loading: true, error: null }));

    try {
      const result = await serverComparisonService.getServers({
        conformityType: state.selectedTab,
      });

      setState((prev) => ({
        ...prev,
        data: result.results,
        totalCount: result.count,
        loading: false,
      }));
    } catch (err) {
      setState((prev) => ({
        ...prev,
        error: "Service indisponible. Prière de réessayer plus tard.",
        loading: false,
      }));
      console.error("Error fetching data:", err);
    }
  }, [state.selectedTab]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  useEffect(() => {
    fetchDropdownOptions();
  }, [fetchDropdownOptions]);

  const handleChangePage = (_event: unknown, newPage: number) => {
    setState((prev) => ({ ...prev, page: newPage }));
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    setState((prev) => ({
      ...prev,
      rowsPerPage: Number.parseInt(event.target.value, 10),
      page: 0,
    }));
  };

  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setState((prev) => ({
      ...prev,
      searchTerm: event.target.value,
      page: 0,
    }));
  };

  const handleTabChange = (
    _event: React.SyntheticEvent,
    newValue: ServerConformityType,
  ) => {
    setState((prev) => ({
      ...prev,
      selectedTab: newValue,
      page: 0,
    }));
  };

  const handleValueChange = (
    serverId: number,
    field: string,
    value: string,
  ) => {
    setState((prev) => ({
      ...prev,
      editableValues: {
        ...prev.editableValues,
        [`${serverId}-${field}`]: value,
      },
    }));
  };

  const handleUpdateServer = async (serverId: number) => {
    const server = state.data.find((s) => s.id === serverId);
    if (!server) return;

    // Récupère l'IP depuis les données du serveur
    const ip = server.inventory_data.ip_addresses?.[0] || server.ip;

    // Transforme les données d'édition dans le format de l'API
    const buildApiPayload = (edits: Record<string, string>) => {
      const payload: Record<string, any> = {};

      console.log(edits);

      // Mapping manuel pour chaque champ possible
      if ("os" in edits) payload.os_type = edits.os;
      if ("os_details" in edits) payload.os_details = edits.os_details;
      if ("hostname" in edits) payload.hostname = edits.hostname;
      if ("solution_name" in edits) payload.solution_name = edits.solution_name;
      if ("environments" in edits)
        payload.environments = edits.environments
          .split(",")
          .map((v) => v.trim());
      if ("server_nature" in edits)
        payload.server_nature = edits.server_nature
          .split(",")
          .map((v) => v.trim());
      if ("solution_role" in edits) payload.solution_role = edits.solution_role;
      if ("solution_type" in edits) payload.solution_type = edits.solution_type;
      if ("solution_deployed_version" in edits)
        payload.solution_deployed_version = edits.solution_deployed_version;
      if ("pci" in edits) payload.pci = edits.pci;
      if ("solution_popularity" in edits)
        payload.solution_popularity = edits.solution_popularity;

      // Gestion des relations
      if ("tam" in edits) payload.tam_email = edits.tam;
      if ("functionals_admins" in edits)
        payload.functionals_admins_emails = edits.functionals_admins.split(",");
      if ("technicals_admins" in edits)
        payload.technicals_admins_emails = edits.technicals_admins.split(",");
      if ("domain" in edits) payload.domain_name = edits.domain;
      if ("pole" in edits) payload.pole_name = edits.pole;
      if ("entity" in edits) payload.entity_name = edits.entity;

      return payload;
    };

    try {
      setState((prev) => ({ ...prev, loading: true }));

      // Récupère les modifications pour ce serveur
      const serverEdits = Object.entries(state.editableValues)
        .filter(([key]) => key.startsWith(`${serverId}-`))
        .reduce(
          (acc, [key, value]) => {
            const field = key.split("-")[1];
            acc[field] = value;
            return acc;
          },
          {} as Record<string, string>,
        );

      const apiPayload = buildApiPayload(serverEdits);

      await serverComparisonService.updateServer({
        ip,
        updates: apiPayload,
      });

      // Rafraîchir les données
      await fetchData();

      // Réinitialiser les valeurs éditées
      const newEditableValues = { ...state.editableValues };
      Object.keys(newEditableValues).forEach((key) => {
        if (key.startsWith(`${serverId}-`)) {
          delete newEditableValues[key];
        }
      });

      setState((prev) => ({
        ...prev,
        editableValues: newEditableValues,
        loading: false,
        success: `Serveur ${server.inventory_data.hostname} mis à jour avec succès`,
      }));
    } catch (error) {
      setState((prev) => ({
        ...prev,
        error: `Échec de la mise à jour du serveur ${error}`,
        loading: false,
      }));
    }
  };

  const filteredData = useMemo(() => {
    return state.data.filter(
      (server) =>
        server.ip.toLowerCase().includes(state.searchTerm.toLowerCase()) ||
        server.inventory_data.os
          .toLowerCase()
          .includes(state.searchTerm.toLowerCase()) ||
        server.inventory_data.solution_name
          .toLowerCase()
          .includes(state.searchTerm.toLowerCase()) ||
        server.inventory_data.hostname
          .toLowerCase()
          .includes(state.searchTerm.toLowerCase()),
    );
  }, [state.data, state.searchTerm]);

  const paginatedData = useMemo(() => {
    return filteredData.slice(
      state.page * state.rowsPerPage,
      state.page * state.rowsPerPage + state.rowsPerPage,
    );
  }, [filteredData, state.page, state.rowsPerPage]);

  return {
    ...state,
    tabLabels,
    filteredData,
    paginatedData,
    handleChangePage,
    handleChangeRowsPerPage,
    handleSearchChange,
    handleTabChange,
    handleValueChange,
    handleUpdateServer,
    fetchData,
  };
};
