import React, { useState, useEffect } from "react";
import {
  Box,
  Tab,
  Tabs,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  CircularProgress,
  Typography,
  useTheme,
} from "@mui/material";
import { Activity, CheckCircle, XCircle, Clock, RefreshCw } from "lucide-react";
import { GetAudit_BaseURL } from "@/config/api.config";
import fetchWithAuth from "@/middleware/fetch-auth";

// Interfaces pour les données
interface Batch {
  id: string;
  name: string;
  timestamp: string;
  execution_time: null | string;
  status: string;
}

interface Action {
  id: string;
  timestamp: string;
  action: string;
  actor: string;
  app: string;
  ressource: string;
  verb: string;
  status: boolean;
  comment: string;
}

interface Insert {
  id: string;
  timestamp: string;
  actor: string;
  target: string;
  count_add: number;
  count_updated: number;
  source: null | string;
}

const SignaturePage: React.FC = () => {
  const theme = useTheme();
  const [activeTab, setActiveTab] = useState(0);
  const [batches, setBatches] = useState<Batch[]>([]);
  const [actions, setActions] = useState<Action[]>([]);
  const [inserts, setInserts] = useState<Insert[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const batchResponse = await fetchWithAuth(`${GetAudit_BaseURL()}batch/`);
      const actionResponse = await fetchWithAuth(
        `${GetAudit_BaseURL()}action/`,
      );
      const insertResponse = await fetchWithAuth(
        `${GetAudit_BaseURL()}insert/`,
      );

      const batchData = await batchResponse.json();
      const actionData = await actionResponse.json();
      const insertData = await insertResponse.json();

      setBatches(batchData);
      setActions(actionData);
      setInserts(insertData);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleTabChange = (_event: React.SyntheticEvent, newValue: number) => {
    setActiveTab(newValue);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString("fr-FR");
  };

  const getStatusChip = (status: string) => {
    switch (status.toLowerCase()) {
      case "success":
        return (
          <Chip
            icon={<CheckCircle size={14} />}
            label="Terminé"
            color="success"
            size="small"
          />
        );
      case "failure":
        return (
          <Chip
            icon={<XCircle size={14} />}
            label="Échec"
            color="error"
            size="small"
          />
        );
      default:
        return (
          <Chip
            icon={<Clock size={14} />}
            label="En cours"
            color="warning"
            size="small"
          />
        );
    }
  };

  return (
    <Box
      sx={{
        p: 3,
        backgroundColor: theme.palette.background.default,
        minHeight: "100vh",
      }}
    >
      <Paper sx={{ p: 2, borderRadius: 2, boxShadow: theme.shadows[3] }}>
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            mb: 2,
          }}
        >
          <Typography
            variant="h5"
            sx={{ display: "flex", alignItems: "center", gap: 1 }}
          >
            <Activity size={24} />
            Journal d'audit
          </Typography>
          <Chip
            icon={<RefreshCw size={16} />}
            label="Rafraîchir"
            onClick={fetchData}
            variant="outlined"
            sx={{ cursor: "pointer" }}
          />
        </Box>

        <Tabs
          value={activeTab}
          onChange={handleTabChange}
          indicatorColor="primary"
          textColor="primary"
          sx={{ mb: 3 }}
        >
          <Tab label="Batches" />
          <Tab label="Activités" />
          <Tab label="Insertions CSV" />
        </Tabs>

        {loading ? (
          <Box sx={{ display: "flex", justifyContent: "center", p: 4 }}>
            <CircularProgress />
          </Box>
        ) : activeTab === 0 ? (
          <TableContainer
            component={Paper}
            sx={{ boxShadow: theme.shadows[1] }}
          >
            <Table>
              <TableHead sx={{ backgroundColor: theme.palette.grey[100] }}>
                <TableRow>
                  <TableCell>ID</TableCell>
                  <TableCell>Nom</TableCell>
                  <TableCell>Date/Heure</TableCell>
                  <TableCell>Temps d'exécution</TableCell>
                  <TableCell>Statut</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {batches.length > 0 ? (
                  batches.map((batch) => (
                    <TableRow key={batch.id} hover>
                      <TableCell sx={{ fontFamily: "monospace" }}>
                        {batch.id}
                      </TableCell>
                      <TableCell>{batch.name}</TableCell>
                      <TableCell>{formatDate(batch.timestamp)}</TableCell>
                      <TableCell>{batch.execution_time || "N/A"}</TableCell>
                      <TableCell>{getStatusChip(batch.status)}</TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={5} align="center">
                      Aucun batch disponible
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
        ) : activeTab === 1 ? (
          <TableContainer
            component={Paper}
            sx={{ boxShadow: theme.shadows[1] }}
          >
            <Table>
              <TableHead sx={{ backgroundColor: theme.palette.grey[100] }}>
                <TableRow>
                  <TableCell>ID</TableCell>
                  <TableCell>Date/Heure</TableCell>
                  <TableCell>Action</TableCell>
                  <TableCell>Acteur</TableCell>
                  <TableCell>Application</TableCell>
                  <TableCell>Ressource</TableCell>
                  <TableCell>Statut</TableCell>
                  <TableCell>Résumé</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {actions.length > 0 ? (
                  actions.map((action) => (
                    <TableRow key={action.id} hover>
                      <TableCell sx={{ fontFamily: "monospace" }}>
                        {action.id}
                      </TableCell>
                      <TableCell>{formatDate(action.timestamp)}</TableCell>
                      <TableCell>{action.action}</TableCell>
                      <TableCell>{action.actor}</TableCell>
                      <TableCell>{action.app}</TableCell>
                      <TableCell>{action.ressource}</TableCell>
                      <TableCell>
                        {action.status ? (
                          <Chip
                            icon={<CheckCircle size={14} />}
                            label="Succès"
                            color="success"
                            size="small"
                          />
                        ) : (
                          <Chip
                            icon={<XCircle size={14} />}
                            label="Échec"
                            color="error"
                            size="small"
                          />
                        )}
                      </TableCell>
                      <TableCell>{action.comment}</TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} align="center">
                      Aucune activité disponible
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
        ) : (
          <TableContainer
            component={Paper}
            sx={{ boxShadow: theme.shadows[1] }}
          >
            <Table>
              <TableHead sx={{ backgroundColor: theme.palette.grey[100] }}>
                <TableRow>
                  <TableCell>ID</TableCell>
                  <TableCell>Date/Heure</TableCell>
                  <TableCell>Acteur</TableCell>
                  <TableCell>Cible</TableCell>
                  <TableCell>Ajouts</TableCell>
                  <TableCell>Mises à jour</TableCell>
                  <TableCell>Source</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {inserts.length > 0 ? (
                  inserts.map((insert) => (
                    <TableRow key={insert.id} hover>
                      <TableCell sx={{ fontFamily: "monospace" }}>
                        {insert.id}
                      </TableCell>
                      <TableCell>{formatDate(insert.timestamp)}</TableCell>
                      <TableCell>{insert.actor}</TableCell>
                      <TableCell>{insert.target}</TableCell>
                      <TableCell>{insert.count_add}</TableCell>
                      <TableCell>{insert.count_updated}</TableCell>
                      <TableCell>{insert.source || "N/A"}</TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} align="center">
                      Aucune insertion disponible
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </Paper>
    </Box>
  );
};

export default SignaturePage;
