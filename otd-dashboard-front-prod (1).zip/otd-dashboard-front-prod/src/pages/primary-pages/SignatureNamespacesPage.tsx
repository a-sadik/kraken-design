import type React from "react";
import { useState } from "react";
import NamespaceDataTable from "@/components/data-tables/NamespaceDataTable";

const SignatureNamespacesPage: React.FC = () => {
  const [openModal, setOpenModal] = useState(false);

  return (
    <NamespaceDataTable openModal={openModal} setOpenModal={setOpenModal} />
  );
};

export default SignatureNamespacesPage;
