// src/types/dto/PersonDTO.ts

export interface PersonRequestDTO {
  username?: string;
  firstname: string;
  lastname: string;
  email: string;
  posts?: string[];
}

export interface PersonShortResponseDTO {
  person_id: number;
  firstname: string;
  lastname: string;
  email?: string;
  posts?: string[] | null;
  role?: string | null;
}

export interface PersonDetailResponseDTO {
  username: string;
  firstname: string;
  lastname: string;
  email: string;
  posts: string[] | null;
  role: string | null;
}
