// src/types/view/OrganigrammeView.ts

export default interface OrganigrammeView {
  name: string;
}
