// src/components/charts/PieChart.tsx

import { Pie } from "react-chartjs-2";
import { Chart, ArcElement, Tooltip, Legend, ChartData } from "chart.js";
Chart.register(ArcElement, Tooltip, Legend);

interface PieChartProps {
  chartData: ChartData<"pie">;
}

function PieChart({ chartData }: PieChartProps) {
  return (
    <div className="chart-container">
      <Pie
        data={chartData}
        options={{
          plugins: {
            title: {
              display: true,
              text: "Statstique de disponibilité des serveurs en fonction de deux sources",
            },
          },
        }}
        style={{ maxHeight: "35rem" }}
      />
    </div>
  );
}
export default PieChart;
