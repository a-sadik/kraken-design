// src/components/modals/RenewCertificateModal.tsx

import { Box, Typography, Divider, Button } from "@mui/material";

// import files
import MyModal from "@/components/modals/MyModal";

// import icons
import { BsKeyFill } from "react-icons/bs";

export enum Mode {
  OLD = "old-key",
  NEW = "new-key",
}

interface RenewCertificateModalProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (mode: Mode) => void;
  title: string;
  data: any;
}

const RenewCertificateModal = ({
  open,
  onClose,
  onSubmit,
  title,
  data,
}: RenewCertificateModalProps) => {
  return (
    <MyModal
      mainColor="--certifcate-renew-icon-button-background-color"
      open={open}
      onClose={onClose}
      title={title}
      data={data || {}}
    >
      <Typography variant="h5" color="textSecondary" paragraph>
        Confirmez votre demande de renouvelement du certificat avec l'ancienne
        key :
      </Typography>

      <Divider sx={{ my: 2 }} />
      <Box
        sx={{ display: "flex", justifyContent: "center", alignItems: "center" }}
      >
        {/* <Button
          variant="outlined"
          sx={{ marginX: "5px" }}
          endIcon={<BsKey />}
          color='error'
          onClick={() => onSubmit(Mode.NEW)}
        >
          Nouvelle clé
        </Button> */}

        <Button
          variant="contained"
          sx={{ marginX: "5px" }}
          endIcon={<BsKeyFill />}
          onClick={() => onSubmit(Mode.OLD)}
        >
          {/* Ancienne clé */}
          Confirmer
        </Button>
      </Box>
    </MyModal>
  );
};

export default RenewCertificateModal;
