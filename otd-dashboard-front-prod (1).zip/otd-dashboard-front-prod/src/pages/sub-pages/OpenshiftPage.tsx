// src/pages/sub-pages/OpenshiftPage.tsx

import { FC, useState } from "react";

// import files
import OpenshiftPageDataTable from "@/components/data-tables/OpenshiftDataTable";

const OpenshiftPage: FC = () => {
  const [openModal, setOpenModal] = useState(false);

  return (
    <OpenshiftPageDataTable openModal={openModal} setOpenModal={setOpenModal} />
  );
};

export default OpenshiftPage;
