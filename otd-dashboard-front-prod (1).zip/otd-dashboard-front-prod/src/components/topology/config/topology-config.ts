export const API_CONFIG = {
  RELIABILITY_URL: `${import.meta.env.VITE_PREFIX_RELIABILITY_PATH}:${
    import.meta.env.VITE_RELIABILITY_SERVER_PORT
  }`,
  RELIABILITY_API_VERSION: import.meta.env.VITE_SUFFIX_RELIABILITY_PATH,

  DATA_URL: `${import.meta.env.VITE_PREFIX_DATA_PATH}:${
    import.meta.env.VITE_DATA_SERVER_PORT
  }`,
  DATA_API_VERSION: import.meta.env.VITE_SUFFIX_DATA_PATH,
};

export const getServersApiUrl = (endpoint: string): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/servers/${endpoint}`;
};

export const getFieldsApiUrl = (endpoint: string): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/options/${endpoint}`;
};

export const patchUpdateSolutionServerApiUrl = (): string => {
  return `${API_CONFIG.DATA_URL}/${API_CONFIG.DATA_API_VERSION}/solutions-servers/`;
};

export const postRefreshReliabilityApiUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/refresh/`;
};

export const getSignatureListApiUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/servers/signature-status/`;
};

export const postDeploySignatureApiUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/deploy_signature/`;
};

export const getTopologyRootApiUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/openshift-tree/entities/`;
};
export const getMyViewRootApiUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/openshift-tree`;
};

export const postDeployMultipleSignatureApiUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/deploy_signatures/`;
};

export const getSolutionsApiUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/admin/solutions/`;
};

export const getAllTopology = (type: string): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/openshift-tree/${type}`;
};

export const getNamespacesApiUrl = (): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/namespaces/`;
};

export const getPodsbyNamespacesApiUrl = (namespaceId: number): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/namespace/${namespaceId}/pods`;
};

export const postAffechtNamespacesToSolutionsApiUrl = (
  namespaceId: number,
): string => {
  return `${API_CONFIG.RELIABILITY_URL}/${API_CONFIG.RELIABILITY_API_VERSION}/fiabilisation/namespace/${namespaceId}/affect/`;
};
