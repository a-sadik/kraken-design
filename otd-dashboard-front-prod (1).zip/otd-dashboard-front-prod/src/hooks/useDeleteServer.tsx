/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-vars */
// handleDelete.tsx
import { useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Typography,
  IconButton,
} from "@mui/material";
import fetchWithAuth from "@/middleware/fetch-auth";
import { keycloak } from "@/auth/keycloakConnectAdapter";
import DeleteIcon from "@mui/icons-material/Delete";
import { DeleteServerApiURL } from "@/config/api.config";

interface DeleteServerButtonProps {
  row: any;
  disabled?: boolean;
  onDeleteSuccess?: () => void;
  onShowSnackbar?: (message: string) => void; // <- Ajouter cette prop
}

export default function DeleteServerButton({
  row,
  disabled = false,
  onDeleteSuccess,
  onShowSnackbar // <- Ajouter cette prop
}: DeleteServerButtonProps) {
  const [open, setOpen] = useState(false);
  const [hostnameInput, setHostnameInput] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const isAdmin = keycloak.hasRoles("admin_role");
  const isTAM =
    keycloak.hasRoles("tam_role") &&
    row.TAM?.some((t: any) => t.email === keycloak.getEmail());
  const isAuthorized = isAdmin || isTAM;

  const expectedHostname = row.Hostname;

  const isInputValid = hostnameInput === expectedHostname;

  const handleClick = () => {
    if (disabled) return;

    if (!isAuthorized) {
      setError("Vous n'avez pas les droits pour supprimer ce serveur.");
    } else {
      setError(null);
    }

    setHostnameInput("");
    setOpen(true);
  };

  const handleConfirm = async () => {
    if (!isInputValid) {
      setError(`Saisissez correctement : ${expectedHostname}`);
      return;
    }

    setIsDeleting(true);
    try {
      await fetchWithAuth(DeleteServerApiURL(row.id), {
        method: "DELETE",
      });
      setOpen(false);

      // Afficher le Snackbar de succès
      if (onShowSnackbar) {
        onShowSnackbar("🗑️ Serveur supprimé avec succès");
      }

      if (onDeleteSuccess) {
        onDeleteSuccess();
      }
    } catch (err) {
      setError("Erreur lors de la suppression.");
      if (onShowSnackbar) {
        onShowSnackbar("❌ Erreur lors de la suppression");
      }
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <>
      <IconButton
        onClick={handleClick}
        size="small"
        sx={{
          color: "#EF4444",
          backgroundColor: "#FEF2F2",
          "&:hover": {
            backgroundColor: "#FECACA",
            color: "#DC2626",
          },
          ...(disabled && {
            opacity: 0.5,
            cursor: "not-allowed",
            "&:hover": {
              backgroundColor: "#FEF2F2",
              color: "#EF4444",
            }
          })
        }}
        disabled={disabled || isDeleting}
      >
        <DeleteIcon fontSize="small" />
      </IconButton>

      <Dialog open={open} onClose={() => !isDeleting && setOpen(false)}>
        <DialogTitle>Confirmation de suppression</DialogTitle>
        <DialogContent>
          {error && <Typography color="error">{error}</Typography>}
          <Typography>Pour confirmer, saisissez :</Typography>
          <Typography>- Hostname : {expectedHostname}</Typography>

          <TextField
            margin="dense"
            label="Hostname"
            fullWidth
            value={hostnameInput}
            onChange={(e) => setHostnameInput(e.target.value)}
            disabled={isDeleting}
          />

          {isDeleting && (
            <Typography variant="body2" sx={{ mt: 1, color: 'primary.main' }}>
              Suppression en cours...
            </Typography>
          )}
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => setOpen(false)}
            disabled={isDeleting}
          >
            Annuler
          </Button>
          <Button
            color="error"
            onClick={handleConfirm}
            disabled={!isAuthorized || !isInputValid || isDeleting}
          >
            {isDeleting ? "Suppression..." : "Confirmer"}
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
}