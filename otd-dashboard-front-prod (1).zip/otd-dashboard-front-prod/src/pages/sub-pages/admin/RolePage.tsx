// src/pages/sub-pages/admin/RolePage.tsx

import { FC } from "react";

// import files
import RoleDataTable from "@/components/data-tables/RoleDataTable";

const RolePage: FC = () => {
  return <RoleDataTable />;
};

export default RolePage;
