// src/main.tsx

import { StrictMode } from "react";
import { createRoot } from "react-dom/client";

// import files
import App from "@/App";

// import styles
import "../node_modules/awb-ui-front/dist/css/styles.css";
import "@/styles/styles.css";
import "@/styles/colors.css";
import { keycloak } from "./auth/keycloakConnectAdapter";

keycloak.init().then(() => {
  createRoot(document.getElementById("root")!).render(
    <StrictMode>
      <App />
    </StrictMode>,
  );
});
