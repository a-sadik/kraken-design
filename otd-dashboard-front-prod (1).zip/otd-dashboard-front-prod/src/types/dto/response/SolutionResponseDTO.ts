// src/types/dto/response/SolutionResponseDTO.ts

import { SolutionPopularity } from "@/enums/SolutionPopularity";
import { SolutionType } from "@/enums/SolutionType";

export interface SolutionResponseDTO {
  solution_id: number;
  solution_name: string;
  solution_popularity: SolutionPopularity;
  solution_type: SolutionType | string;
  solution_role: string;
  functional_admin: string;
  technical_admin: string;
  tam: string;
  pci: boolean;
  domain_id: any | null;
  created_at: string;
  updated_at: string;
  created_by: string;
  updated_by: string;
}
