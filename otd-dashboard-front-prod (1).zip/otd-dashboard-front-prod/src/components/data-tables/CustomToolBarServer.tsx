/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  Box,
  Button,
  TextField,
  InputAdornment,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Checkbox,
  ListItemText,
  OutlinedInput,
  Chip,
  IconButton,
  Autocomplete,
} from "@mui/material";
import {
  GridToolbarContainer,
  GridToolbarColumnsButton,
  GridToolbarDensitySelector,
} from "@mui/x-data-grid";
import SearchIcon from "@mui/icons-material/Search";
import ClearIcon from "@mui/icons-material/Clear";
import { useEffect, useState, type Dispatch, type SetStateAction } from "react";
import fetchWithAuth from "@/middleware/fetch-auth";
import { getSolutionsApiUrl } from "@/config/api.config";

// Interface simplifiée pour les filtres côté front
interface FrontendServerFilterParams {
  global_search?: string;
  os_type?: string;
  environments?: string[];
  fiable?: boolean | undefined;
  solutions_inventory?: string;
  bigfix_conformity?: string[]; // ← Ajout du filtre BigFix
}

interface CustomToolBarServerProps {
  filterState: FrontendServerFilterParams;
  setFilterState: Dispatch<SetStateAction<FrontendServerFilterParams>>;
}

// Define possible environment values
const environmentOptions = [
  "Production",
  "Préproduction",
  "Intégration",
  "Recette",
  "Développement",
  "Technique",
  "POC",
  "Formation",
  "Sans environnement",
];

// Define possible OS types
const osTypeOptions = ["Windows", "Linux", "AIX", "MacOS", "Other"];

// Options pour le filtre BigFix
const bigFixStatusOptions = [
  "Conforme",
  "Non Déclaré",
  "Déclaré mais non conforme"
];


export default function CustomToolBarServer({
  filterState,
  setFilterState,
}: CustomToolBarServerProps) {
  const handleFilterChange = (
    field: keyof FrontendServerFilterParams,
    value: any,
  ) => {
    setFilterState((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleClearFilter = (field: keyof FrontendServerFilterParams) => {
    setFilterState((prev) => ({
      ...prev,
      [field]: Array.isArray(prev[field])
        ? []
        : typeof prev[field] === "boolean"
          ? undefined
          : "",
    }));
  };

  const [solutions, setSolutions] = useState([]);

  useEffect(() => {
    fetchWithAuth(getSolutionsApiUrl())
      .then((res) => res.json())
      .then((data) => {
        const sortedSolutions = data
          .map((solution: { solution_name: any }) => solution.solution_name)
          .sort((a: string, b: any) => a.localeCompare(b));
        setSolutions(sortedSolutions);
      })
      .catch((err) => {
        console.error("Erreur lors du fetch des solutions :", err);
      });
  }, []);

  return (
    <GridToolbarContainer
      sx={{
        p: 2,
        display: "flex",
        flexWrap: "wrap",
        gap: 2,
        alignItems: "center",
      }}
    >
      <GridToolbarColumnsButton />
      <GridToolbarDensitySelector />

      {/* Recherche globale */}
      <TextField
        variant="outlined"
        size="small"
        placeholder="Recherche globale..."
        value={filterState.global_search || ""}
        onChange={(e) => handleFilterChange("global_search", e.target.value)}
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <SearchIcon />
            </InputAdornment>
          ),
          endAdornment: filterState.global_search && (
            <InputAdornment position="end">
              <IconButton
                onClick={() => handleClearFilter("global_search")}
                size="small"
              >
                <ClearIcon />
              </IconButton>
            </InputAdornment>
          ),
        }}
        sx={{ width: 250 }}
      />

      {/* OS Type Filter */}
      <FormControl sx={{ width: 150 }} size="small">
        <InputLabel>Type OS</InputLabel>
        <Select
          value={filterState.os_type || ""}
          onChange={(e) => {
            handleFilterChange("os_type", e.target.value);
          }}
          input={<OutlinedInput label="Type OS" />}
          renderValue={(selected) => (selected ? (selected as string) : "Tous")}
        >
          <MenuItem value="">
            <em>Tous</em>
          </MenuItem>
          {osTypeOptions.map((option) => (
            <MenuItem key={option} value={option}>
              {option}
            </MenuItem>
          ))}
        </Select>
      </FormControl>

      {/* Environments Filter */}
      <FormControl sx={{ width: 200 }} size="small">
        <InputLabel>Environnements</InputLabel>
        <Select
          multiple
          value={filterState.environments || []}
          onChange={(e) => {
            const value = e.target.value;
            const selectedEnvironments = Array.isArray(value) ? value : [value];
            handleFilterChange("environments", selectedEnvironments);
          }}
          input={<OutlinedInput label="Environnements" />}
          renderValue={(selected) => (
            <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
              {(Array.isArray(selected) ? selected : [selected]).map(
                (value) => (
                  <Chip key={value} label={value} size="small" />
                ),
              )}
            </Box>
          )}
        >
          {environmentOptions.map((env) => (
            <MenuItem key={env} value={env}>
              <Checkbox
                checked={(filterState.environments || []).indexOf(env) > -1}
              />
              <ListItemText primary={env} />
            </MenuItem>
          ))}
        </Select>
      </FormControl>


      {/* Fiabilité Filter */}
      <FormControl sx={{ width: 150 }} size="small">
        <InputLabel>Fiabilité</InputLabel>
        <Select
          value={
            filterState.fiable === true
              ? "true"
              : filterState.fiable === false
                ? "false"
                : ""
          }
          onChange={(e) => {
            const value = e.target.value;
            handleFilterChange(
              "fiable",
              value === "true" ? true : value === "false" ? false : undefined,
            );
          }}
          input={<OutlinedInput label="Fiabilité" />}
          renderValue={(selected) => {
            if (selected === "true") return "Fiable";
            if (selected === "false") return "Non fiable";
            return "Tous";
          }}
        >
          <MenuItem value="">
            <em>Tous</em>
          </MenuItem>
          <MenuItem value="true">Fiable</MenuItem>
          <MenuItem value="false">Non fiable</MenuItem>
        </Select>
      </FormControl>

      {/* Solutions Inventory Filter */}
      <Autocomplete
        options={solutions}
        value={filterState.solutions_inventory || ""}
        onChange={(_event, newValue) => {
          handleFilterChange("solutions_inventory", newValue);
        }}
        renderInput={(params) => (
          <TextField
            {...params}
            label="Solutions Inventaire"
            variant="outlined"
            size="small"
            InputProps={{
              ...params.InputProps,
              endAdornment: (
                <>
                  {filterState.solutions_inventory && (
                    <InputAdornment position="end">
                      <IconButton
                        onClick={() => handleClearFilter("solutions_inventory")}
                        size="small"
                      >
                        <ClearIcon />
                      </IconButton>
                    </InputAdornment>
                  )}
                  {params.InputProps.endAdornment}
                </>
              ),
            }}
            sx={{ width: 200 }}
          />
        )}
      />

      {/* NOUVEAU FILTRE : Conformité BigFix */}
      <FormControl sx={{ width: 220 }} size="small">
        <InputLabel>Conformité BigFix</InputLabel>
        <Select
          multiple
          value={filterState.bigfix_conformity || []}
          onChange={(e) => {
            const value = e.target.value;
            const selectedStatus = Array.isArray(value) ? value : [value];
            handleFilterChange("bigfix_conformity", selectedStatus);
          }}
          input={<OutlinedInput label="Conformité BigFix" />}
          renderValue={(selected) => (
            <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
              {(Array.isArray(selected) ? selected : [selected]).map(
                (value) => (
                  <Chip
                    key={value}
                    label={value}
                    size="small"
                  />
                ),
              )}
            </Box>
          )}
        >
          {bigFixStatusOptions.map((status) => (
            <MenuItem key={status} value={status}>
              <Checkbox
                checked={
                  (filterState.bigfix_conformity || []).indexOf(status) > -1
                }
              />
              <ListItemText
                primary={status}
                primaryTypographyProps={{
                  sx: {
                    fontWeight: 500,
                  },
                }}
              />
            </MenuItem>
          ))}
        </Select>
      </FormControl>

      {/* Clear All Filters Button */}
      <Button
        variant="outlined"
        onClick={() => {
          setFilterState({});
        }}
        startIcon={<ClearIcon />}
        size="small"
        sx={{
          backgroundColor: "#F3F4F6",
          borderColor: "#D1D5DB",
          color: "#374151",
          "&:hover": {
            backgroundColor: "#E5E7EB",
            borderColor: "#9CA3AF",
          },
        }}
      >
        Effacer tous les filtres
      </Button>

      {/* Indicateur de filtres actifs */}
      {(filterState.global_search ||
        filterState.os_type ||
        filterState.environments?.length ||
        filterState.fiable !== undefined ||
        filterState.solutions_inventory ||
        filterState.bigfix_conformity?.length) && (
          <Chip
            label="Filtres actifs"
            color="primary"
            size="small"
            variant="outlined"
            sx={{
              fontWeight: 600,
              fontSize: "0.75rem",
            }}
          />
        )}
    </GridToolbarContainer>
  );
}