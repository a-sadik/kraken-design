// src/pages/sub-pages/admin/EntityPage.tsx

import { FC } from "react";

// import files
import EntityDataTable from "@/components/data-tables/EntityDataTable";

const EntityPage: FC = () => {
  return <EntityDataTable />;
};

export default EntityPage;
