// import React, { ReactElement } from "react";
// import { Paper, Stack, IconButton, Breadcrumbs, Typography, Box, alpha, colors } from "@mui/material";
// import { NavigateNext, Home, KeyboardArrowRight } from "@mui/icons-material";
// import { Business, AccountTree, Apps } from "@mui/icons-material"
// import { FiServer } from "react-icons/fi";
// import { LuRocket } from "react-icons/lu";
// import { PiCubeBold } from "react-icons/pi";
// import { TbBuildingBank } from "react-icons/tb";
// import { VscSymbolNamespace } from "react-icons/vsc";
// import { pastelTheme } from "../basics/ThemeButton";
// import { modernTheme } from "./utils/theme";

// interface BreadcrumbNavProps {
//   navigation: any;
//   navigateToBreadcrumb: (index: number) => void;
// }

// const modernTheme = {
//     primary: "#2563EB",
//     secondary: "#7C3AED",
//     accent: "#059669",
//     surface: "#FFCE14",
//     background: "#F1F5F9", // Plus sombre
//     surfaceVariant: "#e04434", // Plus sombre
//     outline: "#CBD5E1", // Plus visible
//     shadow: "rgba(15, 23, 42, 0.12)", // Plus prononcé
//     cardBackground: "#FFFFFF",
//     textPrimary: "#1E293B",
//     textSecondary: "#475569",
//   }

//  const getLevelIcon = (level: string): ReactElement => {
//     const iconMap: Record<string, ReactElement> = {
//       entity: <Business />,
//       pole: <AccountTree />,
//       domain: <TbBuildingBank />,
//       solution: <Apps />,
//       namespace: <VscSymbolNamespace />,
//       deployment: <LuRocket />,
//       server: <FiServer />,
//       pod: <PiCubeBold />,
//     }
//     return iconMap[level] || <Business />
//   }

//   const getLevelColor = (level: string) => {
//     return colors[level as keyof typeof colors] || modernTheme.primary
//   }

// const BreadcrumbNav: React.FC<BreadcrumbNavProps> = ({ navigation, navigateToBreadcrumb }) => {
//   const currentLevelColor = getLevelColor(navigation.currentLevel);

//   return (
//         <Paper
//           elevation={0}
//           sx={{
//             background: `linear-gradient(135deg, ${alpha(currentLevelColor, 0.1)} 0%, ${alpha(currentLevelColor, 0.05)} 100%)`,
//             borderBottom: `2px solid ${alpha(currentLevelColor, 0.3)}`,
//             py: 2,
//             px: 3,
//             boxShadow: `0 2px 8px ${pastelTheme.shadow}`,
//             borderRadius: 0,
//           }}
//         >
//           <Stack direction="row" alignItems="center" spacing={2}>
//             <IconButton
//               onClick={() => navigateToBreadcrumb(-1)}
//               sx={{
//                 backgroundColor: alpha(currentLevelColor, 0.2),
//                 color: currentLevelColor,
//                 "&:hover": {
//                   backgroundColor: alpha(currentLevelColor, 0.3),
//                 },
//               }}
//             >
//               <Home />
//             </IconButton>

//             {navigation.breadcrumb.length > 0 && (
//               <>
//                 <KeyboardArrowRight sx={{ color: alpha(currentLevelColor, 0.8) }} />
//                 <Breadcrumbs
//                   separator={<NavigateNext fontSize="small" sx={{ color: alpha(currentLevelColor, 0.8) }} />}
//                   sx={{ flexGrow: 1 }}
//                 >
//                   {navigation.breadcrumb.map((item, index) => (
//                     <Box
//                       key={index}
//                       onClick={() => navigateToBreadcrumb(index)}
//                       sx={{
//                         display: "flex",
//                         alignItems: "center",
//                         gap: 1,
//                         cursor: "pointer",
//                         padding: "6px 12px",
//                         borderRadius: 3,
//                         transition: "all 0.2s ease-in-out",
//                         "&:hover": {
//                           backgroundColor: alpha(currentLevelColor, 0.15),
//                         },
//                       }}
//                     >
//                       {React.cloneElement(getLevelIcon(item.level), {
//                         sx: { fontSize: 18, color: getLevelColor(item.level) },
//                       })}
//                       <Typography
//                         variant="body2"
//                         sx={{
//                           fontWeight: 700,
//                           color: pastelTheme.textPrimary,
//                           fontSize: "14px",
//                         }}
//                       >
//                         {item.name}
//                       </Typography>
//                     </Box>
//                   ))}
//                 </Breadcrumbs>
//               </>
//             )}
//           </Stack>
//         </Paper>
//       )
// };

// export default BreadcrumbNav;
