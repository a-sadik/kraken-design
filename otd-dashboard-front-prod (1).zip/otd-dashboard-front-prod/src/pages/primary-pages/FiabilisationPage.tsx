// src/pages/SignatureServersPage.tsx

import React from "react";
import { FaChartPie } from "react-icons/fa";
import { HiOutlineServerStack } from "react-icons/hi2";
import { PiSplitHorizontalBold } from "react-icons/pi";

import { useNavigate } from "react-router-dom";

import { Button, Grid2 } from "@mui/material";

const FiabilisationPage: React.FC = () => {
  const navigate = useNavigate();

  const goToPage = (path: string) => {
    navigate(path);
  };

  return (
    <Grid2
      container
      spacing={2}
      sx={{ width: "70%", marginX: "auto", rowGap: "6rem" }}
    >
      <Grid2 size={4}>
        <Button
          className="btn-self-service others"
          color="primary"
          variant="contained"
          size="large"
          startIcon={<FaChartPie />}
          onClick={() => {
            goToPage("/reliability/dashboard");
          }}
        >
          Dashboard
        </Button>
      </Grid2>
      <Grid2 size={4}>
        <Button
          className="btn-self-service others"
          color="primary"
          variant="contained"
          size="large"
          startIcon={<HiOutlineServerStack />}
          onClick={() => {
            goToPage("/reliability/server-compare");
          }}
        >
          Inventaire vs Bigfix
        </Button>
      </Grid2>
      <Grid2 size={4}>
        <Button
          className="btn-self-service others"
          color="primary"
          variant="contained"
          size="large"
          startIcon={<PiSplitHorizontalBold />}
          onClick={() => {
            goToPage("/reliability/isolated");
          }}
        >
          Serveurs isolés
        </Button>
      </Grid2>
    </Grid2>
  );
};

export default FiabilisationPage;
