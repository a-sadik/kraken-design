// src/pages/sub-pages/DomainPage.tsx

import { FC } from "react";

// import Typography from '@mui/material/Typography'
import DomainDataTable from "@/components/data-tables/DomainDataTable";

const DomainPage: FC = () => {
  return <DomainDataTable />;
};

export default DomainPage;
