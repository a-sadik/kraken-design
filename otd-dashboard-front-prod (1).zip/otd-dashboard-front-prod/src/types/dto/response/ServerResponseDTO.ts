import type { Environnement } from "@/enums/Environnement";
import type { OperatingSystemType } from "@/enums/OperatingSystemType";

// Define the detailed structure for a solution object as it comes from the API
export interface SolutionDetailFromAPI {
  service_type: boolean;
  tenant: boolean;
  domains_inventory: boolean;
  solution_id: number;
  psi: string;
  solution_type: string;
  solution_popularity: string;
  domain: string; // Domain inside solution object
  pole: string; // Pole inside solution object
  entity: string;
  list_admins: {
    technical_admins: Array<{ email: string; name: string }>;
    functional_admins: Array<{ email: string; name: string }>;
    tams: Array<{ email: string; name: string }>;
  };
  tam: string;
  tam_full_name: string;
  created_at: string;
  solution_name: string;
  solution_role: string;
  activated: boolean;
  itop_id: string;
  declarted_on_itop: boolean;
  declarted_on_bigfix: boolean;
  created_by: string;
  updated_at: string;
  updated_by: string;
}

export interface ServerResponseDTO {
  bigfix_conformity: any;
  to_decom: boolean;
  entities_inventory: string[];
  poles_inventory: string[];
  domains_inventory: string[];
  solutions_inventory_details: SolutionDetailFromAPI[] | null;
  entities: never[];
  fiable: boolean;
  server_id: number;
  hostname: string;
  ip_addresses: string[];
  server_nature: string[] | null;
  nature_detail: string | null;
  os_type: OperatingSystemType | string | null;
  uname: string | null;
  os_detail: string | null;
  signed: string | null;
  solutions: SolutionDetailFromAPI[] | null; // Now specific type
  solutions_inventory: string[] | null;
  natures_inventory: string | null;
  domains: string[] | null; // Changed to array as per API response
  poles: string[] | null; // Changed to array as per API response
  environments: Environnement[] | string[] | null;
  tenant: string | null;
  service_type: string | null;
  created_at: string;
  updated_at: string;
  created_by: string;
  updated_by: string;
  login?: string | null;
  password?: string | null;
  sudo_password?: string | null;
}
