// components/StatBox.tsx
import React from "react";
import { alpha, Box, Typography } from "@mui/material";
import type { ReactElement } from "react";

interface StatBoxProps {
  icon: ReactElement;
  value: number;
  label: string;
  color: string;
}

const StatBox = ({ icon, value, label, color }: StatBoxProps) => (
  <Box
    sx={{
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      p: 1,
      borderRadius: 2,
      backgroundColor: alpha(color, 0.05),
      border: `1px solid ${alpha(color, 0.2)}`,
    }}
  >
    <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
      {React.cloneElement(icon, { sx: { fontSize: 14, color: color } })}
      <Typography variant="body2" sx={{ fontWeight: 700, fontSize: "12px" }}>
        {value}
      </Typography>
    </Box>
    <Typography
      variant="caption"
      sx={{ fontSize: "10px", textAlign: "center" }}
    >
      {label}
    </Typography>
  </Box>
);

export default StatBox;
