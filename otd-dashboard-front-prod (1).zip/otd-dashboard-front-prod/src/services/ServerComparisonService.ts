/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  patchUpdateSolutionServerApiUrl,
  postRefreshReliabilityApiUrl,
} from "@/config/api.config";
import type { ApiFieldMapping, Comparatif } from "@/types/ReliabilityTypes";
import { ServerComparisonRequestDto } from "@/types/dto/request/ReliabilityRequest";
import { apiService } from "./FetchService";

class ServerComparisonService {
  private apiFieldMapper: ApiFieldMapping = {
    pole: "poles",
    domain: "domains",
    entity: "entities",
    tam: "tams",
    solution_name: "solutions",
    solution_role: "solutions",
    technicals_admins: "technical-admins",
    functionals_admins: "functional-admins",
  };

  async getServers(request: ServerComparisonRequestDto): Promise<Comparatif> {
    try {
      const { conformityType } = request;
      const response = await apiService.get<Comparatif>(conformityType);
      return response;
    } catch (error) {
      console.error("Error fetching servers:", error);
      throw error;
    }
  }

  updateServer = async (payload: {
    ip: string;
    updates: Record<string, any>;
  }) => {
    await fetch(patchUpdateSolutionServerApiUrl(), {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        ip: payload.ip,
        ...payload.updates,
      }),
    });
    const final_update = await fetch(postRefreshReliabilityApiUrl(), {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        ip: payload.ip,
        updates: payload.updates,
      }),
    });
    return final_update.json();
  };

  async getDropdownOptions(fieldName: string): Promise<string[]> {
    try {
      if (!this.apiFieldMapper[fieldName]) {
        throw new Error(`No endpoint mapping found for field: ${fieldName}`);
      }

      const endpoint = this.apiFieldMapper[fieldName];
      const response = await apiService.get<any[]>(endpoint, true);

      // Extract names from the response based on the field type
      return response.map((item: any) => item);
    } catch (error) {
      console.error(`Error fetching options for ${fieldName}:`, error);
      return [];
    }
  }

  async getAllDropdownOptions(): Promise<Record<string, string[]>> {
    try {
      const optionsPromises = Object.keys(this.apiFieldMapper).map(
        async (field) => {
          const options = await this.getDropdownOptions(field);
          return { field, options };
        },
      );

      const results = await Promise.all(optionsPromises);

      return results.reduce(
        (acc, { field, options }) => {
          acc[field] = options;
          return acc;
        },
        {} as Record<string, string[]>,
      );
    } catch (error) {
      console.error("Error fetching all dropdown options:", error);
      return {};
    }
  }
}

export const serverComparisonService = new ServerComparisonService();
