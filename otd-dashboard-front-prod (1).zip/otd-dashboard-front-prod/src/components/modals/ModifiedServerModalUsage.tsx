import type React from "react";
import { useState } from "react";
import { Button, Box } from "@mui/material";
import ModifiedServerModal from "./ModifiedServerModal";
import type { ServerFormData } from "./ModifiedServerModal";

// Exemple d'utilisation du ModifiedServerModal
const ModifiedServerModalUsage: React.FC = () => {
  const [modalOpen, setModalOpen] = useState(false);
  const [modalType, setModalType] = useState<
    "add" | "edit" | "view" | "delete" | "deploy"
  >("add");

  // Données d'exemple pour les tests
  const sampleServerData = {
    hostname: "server-example-01",
    ip_addresses: ["192.168.1.100", "10.0.0.50"],
    os_type: "Linux",
    server_nature: ["Application", "Base de données"],
    nature_detail: "Serveur d'application web avec base de données MySQL",
    solutions: [
      {
        solution_id: 1,
        solution_name: "Apache HTTP Server",
        solution_popularity: "Très populaire",
      },
    ],
    environments: ["Production", "Préproduction"],
    solutions_inventory: ["Solution 1", "Solution 2"],
    natures_inventory: ["Nature 1", "Nature 2"],
  };

  const handleSubmit = (data: ServerFormData) => {
    console.log("Données soumises:", data);
    // Ici vous pouvez traiter les données (API call, etc.)
    setModalOpen(false);
  };

  const openModal = (type: typeof modalType) => {
    setModalType(type);
    setModalOpen(true);
  };

  return (
    <Box sx={{ p: 3, display: "flex", gap: 2, flexWrap: "wrap" }}>
      <Button
        variant="contained"
        onClick={() => openModal("add")}
        sx={{ backgroundColor: "#1976d2" }}
      >
        Ajouter un serveur
      </Button>

      <Button
        variant="contained"
        onClick={() => openModal("edit")}
        sx={{ backgroundColor: "#ed6c02" }}
      >
        Modifier un serveur
      </Button>

      <Button
        variant="contained"
        onClick={() => openModal("view")}
        sx={{ backgroundColor: "#2e7d32" }}
      >
        Voir les détails
      </Button>

      <Button
        variant="contained"
        onClick={() => openModal("delete")}
        sx={{ backgroundColor: "#d32f2f" }}
      >
        Supprimer un serveur
      </Button>

      <Button
        variant="contained"
        onClick={() => openModal("deploy")}
        sx={{ backgroundColor: "#7b1fa2" }}
      >
        Déployer signature
      </Button>

      <ModifiedServerModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        initialData={modalType !== "add" ? sampleServerData : undefined}
        onSubmit={handleSubmit}
        isEditMode={modalType === "edit"}
        isViewMode={modalType === "view"}
        isDeleteMode={modalType === "delete"}
        isDeployMode={modalType === "deploy"}
        modalType={modalType}
        errorMessage={null}
      />
    </Box>
  );
};

export default ModifiedServerModalUsage;
