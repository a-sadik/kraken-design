// src/mappers/SolutionMapper.ts

import { SolutionDetailResponseDTO } from "@/types/dto/response/solution/SolutionDetailResponseDTO";
import SolutionView from "@/types/view/SolutionView";

export const solutionResToView = (
  data: SolutionDetailResponseDTO[],
): SolutionView[] => {
  return data.map((item) => ({
    id: item.solution_id || 0,
    Nom: item.solution_name,
    Popularité: item.solution_popularity,
    Type: item.solution_type,
    PSI: item.psi,
    // "Interne/Externe": item.solution_type,
    Rôle: item.solution_role,
    // "Admin(s) fonctionnel(s)": item.functional_admin ? item.functional_admin : [],
    // "Admin(s) technique(s)": item.technical_admin ? item.technical_admin : [],
    // "TAM": item.tam,
    // "Domaine": item.domain,
  }));
};

export const solutionDataFormToRes = (
  data: SolutionDetailResponseDTO[],
): SolutionView[] => {
  return data.map((item) => ({
    id: item.solution_id || 0,
    Nom: item.solution_name,
    Popularité: item.solution_popularity,
    Type: item.solution_type,
    PSI: item.psi,
    // "Interne/Externe": item.solution_type,
    Rôle: item.solution_role,
    // "Admin(s) fonctionnel(s)": item.functional_admin ? item.functional_admin : [],
    // "Admin(s) technique(s)": item.technical_admin ? item.technical_admin : [],
    // "TAM": item.tam,
    // "Domaine": item.domain,
  }));
};
