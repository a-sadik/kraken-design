import React from "react";
import Box from "@mui/material/Box";

import BackGroundImage from "/logos/awb/awb-log-form.png";

type FormContainerProps = {
  children: React.ReactNode;
};

export const FormContainer: React.FC<FormContainerProps> = ({ children }) => {
  return (
    <Box
      sx={{
        p: 3,
        backgroundImage: `url(${BackGroundImage})`,
        backgroundSize: "110%",
        backgroundRepeat: "no-repeat",
        backgroundPosition: "bottom",
        backgroundColor: "white",
        borderRadius: "15px",
        boxShadow: 2,
        width: "100%",
        maxWidth: "400px",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        height: "auto",
      }}
    >
      {children}
    </Box>
  );
};
