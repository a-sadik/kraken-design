// src/pages/NotFoundPage.tsx

import Typography from "@mui/material/Typography";

export default function NotFoundPage() {
  return (
    <>
      <div>
        <Typography variant="h4">Not Found</Typography>
      </div>
    </>
  );
}
