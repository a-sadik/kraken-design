// src/types/dto/response/DomainNameResponseDTO.ts

export interface DomainNameResponseDTO {
  domain_name_id: number;
  domain_name_value: string;
}
