/* eslint-disable @typescript-eslint/no-explicit-any */
import { Snackbar, Alert } from '@mui/material';

const NotificationSnackbar = ({ snackbar, onClose }: any) => (
  <Snackbar
    open={!!snackbar}
    autoHideDuration={3000}
    onClose={onClose}
    anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
  >
    {snackbar ? (
      <Alert severity={snackbar.severity} onClose={onClose} sx={{ width: '100%' }}>
        {snackbar.message}
      </Alert>
    ) : undefined}
  </Snackbar>
);



export default NotificationSnackbar;