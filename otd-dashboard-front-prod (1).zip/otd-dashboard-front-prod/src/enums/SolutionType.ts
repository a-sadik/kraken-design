// src/types/enums/SolutionType.ts

export enum SolutionType {
  IN_HOUSE = "InHouse",
  PROGICIEL = "Progiciel",
  MIDDLEWARE = "Middleware",
  PROGICIEL_MICROSERVICE = "Progiciel microservice",
}
