// src/pages/primary-pages/auditadmin/sections/PostSection.tsx

import React, { useEffect, useMemo, useState } from "react";
import {
  Box,
  Grid,
  Stack,
  Typography,
  IconButton,
  Collapse,
  TextField,
  Snackbar,
  Alert as MuiAlert,
  Button,
  useMediaQuery,
} from "@mui/material";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";
import SearchIcon from "@mui/icons-material/Search";

import WidgetMainContainer from "@/components/containers/WidgetMainContainer";
import { MaterialReactTable, MRT_ColumnDef } from "material-react-table";

import { AddPostModal } from "@/components/modals/AddPostModal";
import { EditPostModal } from "@/components/modals/EditPostModal";

import { getAllPosts } from "@/services/admin/PostService";
import { PostShortResponseDTO } from "@/types/dto/PostDTO";

const PAGE_SIZE = 5;

const PostSection: React.FC = () => {
  const [posts, setPosts] = useState<PostShortResponseDTO[]>([]);
  const [loading, setLoading] = useState(false);

  const [collapseOpen, setCollapseOpen] = useState(true);
  const [globalFilter, setGlobalFilter] = useState("");
  const [snack, setSnack] = useState({
    open: false,
    msg: "",
    severity: "success" as "success" | "error",
  });

  const [addOpen, setAddOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [selected, setSelected] = useState<PostShortResponseDTO | null>(null);

  const isXs = useMediaQuery("(max-width:480px)");

  const fetchPosts = () => {
    setLoading(true);
    getAllPosts()
      // .then(setPosts)
      .then((data) => {
        // ⇢ On place le plus récent (post_id le plus élevé) en tête
        const sorted = [...data].sort((a, b) => b.post_id - a.post_id);
        setPosts(sorted);
      })
      .catch(() =>
        setSnack({
          open: true,
          msg: "Erreur de chargement",
          severity: "error",
        }),
      )
      .finally(() => setLoading(false));
  };

  // const fetchPosts = () => {
  //   setLoading(true);
  //   getAllPosts()
  //     .then(setPosts)
  //     .catch(() => setSnack({ open: true, msg: 'Erreur de chargement', severity: 'error' }))
  //     .finally(() => setLoading(false));
  // };

  useEffect(fetchPosts, []);

  const columns = useMemo<MRT_ColumnDef<PostShortResponseDTO>[]>(
    () => [
      {
        header: "Nom du poste",
        accessorKey: "post_name",
        // muiTableBodyCellProps: {
        //   sx: {
        //     color: 'green',
        //     textDecoration: 'underline',
        //   }
        // },
        Cell: ({ row }) => (
          <Typography
            sx={{
              // cursor: 'pointer',
              fontWeight: 500,
              color: "primary.main",
              // '&:hover': { textDecoration: 'underline' },
            }}
          >
            {row.original.post_name}
          </Typography>
        ),
      },
      {
        header: "Actions",
        id: "actions",
        enableSorting: false,
        enableColumnFilter: false,
        muiTableHeadCellProps: { sx: { textAlign: "right" } },
        muiTableBodyCellProps: { sx: { textAlign: "right" } },
        Cell: ({ row }) => (
          <Stack direction="row" justifyContent="flex-end" spacing={1}>
            <Button
              variant="contained"
              color="info"
              size="small"
              onClick={() => {
                setSelected(row.original);
                setEditOpen(true);
              }}
            >
              Modifier
            </Button>
          </Stack>
        ),
      },
    ],
    [],
  );

  const data = useMemo(() => {
    if (!globalFilter) return posts;
    return posts.filter((p) =>
      p.post_name.toLowerCase().includes(globalFilter.toLowerCase()),
    );
  }, [posts, globalFilter]);

  useEffect(() => {
    if (globalFilter.trim() && !collapseOpen) {
      setCollapseOpen(true);
    }
  }, [globalFilter]);

  return (
    <Grid container spacing={3} sx={{ mb: 3 }}>
      <Grid item xs={12}>
        <WidgetMainContainer>
          <Stack
            direction="row"
            justifyContent="space-between"
            alignItems="center"
            flexWrap="wrap"
          >
            <Stack direction="row" alignItems="center" spacing={1}>
              <Typography variant="h6" fontWeight="bold">
                Postes
              </Typography>
              <IconButton onClick={() => setAddOpen(true)}>
                <AddCircleOutlineIcon color="primary" />
              </IconButton>
            </Stack>

            <Stack
              direction="row"
              spacing={1}
              alignItems="center"
              flexWrap="wrap"
            >
              {isXs ? (
                <IconButton>
                  <SearchIcon />
                </IconButton>
              ) : (
                <Box sx={{ width: { xs: "120px", sm: "230px" } }}>
                  <TextField
                    size="small"
                    fullWidth
                    placeholder="Rechercher…"
                    value={globalFilter}
                    onChange={(e) => setGlobalFilter(e.target.value)}
                  />
                  {!collapseOpen && globalFilter && (
                    <Typography variant="caption" color="textSecondary">
                      Résultats filtrés — ouvrez la section pour les voir.
                    </Typography>
                  )}
                </Box>
              )}

              <IconButton onClick={() => setCollapseOpen((o) => !o)}>
                {collapseOpen ? <ExpandLessIcon /> : <ExpandMoreIcon />}
              </IconButton>
            </Stack>
          </Stack>

          <Collapse in={collapseOpen}>
            <MaterialReactTable
              columns={columns}
              data={data}
              state={{ isLoading: loading, showProgressBars: loading }}
              enableColumnActions={false}
              enableDensityToggle={false}
              enableHiding={false}
              enableFullScreenToggle={false}
              enableToolbarInternalActions={false}
              enableGlobalFilter={false}
              initialState={{
                pagination: { pageIndex: 0, pageSize: PAGE_SIZE },
              }}
              muiTablePaperProps={{
                elevation: 0,
                sx: { boxShadow: "none", border: "none" },
              }}
              muiTableContainerProps={{
                sx: {
                  border: "none",
                  "& .MuiTableRow-root, & .MuiTableCell-root": {
                    borderBottom: "none",
                  },
                },
              }}
              muiTableHeadProps={{ sx: { display: "none" } }}
              muiTableBodyProps={{ sx: { paddingTop: 0 } }}
            />
          </Collapse>
        </WidgetMainContainer>
      </Grid>

      <AddPostModal
        open={addOpen}
        onClose={() => setAddOpen(false)}
        onSave={() => {
          fetchPosts();
          setAddOpen(false);
          // setSnack({ open: true, msg: 'Post ajouté avec succès', severity: 'success' });
        }}
      />

      {selected && (
        <EditPostModal
          open={editOpen}
          onClose={() => setEditOpen(false)}
          onSave={() => {
            fetchPosts();
            setEditOpen(false);
            // setSnack({ open: true, msg: 'Post modifié avec succès', severity: 'success' });
          }}
          postId={selected.post_id}
          currentName={selected.post_name}
        />
      )}

      <Snackbar
        open={snack.open}
        autoHideDuration={3000}
        onClose={() => setSnack((s) => ({ ...s, open: false }))}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <MuiAlert severity={snack.severity} variant="filled">
          {snack.msg}
        </MuiAlert>
      </Snackbar>
    </Grid>
  );
};

export default PostSection;
