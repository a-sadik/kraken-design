// src/components/data-tables/CustomToolBarHome.tsx

import { FC } from "react";
import {
  GridToolbarContainer,
  GridToolbarColumnsButton,
  GridToolbarFilterButton,
  GridToolbarExport,
  GridToolbarQuickFilter,
  GridToolbarProps,
} from "@mui/x-data-grid";
import { Box, Button } from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import CustomSwitchOption from "../inputs/CustomSwitchOption";

// Interface fusionnée avec toutes les props
interface CustomToolBarHomeProps extends GridToolbarProps {
  // Filtres de production
  existProductionFilter?: boolean;
  isProduction?: boolean;
  setIsProduction?: React.Dispatch<React.SetStateAction<boolean>>;
  isHorsProduction?: boolean;
  setIsHorsProduction?: React.Dispatch<React.SetStateAction<boolean>>;

  // Filtres de pôle
  existPoleFilter?: boolean;
  isPoleOTD?: boolean;
  setIsPoleOTD?: React.Dispatch<React.SetStateAction<boolean>>;

  // Filtres de certification
  existCertTypeFilter?: boolean;
  isInterne?: boolean;
  setIsInterne?: React.Dispatch<React.SetStateAction<boolean>>;
  isExterne?: boolean;
  setIsExterne?: React.Dispatch<React.SetStateAction<boolean>>;
  isInProgress?: boolean;
  setIsInProgress?: React.Dispatch<React.SetStateAction<boolean>>;

  // Nouveaux filtres
  existSansEnvironnementFilter?: boolean;
  isSansEnvironnement?: boolean;
  setIsSansEnvironnement?: React.Dispatch<React.SetStateAction<boolean>>;
  existSansSolutionFilter?: boolean;
  isSansSolution?: boolean;
  setIsSansSolution?: React.Dispatch<React.SetStateAction<boolean>>;

  // Sélection multiple
  selectedNamespaces?: number[];
  setSelectedNamespaces?: React.Dispatch<React.SetStateAction<number[]>>;
  setAssignDialogOpen?: React.Dispatch<React.SetStateAction<boolean>>;
}

const CustomToolBarHome: FC<CustomToolBarHomeProps> = ({
  // Filtres de production
  existProductionFilter = true,
  isProduction,
  setIsProduction,
  isHorsProduction,
  setIsHorsProduction,

  // Filtres de pôle
  existPoleFilter = true,
  isPoleOTD = false,
  setIsPoleOTD,

  // Filtres de certification
  existCertTypeFilter = false,
  isInterne,
  setIsInterne,
  isExterne,
  setIsExterne,
  isInProgress,
  setIsInProgress,

  // Nouveaux filtres
  existSansEnvironnementFilter = false,
  isSansEnvironnement = false,
  setIsSansEnvironnement,
  existSansSolutionFilter = false,
  isSansSolution = false,
  setIsSansSolution,

  // Sélection multiple
  selectedNamespaces = [],
  setSelectedNamespaces,
  setAssignDialogOpen,

  ...gridToolbarProps
}) => {
  const hasSelection = selectedNamespaces.length > 0;

  return (
    <GridToolbarContainer
      sx={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        p: 1,
      }}
      {...gridToolbarProps}
    >
      {/* Section gauche - Actions principales et bouton d'affectation */}
      <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
        <GridToolbarColumnsButton />
        <GridToolbarFilterButton />
        <GridToolbarExport />

        {hasSelection && setAssignDialogOpen && (
          <Button
            startIcon={<EditIcon />}
            onClick={() => setAssignDialogOpen(true)}
            variant="contained"
            size="small"
            sx={{
              backgroundColor: "#FFFBEB",
              color: "#F59E0B",
              "&:hover": { backgroundColor: "#FEF3C7" },
              minWidth: 180,
            }}
          >
            Affecter ({selectedNamespaces.length})
          </Button>
        )}
      </Box>

      {/* Section centre - Filtres */}
      <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
        {/* Filtre Pôle OTD */}
        {existPoleFilter && isPoleOTD !== undefined && setIsPoleOTD && (
          <CustomSwitchOption
            title="Pôle OTD"
            checked={isPoleOTD}
            onChange={() => setIsPoleOTD(!isPoleOTD)}
          />
        )}

        {/* Filtre En cours de signature */}
        {existCertTypeFilter &&
          typeof isInProgress === "boolean" &&
          typeof setIsInProgress === "function" && (
            <CustomSwitchOption
              title="En cours de signature"
              checked={isInProgress}
              onChange={() => setIsInProgress(!isInProgress)}
              color="warning"
            />
          )}

        {/* Filtre Interne */}
        {existCertTypeFilter &&
          typeof isInterne === "boolean" &&
          typeof setIsInterne === "function" &&
          typeof setIsExterne === "function" && (
            <CustomSwitchOption
              title="Interne"
              checked={isInterne}
              onChange={() => {
                setIsInterne(!isInterne);
                if (!isInterne) setIsExterne(false); // Si on active Interne, on désactive Externe
              }}
            />
          )}

        {/* Filtre Externe */}
        {existCertTypeFilter &&
          typeof isExterne === "boolean" &&
          typeof setIsExterne === "function" &&
          typeof setIsInterne === "function" && (
            <CustomSwitchOption
              title="Externe"
              checked={isExterne}
              onChange={() => {
                setIsExterne(!isExterne);
                if (!isExterne) setIsInterne(false); // Si on active Externe, on désactive Interne
              }}
            />
          )}

        {/* Filtre Sans Solution */}
        {existSansSolutionFilter && setIsSansSolution && (
          <CustomSwitchOption
            title="Sans Solution"
            checked={isSansSolution}
            onChange={() => setIsSansSolution(!isSansSolution)}
            color="warning"
          />
        )}

        {/* Filtre Sans Environnement */}
        {existSansEnvironnementFilter && setIsSansEnvironnement && (
          <CustomSwitchOption
            title="Sans Environnement"
            checked={isSansEnvironnement}
            onChange={() => setIsSansEnvironnement(!isSansEnvironnement)}
            color="error"
          />
        )}
      </Box>

      {/* Section droite - Recherche */}
      <Box sx={{ display: "flex", alignItems: "center" }}>
        <GridToolbarQuickFilter sx={{ width: 250 }} />
      </Box>
    </GridToolbarContainer>
  );
};

export default CustomToolBarHome;
