/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useCallback, useEffect, useState } from "react";

import { TbNote } from "react-icons/tb";
import { ContentCopy, HighlightAlt, Visibility } from "@mui/icons-material";

import {
  Box,
  Typography,
  Chip,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Grid,
  IconButton,
  Tabs,
  Tab,
  Alert,
  Divider,
  Collapse,
  Fade,
  CircularProgress,
  Tooltip,
  Skeleton,
  Link,
  Button,
  DialogTitle,
  Dialog,
  DialogActions,
  DialogContent,
  SvgIcon,
} from "@mui/material";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import { alpha } from "@mui/material/styles";
import ReactMarkdown from 'react-markdown';

import {
  Apps,
  Business,
  Person,
  ArrowUpward,
  ArrowDownward,
  Memory as MemoryIcon,
  Speed as CpuIcon,
  Computer as NodeIcon,
  Schedule as TimeIcon,
  RestartAlt,
  Description,
  Speed,
  Memory,
} from "@mui/icons-material";
import {
  MdAdminPanelSettings,
  MdGroups,
  MdOutlineAdminPanelSettings,
  MdOutlineSchema,
} from "react-icons/md";
import { FiServer } from "react-icons/fi";
import { VscSymbolNamespace } from "react-icons/vsc";
import { LuRocket } from "react-icons/lu";
import { FaNetworkWired, FaUserTie } from "react-icons/fa6";
import { TbBuildingBank } from "react-icons/tb";

// Import des thèmes et configurations partagées
import {
  pastelTheme,
  colors,
  darkColors,
  envColors,
  osColors,
} from "@/pages/primary-pages/TopologyPage";
import { getBadgeColorRestart } from "../data-tables/NamespaceDataTable";
import { BiNetworkChart } from "react-icons/bi";
import { theme } from "@/utils/getDynamicColor";
import { DiOpenshift } from "react-icons/di";
import fetchWithAuth from "@/middleware/fetch-auth";
import { hardware_info_openshift_info, hardware_info_power_info } from "@/config/api.config";

interface SolutionDetailViewProps {
  solution: any;
  podsData?: Map<string, any[]>;
  serversData?: Map<string, any[]>;
  environmentTabs?: Map<string, number>;
  setEnvironmentTabs?: React.Dispatch<
    React.SetStateAction<Map<string, number>>
  >;
  selectedPodEnvironments?: Map<string, string>;
  setSelectedPodEnvironments?: React.Dispatch<
    React.SetStateAction<Map<string, string>>
  >;
  solutionViewTab?: Map<string, number>;
  setSolutionViewTab?: React.Dispatch<
    React.SetStateAction<Map<string, number>>
  >;
  showRoleDetails?: boolean;
  setShowRoleDetails?: React.Dispatch<React.SetStateAction<boolean>>;
  loading?: boolean;

  caasData?: Map<string, any>;
}

// interface Document {
//   id: number;
//   solution: string;
//   content: string;
//   created_at: string;
//   updated_at: string;
// }

interface ReleaseNote {
  id: number;
  title: string;
  content: string;
  type: string;
  category: string; // ECAB ou CAB
  emergency: boolean;
  solution: string;
  document_fonctionnel: string | null;
  document_technique: string | null;
  document_security: string | null;
  document_additionnel: string[];
  created_at: string;
  updated_at: string;
  reference_externe: string;
  author: string;
  status: string;
  rejection_reason?: string;
}

interface HardwareGlobalSolutionData {
  cpu_limit_total: string;
  total_ram: any;
  cpu_request_total: string;
  solution_name: string;
  total_cpu_m: string;
  total_request_cpu_m: string;
  total_ram_mi: string;
  total_request_ram_mi: string;
}

const orderedEnvironments = [
  "Production",
  "Préproduction",
  "Recette",
  "Développement",
  "Technique",
  "POC",
  "Intégration",
  "Formation",
  "Sans environnement",
];

// Fonctions utilitaires pour les administrateurs
const getDisplayName = (admin: any): string => {
  if (!admin) return "N/A";
  if (typeof admin === "string") {
    if (admin.trim() === "" || admin === "N/A") return "N/A";
    if (admin.includes("@")) {
      return admin.split("@")[0].trim();
    }
    return admin.trim();
  }
  if (typeof admin === "object") {
    if (admin.email && typeof admin.email === "string") {
      const emailPrefix = admin.email.split("@")[0];
      return admin.name && typeof admin.name === "string"
        ? admin.name.replace(/@.*$/, "")
        : emailPrefix;
    }
    if (admin.name && typeof admin.name === "string") {
      return admin.name.replace(/@.*$/, "");
    }
  }
  return "N/A";
};

const filterValidAdmins = (admins: any[]): any[] => {
  if (!Array.isArray(admins)) return [];
  return admins.filter((admin) => {
    if (typeof admin === "string") {
      return admin.trim() !== "" && admin !== "N/A";
    }
    if (typeof admin === "object" && admin !== null) {
      return (
        (admin.email && admin.email.trim() !== "") ||
        (admin.name && admin.name.trim() !== "")
      );
    }
    return false;
  });
};

// Composant pour les cellules triables
const SortableTableCell = ({
  field,
  label,
  currentSort,
  onSort,
}: {
  field: string;
  label: string;
  currentSort: { field: string; direction: "asc" | "desc" };
  onSort: (field: string) => void;
}) => (
  <TableCell
    sx={{
      color: "black",
      fontWeight: 700,
      fontSize: "0.875rem",
      cursor: "pointer",
      userSelect: "none",
      "&:hover": {
        backgroundColor: alpha(colors.server, 0.1),
      },
    }}
    onClick={() => onSort(field)}
  >
    <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
      {label}
      {currentSort.field === field &&
        (currentSort.direction === "asc" ? (
          <ArrowUpward sx={{ fontSize: 16 }} />
        ) : (
          <ArrowDownward sx={{ fontSize: 16 }} />
        ))}
    </Box>
  </TableCell>
);

const globalCaasCache = new Map<string, any>();
const globalPowerCache = new Map<string, any>();
const globalReleaseNotesCache = new Map<string, ReleaseNote[]>();

export const SolutionDetailView: React.FC<SolutionDetailViewProps> = ({
  solution,
  podsData = new Map(),
  serversData = new Map(),
  environmentTabs = new Map(),
  setEnvironmentTabs = () => { },
  selectedPodEnvironments = new Map(),
  setSelectedPodEnvironments = () => { },
  solutionViewTab = new Map(),
  setSolutionViewTab = () => { },
  showRoleDetails = false,
  setShowRoleDetails = () => { },
  loading = false,
  caasData = new Map(),
}) => {



  const [releaseNotes, setReleaseNotes] = useState<ReleaseNote[]>([]);
  const [releaseNotesLoading, setReleaseNotesLoading] = useState(false);
  const [releaseNotesError, setReleaseNotesError] = useState<string | null>(null);
  const [selectedReleaseNote, setSelectedReleaseNote] = useState<ReleaseNote | null>(null);
  const [showReleaseNoteDetails, setShowReleaseNoteDetails] = useState(false);

  const [caasDataForSolution, setCaasDataForSolution] = useState<any>(null);
  const [loadingCaas, setLoadingCaas] = useState(false);

  const [hardwareGlobalSolutionData, setHardwareGlobalSolutionData] = useState<HardwareGlobalSolutionData | null>(null);
  const [, setLoadingHardwareGlobal] = useState(false);

  // Fonction pour charger les données Hardware ower de la solution
  const fetchSolutionHardwareGlobalData = useCallback(async () => {
    const solutionName = solution.solution_name?.replace(/\*/g, '').trim();

    if (!solutionName) {
      setHardwareGlobalSolutionData(null);
      return;
    }

    // Vérifier le cache GLOBAL
    if (globalPowerCache.has(solutionName)) {
      setHardwareGlobalSolutionData(globalPowerCache.get(solutionName));
      return;
    }

    setLoadingHardwareGlobal(true);
    try {
      const response = await fetchWithAuth(hardware_info_power_info(), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          scope: 'solutions'
        }),
      });

      if (!response.ok) {
        throw new Error(`Erreur HTTP! statut: ${response.status}`);
      }

      const data = await response.json();

      // Trouver les données pour cette solution spécifique
      if (Array.isArray(data)) {
        const solutionData = data.find((item: any) =>
          item.solution_name &&
          item.solution_name.replace(/\*/g, '').trim() === solutionName
        );
        setHardwareGlobalSolutionData(solutionData || null);
        globalPowerCache.set(solutionName, solutionData || null); // Cache GLOBAL
      }
    } catch (error) {
      console.error('Erreur lors du chargement des données hardware globales:', error);
      setHardwareGlobalSolutionData(null);
      globalPowerCache.set(solutionName, null);
    } finally {
      setLoadingHardwareGlobal(false);
    }
  }, [solution.solution_name]);

  // Chargez les données au montage
  // Pour Power
  useEffect(() => {
    fetchSolutionHardwareGlobalData();
  }, [fetchSolutionHardwareGlobalData]);

  const fetchSolutionCaasData = useCallback(async () => {
    const solutionName = solution.solution_name?.replace(/\*/g, '').trim();

    if (!solutionName) {
      setCaasDataForSolution(null);
      return;
    }

    // Vérifier le cache GLOBAL
    if (globalCaasCache.has(solutionName)) {
      setCaasDataForSolution(globalCaasCache.get(solutionName));
      return;
    }

    setLoadingCaas(true);
    try {
      console.log(`📡 Appel API CaaS pour: ${solutionName}`);

      const response = await fetchWithAuth(hardware_info_openshift_info(), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          scope: 'solutions',
          solution_name: solutionName
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      console.log('📦 Réponse CaaS:', data);

      if (Array.isArray(data)) {
        const solutionData = data.find((item: any) =>
          item.solution_name &&
          item.solution_name.replace(/\*/g, '').trim() === solutionName
        );

        const result = solutionData ? {
          total_cpu_m: solutionData.total_cpu_m || "0",
          total_ram_mi: solutionData.total_ram_mi || "0",
          total_request_cpu_m: solutionData.total_request_cpu_m || "0",
          total_request_ram_mi: solutionData.total_request_ram_mi || "0"
        } : null;

        setCaasDataForSolution(result);
        globalCaasCache.set(solutionName, result); // Mettre en cache GLOBAL
      }
    } catch (error) {
      console.error('❌ Erreur lors du chargement des données CaaS:', error);
      setCaasDataForSolution(null);
      globalCaasCache.set(solutionName, null); // Mettre null en cache aussi
    } finally {
      setLoadingCaas(false);
    }
  }, [solution.solution_name]);

  // Pour CaaS
  useEffect(() => {
    fetchSolutionCaasData();
  }, [fetchSolutionCaasData]);

  const [releaseNotesSort, setReleaseNotesSort] = useState<{
    field: string;
    direction: "asc" | "desc";
  }>({
    field: "created_at",
    direction: "desc"
  });

  // Fonction pour obtenir la valeur RAM selon le type de serveur
  const getServerRamValue = (server: any) => {
    if (server.os_type === "AIX") {
      // Pour AIX, la mémoire est en octets, convertir en MiB
      const memory = server.specs?.memory;
      if (memory) {
        // Convertir de octets à MiB (1 MiB = 1024 * 1024 octets)
        return parseInt(memory) / (1024 * 1024) || 0;
      }
    }
    // Pour les autres OS, utiliser le format standard (déjà en MiB)
    return server.specs?.memory?.size_MiB || 0;
  };

  // Fonction pour obtenir la valeur RAM en Go pour l'affichage
  const getServerRamInGB = (server: any) => {
    const ramInMiB = getServerRamValue(server);
    return Math.round(ramInMiB / 1024); // Convertir MiB en GiB
  };

  // Fonction pour obtenir la valeur stockage selon le type de serveur
  const getServerStorageValue = (server: any) => {
    if (server.os_type === "AIX") {
      // Pour AIX, vous pouvez chercher dans d'autres champs
      // ou retourner 0 si non disponible
      return 0;
    }
    // Pour les autres OS, utiliser le format standard (en octets)
    return server.specs?.storage || 0;
  };

  // Fonction pour obtenir la valeur stockage en Go pour l'affichage
  const getServerStorageInGB = (server: any) => {
    const storageInBytes = getServerStorageValue(server);
    // Convertir octets à Go (1 Go = 1024 * 1024 * 1024 octets)
    return Math.round(storageInBytes / (1024 * 1024 * 1024));
  };

  // Fonction de tri simple
  const getSortedReleaseNotes = () => {
    if (!releaseNotesSort) return releaseNotes;

    return [...releaseNotes].sort((a, b) => {
      const { field, direction } = releaseNotesSort;

      // Valeurs à comparer
      let aValue = a[field as keyof ReleaseNote];
      let bValue = b[field as keyof ReleaseNote];

      // Traitement spécial pour les dates
      if (field === 'created_at') {
        aValue = new Date(aValue as string).getTime();
        bValue = new Date(bValue as string).getTime();
      } else {
        // Convertir en string pour la comparaison
        aValue = String(aValue || '').toLowerCase();
        bValue = String(bValue || '').toLowerCase();
      }

      // Comparaison
      if (aValue < bValue) return direction === 'asc' ? -1 : 1;
      if (aValue > bValue) return direction === 'asc' ? 1 : -1;
      return 0;
    });
  };

  // Fonction de gestion du clic sur l'en-tête
  const handleSortClick = (field: string) => {
    setReleaseNotesSort(current => {
      if (!current || current.field !== field) {
        // Nouveau tri par défaut ascendant
        return { field, direction: 'asc' };
      }
      // Inverser le sens si même champ
      return {
        field,
        direction: current.direction === 'asc' ? 'desc' : 'asc'
      };
    });
  };

  const AIX_COLORS = {
    LIGHT: "#fce38a", // jaune pastel plus profond
    DARK: "#a6842e",
    MID: "#caa34b"
  };

  // Composant ULTRA COMPACT pour responsable
  const ResponsableSection = ({
    title,
    count,
    admins,
    icon,
    iconColor
  }: {
    title: string;
    count?: number;
    admins?: any[];
    icon: React.ReactElement;
    iconColor: string;
  }) => {
    if (!count || count === 0) return (
      <Box sx={{
        p: 1,
        backgroundColor: alpha('#999', 0.05),
        borderRadius: 1,
        border: `1px dashed ${alpha('#999', 0.2)}`,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        opacity: 0.5
      }}>
        <Typography variant="caption" sx={{ color: '#999' }}>
          {title}
        </Typography>
        <Typography variant="caption" sx={{ color: '#999', fontSize: '0.7rem' }}>
          0
        </Typography>
      </Box>
    );

    const validAdmins = filterValidAdmins(admins || []);
    const displayAdmins = validAdmins.slice(0, 3); // Prendre seulement les 3 premiers
    const remainingCount = validAdmins.length > 3 ? validAdmins.length - 3 : 0;

    return (
      <Tooltip
        title={
          <Box sx={{ p: 0.5 }}>
            <Typography variant="caption" sx={{ fontWeight: 700, display: 'block', mb: 0.5 }}>
              {title} ({validAdmins.length})
            </Typography>
            {validAdmins.map((admin, idx) => (
              <Typography key={idx} variant="caption" sx={{ display: 'block' }}>
                • {getDisplayName(admin)}
              </Typography>
            ))}
          </Box>
        }
        arrow
        placement="top"
      >
        <Box sx={{
          p: 1,
          backgroundColor: alpha(iconColor, 0.1),
          borderRadius: 1,
          border: `1px solid ${alpha(iconColor, 0.2)}`,
          cursor: 'pointer',
          transition: 'all 0.2s',
          '&:hover': {
            backgroundColor: alpha(iconColor, 0.15),
            transform: 'translateY(-1px)'
          },
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          height: '100%',
          minHeight: 60
        }}>
          {/* En-tête mini */}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mb: 0.5 }}>
            {React.cloneElement(icon, { size: 12, color: iconColor })}
            <Typography variant="caption" sx={{
              fontWeight: 700,
              color: iconColor,
              fontSize: '0.7rem',
              textTransform: 'uppercase'
            }}>
              {title}
            </Typography>
          </Box>

          {/* Noms avec séparateur "|" */}
          <Box sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexWrap: 'wrap',
            gap: 0.25
          }}>
            {displayAdmins.map((admin, index) => (
              <Box key={index} sx={{ display: 'flex', alignItems: 'center' }}>
                <Typography
                  variant="body2"
                  sx={{
                    fontWeight: 600,
                    fontSize: '0.75rem',
                    color: '#333',
                    textAlign: 'center',
                    lineHeight: 1.2,
                  }}
                >
                  {getDisplayName(admin)}
                </Typography>
                {index < displayAdmins.length - 1 && (
                  <Typography
                    variant="caption"
                    sx={{
                      color: alpha(iconColor, 0.5),
                      mx: 0.25,
                      fontWeight: 700
                    }}
                  >
                    |
                  </Typography>
                )}
              </Box>
            ))}

            {/* Placeholder si plus de 3 */}
            {remainingCount > 0 && (
              <>
                <Typography
                  variant="caption"
                  sx={{
                    color: alpha(iconColor, 0.5),
                    mx: 0.25,
                    fontWeight: 700
                  }}
                >
                  |
                </Typography>
                <Typography
                  variant="caption"
                  sx={{
                    fontWeight: 700,
                    color: iconColor,
                    fontSize: '0.65rem',
                  }}
                >
                  +{remainingCount}
                </Typography>
              </>
            )}
          </Box>

          {/* Petit badge de compteur */}
          <Box sx={{
            position: 'absolute',
            top: 4,
            right: 4,
            backgroundColor: iconColor,
            color: 'white',
            borderRadius: '50%',
            width: 16,
            height: 16,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '0.6rem',
            fontWeight: 700
          }}>
            {validAdmins.length}
          </Box>
        </Box>
      </Tooltip>
    );
  };

  const tabKey = `solution-${solution.id}-view`;
  const tabValue = solutionViewTab.get(tabKey) || 0;
  // États pour le tri des serveurs
  const [serverSort, setServerSort] = React.useState<{
    field: string;
    direction: "asc" | "desc";
  }>({
    field: "natures_inventory",
    direction: "asc",
  });

  const InfoSection = ({
    title,
    icon,
    children,
  }: {
    title: string;
    icon: React.ReactElement;
    children: React.ReactNode;
  }) => (
    <Box sx={{ mb: 3 }}>
      <Paper
        elevation={0}
        sx={{
          p: 2,
          background: alpha(colors.solution, 0.1),
          border: `1px solid ${alpha(colors.solution, 0.3)}`,
          borderRadius: 2,
        }}
      >
        <Typography
          variant="subtitle2"
          sx={{
            fontWeight: 700,
            color: darkColors.solution,
            mb: 1,
            display: "flex",
            alignItems: "center",
            gap: 1,
          }}
        >
          {icon} {title}
        </Typography>
        {children}
      </Paper>
    </Box>
  );

  // fct pour obtenir les données CaaS
  const getSolutionCaasData = () => {
    console.log('🔍 getSolutionCaasData - Données locales:', caasDataForSolution);

    // 1. Utiliser les données fraîchement chargées
    if (caasDataForSolution) {
      return caasDataForSolution;
    }

    // 2. Fallback: utiliser les anciennes données si disponibles
    if (solution.caas_resources) {
      return solution.caas_resources;
    }

    // 3. Fallback: utiliser caasData prop
    if (caasData && caasData.size > 0) {
      const solutionName = solution.solution_name;
      const cleanName = solutionName.replace(/\*/g, '').trim();

      for (const [key, value] of caasData.entries()) {
        const cleanKey = key.replace(/\*/g, '').trim();
        if (cleanKey === cleanName) {
          return value;
        }
      }
    }

    return null;
  };

  // Fonction de formatage pour CaaS
  const formatCaasResource = (value: any, type: 'cpu' | 'ram' | 'cpu-request' | 'ram-request') => {
    console.log(`🛠️ Formatage ${type}:`, value, 'type:', typeof value);

    // Gérer le cas où value est "0" string
    if (value === "0" || value === 0) {
      console.log('ℹ️ Valeur est zéro');
      return "0";
    }

    if (value === null || value === undefined || value === "") {
      console.log('❌ Valeur vide');
      return "0";
    }

    // Convertir en string si ce n'est pas déjà le cas
    const stringValue = String(value).trim();

    if (stringValue === "" || stringValue === "0") {
      console.log('❌ Valeur zero ou vide après conversion');
      return "0";
    }

    // Remplacer la virgule par un point pour les nombres français
    const normalized = stringValue.replace(',', '.');
    let numValue = parseFloat(normalized);

    console.log('🔢 Valeur normalisée:', normalized, 'numValue:', numValue);

    if (!Number.isFinite(numValue) || numValue === 0) {
      console.log('❌ Pas un nombre fini ou zéro');
      return "0";
    }

    const fmt = (n: number, decimals = 1) => {
      const s = n.toFixed(decimals);
      return s.endsWith('.0') ? s.slice(0, -2) : s;
    };

    switch (type) {
      case 'cpu':
      case 'cpu-request':
        // CPU est en millicores (m)
        if (numValue >= 1000) {
          const result = `${fmt(numValue / 1000)} cores`;
          console.log('⚡ CPU result:', result);
          return result;
        } else {
          const result = `${fmt(numValue)} millicores`;
          console.log('⚡ CPU result:', result);
          return result;
        }

      case 'ram':
      case 'ram-request':
        // RAM est déjà en Mio (mébioctets) - PAS de conversion octets->Mio
        console.log('💾 RAM en Mio:', numValue, 'Mio');

        if (numValue >= 1024) {
          // Convertir Mio -> Gio (gibioctets)
          const gio = numValue / 1024;
          const result = `${fmt(gio)} Go`;
          console.log('💾 RAM final result:', result);
          return result;
        } else {
          const result = `${fmt(numValue)} Mo`;
          console.log('💾 RAM final result:', result);
          return result;
        }

      default:
        return `${numValue}`;
    }
  };


  const fetchReleaseNotes = useCallback(async () => {
    if (!solution.child_releases) {
      setReleaseNotes([]);
      return;
    }

    const cacheKey = `releasenotes-${solution.id}`;

    // Vérifier le cache GLOBAL
    if (globalReleaseNotesCache.has(cacheKey)) {
      setReleaseNotes(globalReleaseNotesCache.get(cacheKey) || []);
      return;
    }

    setReleaseNotesLoading(true);
    setReleaseNotesError(null);

    try {
      const token = localStorage.getItem("bearerToken") ||
        localStorage.getItem("access_token") ||
        localStorage.getItem("token");

      if (!token) {
        throw new Error("Aucun token d'authentification trouvé");
      }

      const response = await fetch(solution.child_releases, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        if (response.status === 404) {
          setReleaseNotes([]);
          return;
        }
        throw new Error(`Erreur ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      let notes: ReleaseNote[] = [];

      if (Array.isArray(data)) {
        notes = data;
      } else if (data && typeof data === 'object') {
        notes = [data];
      }

      setReleaseNotes(notes);
      globalReleaseNotesCache.set(cacheKey, notes); // Cache GLOBAL

    } catch (err) {
      console.error("Erreur lors du chargement des release notes:", err);
      setReleaseNotes([]);
      globalReleaseNotesCache.set(cacheKey, []); // Cache même les erreurs
    } finally {
      setReleaseNotesLoading(false);
    }
  }, [solution.child_releases, solution.id]);

  // Pour Release Notes
  useEffect(() => {
    if (solution.child_releases) {
      fetchReleaseNotes();
    }
  }, [fetchReleaseNotes, solution.child_releases]);

  const MarkdownRenderer = ({ content }: { content: string }) => {
    return (
      <ReactMarkdown
        components={{
          // Correction : utilisez node et className au lieu de inline
          code({ node, className, children, ...props }) {
            const match = /language-(\w+)/.exec(className || '');
            const hasLanguage = Boolean(match);

            if (hasLanguage) {
              // Pour les blocs de code avec langage spécifié
              return (
                <Box
                  component="pre"
                  sx={{
                    backgroundColor: alpha(theme.primary, 0.05),
                    padding: 2,
                    borderRadius: 2,
                    overflow: 'auto',
                    fontSize: '0.875rem',
                    fontFamily: 'Monaco, Consolas, "Courier New", monospace',
                    border: `1px solid ${alpha(theme.primary, 0.2)}`,
                    mt: 1,
                    mb: 1,
                  }}
                >
                  <code {...props} style={{ display: 'block' }}>
                    {String(children).replace(/\n$/, '')}
                  </code>
                </Box>
              );
            }

            // Pour le code inline
            return (
              <code
                className={className}
                {...props}
                style={{
                  backgroundColor: alpha(theme.primary, 0.1),
                  padding: '2px 6px',
                  borderRadius: 1,
                  fontSize: '0.875rem',
                  fontFamily: 'Monaco, Consolas, "Courier New", monospace',
                }}
              >
                {children}
              </code>
            );
          },
          h1: ({ children }) => (
            <Typography variant="h4" sx={{ mt: 3, mb: 2, fontWeight: 700, color: colors.solution }}>
              {children}
            </Typography>
          ),
          h2: ({ children }) => (
            <Typography variant="h5" sx={{ mt: 2, mb: 1, fontWeight: 700 }}>
              {children}
            </Typography>
          ),
          h3: ({ children }) => (
            <Typography variant="h6" sx={{ mt: 2, mb: 1, fontWeight: 600 }}>
              {children}
            </Typography>
          ),
          p: ({ children }) => (
            <Typography variant="body1" sx={{ mb: 1, lineHeight: 1.6 }}>
              {children}
            </Typography>
          ),
          ul: ({ children }) => (
            <Box component="ul" sx={{ pl: 2, mb: 2 }}>
              {children}
            </Box>
          ),
          ol: ({ children }) => (
            <Box component="ol" sx={{ pl: 2, mb: 2 }}>
              {children}
            </Box>
          ),
          li: ({ children }) => (
            <Typography component="li" variant="body1" sx={{ mb: 0.5 }}>
              {children}
            </Typography>
          ),
          blockquote: ({ children }) => (
            <Box
              sx={{
                borderLeft: `4px solid ${colors.solution}`,
                pl: 2,
                ml: 0,
                my: 2,
                backgroundColor: alpha(colors.solution, 0.05),
                py: 1,
                borderRadius: '0 8px 8px 0',
              }}
            >
              {children}
            </Box>
          ),
          table: ({ children }) => (
            <TableContainer
              component={Paper}
              sx={{
                my: 2,
                backgroundColor: alpha(colors.solution, 0.02),
              }}
            >
              <Table size="small">{children}</Table>
            </TableContainer>
          ),
          th: ({ children }) => (
            <TableCell sx={{ fontWeight: 700, backgroundColor: alpha(colors.solution, 0.1) }}>
              {children}
            </TableCell>
          ),
          td: ({ children }) => (
            <TableCell sx={{ borderBottom: `1px solid ${alpha(colors.solution, 0.1)}` }}>
              {children}
            </TableCell>
          ),
          a: ({ href, children }) => (
            <Link
              href={href}
              target="_blank"
              rel="noopener noreferrer"
              sx={{
                color: colors.solution,
                textDecoration: 'none',
                '&:hover': {
                  textDecoration: 'underline',
                },
              }}
            >
              {children}
            </Link>
          ),
        }}
      >
        {content}
      </ReactMarkdown>
    );
  };

  const renderReleaseNotesSection = () => {
    if (!solution.child_releases) {
      return (
        <Alert severity="info" sx={{ mt: 2 }}>
          Aucune release note disponible pour cette solution
        </Alert>
      );
    }

    if (releaseNotesLoading) {
      return (
        <Box sx={{ display: "flex", justifyContent: "center", py: 3 }}>
          <CircularProgress />
        </Box>
      );
    }

    if (releaseNotesError) {
      return (
        <Alert severity="error" sx={{ mt: 2 }}>
          {releaseNotesError}
        </Alert>
      );
    }

    if (releaseNotes.length === 0) {
      return (
        <Alert severity="info">
          Aucune release note trouvée pour cette solution
        </Alert>
      );
    }

    const formatDate = (dateString: string) => {
      try {
        return new Date(dateString).toLocaleDateString('fr-FR', {
          year: 'numeric',
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        });
      } catch {
        return dateString;
      }
    };

    const getCategoryColor = (category: string) => {
      return category === 'ECAB' ? theme.error : theme.success;
    };

    const getTypeColor = (type: string) => {
      switch (type) {
        case 'Evolution': return '#2e7d32'; // Vert
        case 'Correction': return '#1976d2'; // Bleu
        case 'Test PSI': return '#ed6c02'; // Orange
        case 'Evolution et Correction': return '#9c27b0'; // Violet
        default: return theme.textSecondary;
      }
    };

    // Fonction pour déterminer si une release note est refusée
    const isRefusedStatus = (status: string | null | undefined) => {
      if (!status) return false;
      return status.toLowerCase().includes('refusé') ||
        status.toLowerCase().includes('rejected') ||
        status.toLowerCase().includes('refuse');
    };


    return (
      <Box sx={{ mt: 2 }}>
        {/* En-tête */}
        <Paper
          sx={{
            p: 2,
            mb: 2,
            backgroundColor: alpha(colors.solution, 0.1),
            border: `1px solid ${alpha(colors.solution, 0.3)}`,
            borderRadius: 2,
          }}
        >
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <TbNote size={24} style={{ color: colors.solution }} />
            <Box>
              <Typography variant="h6" sx={{ fontWeight: 700, color: colors.solution }}>
                📋 Release Notes ({releaseNotes.length})
              </Typography>
              <Typography variant="caption" color="text.secondary">
                Historique des déploiements et mises à jour
              </Typography>
            </Box>
          </Box>
        </Paper>


        {/* Tableau des release notes */}
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow sx={{ backgroundColor: alpha(colors.solution, 0.1) }}>
                {/* Actions (non triable) */}
                <TableCell sx={{ fontWeight: 700 }}>Actions</TableCell>

                {/* Titre (triable) */}
                <TableCell
                  sx={{
                    fontWeight: 700,
                    cursor: 'pointer',
                    '&:hover': { backgroundColor: alpha(colors.solution, 0.1) }
                  }}
                  onClick={() => handleSortClick('title')}
                >
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    Titre
                    {releaseNotesSort?.field === 'title' && (
                      releaseNotesSort.direction === 'asc' ?
                        <ArrowUpward sx={{ fontSize: 16 }} /> :
                        <ArrowDownward sx={{ fontSize: 16 }} />
                    )}
                  </Box>
                </TableCell>

                {/* Référence iTop (triable) */}
                <TableCell
                  sx={{
                    fontWeight: 700,
                    cursor: 'pointer',
                    '&:hover': { backgroundColor: alpha(colors.solution, 0.1) }
                  }}
                  onClick={() => handleSortClick('reference_externe')}
                >
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    Référence iTop
                    {releaseNotesSort?.field === 'reference_externe' && (
                      releaseNotesSort.direction === 'asc' ?
                        <ArrowUpward sx={{ fontSize: 16 }} /> :
                        <ArrowDownward sx={{ fontSize: 16 }} />
                    )}
                  </Box>
                </TableCell>

                {/* Type (triable) */}
                <TableCell
                  sx={{
                    fontWeight: 700,
                    cursor: 'pointer',
                    '&:hover': { backgroundColor: alpha(colors.solution, 0.1) }
                  }}
                  onClick={() => handleSortClick('type')}
                >
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    Type
                    {releaseNotesSort?.field === 'type' && (
                      releaseNotesSort.direction === 'asc' ?
                        <ArrowUpward sx={{ fontSize: 16 }} /> :
                        <ArrowDownward sx={{ fontSize: 16 }} />
                    )}
                  </Box>
                </TableCell>

                {/* Catégorie (triable) */}
                <TableCell
                  sx={{
                    fontWeight: 700,
                    cursor: 'pointer',
                    '&:hover': { backgroundColor: alpha(colors.solution, 0.1) }
                  }}
                  onClick={() => handleSortClick('category')}
                >
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    Catégorie
                    {releaseNotesSort?.field === 'category' && (
                      releaseNotesSort.direction === 'asc' ?
                        <ArrowUpward sx={{ fontSize: 16 }} /> :
                        <ArrowDownward sx={{ fontSize: 16 }} />
                    )}
                  </Box>
                </TableCell>

                {/* Auteur (triable) */}
                <TableCell
                  sx={{
                    fontWeight: 700,
                    cursor: 'pointer',
                    '&:hover': { backgroundColor: alpha(colors.solution, 0.1) }
                  }}
                  onClick={() => handleSortClick('author')}
                >
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    Auteur
                    {releaseNotesSort?.field === 'author' && (
                      releaseNotesSort.direction === 'asc' ?
                        <ArrowUpward sx={{ fontSize: 16 }} /> :
                        <ArrowDownward sx={{ fontSize: 16 }} />
                    )}
                  </Box>
                </TableCell>

                {/* Date (triable) */}
                <TableCell
                  sx={{
                    fontWeight: 700,
                    cursor: 'pointer',
                    '&:hover': { backgroundColor: alpha(colors.solution, 0.1) }
                  }}
                  onClick={() => handleSortClick('created_at')}
                >
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    Date
                    {releaseNotesSort?.field === 'created_at' && (
                      releaseNotesSort.direction === 'asc' ?
                        <ArrowUpward sx={{ fontSize: 16 }} /> :
                        <ArrowDownward sx={{ fontSize: 16 }} />
                    )}
                  </Box>
                </TableCell>

                {/* Nouvelle colonne: Statut (triable) */}
                <TableCell
                  sx={{
                    fontWeight: 700,
                    cursor: 'pointer',
                    '&:hover': { backgroundColor: alpha(colors.solution, 0.1) }
                  }}
                  onClick={() => handleSortClick('status')}
                >
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    Statut
                    {releaseNotesSort?.field === 'status' && (
                      releaseNotesSort.direction === 'asc' ?
                        <ArrowUpward sx={{ fontSize: 16 }} /> :
                        <ArrowDownward sx={{ fontSize: 16 }} />
                    )}
                  </Box>
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {getSortedReleaseNotes().map((note) => {
                const isRefused = isRefusedStatus(note.status);
                const statusText = note.status || 'En attente';

                return (
                  <TableRow
                    key={note.id}
                    sx={{
                      backgroundColor: isRefused ? '#ffebee' : 'inherit',
                      '&:hover': {
                        backgroundColor: isRefused ? '#ffcdd2' : alpha(colors.solution, 0.05),
                      },
                      borderLeft: isRefused ? '4px solid #f44336' : 'none',
                    }}
                  >
                    {/* Colonne Actions en premier */}
                    <TableCell>
                      <Tooltip title="Voir les détails">
                        <IconButton
                          size="small"
                          onClick={() => {
                            setSelectedReleaseNote(note);
                            setShowReleaseNoteDetails(true);
                          }}
                          sx={{ color: theme.primary }}
                        >
                          <Visibility />
                        </IconButton>
                      </Tooltip>
                    </TableCell>

                    {/* Colonne Titre */}
                    <TableCell>
                      <Typography variant="body1" sx={{ fontWeight: 500 }}>
                        {note.title}
                      </Typography>
                    </TableCell>

                    {/* Colonne Référence iTop */}
                    <TableCell>
                      {note.reference_externe ? (
                        <Tooltip title="Ouvrir le ticket iTop">
                          <Link
                            href={
                              note.category === 'ECAB'
                                ? `https://itop.attijariwafa.net/pages/UI.php?operation=details&class=RoutineChange&id=${note.reference_externe}`
                                : `https://itop.attijariwafa.net/pages/UI.php?operation=details&class=NormalChange&id=${note.reference_externe}`
                            }
                            target="_blank"
                            rel="noopener noreferrer"
                            sx={{
                              fontWeight: 600,
                              textDecoration: 'none',
                              fontFamily: 'monospace',
                              fontSize: '0.875rem',
                              '&:hover': {
                                textDecoration: 'underline',
                              }
                            }}
                          >
                            {note.reference_externe}
                          </Link>
                        </Tooltip>
                      ) : (
                        <Typography variant="body2" color="text.secondary">
                          -
                        </Typography>
                      )}
                    </TableCell>

                    {/* Colonne Type */}
                    <TableCell>
                      <Chip
                        label={note.type}
                        size="small"
                        sx={{
                          backgroundColor: alpha(getTypeColor(note.type), 0.1),
                          color: getTypeColor(note.type),
                          fontWeight: 600,
                        }}
                      />
                    </TableCell>

                    {/* Colonne Catégorie */}
                    <TableCell>
                      <Chip
                        label={note.category}
                        size="small"
                        sx={{
                          backgroundColor: alpha(getCategoryColor(note.category), 0.1),
                          color: getCategoryColor(note.category),
                          fontWeight: 600,
                        }}
                      />
                    </TableCell>

                    {/* Colonne Auteur */}
                    <TableCell>
                      {note.author ? (
                        <Tooltip title={note.author}>
                          <Chip
                            label={note.author.split('@')[0]}
                            size="small"
                            sx={{
                              backgroundColor: alpha(theme.textSecondary || theme.primary, 0.1),
                              color: theme.textPrimary,
                              fontWeight: 500,
                              maxWidth: 120,
                              textOverflow: 'ellipsis',
                              overflow: 'hidden',
                            }}
                          />
                        </Tooltip>
                      ) : (
                        <Typography variant="body2" color="text.secondary">
                          -
                        </Typography>
                      )}
                    </TableCell>

                    {/* Colonne Date */}
                    <TableCell>
                      <Typography variant="body2">
                        {formatDate(note.created_at)}
                      </Typography>
                    </TableCell>

                    {/* Nouvelle colonne: Statut */}
                    <TableCell>
                      <Chip
                        label={statusText}
                        size="small"
                        sx={{
                          backgroundColor: isRefused
                            ? '#f44336'
                            : statusText.toLowerCase().includes('accepté') || statusText.toLowerCase().includes('accepted')
                              ? '#4caf50'
                              : statusText.toLowerCase().includes('en cours') || statusText.toLowerCase().includes('in progress')
                                ? '#ff9800'
                                : '#e0e0e0',
                          color: isRefused ? 'white' :
                            statusText.toLowerCase().includes('accepté') || statusText.toLowerCase().includes('accepted') ? 'white' :
                              statusText.toLowerCase().includes('en cours') || statusText.toLowerCase().includes('in progress') ? 'white' : '#000',
                          fontWeight: 600,
                          fontSize: '0.75rem',
                        }}
                      />

                      {/* Afficher la raison du refus si disponible */}
                      {isRefused && note.rejection_reason && (
                        <Tooltip title={`Raison: ${note.rejection_reason}`}>
                          <InfoOutlinedIcon
                            sx={{
                              fontSize: 16,
                              color: '#f44336',
                              ml: 1,
                              verticalAlign: 'middle',
                              cursor: 'pointer'
                            }}
                          />
                        </Tooltip>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>

        {/* Modal pour afficher les détails d'une release note */}
        {selectedReleaseNote && (
          <Dialog
            open={showReleaseNoteDetails}
            onClose={() => setShowReleaseNoteDetails(false)}
            maxWidth="md"
            fullWidth
            scroll="paper"
          >
            <DialogTitle>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <SvgIcon sx={{ color: theme.primary, fontSize: 24 }}>
                  <TbNote />
                </SvgIcon>
                <Typography variant="h6">
                  {selectedReleaseNote.title}
                </Typography>

                {/* Afficher le statut dans le modal */}
                {selectedReleaseNote.status && (
                  <Chip
                    label={selectedReleaseNote.status}
                    size="small"
                    sx={{
                      ml: 2,
                      backgroundColor: isRefusedStatus(selectedReleaseNote.status)
                        ? '#f44336'
                        : selectedReleaseNote.status.toLowerCase().includes('accepté') ||
                          selectedReleaseNote.status.toLowerCase().includes('accepted')
                          ? '#4caf50'
                          : '#ff9800',
                      color: 'white',
                      fontWeight: 600,
                    }}
                  />
                )}
              </Box>

              {/* Afficher la raison du refus si disponible */}
              {isRefusedStatus(selectedReleaseNote.status) &&
                selectedReleaseNote.rejection_reason && (
                  <Alert
                    severity="error"
                    sx={{ mt: 2 }}
                    icon={false}
                  >
                    <Typography variant="body2">
                      <strong>Raison du refus :</strong> {selectedReleaseNote.rejection_reason}
                    </Typography>
                  </Alert>
                )}

              <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
                <Chip
                  label={selectedReleaseNote.type}
                  size="small"
                  sx={{
                    backgroundColor: alpha(getTypeColor(selectedReleaseNote.type), 0.2),
                    color: getTypeColor(selectedReleaseNote.type),
                    fontWeight: 600,
                  }}
                />
                <Chip
                  label={selectedReleaseNote.category}
                  size="small"
                  sx={{
                    backgroundColor: alpha(getCategoryColor(selectedReleaseNote.category), 0.1),
                    color: getCategoryColor(selectedReleaseNote.category),
                    fontWeight: 600,
                  }}
                />
                <Chip
                  label={selectedReleaseNote.emergency ? "Emergency: Oui" : "Emergency: Non"}
                  size="small"
                  sx={{
                    backgroundColor: selectedReleaseNote.emergency
                      ? alpha(theme.warning, 0.1)
                      : alpha(theme.success, 0.1),
                    color: selectedReleaseNote.emergency ? theme.warning : theme.success,
                  }}
                />
              </Stack>
            </DialogTitle>
            <DialogContent dividers>
              <Box sx={{ p: 1 }}>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                  Créé le: {formatDate(selectedReleaseNote.created_at)} |
                  Auteur: {selectedReleaseNote.author}
                </Typography>

                {/* Documents joints */}
                {(selectedReleaseNote.document_fonctionnel ||
                  selectedReleaseNote.document_technique ||
                  selectedReleaseNote.document_security ||
                  (Array.isArray(selectedReleaseNote.document_additionnel) &&
                    selectedReleaseNote.document_additionnel.length > 0)) && (
                    <Box sx={{ mb: 3, p: 2, backgroundColor: alpha(theme.primary, 0.05), borderRadius: 1 }}>
                      <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600 }}>
                        📎 Documents joints:
                      </Typography>
                      <Stack direction="row" spacing={1} flexWrap="wrap">
                        {selectedReleaseNote.document_fonctionnel && (
                          <Chip
                            icon={<Description />}
                            label="Document Fonctionnel"
                            size="small"
                            sx={{ backgroundColor: alpha(theme.primary, 0.2) }}
                          />
                        )}
                        {selectedReleaseNote.document_technique && (
                          <Chip
                            icon={<Description />}
                            label="Document Technique"
                            size="small"
                            sx={{ backgroundColor: alpha(theme.success, 0.2) }}
                          />
                        )}
                        {selectedReleaseNote.document_security && (
                          <Chip
                            icon={<Description />}
                            label="Document Sécurité"
                            size="small"
                            sx={{ backgroundColor: alpha(theme.warning, 0.2) }}
                          />
                        )}
                        {Array.isArray(selectedReleaseNote.document_additionnel) &&
                          selectedReleaseNote.document_additionnel.map((_doc, index) => (
                            <Chip
                              key={index}
                              icon={<Description />}
                              label={`Additionnel ${index + 1}`}
                              size="small"
                              sx={{ backgroundColor: alpha(theme.textSecondary, 0.2) }}
                            />
                          ))}
                      </Stack>
                    </Box>
                  )}

                {/* Contenu en Markdown */}
                <Box sx={{
                  border: `1px solid ${theme.border}`,
                  borderRadius: 1,
                  p: 2,
                  backgroundColor: 'white'
                }}>
                  <MarkdownRenderer content={selectedReleaseNote.content} />
                </Box>
              </Box>
            </DialogContent>
            <DialogActions>
              <Button onClick={() => setShowReleaseNoteDetails(false)}>
                Fermer
              </Button>
            </DialogActions>
          </Dialog>
        )}
      </Box>
    );
  };


  // Fonction de tri des serveurs
  // Fonction de tri des serveurs
  const sortServers = (
    servers: any[],
    sortField: string,
    sortDirection: "asc" | "desc",
  ) => {
    return [...servers].sort((a, b) => {
      let aValue: any;
      let bValue: any;

      // Fonction pour extraire la valeur CPU de manière uniforme
      const getCpuValue = (server: any): number => {
        // DEBUG: Afficher la structure complète
        console.log(`DEBUG ${server.hostname} (${server.os_type}):`, {
          os_type: server.os_type,
          specs_cpu: server.specs?.cpu,
          specs_cpu_limit: server.specs?.cpu?.limit,
          specs_cpu_request: server.specs?.cpu?.request,
          specs_cpu_count: server.specs?.cpu?.count,
          specs_cpu_cores: server.specs?.cpu?.cores
        });

        // Cas 1: AIX avec specs.cpu.limit (comme "6")
        if (server?.os_type === "AIX") {
          const aixCpuLimit = server.specs?.cpu?.limit;
          if (aixCpuLimit !== undefined && aixCpuLimit !== null) {
            const num = parseFloat(String(aixCpuLimit));
            if (!isNaN(num)) return num;
          }

          // Fallback pour AIX: specs.cpu direct
          const aixCpuDirect = server.specs?.cpu;
          if (typeof aixCpuDirect === 'number') {
            return aixCpuDirect;
          }
          if (typeof aixCpuDirect === 'string') {
            const num = parseFloat(aixCpuDirect);
            if (!isNaN(num)) return num;
          }
        }

        // Cas 2: Linux/autres avec specs.cpu.count
        const linuxCpu =
          server?.specs?.cpu?.count ||
          server?.specs?.cpu?.cores ||
          server?.specs?.cpu; // Format direct

        if (linuxCpu !== undefined && linuxCpu !== null) {
          const num = parseFloat(String(linuxCpu));
          if (!isNaN(num)) return num;
        }

        return 0;
      };

      // Fonction pour extraire la valeur RAM en MiB
      const getRamValue = (server: any): number => {
        if (server?.os_type === "AIX") {
          // Pour AIX, la mémoire peut être en octets ou en Mo
          const memory = server.specs?.memory;
          if (memory) {
            const num = parseInt(String(memory), 10);
            if (!isNaN(num)) {
              // Si c'est un grand nombre (octets), convertir en MiB
              if (num > 1000000) { // Supérieur à 1 Mo
                return num / (1024 * 1024); // Octets -> MiB
              }
              // Sinon, on suppose que c'est déjà en MiB
              return num;
            }
          }
          return 0;
        }
        // Pour les autres OS
        return server?.specs?.memory?.size_MiB ||
          server?.specs?.memory ||
          0;
      };

      // Fonction pour extraire la valeur stockage en octets
      const getStorageValue = (server: any): number => {
        if (server?.os_type === "AIX") {
          // Chercher dans différents champs pour AIX
          const storagePaths = [
            server?.specs?.storage,
            server?.specs?.disk_space,
            server?.storage,
          ];

          for (const path of storagePaths) {
            if (path) {
              const num = parseInt(String(path), 10);
              if (!isNaN(num)) return num;
            }
          }
          return 0;
        }
        // Pour les autres OS
        return server?.specs?.storage || 0;
      };

      // Déterminer les valeurs selon le champ de tri
      switch (sortField) {
        case "cpu":
        case "specs.cpu.count":
          aValue = getCpuValue(a);
          bValue = getCpuValue(b);
          break;

        case "ram":
        case "specs.memory.size_MiB":
          aValue = getRamValue(a);
          bValue = getRamValue(b);
          break;

        case "storage":
        case "specs.storage":
          aValue = getStorageValue(a);
          bValue = getStorageValue(b);
          break;

        case "natures_inventory":
          aValue = Array.isArray(a.natures_inventory)
            ? a.natures_inventory.join(" / ")
            : a.natures_inventory || "";
          bValue = Array.isArray(b.natures_inventory)
            ? b.natures_inventory.join(" / ")
            : b.natures_inventory || "";
          break;

        case "ip_addresses":
          aValue = Array.isArray(a.ip_addresses)
            ? a.ip_addresses.join(", ")
            : a.ip_addresses || "";
          bValue = Array.isArray(b.ip_addresses)
            ? b.ip_addresses.join(", ")
            : b.ip_addresses || "";
          break;

        default:
          // Gestion des champs imbriqués
          if (sortField.includes(".")) {
            const parts = sortField.split(".");
            let currentA: any = a;
            let currentB: any = b;

            for (const part of parts) {
              currentA = currentA ? currentA[part] : undefined;
              currentB = currentB ? currentB[part] : undefined;
            }
            aValue = currentA;
            bValue = currentB;
          } else {
            aValue = a[sortField];
            bValue = b[sortField];
          }
      }

      // Debug: Afficher les valeurs pour le tri
      if (sortField === "cpu" && aValue !== bValue) {
        console.log(`Tri CPU - ${a.hostname}: ${aValue} vs ${b.hostname}: ${bValue}`);
        console.log('Structure a.specs.cpu:', a.specs?.cpu);
        console.log('Structure b.specs.cpu:', b.specs?.cpu);
      }

      // Conversion en nombre pour les champs de ressources
      const isResourceField =
        sortField.includes("cpu") ||
        sortField.includes("ram") ||
        sortField.includes("memory") ||
        sortField.includes("storage");

      if (isResourceField) {
        aValue = Number(aValue) || 0;
        bValue = Number(bValue) || 0;
      } else {
        // Pour les champs textuels
        aValue = String(aValue ?? "").toLowerCase();
        bValue = String(bValue ?? "").toLowerCase();
      }

      // Comparaison
      let comparison = 0;
      if (aValue < bValue) comparison = -1;
      if (aValue > bValue) comparison = 1;

      // En cas d'égalité, trier par hostname
      if (comparison === 0) {
        const aHostname = a.hostname?.toLowerCase() || "";
        const bHostname = b.hostname?.toLowerCase() || "";
        if (aHostname < bHostname) comparison = -1;
        if (aHostname > bHostname) comparison = 1;
      }

      return sortDirection === "asc" ? comparison : -comparison;
    });
  };

  const handleServerSort = (field: string) => {
    setServerSort((prev) => {
      // Si on clique sur la même colonne, on inverse le sens
      if (prev.field === field) {
        return {
          field,
          direction: prev.direction === "asc" ? "desc" : "asc",
        };
      }
      // Si on clique sur une nouvelle colonne, on trie par ordre ascendant
      return {
        field,
        direction: "asc",
      };
    });
  };

  const calculateTotalCPU = (): number => {
    let totalCPU = 0;

    if (solution.child_servers && Array.isArray(solution.child_servers)) {
      solution.child_servers.forEach((serverEnv: any) => {
        if (typeof serverEnv === 'object' && serverEnv !== null) {
          const env = Object.keys(serverEnv)[0];
          const serverKey = `solution-${solution.id}-servers-${env}`;
          const servers = serversData.get(serverKey) || [];
          servers.forEach((server: { specs: { cpu: { count: number; }; }; }) => {
            if (server.specs?.cpu?.count) {
              totalCPU += server.specs.cpu.count;
            }
          });
        }
      });
    } else if (solution.serversByEnv) {
      Object.keys(solution.serversByEnv).forEach(env => {
        const serverKey = `solution-${solution.id}-servers-${env}`;
        const servers = serversData.get(serverKey) || [];
        servers.forEach((server: { specs: { cpu: { count: number; }; }; }) => {
          if (server.specs?.cpu?.count) {
            totalCPU += server.specs.cpu.count;
          }
        });
      });
    }

    return totalCPU;
  };

  const calculateTotalRAM = (): number => {
    let totalRAMInGB = 0;

    if (solution.child_servers && Array.isArray(solution.child_servers)) {
      solution.child_servers.forEach((serverEnv: any) => {
        if (typeof serverEnv === 'object' && serverEnv !== null) {
          const env = Object.keys(serverEnv)[0];
          const serverKey = `solution-${solution.id}-servers-${env}`;
          const servers = serversData.get(serverKey) || [];
          servers.forEach((server: any) => {
            totalRAMInGB += getServerRamInGB(server);
          });
        }
      });
    } else if (solution.serversByEnv) {
      Object.keys(solution.serversByEnv).forEach(env => {
        const serverKey = `solution-${solution.id}-servers-${env}`;
        const servers = serversData.get(serverKey) || [];
        servers.forEach((server: any) => {
          totalRAMInGB += getServerRamInGB(server);
        });
      });
    }

    return totalRAMInGB; // En Go
  };

  const calculateTotalStorage = (): number => {
    let totalStorage = 0;

    if (solution.child_servers && Array.isArray(solution.child_servers)) {
      solution.child_servers.forEach((serverEnv: any) => {
        if (typeof serverEnv === 'object' && serverEnv !== null) {
          const env = Object.keys(serverEnv)[0];
          const serverKey = `solution-${solution.id}-servers-${env}`;
          const servers = serversData.get(serverKey) || [];
          servers.forEach((server: any) => {
            totalStorage += getServerStorageInGB(server);
          });
        }
      });
    } else if (solution.serversByEnv) {
      Object.keys(solution.serversByEnv).forEach(env => {
        const serverKey = `solution-${solution.id}-servers-${env}`;
        const servers = serversData.get(serverKey) || [];
        servers.forEach((server: any) => {
          totalStorage += getServerStorageInGB(server);
        });
      });
    }

    return totalStorage; // Déjà en Go
  };

  // Organisation améliorée des informations (SANS FinOps)
  const renderOrganizationInfo = () => {
    return (
      <InfoSection title="" icon={<></>}>
        <Grid container spacing={2}>
          <Grid item xs={12} md={12}>
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                height: "100%",
              }}
            >
              <Typography
                variant="subtitle1"
                sx={{
                  fontWeight: 700,
                  mb: 1,
                  display: "flex",
                  alignItems: "center",
                  gap: 1,
                  visibility: "hidden",
                }}
              >
                {/* Titre vide pour créer un espace */}
              </Typography>

              <Grid container spacing={2}>
                <Grid item xs={12} md={12}>
                  <Box
                    sx={{
                      display: "flex",
                      flexDirection: "column",
                      height: "100%",
                    }}
                  >

                    <Grid container spacing={2}>
                      {solution.person && (
                        <Grid item xs={12} md={12}>
                          <Box
                            sx={{
                              display: "flex",
                              alignItems: "center",
                              gap: 1,
                            }}
                          >
                            <Person fontSize="small" />
                            <Typography variant="body2">
                              <strong>TAM:</strong>{" "}
                              {solution.person.split("@")[0]}
                            </Typography>
                          </Box>
                        </Grid>
                      )}

                      {/* SECTION OPTIMISÉE : Toutes les ressources sur une même ligne */}
                      <Grid item xs={12} md={12}>
                        <Box sx={{ mt: 2 }}>
                          <Typography
                            variant="subtitle2"
                            sx={{
                              fontWeight: 700,
                              mb: 1.5,
                              display: "flex",
                              alignItems: "center",
                              gap: 1,
                              color: "black",
                              fontSize: "1rem",
                            }}
                          >
                            <FiServer /> Ressources Infra
                          </Typography>

                          <Grid container spacing={2}>
                            {/* BOX 1: Hardware x86 */}
                            <Grid item xs={12} md={4}>
                              <Box
                                sx={{
                                  p: 1.5,
                                  backgroundColor: alpha(colors.server, 0.05),
                                  borderRadius: 2,
                                  border: `1px solid ${alpha(colors.server, 0.2)}`,
                                  height: "100%",
                                  minHeight: 120,
                                }}
                              >
                                <Typography
                                  variant="caption"
                                  sx={{
                                    fontWeight: 700,
                                    mb: 1,
                                    display: "flex",
                                    alignItems: "center",
                                    gap: 0.5,
                                    color: colors.server,
                                    fontSize: "0.8rem",
                                  }}
                                >
                                  <FiServer size={14} /> Hardware x86
                                </Typography>

                                <Stack spacing={1}>
                                  {/* CPU */}
                                  <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                                    <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                                      <CpuIcon fontSize="small" sx={{ color: "#5c6bc0", fontSize: "0.9rem" }} />
                                      <Typography variant="caption" sx={{ fontWeight: 600, fontSize: "0.75rem" }}>
                                        CPU:
                                      </Typography>
                                    </Box>
                                    <Typography variant="body2" sx={{ fontWeight: 700, fontSize: "0.85rem" }}>
                                      {calculateTotalCPU()} cores
                                    </Typography>
                                  </Box>

                                  {/* RAM */}
                                  <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                                    <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                                      <MemoryIcon fontSize="small" sx={{ color: "#26a69a", fontSize: "0.9rem" }} />
                                      <Typography variant="caption" sx={{ fontWeight: 600, fontSize: "0.75rem" }}>
                                        RAM:
                                      </Typography>
                                    </Box>
                                    <Typography variant="body2" sx={{ fontWeight: 700, fontSize: "0.85rem" }}>
                                      {calculateTotalRAM()} Go
                                    </Typography>
                                  </Box>

                                  {/* Stockage */}
                                  <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                                    <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                                      <FiServer size={14} color="#616161" />
                                      <Typography variant="caption" sx={{ fontWeight: 600, fontSize: "0.75rem" }}>
                                        Stockage:
                                      </Typography>
                                    </Box>
                                    <Typography variant="body2" sx={{ fontWeight: 700, fontSize: "0.85rem" }}>
                                      {calculateTotalStorage()} Go
                                    </Typography>
                                  </Box>
                                </Stack>
                              </Box>
                            </Grid>

                            {/* BOX 2: Hardware Power AIX */}
                            {hardwareGlobalSolutionData && (
                              <Grid item xs={12} md={4}>
                                <Box
                                  sx={{
                                    p: 1.5,
                                    backgroundColor: alpha(AIX_COLORS.LIGHT, 0.1),
                                    borderRadius: 2,
                                    border: `1px solid ${alpha(AIX_COLORS.MID, 0.2)}`,
                                    height: "100%",
                                    minHeight: 120,
                                  }}
                                >
                                  <Typography
                                    variant="caption"
                                    sx={{
                                      fontWeight: 700,
                                      mb: 1,
                                      display: "flex",
                                      alignItems: "center",
                                      gap: 0.5,
                                      color: AIX_COLORS.DARK,
                                      fontSize: "0.8rem",
                                    }}
                                  >
                                    <FiServer size={14} /> Power AIX
                                  </Typography>

                                  <Stack spacing={1}>
                                    {/* CPU AIX */}
                                    <Box>
                                      <Box sx={{ display: "flex", alignItems: "center", gap: 0.5, mb: 0.5 }}>
                                        <Speed fontSize="small" sx={{ color: AIX_COLORS.DARK, fontSize: "0.9rem" }} />
                                        <Typography variant="caption" sx={{ fontWeight: 600, fontSize: "0.75rem" }}>
                                          CPU:
                                        </Typography>
                                      </Box>
                                      <Grid container spacing={0.5}>
                                        <Grid item xs={6}>
                                          <Box sx={{ textAlign: "center" }}>
                                            <Typography variant="caption" sx={{ fontWeight: 600, fontSize: "0.7rem", display: "block" }}>
                                              Requests
                                            </Typography>
                                            <Typography variant="body2" sx={{ fontWeight: 700, fontSize: "0.8rem" }}>
                                              {hardwareGlobalSolutionData.cpu_request_total || "0"}
                                            </Typography>
                                          </Box>
                                        </Grid>
                                        <Grid item xs={6}>
                                          <Box sx={{ textAlign: "center" }}>
                                            <Typography variant="caption" sx={{ fontWeight: 600, fontSize: "0.7rem", display: "block" }}>
                                              Limits
                                            </Typography>
                                            <Typography variant="body2" sx={{ fontWeight: 700, fontSize: "0.8rem" }}>
                                              {hardwareGlobalSolutionData.cpu_limit_total || "0"}
                                            </Typography>
                                          </Box>
                                        </Grid>
                                      </Grid>
                                    </Box>


                                    {/* RAM AIX */}
                                    <Box>
                                      <Box sx={{ display: "flex", alignItems: "center", gap: 0.5, mb: 0.5 }}>
                                        <Memory fontSize="small" sx={{ color: AIX_COLORS.DARK, fontSize: "0.9rem" }} />
                                        <Typography variant="caption" sx={{ fontWeight: 600, fontSize: "0.75rem" }}>
                                          RAM:
                                        </Typography>
                                      </Box>
                                      <Typography variant="body2" sx={{ fontWeight: 700, fontSize: "0.8rem", textAlign: "center" }}>
                                        {(() => {
                                          const totalRam = hardwareGlobalSolutionData.total_ram;
                                          if (!totalRam || totalRam === "0") return "0";
                                          const octets = parseInt(totalRam);
                                          if (isNaN(octets)) return "N/A";
                                          if (octets >= 1073741824) {
                                            const gb = octets / 1073741824;
                                            return `${gb.toFixed(1)} Go`;
                                          }
                                          if (octets >= 1048576) {
                                            const mb = octets / 1048576;
                                            return `${mb.toFixed(1)} Mo`;
                                          }
                                          return `${octets} octets`;
                                        })()}
                                      </Typography>
                                    </Box>
                                  </Stack>
                                </Box>
                              </Grid>
                            )}

                            {/* BOX 3: CaaS OpenShift */}
                            {(() => {
                              const solutionCaasData = getSolutionCaasData();
                              const solutionPods = podsData.get(`solution-${solution.id}-pods`) || [];
                              const hasNamespaces = solutionPods.some(
                                (pod: any) => pod.namespace_name && pod.namespace_name.trim() !== ""
                              );

                              if (!hasNamespaces) return null;

                              return (
                                <Grid item xs={12} md={4}>
                                  <Box
                                    sx={{
                                      p: 1.5,
                                      backgroundColor: alpha("#e60000", 0.05),
                                      borderRadius: 2,
                                      border: `1px solid ${alpha("#e60000", 0.2)}`,
                                      height: "100%",
                                      minHeight: 120,
                                    }}
                                  >
                                    <Typography
                                      variant="caption"
                                      sx={{
                                        fontWeight: 700,
                                        mb: 1,
                                        display: "flex",
                                        alignItems: "center",
                                        gap: 0.5,
                                        color: "#e60000",
                                        fontSize: "0.8rem",
                                      }}
                                    >
                                      <DiOpenshift style={{ fontSize: "14px" }} /> CaaS OpenShift
                                    </Typography>

                                    {loadingCaas ? (
                                      <Box sx={{ display: "flex", justifyContent: "center", py: 1 }}>
                                        <CircularProgress size={16} />
                                      </Box>
                                    ) : !solutionCaasData ? (
                                      <Typography variant="caption" sx={{ fontSize: "0.75rem", color: "#666" }}>
                                        Données non disponibles
                                      </Typography>
                                    ) : (
                                      <Stack spacing={1}>
                                        {/* CPU CaaS */}
                                        <Box>
                                          <Box sx={{ display: "flex", alignItems: "center", gap: 0.5, mb: 0.5 }}>
                                            <Speed fontSize="small" sx={{ color: "#e60000", fontSize: "0.9rem" }} />
                                            <Typography variant="caption" sx={{ fontWeight: 600, fontSize: "0.75rem" }}>
                                              CPU:
                                            </Typography>
                                          </Box>
                                          <Grid container spacing={0.5}>
                                            <Grid item xs={6}>
                                              <Box sx={{ textAlign: "center" }}>
                                                <Typography variant="caption" sx={{ fontWeight: 600, fontSize: "0.7rem", display: "block" }}>
                                                  Requests
                                                </Typography>
                                                <Typography variant="body2" sx={{ fontWeight: 700, fontSize: "0.8rem", color: "#ff8c00" }}>
                                                  {formatCaasResource(solutionCaasData.total_request_cpu_m || "0", "cpu-request")}
                                                </Typography>
                                              </Box>
                                            </Grid>
                                            <Grid item xs={6}>
                                              <Box sx={{ textAlign: "center" }}>
                                                <Typography variant="caption" sx={{ fontWeight: 600, fontSize: "0.7rem", display: "block" }}>
                                                  Limits
                                                </Typography>
                                                <Typography variant="body2" sx={{ fontWeight: 700, fontSize: "0.8rem", color: "#e60000" }}>
                                                  {formatCaasResource(solutionCaasData.total_cpu_m || "0", "cpu")}
                                                </Typography>
                                              </Box>
                                            </Grid>
                                          </Grid>
                                        </Box>

                                        {/* RAM CaaS */}
                                        <Box>
                                          <Box sx={{ display: "flex", alignItems: "center", gap: 0.5, mb: 0.5 }}>
                                            <Memory fontSize="small" sx={{ color: "#e60000", fontSize: "0.9rem" }} />
                                            <Typography variant="caption" sx={{ fontWeight: 600, fontSize: "0.75rem" }}>
                                              RAM:
                                            </Typography>
                                          </Box>
                                          <Grid container spacing={0.5}>
                                            <Grid item xs={6}>
                                              <Box sx={{ textAlign: "center" }}>
                                                <Typography variant="caption" sx={{ fontWeight: 600, fontSize: "0.7rem", display: "block" }}>
                                                  Requests
                                                </Typography>
                                                <Typography variant="body2" sx={{ fontWeight: 700, fontSize: "0.8rem", color: "#ff8c00" }}>
                                                  {formatCaasResource(solutionCaasData.total_request_ram_mi || "0", "ram-request")}
                                                </Typography>
                                              </Box>
                                            </Grid>
                                            <Grid item xs={6}>
                                              <Box sx={{ textAlign: "center" }}>
                                                <Typography variant="caption" sx={{ fontWeight: 600, fontSize: "0.7rem", display: "block" }}>
                                                  Limits
                                                </Typography>
                                                <Typography variant="body2" sx={{ fontWeight: 700, fontSize: "0.8rem", color: "#e60000" }}>
                                                  {formatCaasResource(solutionCaasData.total_ram_mi || "0", "ram")}
                                                </Typography>
                                              </Box>
                                            </Grid>
                                          </Grid>
                                        </Box>
                                      </Stack>
                                    )}
                                  </Box>
                                </Grid>
                              );
                            })()}
                          </Grid>
                        </Box>
                      </Grid>
                    </Grid>
                  </Box>
                </Grid>
              </Grid>
            </Box>
          </Grid>
        </Grid>
      </InfoSection>
    );
  };

  // Composant pour les onglets des pods (STYLE COMPLET)
  const renderNamespaceTabs = () => {
    const solutionPods = podsData.get(`solution-${solution.id}-pods`) || [];

    if (solutionPods.length === 0) {
      return <Alert severity="info">Aucun pod trouvé</Alert>;
    }

    // Calculer le nombre de pods par environnement
    const podsByEnv: { [key: string]: number } = {};
    solutionPods.forEach((pod: any) => {
      const env = pod.environement || "Sans environnement";
      podsByEnv[env] = (podsByEnv[env] || 0) + 1;
    });

    // Récupérer et trier les environnements selon l'ordre spécifié
    const environmentsWithPods = Array.from(
      new Set(solutionPods.map((pod: any) => pod.environement)),
    )
      .filter((env) => {
        const podsInEnv = solutionPods.filter(
          (pod: any) => pod.environement === env,
        );
        return (
          podsInEnv.length > 0 &&
          env !== null &&
          env !== undefined &&
          env !== "null"
        );
      })
      .sort((a, b) => {
        const indexA = orderedEnvironments.indexOf(a as string);
        const indexB = orderedEnvironments.indexOf(b as string);
        return (
          (indexA === -1 ? orderedEnvironments.length : indexA) -
          (indexB === -1 ? orderedEnvironments.length : indexB)
        );
      });

    const solutionKey = `solution-${solution.id}`;
    const selectedEnvironment =
      selectedPodEnvironments.get(solutionKey) || "all";

    const filteredPods =
      selectedEnvironment === "all"
        ? solutionPods
        : solutionPods.filter(
          (pod: any) => pod.environement === selectedEnvironment,
        );

    const handleEnvironmentChange = (newValue: string) => {
      setSelectedPodEnvironments((prev: Map<string, string>) => {
        const newMap = new Map(prev);
        newMap.set(solutionKey, newValue);
        return newMap;
      });
    };

    return (
      <Box sx={{ mt: 2 }}>
        <Box sx={{ mb: 2 }}>
          <Tabs
            value={selectedEnvironment}
            onChange={(_, newValue) =>
              handleEnvironmentChange(newValue as string)
            }
            variant="scrollable"
            scrollButtons="auto"
            sx={{
              "& .MuiTab-root": {
                fontSize: "13px",
                fontWeight: 700,
                textTransform: "none",
                borderRadius: "8px 8px 0 0",
                "&.Mui-selected": {
                  backgroundColor: (_theme) =>
                    envColors[
                    selectedEnvironment === "all"
                      ? "Production"
                      : (selectedEnvironment as keyof typeof envColors)
                    ],
                  color:
                    selectedEnvironment === "Préproduction" ? "#333" : "white",
                },
              },
              "& .MuiTabs-indicator": {
                backgroundColor: (_theme) =>
                  envColors[
                  selectedEnvironment === "all"
                    ? "Production"
                    : (selectedEnvironment as keyof typeof envColors)
                  ],
              },
            }}
          >
            <Tab label={`Tous (${solutionPods.length})`} value="all" />
            {environmentsWithPods.map((env, index) => (
              <Tab
                key={index}
                label={`${env} (${podsByEnv[env as string] || 0})`}
                value={env as string}
              />
            ))}
          </Tabs>
        </Box>

        <TableContainer
          component={Paper}
          sx={{ backgroundColor: alpha(colors.namespace, 0.05) }}
        >
          <Table>
            <TableHead>
              <TableRow sx={{ backgroundColor: alpha(colors.namespace, 0.1) }}>
                <TableCell sx={{ color: "black", fontWeight: 700 }}>
                  Nom du Pod
                </TableCell>
                <TableCell sx={{ color: "black", fontWeight: 700 }}>
                  Environnement
                </TableCell>
                <TableCell sx={{ color: "black", fontWeight: 700 }}>
                  Status
                </TableCell>
                <TableCell sx={{ color: "black", fontWeight: 700 }}>
                  Namespace
                </TableCell>
                <TableCell sx={{ color: "black", fontWeight: 700 }}>
                  Déploiement
                </TableCell>
                <TableCell sx={{ color: "black", fontWeight: 700 }}>
                  CPU
                </TableCell>
                <TableCell sx={{ color: "black", fontWeight: 700 }}>
                  RAM
                </TableCell>
                <TableCell sx={{ color: "black", fontWeight: 700 }}>
                  Redémarrages
                </TableCell>
                <TableCell sx={{ color: "black", fontWeight: 700 }}>
                  Créé le
                </TableCell>
                <TableCell sx={{ color: "black", fontWeight: 700 }}>
                  IP Host
                </TableCell>
              </TableRow>
            </TableHead>


            <TableBody>
              {filteredPods.map((pod: any) => (
                <TableRow
                  key={pod.id}
                  sx={{
                    backgroundColor: "white",
                    "&:hover": {
                      backgroundColor: alpha(colors.namespace, 0.1),
                    },
                  }}
                >
                  <TableCell sx={{ color: "black" }}>
                    <Box
                      sx={{ display: "flex", alignItems: "center", gap: 0.5 }}
                    >
                      <NodeIcon color="primary" fontSize="small" />
                      {pod.pod_name}
                    </Box>
                  </TableCell>
                  <TableCell>
                    <Box
                      sx={{ display: "flex", alignItems: "center", gap: 0.5 }}
                    >
                      <Chip
                        label={pod.environement || "N/A"}
                        size="small"
                        sx={{
                          backgroundColor:
                            envColors[
                            pod.environement as keyof typeof envColors
                            ] || "#e0f7fa",
                          color:
                            pod.environement === "Préproduction"
                              ? "#333"
                              : "white",
                          border: "1px solid #b2ebf2",
                          fontSize: "0.75rem",
                          borderRadius: "8px",
                          height: "24px",
                          lineHeight: "24px",
                          fontWeight: 600,
                        }}
                      />
                    </Box>
                  </TableCell>
                  <TableCell sx={{ color: colors.namespace }}>
                    <Box
                      sx={{ display: "flex", alignItems: "center", gap: 0.5 }}
                    >
                      <Chip
                        label={pod.phase}
                        size="small"
                        sx={{
                          backgroundColor:
                            pod.phase === "Running" ? "#a8e6b1" : "#ffebee",
                          color: pod.phase === "Running" ? "black" : "#c62828",
                          border: `1px solid ${pod.phase === "Running" ? "#bbdefb" : "#ffcdd2"}`,
                          fontSize: "0.75rem",
                          borderRadius: "8px",
                          height: "24px",
                          lineHeight: "24px",
                          fontWeight: "medium",
                        }}
                      />
                    </Box>
                  </TableCell>
                  <TableCell sx={{ color: "black" }}>
                    <Box
                      sx={{ display: "flex", alignItems: "center", gap: 0.5 }}
                    >
                      <VscSymbolNamespace
                        style={{ fontSize: 16, color: "#cc6600" }}
                      />
                      {pod.namespace_name || "N/A"}
                    </Box>
                  </TableCell>
                  <TableCell sx={{ color: "black" }}>
                    <Box
                      sx={{ display: "flex", alignItems: "center", gap: 0.5 }}
                    >
                      <LuRocket size={14} color={colors.deployment} />
                      {pod.deployment_name || "N/A"}
                    </Box>
                  </TableCell>
                  <TableCell sx={{ color: colors.namespace }}>
                    <Box
                      sx={{ display: "flex", alignItems: "center", gap: 0.5 }}
                    >
                      <CpuIcon fontSize="small" sx={{ color: "#5c6bc0" }} />
                      <Box display="flex" gap={1}>
                        <Chip
                          label={`Req: ${pod.requestCPU || "N/A"}`}
                          size="small"
                          sx={{
                            backgroundColor: "#cce6ff",
                            color: "#337ab7",
                            border: "1px solid #b3d7ff",
                            fontSize: "0.7rem",
                            borderRadius: "8px",
                            height: "24px",
                            lineHeight: "24px",
                          }}
                        />
                        <Chip
                          label={`Lim: ${pod.limitCPU || "N/A"}`}
                          size="small"
                          sx={{
                            backgroundColor: "#ffe6cc",
                            color: "#ff9900",
                            border: "1px solid #ffd7b3",
                            fontSize: "0.7rem",
                            borderRadius: "8px",
                            height: "24px",
                            lineHeight: "24px",
                          }}
                        />
                      </Box>
                    </Box>
                  </TableCell>
                  <TableCell sx={{ color: colors.namespace }}>
                    <Box
                      sx={{ display: "flex", alignItems: "center", gap: 0.5 }}
                    >
                      <MemoryIcon fontSize="small" sx={{ color: "#26a69a" }} />
                      <Box display="flex" gap={1}>
                        <Chip
                          label={`Req: ${pod.requestRAM || "N/A"}`}
                          size="small"
                          sx={{
                            backgroundColor: "#e0f2f1",
                            color: "#009688",
                            border: "1px solid #b2dfdb",
                            fontSize: "0.7rem",
                            borderRadius: "8px",
                            height: "24px",
                            lineHeight: "24px",
                          }}
                        />
                        <Chip
                          label={`Lim: ${pod.limitRAM || "N/A"}`}
                          size="small"
                          sx={{
                            backgroundColor: "#ffebee",
                            color: "#c62828",
                            border: "1px solid #ffcdd2",
                            fontSize: "0.7rem",
                            borderRadius: "8px",
                            height: "24px",
                            lineHeight: "24px",
                          }}
                        />
                      </Box>
                    </Box>
                  </TableCell>
                  <TableCell sx={{ color: colors.namespace }}>
                    <Box
                      sx={{ display: "flex", alignItems: "center", gap: 0.5 }}
                    >
                      <RestartAlt
                        fontSize="small"
                        sx={{
                          color: getBadgeColorRestart(
                            pod.containerStatuses?.[0]?.restartCount || 0,
                          ).text,
                        }}
                      />
                      <Chip
                        label={pod.containerStatuses?.[0]?.restartCount || 0}
                        size="small"
                        sx={{
                          backgroundColor: getBadgeColorRestart(
                            pod.containerStatuses?.[0]?.restartCount || 0,
                          ).bg,
                          color: getBadgeColorRestart(
                            pod.containerStatuses?.[0]?.restartCount || 0,
                          ).text,
                          border: `1px solid ${getBadgeColorRestart(pod.containerStatuses?.[0]?.restartCount || 0).border}`,
                          fontSize: "0.75rem",
                          borderRadius: "8px",
                          height: "24px",
                          lineHeight: "24px",
                          fontWeight: "medium",
                        }}
                      />
                    </Box>
                  </TableCell>
                  <TableCell sx={{ color: "black" }}>
                    <Box
                      sx={{ display: "flex", alignItems: "center", gap: 0.5 }}
                    >
                      <TimeIcon fontSize="small" />
                      {new Date(pod.creationTimestamp).toLocaleDateString()}
                    </Box>
                  </TableCell>
                  <TableCell sx={{ color: colors.namespace }}>
                    <Box
                      sx={{ display: "flex", alignItems: "center", gap: 0.5 }}
                    >
                      <FiServer size={14} color="#616161" />
                      <Chip
                        label={pod.hostIP}
                        size="small"
                        sx={{
                          backgroundColor: "#f2f2f2",
                          color: "#424242",
                          border: "1px solid #e6e6e6",
                          fontSize: "0.8rem",
                          borderRadius: "6px",
                          height: "24px",
                          lineHeight: "24px",
                        }}
                      />
                    </Box>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Box>
    );
  };

  // Composant pour les onglets des serveurs (STYLE COMPLET)
  const renderServerEnvironmentTabs = () => {
    const envTabKey = `solution-${solution.id}-servers`;
    const envTabValue = environmentTabs.get(envTabKey) || 0;

    // Récupération des environnements disponibles
    let availableEnvs: string[] = [];

    // Structure pour Topology (child_servers)
    if (solution.child_servers && Array.isArray(solution.child_servers)) {
      availableEnvs = solution.child_servers
        .map((serverEnv: any) => {
          if (typeof serverEnv === "object" && serverEnv !== null) {
            return Object.keys(serverEnv)[0];
          }
          return null;
        })
        .filter(
          (env: string | null): env is string =>
            env !== null && env !== undefined,
        );
    }
    // Structure pour MyView (serversByEnv)
    else if (solution.serversByEnv) {
      availableEnvs = Object.keys(solution.serversByEnv);
    }

    // Filtrage et tri des environnements
    availableEnvs = availableEnvs
      .filter((env) => {
        const serverKey = `solution-${solution.id}-servers-${env}`;
        const servers = serversData.get(serverKey) || [];
        return (
          servers.length > 0 &&
          env !== null &&
          env !== undefined &&
          env !== "null"
        );
      })
      .sort((a, b) => {
        const indexA = orderedEnvironments.indexOf(a);
        const indexB = orderedEnvironments.indexOf(b);
        return (
          (indexA === -1 ? orderedEnvironments.length : indexA) -
          (indexB === -1 ? orderedEnvironments.length : indexB)
        );
      });

    if (availableEnvs.length === 0) {
      return <Alert severity="info">Aucun serveur trouvé</Alert>;
    }

    const currentEnv = availableEnvs[envTabValue];
    const serverKey = `solution-${solution.id}-servers-${currentEnv}`;
    const rawServers = serversData.get(serverKey) || [];
    const currentServers = sortServers(
      rawServers,
      serverSort.field,
      serverSort.direction,
    );

    const handleTabChange = (_: React.SyntheticEvent, newValue: number) => {
      setEnvironmentTabs((prev: Map<string, number>) => {
        const newMap = new Map(prev);
        newMap.set(envTabKey, newValue);
        return newMap;
      });
      // Reset du tri lors du changement d'environnement
      setServerSort({ field: "natures_inventory", direction: "asc" });
    };

    const getServerCountForEnvironment = (env: string): number => {
      const servers =
        serversData.get(`solution-${solution.id}-servers-${env}`) || [];
      return servers.length;
    };

    return (
      <Box>
        <Tabs
          value={envTabValue}
          onChange={handleTabChange}
          variant="scrollable"
          scrollButtons="auto"
          sx={{
            "& .MuiTab-root": {
              fontSize: "13px",
              fontWeight: 700,
              textTransform: "none",
              borderRadius: "8px 8px 0 0",
              "&.Mui-selected": {
                backgroundColor: (_theme) =>
                  envColors[
                  availableEnvs[envTabValue] as keyof typeof envColors
                  ],
                color:
                  availableEnvs[envTabValue] === "Préproduction"
                    ? "#333"
                    : "white",
              },
            },
            "& .MuiTabs-indicator": {
              backgroundColor: (_theme) =>
                envColors[availableEnvs[envTabValue] as keyof typeof envColors],
            },
          }}
        >
          {availableEnvs.map((env, index) => {
            const serverCount = getServerCountForEnvironment(env);
            return (
              <Tab
                key={index}
                label={`${env} (${serverCount})`}
                sx={{
                  color: envColors[env as keyof typeof envColors],
                  "&:hover": {
                    backgroundColor: `${envColors[env as keyof typeof envColors]}CC`,
                  },
                }}
              />
            );
          })}
        </Tabs>

        <Box sx={{ mt: 2 }}>
          {availableEnvs[envTabValue] && (
            <Box>
              {loading ? (
                <Skeleton variant="rectangular" height={200} />
              ) : (
                <TableContainer
                  component={Paper}
                  sx={{ backgroundColor: alpha(colors.server, 0.05) }}
                >
                  <Table>
                    <TableHead>
                      <TableRow
                        sx={{ backgroundColor: alpha(colors.server, 0.1) }}
                      >
                        <SortableTableCell
                          field="hostname"
                          label="Hostname"
                          currentSort={serverSort}
                          onSort={handleServerSort}
                        />
                        <SortableTableCell
                          field="os_type"
                          label="OS"
                          currentSort={serverSort}
                          onSort={handleServerSort}
                        />
                        <SortableTableCell
                          field="os_detail"
                          label="Détail de l'OS"
                          currentSort={serverSort}
                          onSort={handleServerSort}
                        />
                        <SortableTableCell
                          field="natures_inventory"
                          label="Nature dans l'inventaire"
                          currentSort={serverSort}
                          onSort={handleServerSort}
                        />
                        <SortableTableCell
                          field="ip_addresses"
                          label="IPs"
                          currentSort={serverSort}
                          onSort={handleServerSort}
                        />
                        <TableCell
                          sx={{
                            color: colors.server,
                            fontWeight: 700,
                            fontSize: "0.875rem",
                          }}
                        >
                          Environnement
                        </TableCell>
                        <SortableTableCell
                          field="signed"
                          label="Statut"
                          currentSort={serverSort}
                          onSort={handleServerSort}
                        />

                        <SortableTableCell
                          field="cpu"
                          label="CPU"
                          currentSort={serverSort}
                          onSort={handleServerSort}
                        />
                        <SortableTableCell
                          field="ram"
                          label="RAM (Go)"
                          currentSort={serverSort}
                          onSort={handleServerSort}
                        />
                        <SortableTableCell
                          field="storage"
                          label="Stockage (Go)"
                          currentSort={serverSort}
                          onSort={handleServerSort}
                        />
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {currentServers.map((server: any, index: number) => {
                        const envColor =
                          envColors[
                          availableEnvs[envTabValue] as keyof typeof envColors
                          ] || "#bb688bff";
                        const osColor =
                          osColors[server.os_type as keyof typeof osColors] ||
                          osColors.Default;

                        return (
                          <TableRow
                            key={`${server.hostname}-${index}`}
                            hover
                            sx={{
                              "&:hover": {
                                backgroundColor: server.to_decom ? "#FFCCCB" : alpha(colors.server, 0.1), // Rouge plus vif au survol
                              },
                              backgroundColor: server.to_decom ? "#FFE4E1" : "white", // Rouge plus visible
                              borderLeft: server.to_decom ? "4px solid #FF4444" : "none", // Bordure rouge bien visible
                            }}
                          >
                            <TableCell sx={{ fontWeight: 600 }}>
                              <Box
                                sx={{
                                  display: "flex",
                                  alignItems: "center",
                                  gap: 1,
                                }}
                              >
                                <FiServer size={16} color={colors.server} />
                                <Box>
                                  <Typography
                                    variant="body2"
                                    sx={{ fontWeight: 600 }}
                                  >
                                    {server.hostname}
                                  </Typography>
                                  {/* Afficher le uname uniquement pour AIX, toujours */}
                                  {server.os_type === "AIX" && (
                                    <Typography
                                      variant="caption"
                                      sx={{
                                        color: pastelTheme.textSecondary,
                                        fontStyle: "italic",
                                        display: "block",
                                        mt: 0.5,
                                      }}
                                    >
                                      uname: {server.uname || "_"}
                                    </Typography>
                                  )}
                                </Box>
                              </Box>
                            </TableCell>
                            <TableCell>
                              <Box
                                sx={{
                                  display: "flex",
                                  alignItems: "center",
                                  gap: 0.5,
                                }}
                              >
                                <Chip
                                  label={server.os_type}
                                  size="small"
                                  sx={{
                                    fontWeight: 600,
                                    borderRadius: "8px",
                                    backgroundColor: osColor,
                                    color:
                                      server.os_type === "Default"
                                        ? "#333"
                                        : "white",
                                    border: `1px solid ${alpha(osColor, 0.7)}`,
                                    fontSize: "0.75rem",
                                    height: "24px",
                                    lineHeight: "24px",
                                  }}
                                />
                              </Box>
                            </TableCell>
                            <TableCell sx={{ fontWeight: 600 }}>
                              <Box
                                sx={{
                                  display: "flex",
                                  alignItems: "center",
                                  gap: 1,
                                }}
                              >
                                <Typography
                                  variant="body2"
                                  sx={{ fontWeight: 600 }}
                                >
                                  {server.os_detail || "_"}
                                </Typography>
                              </Box>
                            </TableCell>
                            <TableCell>
                              <Typography variant="body2">
                                {Array.isArray(server.natures_inventory)
                                  ? server.natures_inventory.join(" / ")
                                  : server.natures_inventory}
                              </Typography>
                            </TableCell>
                            <TableCell>
                              <Box sx={{ display: "flex", alignItems: "center", gap: 0.5, flexWrap: "wrap" }}>
                                {/* Bouton Copier toutes les IPs */}
                                {server.ip_addresses?.length > 0 && (
                                  <Tooltip title="Copier toutes les IPs">
                                    <IconButton
                                      size="small"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        navigator.clipboard.writeText(server.ip_addresses.join(", "));
                                      }}
                                      sx={{
                                        padding: 0.5,
                                        backgroundColor: "#E5E7EB",
                                        color: "#374151",
                                        "&:hover": { backgroundColor: "#D1D5DB" }
                                      }}
                                    >
                                      <ContentCopy fontSize="small" />
                                    </IconButton>
                                  </Tooltip>
                                )}

                                {/* IPs cliquables avec placeholder */}
                                {server.ip_addresses?.map((ip: string, index: number) => (
                                  <Tooltip key={index} title={`Copier : ${ip}`}>
                                    <Chip
                                      label={ip}
                                      size="small"
                                      variant="outlined"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        navigator.clipboard.writeText(ip);
                                      }}
                                      sx={{
                                        backgroundColor: "#F3F4F6",
                                        borderColor: "#D1D5DB",
                                        fontSize: "0.9rem",
                                        cursor: "pointer",
                                        "&:hover": {
                                          backgroundColor: "#E5E7EB",
                                          borderColor: "#9CA3AF",
                                        }
                                      }}
                                    />
                                  </Tooltip>
                                ))}
                              </Box>
                            </TableCell>
                            <TableCell>
                              <Box
                                sx={{
                                  display: "flex",
                                  alignItems: "center",
                                  gap: 0.5,
                                }}
                              >
                                <Chip
                                  label={availableEnvs[envTabValue]}
                                  size="small"
                                  sx={{
                                    fontWeight: 600,
                                    borderRadius: "8px",
                                    backgroundColor: envColor,
                                    color:
                                      availableEnvs[envTabValue] ===
                                        "Préproduction"
                                        ? "#333"
                                        : "white",
                                    border: `1px solid ${alpha(envColor, 0.7)}`,
                                    fontSize: "0.75rem",
                                    height: "24px",
                                    lineHeight: "24px",
                                  }}
                                />
                              </Box>
                            </TableCell>
                            <TableCell>
                              <Box
                                sx={{
                                  display: "flex",
                                  alignItems: "center",
                                  gap: 0.5,
                                }}
                              >
                                <Chip
                                  label={
                                    server.signed === "Signé" ||
                                      server.signed === "Oui"
                                      ? "Signé"
                                      : "Non signé"
                                  }
                                  size="small"
                                  sx={{
                                    fontWeight: 600,
                                    borderRadius: "8px",
                                    backgroundColor:
                                      server.signed === "Signé" ||
                                        server.signed === "Oui"
                                        ? "#a8e6b1"
                                        : "#ffb3b3",
                                    color:
                                      server.signed === "Signé" ||
                                        server.signed === "Oui"
                                        ? "black"
                                        : "#B71C1C",
                                    border: `1px solid ${server.signed === "Signé" || server.signed === "Oui" ? "#99ffb3" : "#ff9999"}`,
                                    fontSize: "0.75rem",
                                    height: "24px",
                                    lineHeight: "24px",
                                  }}
                                />
                              </Box>
                            </TableCell>


                            {/* Cellule CPU */}

                            <TableCell>
                              <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                                <CpuIcon fontSize="small" sx={{ color: "#5c6bc0" }} />

                                {(() => {
                                  // Valeurs extraites selon l'OS
                                  let displayValue = "N/A";
                                  let tooltipContent = "";

                                  if (server?.os_type === "AIX") {
                                    // Pour AIX: utiliser limit comme valeur principale
                                    const limit = server.specs?.cpu?.limit;
                                    const request = server.specs?.cpu?.request;

                                    if (limit) {
                                      displayValue = `${limit} cores`;
                                      tooltipContent = `AIX - Limit: ${limit} cores${request ? `, Request: ${request} cores` : ''}`;
                                    } else {
                                      displayValue = "N/A";
                                      tooltipContent = "CPU information non disponible";
                                    }
                                  } else {
                                    // Pour Linux et autres
                                    const cores =
                                      server?.specs?.cpu?.count ||
                                      server?.specs?.cpu?.cores ||
                                      server?.specs?.cpu;

                                    if (cores) {
                                      displayValue = `${cores} cores`;
                                      tooltipContent = `CPU: ${cores} cores`;

                                      // Ajouter des détails supplémentaires si disponibles
                                      if (server.specs?.cpu?.model) {
                                        tooltipContent += `\nModèle: ${server.specs.cpu.model}`;
                                      }
                                      if (server.specs?.cpu?.frequency) {
                                        tooltipContent += `\nFréquence: ${server.specs.cpu.frequency}`;
                                      }
                                    } else {
                                      displayValue = "N/A";
                                      tooltipContent = "CPU information non disponible";
                                    }
                                  }

                                  return (
                                    <Tooltip
                                      title={
                                        <Box sx={{ p: 0.5 }}>
                                          <Typography variant="caption" sx={{ fontWeight: 600, display: 'block', mb: 0.5 }}>
                                            Détails CPU
                                          </Typography>
                                          <Typography variant="caption" sx={{ whiteSpace: 'pre-line' }}>
                                            {tooltipContent}
                                          </Typography>
                                          {server?.specs?.cpu && (
                                            <Typography variant="caption" sx={{ display: 'block', mt: 1, color: '#666' }}>
                                              <strong>Structure brute:</strong> {JSON.stringify(server.specs.cpu)}
                                            </Typography>
                                          )}
                                        </Box>
                                      }
                                      arrow
                                      placement="right"
                                    >
                                      <Box sx={{ cursor: 'help' }}>
                                        <Typography
                                          variant="body2"
                                          sx={{
                                            fontWeight: 600,
                                            '&:hover': {
                                              textDecoration: 'underline',
                                              color: '#1976d2'
                                            }
                                          }}
                                        >
                                          {displayValue}
                                        </Typography>
                                      </Box>
                                    </Tooltip>
                                  );
                                })()}
                              </Box>
                            </TableCell>


                            {/* Cellule RAM */}
                            <TableCell>
                              <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                                <MemoryIcon fontSize="small" sx={{ color: "#26a69a" }} />
                                <Typography variant="body2" sx={{ fontWeight: 600 }}>
                                  {server.os_type === "AIX"
                                    ? server.specs?.memory
                                      ? (() => {
                                        const mo = parseInt(server.specs.memory);
                                        if (isNaN(mo)) return "N/A";

                                        // Si >= 1024 Mo = 1 Go
                                        if (mo >= 1024) {
                                          const gb = Math.round(mo / 1024);
                                          return `${gb} Go`;
                                        }

                                        return `${mo} Mo`;
                                      })()
                                      : "N/A"
                                    : server.specs?.memory?.size_MiB
                                      ? (() => {
                                        const gb = Math.round(server.specs.memory.size_MiB / 1024);
                                        return gb >= 1 ? `${gb} Go` : `${server.specs.memory.size_MiB} MiB`;
                                      })()
                                      : "N/A"
                                  }
                                </Typography>
                              </Box>
                            </TableCell>

                            {/* Cellule Stockage */}
                            <TableCell>
                              {server.os_type === "AIX" ? (
                                <Typography variant="body2" sx={{ color: "text.secondary", fontStyle: "italic" }}>
                                  N/A
                                </Typography>
                              ) : server.specs?.storage ? (
                                <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                                  <FiServer size={16} color="#616161" />
                                  <Typography variant="body2" sx={{ fontWeight: 600 }}>
                                    {Math.round(server.specs.storage / (1024 * 1024 * 1024))} Go
                                  </Typography>
                                </Box>
                              ) : (
                                <Typography variant="body2" sx={{ color: "text.secondary", fontStyle: "italic" }}>
                                  N/A
                                </Typography>
                              )}
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </TableContainer>
              )}
            </Box>
          )}
        </Box>
      </Box>
    );
  };

  const getTabColor = (index: number) => {
    const tabColors = [colors.server, colors.namespace, colors.deployment, colors.solution];
    return tabColors[index] || colors.solution;
  };

  const handleSolutionTabChange = (
    _: React.SyntheticEvent,
    newValue: number,
  ) => {
    setSolutionViewTab((prev: Map<string, number>) => {
      const newMap = new Map(prev);
      newMap.set(tabKey, newValue);
      return newMap;
    });
  };

  if (loading) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", my: 4 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ mt: 3 }}>
      <Paper
        elevation={0}
        sx={{
          p: 3,
          background: pastelTheme.cardBackground,
          border: `1px solid ${pastelTheme.outline}`,
          borderRadius: 3,
          boxShadow: `0 8px 24px ${pastelTheme.shadow}`,
        }}
      >
        {/* En-tête avec TOUTES les infos organisationnelles à droite en HORIZONTAL AMÉLIORÉ */}
        <Box
          sx={{
            display: "flex",
            alignItems: "flex-start",
            justifyContent: "space-between",
            gap: 4,
            mb: 3,
            flexDirection: { xs: "column", md: "row" },
          }}
        >
          {/* Partie gauche : Nom et détails de la solution (STYLE ORIGINAL) */}
          <Box sx={{ flex: 1 }}>
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 3,
                mb: 2,
                flexDirection: { xs: "column", sm: "row" },
                textAlign: { xs: "center", sm: "left" },
              }}
            >
              <Box
                sx={{
                  p: 3,
                  borderRadius: "50%",
                  backgroundColor: alpha(colors.solution, 0.2),
                  color: darkColors.solution,
                  flexShrink: 0,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Apps sx={{ fontSize: 40 }} />
              </Box>
              <Box>
                <Typography
                  variant="h4"
                  sx={{ fontWeight: 800, color: darkColors.solution, mb: 1 }}
                >
                  {solution.solution_name}
                  {!(
                    solution.declarted_on_itop &&
                    solution.declarted_on_bigfix &&
                    solution.psi &&
                    solution.itop_id &&
                    solution.solution_role &&
                    solution.solution_popularity &&
                    solution.solution_type &&
                    solution.domain &&
                    solution.tenant &&
                    solution.service_type
                  ) && <span style={{ color: "red" }}>*</span>}
                </Typography>
                <Stack
                  direction="row"
                  spacing={2}
                  divider={<Divider orientation="vertical" flexItem />}
                  sx={{ justifyContent: { xs: "center", sm: "flex-start" } }}
                >
                  <Chip
                    label={solution.solution_type}
                    size="small"
                    sx={{
                      fontWeight: 700,
                      backgroundColor: alpha(colors.solution, 0.2),
                      color: darkColors.solution,
                    }}
                  />
                  <Chip
                    label={solution.psi}
                    size="small"
                    sx={{
                      fontWeight: 700,
                      backgroundColor: alpha(colors.solution, 0.2),
                      color: darkColors.solution,
                    }}
                  />
                  <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                    <Chip
                      label={
                        solution.solution_role && solution.solution_role.length > 30
                          ? `${solution.solution_role.substring(0, 30)}...`
                          : solution.solution_role
                      }
                      size="small"
                      sx={{
                        fontWeight: 700,
                        backgroundColor: alpha(colors.solution, 0.2),
                        color: darkColors.solution,
                      }}
                    />
                    {solution.solution_role &&
                      solution.solution_role.length > 30 && (
                        <Tooltip title="Afficher les détails du rôle">
                          <IconButton
                            size="small"
                            onClick={() => setShowRoleDetails(!showRoleDetails)}
                            sx={{
                              color: darkColors.solution,
                              backgroundColor: alpha(colors.solution, 0.1),
                              "&:hover": {
                                backgroundColor: alpha(colors.solution, 0.2),
                              },
                            }}
                          >
                            <InfoOutlinedIcon />
                          </IconButton>
                        </Tooltip>
                      )}
                  </Box>
                </Stack>

                {showRoleDetails &&
                  solution.solution_role &&
                  solution.solution_role.length > 30 && (
                    <Collapse in={showRoleDetails}>
                      <Alert
                        severity="info"
                        onClose={() => setShowRoleDetails(false)}
                        sx={{
                          mt: 2,
                          backgroundColor: alpha(colors.solution, 0.05),
                          border: `1px solid ${alpha(colors.solution, 0.2)}`,
                          borderRadius: 2,
                          "& .MuiAlert-message": {
                            color: darkColors.solution,
                          },
                        }}
                      >
                        <Typography variant="body2" sx={{ fontWeight: 500 }}>
                          <strong>Rôle complet :</strong> {solution.solution_role}
                        </Typography>
                      </Alert>
                    </Collapse>
                  )}
              </Box>
            </Box>

            {/* Infos supplémentaires sous le nom */}
            <Box sx={{ mt: 2, display: 'flex', flexWrap: 'wrap', gap: 2, ml: { sm: 15 } }}>
              {solution.domain && (
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                  <Business fontSize="small" sx={{ color: colors.domain }} />
                  <Typography variant="body2">
                    <strong>Domaine:</strong> {solution.domain}
                  </Typography>
                </Box>
              )}
              {solution.tenant && (
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                  <TbBuildingBank size={16} style={{ color: colors.namespace }} />
                  <Typography variant="body2">
                    <strong>Tenant:</strong> {solution.tenant}
                  </Typography>
                </Box>
              )}
              {solution.service_type && (
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                  <FiServer size={16} style={{ color: colors.server }} />
                  <Typography variant="body2">
                    <strong>Type service:</strong> {solution.service_type}
                  </Typography>
                </Box>
              )}
            </Box>
          </Box>

          {/* Partie droite */}
          <Paper
            elevation={0}
            sx={{
              p: 2,
              width: { xs: '100%', md: '60%' },
              minHeight: 140,
              backgroundColor: alpha(colors.solution, 0.05),
              border: `1px solid ${alpha(colors.solution, 0.3)}`,
              borderRadius: 2,
              boxShadow: `0 2px 8px ${alpha(colors.solution, 0.1)}`,
              display: 'flex',
              flexDirection: 'column',
            }}
          >
            {/* Titre compact */}
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
              <MdGroups style={{ fontSize: 18, color: colors.solution }} />
              <Typography
                variant="subtitle2"
                sx={{
                  fontWeight: 700,
                  color: colors.solution,
                  fontSize: '0.9rem',
                }}
              >
                Équipe
              </Typography>

              {/* TAM Principal ultra compact */}
              {solution.person && (
                <Chip
                  label={solution.person.split("@")[0]}
                  size="small"
                  sx={{
                    ml: 'auto',
                    backgroundColor: alpha(colors.solution, 0.2),
                    fontWeight: 600,
                    fontSize: '0.75rem',
                    height: 24,
                  }}
                />
              )}
            </Box>

            {/* TOUTES les catégories en UNE seule grille 2x3 */}
            <Box sx={{
              display: 'grid',
              gridTemplateColumns: 'repeat(3, 1fr)',
              gridTemplateRows: 'repeat(2, auto)',
              gap: 1.5,
              flex: 1
            }}>
              {/* Ligne 1 */}
              <ResponsableSection
                title="TAMs"
                count={solution.count_tams}
                admins={solution.list_admins?.tams}
                icon={<FaUserTie />}
                iconColor={colors.solution}
              />

              <ResponsableSection
                title="Tech"
                count={solution.count_technical_admins}
                admins={solution.list_admins?.technical_admins}
                icon={<MdAdminPanelSettings />}
                iconColor="#1976d2"
              />

              <ResponsableSection
                title="Fonc"
                count={solution.count_functional_admins}
                admins={solution.list_admins?.functional_admins}
                icon={<MdOutlineAdminPanelSettings />}
                iconColor="#2e7d32"
              />

              {/* Ligne 2 */}
              <ResponsableSection
                title="Arch. Prod"
                count={solution.count_prod_architects}
                admins={solution.list_admins?.prod_architects}
                icon={<FaNetworkWired />}
                iconColor="#ed6c02"
              />

              <ResponsableSection
                title="Arch. DSA"
                count={solution.count_dsa_architects}
                admins={solution.list_admins?.dsa_architects}
                icon={<BiNetworkChart />}
                iconColor="#9c27b0"
              />

              {/* Case vide ou stats */}
              {/* <Box sx={{ 
      p: 1, 
      backgroundColor: alpha(colors.solution, 0.03),
      borderRadius: 1,
      border: `1px dashed ${alpha(colors.solution, 0.2)}`,
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
    }}>
      <Typography variant="caption" sx={{ fontWeight: 700, color: colors.solution }}>
        Total
      </Typography>
      <Typography variant="h6" sx={{ fontWeight: 800, color: colors.solution }}>
        {[
          solution.count_tams || 0,
          solution.count_technical_admins || 0,
          solution.count_functional_admins || 0,
          solution.count_prod_architects || 0,
          solution.count_dsa_architects || 0
        ].reduce((a, b) => a + b, 0)}
      </Typography>
    </Box> */}
            </Box>
          </Paper>
        </Box>

        {/* Informations d'organisation */}
        {renderOrganizationInfo()}

        {/* Onglets améliorés */}
        <Tabs
          value={tabValue}
          onChange={handleSolutionTabChange}
          sx={{
            mb: 3,
            "& .MuiTab-root": {
              fontSize: "14px",
              fontWeight: 700,
              textTransform: "none",
              minHeight: 48,
              borderRadius: 2,
              mx: 1,
              "&.Mui-selected": {
                backgroundColor: (_theme) => getTabColor(tabValue),
                // color: "white",
              },
            },
          }}
          variant="scrollable"
          scrollButtons="auto"
        >
          <Tab
            icon={<FiServer />}
            iconPosition="start"
            label="Serveurs"
            sx={{
              color: colors.server,
            }}
          />
          {solution.count_namespaces !== undefined &&
            solution.count_namespaces !== 0 ? (
            <Tab
              icon={<VscSymbolNamespace />}
              iconPosition="start"
              label="Namespaces"
              sx={{
                color: colors.namespace,
              }}
            />
          ) : (
            <></>
          )}

          {(solution.count_request !== undefined &&
            solution.count_request !== 0) ||
            (solution.count_cab !== undefined && solution.count_cab !== 0) ||
            (solution.count_ecab !== undefined && solution.count_ecab !== 0) ? (
            <Tab
              icon={<LuRocket />}
              iconPosition="start"
              label="Infos MAJ"
              sx={{
                color: colors.deployment,
              }}
            />
          ) : (
            <></>
          )}

          {/* Onglet release */}
          <Tab
            icon={<TbNote />}
            iconPosition="start"
            label={`Release Notes (${releaseNotes.length})`}
            sx={{
              color: colors.solution,
            }}
          />

          {/* <Tab
            icon={<MdOutlineSchema />}
            iconPosition="start"
            label="Architecture"
            sx={{
              color: colors.solution,
            }}
          /> */}
        </Tabs>

        {/* Contenu des onglets */}
        <Box sx={{ mt: 2 }}>
          {tabValue === 0 ? (
            <Box>
              <Typography
                variant="h6"
                sx={{
                  mb: 2,
                  display: "flex",
                  alignItems: "center",
                  gap: 1,
                  fontWeight: 700,
                  color: colors.server,
                  textTransform: "uppercase",
                }}
              >
                <FiServer size={24} style={{ color: colors.server }} />
                Serveurs ({solution.count_servers || 0})
              </Typography>
              {(solution.child_servers && solution.child_servers.length > 0) ||
                (solution.serversByEnv &&
                  Object.keys(solution.serversByEnv).length > 0) ? (
                renderServerEnvironmentTabs()
              ) : (
                <Alert severity="info" sx={{ borderRadius: 2 }}>
                  Aucun serveur configuré pour cette solution
                </Alert>
              )}
            </Box>
          ) : tabValue === 1 ? (
            <Fade in timeout={400}>
              <Box
                sx={{
                  p: 3,
                  borderRadius: 3,
                  backgroundColor: alpha(colors.namespace, 0.05),
                  border: `1px solid ${alpha(colors.namespace, 0.2)}`,
                  boxShadow: `0 2px 8px ${alpha(colors.namespace, 0.1)}`,
                }}
              >
                {/* Titre avec icône */}
                <Typography
                  variant="h6"
                  sx={{
                    mb: 2,
                    display: "flex",
                    alignItems: "center",
                    gap: 1,
                    fontWeight: 700,
                    color: colors.namespace,
                    textTransform: "uppercase",
                  }}
                >
                  <VscSymbolNamespace
                    size={24}
                    style={{ color: colors.namespace }}
                  />
                  Pods OpenShift ({solution.count_pods || 0})
                </Typography>

                {/* Contenu principal */}
                {solution.child_pods ? (
                  loading ? (
                    <Skeleton
                      variant="rectangular"
                      height={300}
                      animation="wave"
                      sx={{
                        borderRadius: 2,
                        backgroundColor: alpha(colors.namespace, 0.1),
                      }}
                    />
                  ) : (
                    <Box sx={{ mt: 2 }}>{renderNamespaceTabs()}</Box>
                  )
                ) : (
                  <Alert
                    severity="info"
                    icon={false}
                    sx={{
                      mt: 2,
                      borderRadius: 2,
                      backgroundColor: alpha(colors.namespace, 0.05),
                      color: colors.namespace,
                      border: `1px solid ${alpha(colors.namespace, 0.2)}`,
                      fontWeight: 500,
                    }}
                  >
                    Aucun pod configuré pour cette solution.
                  </Alert>
                )}
              </Box>
            </Fade>
          ) : tabValue === 2 ? (
            // Nouveau contenu pour Infos MAJ
            <Box>
              <Typography
                variant="h6"
                sx={{
                  mb: 2,
                  display: "flex",
                  alignItems: "center",
                  gap: 1,
                  fontWeight: 700,
                  color: colors.deployment,
                }}
              >
                <LuRocket />
                Informations de Mise à Jour
              </Typography>

              <Paper
                sx={{
                  p: 3,
                  borderRadius: 3,
                  backgroundColor: alpha(colors.deployment, 0.05),
                  borderLeft: `4px solid ${colors.deployment}`,
                }}
              >
                <Grid container spacing={3}>
                  {/* Demandes Utilisateurs */}
                  <Grid item xs={12} sm={6} md={3}>
                    <Box
                      sx={{
                        p: 2,
                        backgroundColor: alpha(colors.solution, 0.1),
                        borderRadius: 2,
                        borderLeft: `4px solid ${colors.solution}`,
                      }}
                    >
                      <Typography
                        variant="subtitle2"
                        sx={{
                          fontWeight: 700,
                          color: colors.solution,
                          display: "flex",
                          alignItems: "center",
                          gap: 1,
                        }}
                      >
                        <Apps /> Demandes Utilisateurs
                      </Typography>
                      <Typography variant="h4" sx={{ mt: 1, fontWeight: 800 }}>
                        {solution.count_request || 0}
                      </Typography>
                    </Box>
                  </Grid>

                  {/* CAB */}
                  <Grid item xs={12} sm={6} md={3}>
                    <Box
                      sx={{
                        p: 2,
                        backgroundColor: alpha(colors.entity, 0.1),
                        borderRadius: 2,
                        borderLeft: `4px solid ${colors.entity}`,
                      }}
                    >
                      <Typography
                        variant="subtitle2"
                        sx={{
                          fontWeight: 700,
                          color: colors.entity,
                          display: "flex",
                          alignItems: "center",
                          gap: 1,
                        }}
                      >
                        <Business /> CAB
                      </Typography>
                      <Typography variant="h4" sx={{ mt: 1, fontWeight: 800 }}>
                        {solution.count_cab || 0}
                      </Typography>
                    </Box>
                  </Grid>

                  {/* ECAB */}
                  <Grid item xs={12} sm={6} md={3}>
                    <Box
                      sx={{
                        p: 2,
                        backgroundColor: alpha(colors.domain, 0.1),
                        borderRadius: 2,
                        borderLeft: `4px solid ${colors.domain}`,
                      }}
                    >
                      <Typography
                        variant="subtitle2"
                        sx={{
                          fontWeight: 700,
                          color: colors.domain,
                          display: "flex",
                          alignItems: "center",
                          gap: 1,
                        }}
                      >
                        <TbBuildingBank /> ECAB
                      </Typography>
                      <Typography variant="h4" sx={{ mt: 1, fontWeight: 800 }}>
                        {solution.count_ecab || 0}
                      </Typography>
                    </Box>
                  </Grid>
                </Grid>


                {/* Vous pouvez ajouter ici des informations supplémentaires ou des graphiques */}
                <Box sx={{ mt: 3 }}>
                  <Typography variant="body2" sx={{ fontStyle: "italic" }}>
                    Dernière mise à jour:{" "}
                    {solution.updated_at
                      ? new Date(solution.updated_at).toLocaleString()
                      : "Inconnue"}
                  </Typography>
                </Box>
              </Paper>
            </Box>
          ) : tabValue === 3 ? (
            <Fade in timeout={400}>
              <Box
                sx={{
                  p: 0,
                  borderRadius: 3,
                  backgroundColor: '#ffffff',
                  border: `1px solid ${alpha(colors.solution, 0.2)}`,
                  boxShadow: `0 8px 32px ${alpha(colors.solution, 0.1)}`,
                  overflow: 'hidden'
                }}
              >
                {renderReleaseNotesSection()}
              </Box>
            </Fade>
          ) : tabValue === 4 ? (
            <Fade in timeout={400}>
              <Box sx={{
                p: 0,
                borderRadius: 3,
                backgroundColor: '#ffffff',
                border: `1px solid ${alpha(colors.solution, 0.2)}`,
                boxShadow: `0 8px 32px ${alpha(colors.solution, 0.1)}`,
                overflow: 'hidden'
              }}>
                {/* En-tête avec dégradé */}
                <Box
                  sx={{
                    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                    color: 'white',
                    p: 3,
                    textAlign: 'center',
                  }}
                >
                  <Typography variant="h5" sx={{ fontWeight: 800, mb: 1, letterSpacing: '0.5px' }}>
                    <MdOutlineSchema />
                    Architecture Back-Office Gold
                  </Typography>
                  <Typography variant="body2" sx={{ opacity: 0.9, maxWidth: 600, mx: 'auto' }}>
                    Vue schématique interactive de l'architecture de production avec ses composants et connexions
                  </Typography>
                </Box>

                {/* Légende moderne */}
                <Box sx={{ p: 2.5, backgroundColor: '#f8fafc', borderBottom: '1px solid #e2e8f0' }}>
                  <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1.5, color: '#2d3748', display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Box component="span" sx={{ width: 6, height: 6, borderRadius: '50%', backgroundColor: colors.solution }} />
                    Légende des Protocoles & Services
                  </Typography>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1.5 }}>
                    {[
                      { label: 'HTTPS', color: '#48bb78', icon: '🔒' },
                      { label: 'JDBC', color: '#4299e1', icon: '🗄️' },
                      { label: 'SSL/TLS', color: '#9f7aea', icon: '🔐' },
                      { label: 'HTTP', color: '#f56565', icon: '🌐' },
                      { label: 'Eureka', color: '#ecc94b', icon: '☁️' },
                      { label: 'Kafka', color: '#ed8936', icon: '📨' },
                    ].map((item, idx) => (
                      <Chip
                        key={idx}
                        label={
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                            <Box component="span">{item.icon}</Box>
                            {item.label}
                          </Box>
                        }
                        size="small"
                        sx={{
                          backgroundColor: alpha(item.color, 0.15),
                          color: item.color,
                          border: `1px solid ${alpha(item.color, 0.3)}`,
                          fontWeight: 600,
                          borderRadius: '20px',
                          height: 28,
                          '& .MuiChip-label': { px: 1.5 },
                        }}
                      />
                    ))}
                  </Box>
                </Box>

                {/* Architecture visuelle élégante */}
                <Box sx={{ p: 3, backgroundColor: '#f7fafc', minHeight: 700, position: 'relative' }}>

                  {/* Niveau 1: Utilisateurs */}
                  <Box sx={{ display: 'flex', justifyContent: 'center', mb: 6 }}>
                    <Box
                      sx={{
                        p: 3,
                        backgroundColor: 'white',
                        borderRadius: 3,
                        boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
                        border: '1px solid #e2e8f0',
                        width: '100%',
                        maxWidth: 500,
                        position: 'relative',
                        '&::before': {
                          content: '"👥 Utilisateurs"',
                          position: 'absolute',
                          top: -12,
                          left: '50%',
                          transform: 'translateX(-50%)',
                          backgroundColor: '#4299e1',
                          color: 'white',
                          px: 2,
                          py: 0.5,
                          borderRadius: '12px',
                          fontSize: '0.75rem',
                          fontWeight: 700,
                        }
                      }}
                    >
                      <Grid container spacing={2} justifyContent="center">
                        <Grid item xs={6}>
                          <Box
                            sx={{
                              p: 2,
                              backgroundColor: '#ebf8ff',
                              borderRadius: 2,
                              textAlign: 'center',
                              border: '2px solid #bee3f8',
                              transition: 'all 0.3s ease',
                              '&:hover': {
                                transform: 'translateY(-2px)',
                                boxShadow: '0 6px 12px rgba(66, 153, 225, 0.2)',
                              }
                            }}
                          >
                            <Typography variant="body2" sx={{ fontWeight: 700, color: '#2c5282', mb: 0.5 }}>
                              Siège Central
                            </Typography>
                            <Typography variant="caption" sx={{ color: '#4a5568' }}>
                              Accès interne
                            </Typography>
                          </Box>
                        </Grid>
                        <Grid item xs={6}>
                          <Box
                            sx={{
                              p: 2,
                              backgroundColor: '#ebf8ff',
                              borderRadius: 2,
                              textAlign: 'center',
                              border: '2px solid #bee3f8',
                              transition: 'all 0.3s ease',
                              '&:hover': {
                                transform: 'translateY(-2px)',
                                boxShadow: '0 6px 12px rgba(66, 153, 225, 0.2)',
                              }
                            }}
                          >
                            <Typography variant="body2" sx={{ fontWeight: 700, color: '#2c5282', mb: 0.5 }}>
                              Agences
                            </Typography>
                            <Typography variant="caption" sx={{ color: '#4a5568' }}>
                              Accès réseau sécurisé
                            </Typography>
                          </Box>
                        </Grid>
                      </Grid>
                    </Box>
                  </Box>

                  {/* Flèche directionnelle */}
                  <Box sx={{ textAlign: 'center', mb: 6, position: 'relative' }}>
                    <Box
                      sx={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: 1,
                        backgroundColor: 'white',
                        px: 3,
                        py: 1,
                        borderRadius: '20px',
                        border: '2px dashed #cbd5e0',
                        boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
                      }}
                    >
                      <Box sx={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: '#48bb78' }} />
                      <Typography variant="caption" sx={{ fontWeight: 700, color: '#2d3748' }}>
                        HTTPS :9047 • Load Balancing
                      </Typography>
                      <Box sx={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: '#48bb78' }} />
                    </Box>
                    <Box sx={{ width: 2, height: 20, backgroundColor: '#cbd5e0', mx: 'auto', mt: 1 }} />
                  </Box>

                  {/* Niveau 2: Frontend */}
                  <Box sx={{ display: 'flex', justifyContent: 'center', mb: 8 }}>
                    <Box
                      sx={{
                        p: 3,
                        backgroundColor: 'white',
                        borderRadius: 3,
                        boxShadow: '0 8px 25px rgba(0,0,0,0.1)',
                        border: '1px solid #e2e8f0',
                        width: '100%',
                        maxWidth: 700,
                        position: 'relative',
                        '&::before': {
                          content: '"🖥️ Frontend Vente"',
                          position: 'absolute',
                          top: -12,
                          left: '50%',
                          transform: 'translateX(-50%)',
                          backgroundColor: '#48bb78',
                          color: 'white',
                          px: 2,
                          py: 0.5,
                          borderRadius: '12px',
                          fontSize: '0.75rem',
                          fontWeight: 700,
                        }
                      }}
                    >
                      <Typography variant="caption" sx={{ display: 'block', textAlign: 'center', mb: 2, color: '#718096' }}>
                        Apache httpd • Reverse Proxy • Load Balancer
                      </Typography>
                      <Grid container spacing={3} justifyContent="center">
                        {[
                          {
                            name: 'frontend-vente-1',
                            ip: '172.29.161.132',
                            status: 'Actif',
                            color: '#48bb78'
                          },
                          {
                            name: 'frontend-vente-2',
                            ip: '172.29.161.133',
                            status: 'Actif',
                            color: '#48bb78'
                          },
                        ].map((server, idx) => (
                          <Grid item xs={12} sm={6} key={idx}>
                            <Box
                              sx={{
                                p: 2.5,
                                backgroundColor: alpha(server.color, 0.1),
                                borderRadius: 2,
                                border: `2px solid ${alpha(server.color, 0.3)}`,
                                textAlign: 'center',
                                position: 'relative',
                                overflow: 'hidden',
                                '&::after': {
                                  content: '""',
                                  position: 'absolute',
                                  top: 0,
                                  right: 0,
                                  width: 8,
                                  height: '100%',
                                  backgroundColor: server.color,
                                  opacity: 0.2,
                                }
                              }}
                            >
                              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 1 }}>
                                <Box
                                  sx={{
                                    width: 10,
                                    height: 10,
                                    borderRadius: '50%',
                                    backgroundColor: server.color,
                                    mr: 1,
                                    animation: 'pulse 2s infinite',
                                    '@keyframes pulse': {
                                      '0%': { opacity: 0.6 },
                                      '50%': { opacity: 1 },
                                      '100%': { opacity: 0.6 },
                                    }
                                  }}
                                />
                                <Typography variant="body2" sx={{ fontWeight: 800, color: server.color }}>
                                  {server.status}
                                </Typography>
                              </Box>
                              <Typography variant="body1" sx={{ fontWeight: 700, color: '#2d3748', mb: 0.5 }}>
                                {server.name}
                              </Typography>
                              <Typography variant="caption" sx={{ display: 'block', color: '#4a5568', fontFamily: 'monospace', mb: 1 }}>
                                {server.ip}
                              </Typography>
                              <Chip
                                label="Apache httpd"
                                size="small"
                                sx={{
                                  backgroundColor: alpha('#4299e1', 0.1),
                                  color: '#2c5282',
                                  fontWeight: 600,
                                  fontSize: '0.7rem',
                                }}
                              />
                            </Box>
                          </Grid>
                        ))}
                      </Grid>
                    </Box>
                  </Box>

                  {/* Flèche directionnelle */}
                  <Box sx={{ textAlign: 'center', mb: 6, position: 'relative' }}>
                    <Box sx={{ width: 2, height: 20, backgroundColor: '#cbd5e0', mx: 'auto', mb: 1 }} />
                    <Box
                      sx={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: 1,
                        backgroundColor: 'white',
                        px: 3,
                        py: 1,
                        borderRadius: '20px',
                        border: '2px solid #e2e8f0',
                        boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
                      }}
                    >
                      <Typography variant="caption" sx={{ fontWeight: 700, color: '#2d3748' }}>
                        API Gateway • Service Routing
                      </Typography>
                    </Box>
                  </Box>

                  {/* Niveau 3: Backend Applications */}
                  <Box sx={{ mb: 8 }}>
                    <Box
                      sx={{
                        p: 3,
                        backgroundColor: 'white',
                        borderRadius: 3,
                        boxShadow: '0 10px 30px rgba(0,0,0,0.12)',
                        border: '1px solid #e2e8f0',
                        position: 'relative',
                        '&::before': {
                          content: '"⚙️ Backoffice Applications"',
                          position: 'absolute',
                          top: -12,
                          left: '50%',
                          transform: 'translateX(-50%)',
                          backgroundColor: '#ed8936',
                          color: 'white',
                          px: 2,
                          py: 0.5,
                          borderRadius: '12px',
                          fontSize: '0.75rem',
                          fontWeight: 700,
                        }
                      }}
                    >
                      <Typography variant="caption" sx={{ display: 'block', textAlign: 'center', mb: 3, color: '#718096' }}>
                        Spring Boot API • Microservices • Port 9047
                      </Typography>

                      <Grid container spacing={3} justifyContent="center">
                        {[
                          {
                            name: 'backoffice-app-prd1',
                            specs: '8 CPU • 16GB RAM',
                            stack: ['Spring Boot', 'Ribbon', 'Hystrix', 'Sleuth'],
                            connections: 6
                          },
                          {
                            name: 'backoffice-app-prd2',
                            specs: '8 CPU • 16GB RAM',
                            stack: ['Spring Boot', 'Feign', 'Actuator', 'OpenAPI'],
                            connections: 6
                          },
                        ].map((app, idx) => (
                          <Grid item xs={12} md={6} key={idx}>
                            <Box
                              sx={{
                                p: 2.5,
                                backgroundColor: alpha('#ed8936', 0.05),
                                borderRadius: 2,
                                border: `2px solid ${alpha('#ed8936', 0.2)}`,
                                height: '100%',
                                transition: 'all 0.3s ease',
                                '&:hover': {
                                  transform: 'translateY(-4px)',
                                  boxShadow: '0 8px 16px rgba(237, 137, 54, 0.15)',
                                }
                              }}
                            >
                              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                                <Typography variant="body1" sx={{ fontWeight: 800, color: '#2d3748' }}>
                                  {app.name}
                                </Typography>
                                <Chip
                                  label={`${app.connections} connexions`}
                                  size="small"
                                  sx={{
                                    backgroundColor: alpha('#4299e1', 0.1),
                                    color: '#2c5282',
                                    fontWeight: 700,
                                    fontSize: '0.7rem',
                                  }}
                                />
                              </Box>

                              <Typography variant="caption" sx={{ display: 'block', color: '#4a5568', mb: 2, fontFamily: 'monospace' }}>
                                {app.specs}
                              </Typography>

                              <Box sx={{ mb: 2 }}>
                                <Typography variant="caption" sx={{ fontWeight: 700, color: '#718096', mb: 1, display: 'block' }}>
                                  Stack Technologique:
                                </Typography>
                                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                                  {app.stack.map((tech, techIdx) => (
                                    <Chip
                                      key={techIdx}
                                      label={tech}
                                      size="small"
                                      sx={{
                                        backgroundColor: alpha('#9f7aea', 0.1),
                                        color: '#553c9a',
                                        fontSize: '0.65rem',
                                        height: 22,
                                      }}
                                    />
                                  ))}
                                </Box>
                              </Box>

                              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 2, pt: 2, borderTop: '1px solid #e2e8f0' }}>
                                <Box sx={{ flex: 1 }}>
                                  <Typography variant="caption" sx={{ fontWeight: 600, color: '#4a5568' }}>
                                    Port: <Box component="span" sx={{ fontFamily: 'monospace' }}>9047</Box>
                                  </Typography>
                                </Box>
                                <Chip
                                  label="Production"
                                  size="small"
                                  sx={{
                                    backgroundColor: alpha('#48bb78', 0.1),
                                    color: '#22543d',
                                    fontWeight: 700,
                                  }}
                                />
                              </Box>
                            </Box>
                          </Grid>
                        ))}
                      </Grid>
                    </Box>
                  </Box>

                  {/* Services Connectés */}
                  <Box sx={{ mb: 4 }}>
                    <Typography variant="subtitle1" sx={{ fontWeight: 800, mb: 3, textAlign: 'center', color: '#2d3748' }}>
                      Services Connectés
                    </Typography>

                    <Grid container spacing={2} justifyContent="center">
                      {[
                        {
                          title: '🗄️ PostgreSQL',
                          description: 'Cluster Actif-Passif',
                          details: '172.29.123.72-73',
                          color: '#4299e1',
                          protocol: 'JDBC',
                          status: 'Cluster'
                        },
                        {
                          title: '📨 Kafka',
                          description: 'Brokers Confluent',
                          details: '3 brokers SSL :9094',
                          color: '#ed8936',
                          protocol: 'SSL',
                          status: 'Actif'
                        },
                        {
                          title: '⚡ Redis',
                          description: 'Cache Cluster',
                          details: '2 nodes • 6 ports',
                          color: '#f56565',
                          protocol: 'HTTP',
                          status: 'Cluster'
                        },
                        {
                          title: '☁️ Eureka',
                          description: 'Service Discovery',
                          details: '172.29.165.114-115',
                          color: '#ecc94b',
                          protocol: 'Eureka',
                          status: 'Haute disponibilité'
                        },
                        {
                          title: '🔐 OAuth2',
                          description: 'Authentification',
                          details: 'Keycloak • AWB Realm',
                          color: '#9f7aea',
                          protocol: 'HTTPS',
                          status: 'Sécurisé'
                        },
                        {
                          title: '🖥️ Host VTXP',
                          description: 'Système Legacy',
                          details: '172.29.4.101',
                          color: '#4fd1c7',
                          protocol: 'HTTP/HTTPS',
                          status: 'Intégré'
                        },
                      ].map((service, idx) => (
                        <Grid item xs={12} sm={6} md={4} key={idx}>
                          <Box
                            sx={{
                              p: 2,
                              backgroundColor: alpha(service.color, 0.08),
                              borderRadius: 2,
                              border: `1px solid ${alpha(service.color, 0.2)}`,
                              height: '100%',
                              transition: 'all 0.3s ease',
                              '&:hover': {
                                transform: 'translateY(-2px)',
                                boxShadow: `0 6px 12px ${alpha(service.color, 0.15)}`,
                              }
                            }}
                          >
                            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 1 }}>
                              <Typography variant="body1" sx={{ fontWeight: 700, color: service.color }}>
                                {service.title}
                              </Typography>
                              <Chip
                                label={service.protocol}
                                size="small"
                                sx={{
                                  backgroundColor: alpha(service.color, 0.2),
                                  color: service.color,
                                  fontWeight: 700,
                                  fontSize: '0.65rem',
                                  height: 20,
                                }}
                              />
                            </Box>

                            <Typography variant="body2" sx={{ fontWeight: 600, color: '#2d3748', mb: 0.5 }}>
                              {service.description}
                            </Typography>

                            <Typography variant="caption" sx={{ display: 'block', color: '#718096', mb: 1.5, fontFamily: 'monospace' }}>
                              {service.details}
                            </Typography>

                            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                              <Typography variant="caption" sx={{ color: '#4a5568', fontSize: '0.7rem' }}>
                                {service.status}
                              </Typography>
                              <Box sx={{ display: 'flex', gap: 0.5 }}>
                                {[1, 2, 3].map((dot) => (
                                  <Box
                                    key={dot}
                                    sx={{
                                      width: 6,
                                      height: 6,
                                      borderRadius: '50%',
                                      backgroundColor: service.color,
                                      opacity: dot === 1 ? 1 : dot === 2 ? 0.6 : 0.3,
                                    }}
                                  />
                                ))}
                              </Box>
                            </Box>
                          </Box>
                        </Grid>
                      ))}
                    </Grid>
                  </Box>

                  {/* Statistiques */}
                  <Paper
                    sx={{
                      p: 2.5,
                      backgroundColor: 'white',
                      borderRadius: 2,
                      boxShadow: '0 4px 12px rgba(0,0,0,0.05)',
                      mt: 4,
                    }}
                  >
                    <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 2, color: '#2d3748', display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Box component="span" sx={{ fontSize: '1.2rem' }}>📊</Box>
                      Vue d'ensemble de l'Architecture
                    </Typography>
                    <Grid container spacing={2}>
                      {[
                        { label: 'Total Composants', value: '15', color: '#667eea' },
                        { label: 'Connexions Actives', value: '24', color: '#48bb78' },
                        { label: 'Services Principaux', value: '8', color: '#ed8936' },
                        { label: 'Environnement', value: 'Production', color: '#9f7aea' },
                        { label: 'Disponibilité', value: '99.9%', color: '#f56565' },
                        { label: 'Sécurité', value: 'Niveau 3', color: '#ecc94b' },
                      ].map((stat, idx) => (
                        <Grid item xs={6} sm={4} md={2} key={idx}>
                          <Box sx={{ textAlign: 'center' }}>
                            <Box
                              sx={{
                                width: 40,
                                height: 40,
                                borderRadius: '12px',
                                backgroundColor: alpha(stat.color, 0.1),
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                mx: 'auto',
                                mb: 1,
                                border: `2px solid ${alpha(stat.color, 0.2)}`,
                              }}
                            >
                              <Typography variant="h6" sx={{ fontWeight: 800, color: stat.color }}>
                                {stat.value}
                              </Typography>
                            </Box>
                            <Typography variant="caption" sx={{ fontWeight: 600, color: '#4a5568' }}>
                              {stat.label}
                            </Typography>
                          </Box>
                        </Grid>
                      ))}
                    </Grid>
                  </Paper>
                </Box>

                {/* Footer avec actions */}
                <Box
                  sx={{
                    p: 2,
                    backgroundColor: '#f8fafc',
                    borderTop: '1px solid #e2e8f0',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    flexWrap: 'wrap',
                    gap: 1,
                  }}
                >
                  <Typography variant="caption" sx={{ color: '#718096', display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Box component="span" sx={{ fontSize: '0.8rem' }}>🔄</Box>
                    Dernière mise à jour: Aujourd'hui • Environnement: Production
                  </Typography>

                  <Box sx={{ display: 'flex', gap: 1 }}>
                    <Button
                      variant="contained"
                      startIcon={<HighlightAlt />}
                      size="small"
                      sx={{
                        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                        color: 'white',
                        fontWeight: 700,
                        borderRadius: '20px',
                        px: 2,
                        '&:hover': {
                          background: 'linear-gradient(135deg, #5a67d8 0%, #6b46c1 100%)',
                        }
                      }}
                    >
                      Visualiser les flux
                    </Button>

                    <Button
                      variant="outlined"
                      size="small"
                      sx={{
                        borderColor: '#cbd5e0',
                        color: '#4a5568',
                        fontWeight: 600,
                        borderRadius: '20px',
                        px: 2,
                        '&:hover': {
                          borderColor: '#a0aec0',
                          backgroundColor: '#edf2f7',
                        }
                      }}
                    >
                      Exporter le schéma
                    </Button>
                  </Box>
                </Box>
              </Box>
            </Fade>
          ) :
            null}
        </Box>
      </Paper>
    </Box>
  );
};

export default SolutionDetailView;
