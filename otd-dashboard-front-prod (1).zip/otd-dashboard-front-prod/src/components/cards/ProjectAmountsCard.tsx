// src/components/card/ProjectMoneyCard.tsx

import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";

// Import files
import CustomTooltip from "../basics/CustomToolTip";
import { ProjectAmountsResponseDTO } from "@/types/dto/response/ProjectAmountsResponseDTO";

interface ProjectAmountsCardProps {
  project_amounts: ProjectAmountsResponseDTO;
}

interface MoneyInfoBoxProps {
  label: string;
  value: number;
}

function MoneyInfoBox({ label, value }: MoneyInfoBoxProps) {
  return (
    <Box sx={{ mx: 1 }}>
      <Typography
        variant="body2"
        color="var(--text-black-color)"
        sx={{ fontSize: "0.80rem" }}
      >
        {label}
      </Typography>
      <Typography
        variant="h6"
        sx={{
          fontSize: "1.20rem",
          fontWeight: "bold",
          color: "var(--text-black-color)",
          maxWidth: "7rem",
          overflow: "hidden",
          textOverflow: "ellipsis",
          whiteSpace: "nowrap",
        }}
      >
        {value}
      </Typography>
    </Box>
  );
}

function ProjectAmountsCard({ project_amounts }: ProjectAmountsCardProps) {
  const backgroundColors: Record<string, string> = {
    green: "var(--green-card-color)",
    red: "var(--red-card-color)",
    orange: "var(--orange-card-color)",
  };

  const backgroundColor = backgroundColors[project_amounts.etat!] || "#FFFFFF";

  return (
    <Card
      sx={{
        position: "relative",
        width: "100%",
        height: "10rem",
        transition: "0.3s",
        boxShadow: 1,
        backgroundColor,
        "&:hover": {
          boxShadow: 6,
          transform: "scale(1.03)",
        },
      }}
    >
      {/* Autres éléments de fond (cercles) */}
      <Box
        sx={{
          position: "absolute",
          right: "-28px",
          width: "8rem",
          height: "8rem",
          backgroundColor: "rgba(255, 255, 255, 0.25)",
          borderRadius: "50%",
          zIndex: 0,
        }}
      />
      <Box
        sx={{
          position: "absolute",
          bottom: "3px",
          right: "-28px",
          width: "5rem",
          height: "5rem",
          backgroundColor: "rgba(255, 255, 255, 0.5)",
          borderRadius: "50%",
          zIndex: 0,
        }}
      />
      <Box
        sx={{
          position: "absolute",
          bottom: "-10px",
          left: "-15px",
          width: "6rem",
          height: "6rem",
          backgroundColor: "rgba(255, 255, 255, 0.6)",
          borderRadius: "50%",
          zIndex: 0,
        }}
      />

      <CardContent sx={{ position: "relative", zIndex: 1 }}>
        <CustomTooltip title={project_amounts?.name || "Name"}>
          <Typography
            sx={{
              color: "var(--text-black-color)",
              fontSize: "1.50rem",
              fontWeight: "bold",
              maxWidth: "20rem",
              overflow: "hidden",
              textOverflow: "ellipsis",
              whiteSpace: "nowrap",
            }}
          >
            {project_amounts?.name || "Name"}
          </Typography>
        </CustomTooltip>

        <Box sx={{ display: "flex", justifyContent: "space-evenly", mt: 2 }}>
          <MoneyInfoBox
            label="Consumption"
            value={project_amounts?.consumption}
          />
          <MoneyInfoBox label="Budget" value={project_amounts?.budget} />
        </Box>
      </CardContent>
    </Card>
  );
}

export default ProjectAmountsCard;
