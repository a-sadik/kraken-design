// src/types/enums/Environnement.ts

export enum CertificateStateEnum {
  IN_PROGRESS = "En cours de signature",
  ACTIVE = "Activer",
  REJECTED = "Rejeter",
  HOLDED = "Mettre en attente",
  EXPRIED = "Expirer",
  RENEWED = "Renouveler",
}
