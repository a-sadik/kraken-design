/* eslint-disable @typescript-eslint/no-explicit-any */
import type React from "react";
import {
  Paper,
  Typography,
  Box,
  Grid,
  Divider,
  Chip,
  LinearProgress,
  Button,
  TableContainer,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  CircularProgress,
} from "@mui/material";
import {
  Dashboard,
  Backup,
  ChangeCircle,
  CalendarMonth,
  History,
  BatchPrediction,
  Stream,
  CheckCircle,
  Cancel,
  Warning,
  Pending,
  Schedule,
  AccessTime,
} from "@mui/icons-material";
import type { SolutionList } from "@/types/TopologyTypes";
import { colors, darkColors, statusColors } from "@/data/topology/constants";
import {
  generateBackupData,
  generateEcabChanges,
  generateCabChanges,
  generateBatchJobs,
  generateCftFlows,
  generateOverviewStats,
} from "@/data/topology/mock-data";
import { ExpandMore as ExpandMoreIcon } from "@mui/icons-material";
import { Accordion, AccordionSummary, AccordionDetails } from "@mui/material";

interface PanelProps {
  solution?: SolutionList;
}

// Remplacer chaque panneau par une version pliable
// Par exemple, pour le OverviewPanel, remplacer tout le composant par:

export const OverviewPanel: React.FC<PanelProps> = ({ solution }) => {
  const stats = generateOverviewStats();

  return (
    <Accordion
      sx={{
        mt: 2,
        backgroundColor: colors.overview,
        borderLeft: `4px solid ${darkColors.overview}`,
        "&.MuiPaper-root": {
          boxShadow: "none",
          border: `1px solid ${darkColors.overview}20`,
        },
      }}
    >
      <AccordionSummary
        expandIcon={<ExpandMoreIcon />}
        sx={{
          "& .MuiAccordionSummary-content": {
            margin: "8px 0",
            alignItems: "center",
          },
        }}
      >
        <Dashboard sx={{ mr: 1, color: darkColors.overview }} />
        <Typography
          variant="h6"
          sx={{ color: darkColors.overview, fontSize: "16px" }}
        >
          Vue d'ensemble (Fake)
        </Typography>
      </AccordionSummary>
      <AccordionDetails>
        <Grid container spacing={2}>
          <Grid item xs={12} md={6}>
            <Paper sx={{ p: 2, height: "100%" }}>
              <Typography variant="subtitle2" sx={{ mb: 1, fontSize: "14px" }}>
                État général
              </Typography>
              <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
                <Box
                  sx={{
                    width: 60,
                    height: 60,
                    borderRadius: "50%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    backgroundColor:
                      stats.healthScore > 90
                        ? "#4CAF50"
                        : stats.healthScore > 80
                          ? "#FFC107"
                          : "#FF5722",
                    color: "white",
                    fontWeight: "bold",
                    fontSize: "18px",
                    mr: 2,
                  }}
                >
                  {stats.healthScore}
                </Box>
                <Box>
                  <Typography variant="body2" sx={{ fontSize: "12px" }}>
                    Score de santé
                  </Typography>
                  <Typography
                    variant="caption"
                    sx={{
                      display: "block",
                      color: "text.secondary",
                      fontSize: "11px",
                    }}
                  >
                    Basé sur {solution?.count_servers || 0} serveurs et{" "}
                    {solution?.count_pods || 0} pods
                  </Typography>
                </Box>
              </Box>

              <Divider sx={{ my: 1 }} />

              <Grid container spacing={1}>
                <Grid item xs={6}>
                  <Typography
                    variant="caption"
                    sx={{
                      display: "block",
                      color: "text.secondary",
                      fontSize: "11px",
                    }}
                  >
                    Uptime
                  </Typography>
                  <Typography
                    variant="body2"
                    sx={{ fontSize: "12px", fontWeight: "bold" }}
                  >
                    {stats.uptime}
                  </Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography
                    variant="caption"
                    sx={{
                      display: "block",
                      color: "text.secondary",
                      fontSize: "11px",
                    }}
                  >
                    Performance
                  </Typography>
                  <Typography
                    variant="body2"
                    sx={{ fontSize: "12px", fontWeight: "bold" }}
                  >
                    {stats.performance}
                  </Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography
                    variant="caption"
                    sx={{
                      display: "block",
                      color: "text.secondary",
                      fontSize: "11px",
                    }}
                  >
                    Dernier incident
                  </Typography>
                  <Typography
                    variant="body2"
                    sx={{ fontSize: "12px", fontWeight: "bold" }}
                  >
                    Il y a {stats.lastIncident}
                  </Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography
                    variant="caption"
                    sx={{
                      display: "block",
                      color: "text.secondary",
                      fontSize: "11px",
                    }}
                  >
                    Alertes actives
                  </Typography>
                  <Typography
                    variant="body2"
                    sx={{
                      fontSize: "12px",
                      fontWeight: "bold",
                      color: stats.alerts > 0 ? "#F44336" : "#4CAF50",
                    }}
                  >
                    {stats.alerts}
                  </Typography>
                </Grid>
              </Grid>
            </Paper>
          </Grid>

          <Grid item xs={12} md={6}>
            <Paper sx={{ p: 2, height: "100%" }}>
              <Typography variant="subtitle2" sx={{ mb: 1, fontSize: "14px" }}>
                Activité récente
              </Typography>

              {[
                {
                  time: "Aujourd'hui, 09:45",
                  type: "Sauvegarde",
                  message: "Sauvegarde complète réussie",
                  color: "#E3F2FD",
                },
                {
                  time: "Hier, 14:30",
                  type: "Déploiement",
                  message: "Mise à jour v2.3.1 déployée",
                  color: "#E8F5E9",
                },
                {
                  time: "Il y a 2 jours",
                  type: "Alerte",
                  message: "Pic de charge CPU détecté et résolu",
                  color: "#FFEBEE",
                },
              ].map((activity, index) => (
                <Box key={index} sx={{ mb: 1 }}>
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                    }}
                  >
                    <Typography variant="body2" sx={{ fontSize: "12px" }}>
                      <AccessTime
                        fontSize="small"
                        sx={{
                          mr: 0.5,
                          fontSize: "14px",
                          verticalAlign: "middle",
                        }}
                      />
                      {activity.time}
                    </Typography>
                    <Chip
                      label={activity.type}
                      size="small"
                      sx={{ fontSize: "10px", backgroundColor: activity.color }}
                    />
                  </Box>
                  <Typography variant="body2" sx={{ fontSize: "12px", ml: 3 }}>
                    {activity.message}
                  </Typography>
                </Box>
              ))}
            </Paper>
          </Grid>

          <Grid item xs={12}>
            <Paper sx={{ p: 2 }}>
              <Typography variant="subtitle2" sx={{ mb: 1, fontSize: "14px" }}>
                Répartition des ressources
              </Typography>
              <Grid container spacing={2}>
                {["CPU", "Mémoire", "Stockage"].map((resource, index) => (
                  <Grid item xs={4} key={resource}>
                    <Typography
                      variant="caption"
                      sx={{
                        display: "block",
                        color: "text.secondary",
                        fontSize: "11px",
                      }}
                    >
                      {resource}
                    </Typography>
                    <LinearProgress
                      variant="determinate"
                      value={Math.floor(Math.random() * 40) + 30 + index * 10}
                      sx={{ height: 8, borderRadius: 4, mb: 0.5 }}
                    />
                  </Grid>
                ))}
              </Grid>
            </Paper>
          </Grid>
        </Grid>
      </AccordionDetails>
    </Accordion>
  );
};

export const BackupStatusPanel: React.FC = () => {
  const backups = generateBackupData();

  return (
    <Accordion
      sx={{
        mt: 2,
        backgroundColor: colors.backup,
        borderLeft: `4px solid ${darkColors.backup}`,
        "&.MuiPaper-root": {
          boxShadow: "none",
          border: `1px solid ${darkColors.backup}20`,
        },
      }}
    >
      <AccordionSummary
        expandIcon={<ExpandMoreIcon />}
        sx={{
          "& .MuiAccordionSummary-content": {
            margin: "8px 0",
            alignItems: "center",
          },
        }}
      >
        <Backup sx={{ mr: 1, color: darkColors.backup }} />
        <Typography
          variant="h6"
          sx={{ color: darkColors.backup, fontSize: "16px" }}
        >
          État des sauvegardes (Fake)
        </Typography>
      </AccordionSummary>
      <AccordionDetails>
        <TableContainer component={Paper} sx={{ maxHeight: 300 }}>
          <Table size="small" stickyHeader>
            <TableHead>
              <TableRow>
                {[
                  "Nom",
                  "Statut",
                  "Dernière sauvegarde",
                  "Prochaine sauvegarde",
                  "Taille",
                  "Type",
                  "Rétention",
                ].map((header) => (
                  <TableCell key={header} sx={{ fontSize: "12px" }}>
                    {header}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {backups.map((backup) => (
                <TableRow key={backup.id} hover>
                  <TableCell sx={{ fontSize: "12px" }}>{backup.name}</TableCell>
                  <TableCell>
                    <Chip
                      icon={
                        backup.status === "success" ? (
                          <CheckCircle fontSize="small" />
                        ) : backup.status === "failed" ? (
                          <Cancel fontSize="small" />
                        ) : backup.status === "pending" ? (
                          <Pending fontSize="small" />
                        ) : (
                          <Warning fontSize="small" />
                        )
                      }
                      label={
                        backup.status === "success"
                          ? "Succès"
                          : backup.status === "failed"
                            ? "Échec"
                            : backup.status === "pending"
                              ? "En cours"
                              : "Avertissement"
                      }
                      size="small"
                      sx={{
                        fontSize: "11px",
                        backgroundColor: statusColors[backup.status] + "20",
                        color: statusColors[backup.status],
                        fontWeight: "bold",
                        "& .MuiChip-icon": {
                          color: statusColors[backup.status],
                        },
                      }}
                    />
                  </TableCell>
                  <TableCell sx={{ fontSize: "12px" }}>
                    {backup.lastBackup}
                  </TableCell>
                  <TableCell sx={{ fontSize: "12px" }}>
                    {backup.nextBackup}
                  </TableCell>
                  <TableCell sx={{ fontSize: "12px" }}>{backup.size}</TableCell>
                  <TableCell sx={{ fontSize: "12px" }}>{backup.type}</TableCell>
                  <TableCell sx={{ fontSize: "12px" }}>
                    {backup.retention}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

        <Box
          sx={{
            mt: 2,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Box>
            <Typography
              variant="caption"
              sx={{
                display: "block",
                color: "text.secondary",
                fontSize: "11px",
              }}
            >
              Prochaine sauvegarde complète
            </Typography>
            <Typography
              variant="body2"
              sx={{ fontSize: "12px", fontWeight: "bold" }}
            >
              {new Date(Date.now() + 86400000 * 2).toLocaleString()}
            </Typography>
          </Box>
          <Button
            variant="outlined"
            size="small"
            startIcon={<Backup />}
            sx={{
              fontSize: "12px",
              color: darkColors.backup,
              borderColor: darkColors.backup,
            }}
          >
            Lancer une sauvegarde
          </Button>
        </Box>
      </AccordionDetails>
    </Accordion>
  );
};

export const EcabChangesPanel: React.FC = () => {
  const changes = generateEcabChanges();

  return (
    <Accordion
      sx={{
        mt: 2,
        backgroundColor: colors.ecab,
        borderLeft: `4px solid ${darkColors.ecab}`,
        "&.MuiPaper-root": {
          boxShadow: "none",
          border: `1px solid ${darkColors.ecab}20`,
        },
      }}
    >
      <AccordionSummary
        expandIcon={<ExpandMoreIcon />}
        sx={{
          "& .MuiAccordionSummary-content": {
            margin: "8px 0",
            alignItems: "center",
          },
        }}
      >
        <ChangeCircle sx={{ mr: 1, color: darkColors.ecab }} />
        <Typography
          variant="h6"
          sx={{ color: darkColors.ecab, fontSize: "16px" }}
        >
          Changements ECAB (Fake)
        </Typography>
      </AccordionSummary>
      <AccordionDetails>
        <TableContainer component={Paper} sx={{ maxHeight: 300 }}>
          <Table size="small" stickyHeader>
            <TableHead>
              <TableRow>
                {[
                  "ID",
                  "Titre",
                  "Statut",
                  "Date d'implémentation",
                  "Priorité",
                  "Impact",
                  "Type",
                ].map((header) => (
                  <TableCell key={header} sx={{ fontSize: "12px" }}>
                    {header}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {changes.map((change) => (
                <TableRow key={change.id} hover>
                  <TableCell sx={{ fontSize: "12px" }}>{change.id}</TableCell>
                  <TableCell sx={{ fontSize: "12px" }}>
                    {change.title}
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={
                        change.status === "approved"
                          ? "Approuvé"
                          : change.status === "pending"
                            ? "En attente"
                            : change.status === "rejected"
                              ? "Rejeté"
                              : "Terminé"
                      }
                      size="small"
                      sx={{
                        fontSize: "11px",
                        backgroundColor: statusColors[change.status] + "20",
                        color: statusColors[change.status],
                        fontWeight: "bold",
                      }}
                    />
                  </TableCell>
                  <TableCell sx={{ fontSize: "12px" }}>
                    {change.implementationDate}
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={
                        change.priority === "high"
                          ? "Haute"
                          : change.priority === "medium"
                            ? "Moyenne"
                            : "Basse"
                      }
                      size="small"
                      sx={{
                        fontSize: "11px",
                        backgroundColor: statusColors[change.priority] + "20",
                        color: statusColors[change.priority],
                        fontWeight: "bold",
                      }}
                    />
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={
                        change.impact === "high"
                          ? "Élevé"
                          : change.impact === "medium"
                            ? "Moyen"
                            : "Faible"
                      }
                      size="small"
                      sx={{
                        fontSize: "11px",
                        backgroundColor: statusColors[change.impact] + "20",
                        color: statusColors[change.impact],
                        fontWeight: "bold",
                      }}
                    />
                  </TableCell>
                  <TableCell sx={{ fontSize: "12px" }}>{change.type}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </AccordionDetails>
    </Accordion>
  );
};

export const CabChangesPanel: React.FC = () => {
  const changes = generateCabChanges();

  return (
    <Accordion
      sx={{
        mt: 2,
        backgroundColor: colors.cab,
        borderLeft: `4px solid ${darkColors.cab}`,
        "&.MuiPaper-root": {
          boxShadow: "none",
          border: `1px solid ${darkColors.cab}20`,
        },
      }}
    >
      <AccordionSummary
        expandIcon={<ExpandMoreIcon />}
        sx={{
          "& .MuiAccordionSummary-content": {
            margin: "8px 0",
            alignItems: "center",
          },
        }}
      >
        <CalendarMonth sx={{ mr: 1, color: darkColors.cab }} />
        <Typography
          variant="h6"
          sx={{ color: darkColors.cab, fontSize: "16px" }}
        >
          Changements CAB (Fake)
        </Typography>
      </AccordionSummary>
      <AccordionDetails>
        <TableContainer component={Paper} sx={{ maxHeight: 300 }}>
          <Table size="small" stickyHeader>
            <TableHead>
              <TableRow>
                {[
                  "ID",
                  "Titre",
                  "Statut",
                  "Date d'implémentation",
                  "Priorité",
                  "Impact",
                  "Type",
                ].map((header) => (
                  <TableCell key={header} sx={{ fontSize: "12px" }}>
                    {header}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {changes.map((change) => (
                <TableRow key={change.id} hover>
                  <TableCell sx={{ fontSize: "12px" }}>{change.id}</TableCell>
                  <TableCell sx={{ fontSize: "12px" }}>
                    {change.title}
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={
                        change.status === "approved"
                          ? "Approuvé"
                          : change.status === "pending"
                            ? "En attente"
                            : change.status === "rejected"
                              ? "Rejeté"
                              : "Terminé"
                      }
                      size="small"
                      sx={{
                        fontSize: "11px",
                        backgroundColor: statusColors[change.status] + "20",
                        color: statusColors[change.status],
                        fontWeight: "bold",
                      }}
                    />
                  </TableCell>
                  <TableCell sx={{ fontSize: "12px" }}>
                    {change.implementationDate}
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={
                        change.priority === "high"
                          ? "Haute"
                          : change.priority === "medium"
                            ? "Moyenne"
                            : "Basse"
                      }
                      size="small"
                      sx={{
                        fontSize: "11px",
                        backgroundColor: statusColors[change.priority] + "20",
                        color: statusColors[change.priority],
                        fontWeight: "bold",
                      }}
                    />
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={
                        change.impact === "high"
                          ? "Élevé"
                          : change.impact === "medium"
                            ? "Moyen"
                            : "Faible"
                      }
                      size="small"
                      sx={{
                        fontSize: "11px",
                        backgroundColor: statusColors[change.impact] + "20",
                        color: statusColors[change.impact],
                        fontWeight: "bold",
                      }}
                    />
                  </TableCell>
                  <TableCell sx={{ fontSize: "12px" }}>{change.type}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </AccordionDetails>
    </Accordion>
  );
};

export const BackupHistoryPanel: React.FC = () => {
  const history = Array.from({ length: 10 }, (_, i) => ({
    id: i + 1,
    date: new Date(Date.now() - i * 86400000).toLocaleDateString(),
    time: new Date(Date.now() - i * 86400000).toLocaleTimeString(),
    type: ["Complète", "Incrémentale", "Différentielle"][
      Math.floor(Math.random() * 3)
    ],
    status: Math.random() > 0.1 ? "success" : "failed",
    size: `${(Math.random() * 50 + 10).toFixed(1)} GB`,
    duration: `${Math.floor(Math.random() * 120 + 30)} min`,
  }));

  return (
    <Accordion
      sx={{
        mt: 2,
        backgroundColor: colors.backupHistory,
        borderLeft: `4px solid ${darkColors.backupHistory}`,
        "&.MuiPaper-root": {
          boxShadow: "none",
          border: `1px solid ${darkColors.backupHistory}20`,
        },
      }}
    >
      <AccordionSummary
        expandIcon={<ExpandMoreIcon />}
        sx={{
          "& .MuiAccordionSummary-content": {
            margin: "8px 0",
            alignItems: "center",
          },
        }}
      >
        <History sx={{ mr: 1, color: darkColors.backupHistory }} />
        <Typography
          variant="h6"
          sx={{ color: darkColors.backupHistory, fontSize: "16px" }}
        >
          Historique des sauvegardes (Fake)
        </Typography>
      </AccordionSummary>
      <AccordionDetails>
        <TableContainer component={Paper} sx={{ maxHeight: 300 }}>
          <Table size="small" stickyHeader>
            <TableHead>
              <TableRow>
                {["Date", "Heure", "Type", "Statut", "Taille", "Durée"].map(
                  (header) => (
                    <TableCell key={header} sx={{ fontSize: "12px" }}>
                      {header}
                    </TableCell>
                  ),
                )}
              </TableRow>
            </TableHead>
            <TableBody>
              {history.map((backup) => (
                <TableRow key={backup.id} hover>
                  <TableCell sx={{ fontSize: "12px" }}>{backup.date}</TableCell>
                  <TableCell sx={{ fontSize: "12px" }}>{backup.time}</TableCell>
                  <TableCell sx={{ fontSize: "12px" }}>{backup.type}</TableCell>
                  <TableCell>
                    <Chip
                      icon={
                        backup.status === "success" ? (
                          <CheckCircle fontSize="small" />
                        ) : (
                          <Cancel fontSize="small" />
                        )
                      }
                      label={backup.status === "success" ? "Succès" : "Échec"}
                      size="small"
                      sx={{
                        fontSize: "11px",
                        backgroundColor:
                          ((statusColors as any)[backup.status] || "#ccc") +
                          "20",
                        color: (statusColors as any)[backup.status] || "#ccc",
                        fontWeight: "bold",
                        "& .MuiChip-icon": {
                          color: (statusColors as any)[backup.status] || "#ccc",
                        },
                      }}
                    />
                  </TableCell>
                  <TableCell sx={{ fontSize: "12px" }}>{backup.size}</TableCell>
                  <TableCell sx={{ fontSize: "12px" }}>
                    {backup.duration}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </AccordionDetails>
    </Accordion>
  );
};

export const BatchJobsPanel: React.FC = () => {
  const jobs = generateBatchJobs();

  return (
    <Accordion
      sx={{
        mt: 2,
        backgroundColor: colors.batch,
        borderLeft: `4px solid ${darkColors.batch}`,
        "&.MuiPaper-root": {
          boxShadow: "none",
          border: `1px solid ${darkColors.batch}20`,
        },
      }}
    >
      <AccordionSummary
        expandIcon={<ExpandMoreIcon />}
        sx={{
          "& .MuiAccordionSummary-content": {
            margin: "8px 0",
            alignItems: "center",
          },
        }}
      >
        <BatchPrediction sx={{ mr: 1, color: darkColors.batch }} />
        <Typography
          variant="h6"
          sx={{ color: darkColors.batch, fontSize: "16px" }}
        >
          Traitements batch (Fake)
        </Typography>
      </AccordionSummary>
      <AccordionDetails>
        <TableContainer component={Paper} sx={{ maxHeight: 300 }}>
          <Table size="small" stickyHeader>
            <TableHead>
              <TableRow>
                {[
                  "Nom du traitement",
                  "Statut",
                  "Début",
                  "Fin",
                  "Durée",
                  "Progression",
                  "Serveur",
                ].map((header) => (
                  <TableCell key={header} sx={{ fontSize: "12px" }}>
                    {header}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {jobs.map((job) => (
                <TableRow key={job.id} hover>
                  <TableCell sx={{ fontSize: "12px" }}>{job.name}</TableCell>
                  <TableCell>
                    <Chip
                      icon={
                        job.status === "running" ? (
                          <CircularProgress size={12} />
                        ) : job.status === "completed" ? (
                          <CheckCircle fontSize="small" />
                        ) : job.status === "failed" ? (
                          <Cancel fontSize="small" />
                        ) : (
                          <Schedule fontSize="small" />
                        )
                      }
                      label={
                        job.status === "running"
                          ? "En cours"
                          : job.status === "completed"
                            ? "Terminé"
                            : job.status === "failed"
                              ? "Échec"
                              : "Planifié"
                      }
                      size="small"
                      sx={{
                        fontSize: "11px",
                        backgroundColor: statusColors[job.status] + "20",
                        color: statusColors[job.status],
                        fontWeight: "bold",
                        "& .MuiChip-icon": { color: statusColors[job.status] },
                      }}
                    />
                  </TableCell>
                  <TableCell sx={{ fontSize: "12px" }}>
                    {job.startTime}
                  </TableCell>
                  <TableCell sx={{ fontSize: "12px" }}>
                    {job.endTime || "-"}
                  </TableCell>
                  <TableCell sx={{ fontSize: "12px" }}>
                    {job.duration}
                  </TableCell>
                  <TableCell sx={{ fontSize: "12px" }}>
                    {job.status === "running" ? (
                      <Box
                        sx={{ display: "flex", alignItems: "center", gap: 1 }}
                      >
                        <LinearProgress
                          variant="determinate"
                          value={job.progress}
                          sx={{ flexGrow: 1, height: 6, borderRadius: 3 }}
                        />
                        <Typography variant="caption" sx={{ fontSize: "10px" }}>
                          {job.progress}%
                        </Typography>
                      </Box>
                    ) : job.status === "completed" ? (
                      "100%"
                    ) : (
                      "-"
                    )}
                  </TableCell>
                  <TableCell sx={{ fontSize: "12px" }}>{job.server}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </AccordionDetails>
    </Accordion>
  );
};

export const CftFlowsPanel: React.FC = () => {
  const flows = generateCftFlows();

  return (
    <Accordion
      sx={{
        mt: 2,
        backgroundColor: colors.cft,
        borderLeft: `4px solid ${darkColors.cft}`,
        "&.MuiPaper-root": {
          boxShadow: "none",
          border: `1px solid ${darkColors.cft}20`,
        },
      }}
    >
      <AccordionSummary
        expandIcon={<ExpandMoreIcon />}
        sx={{
          "& .MuiAccordionSummary-content": {
            margin: "8px 0",
            alignItems: "center",
          },
        }}
      >
        <Stream sx={{ mr: 1, color: darkColors.cft }} />
        <Typography
          variant="h6"
          sx={{ color: darkColors.cft, fontSize: "16px" }}
        >
          Flux CFT (Fake)
        </Typography>
      </AccordionSummary>
      <AccordionDetails>
        <TableContainer component={Paper} sx={{ maxHeight: 300 }}>
          <Table size="small" stickyHeader>
            <TableHead>
              <TableRow>
                {[
                  "Nom du flux",
                  "Statut",
                  "Dernière exécution",
                  "Fréquence",
                  "Source",
                  "Destination",
                  "Fichiers transférés",
                  "Taille moyenne",
                ].map((header) => (
                  <TableCell key={header} sx={{ fontSize: "12px" }}>
                    {header}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {flows.map((flow) => (
                <TableRow key={flow.id} hover>
                  <TableCell sx={{ fontSize: "12px" }}>{flow.name}</TableCell>
                  <TableCell>
                    <Chip
                      icon={
                        flow.status === "active" ? (
                          <CheckCircle fontSize="small" />
                        ) : flow.status === "error" ? (
                          <Cancel fontSize="small" />
                        ) : (
                          <Warning fontSize="small" />
                        )
                      }
                      label={
                        flow.status === "active"
                          ? "Actif"
                          : flow.status === "error"
                            ? "Erreur"
                            : "Inactif"
                      }
                      size="small"
                      sx={{
                        fontSize: "11px",
                        backgroundColor: statusColors[flow.status] + "20",
                        color: statusColors[flow.status],
                        fontWeight: "bold",
                        "& .MuiChip-icon": { color: statusColors[flow.status] },
                      }}
                    />
                  </TableCell>
                  <TableCell sx={{ fontSize: "12px" }}>
                    {flow.lastExecution}
                  </TableCell>
                  <TableCell sx={{ fontSize: "12px" }}>
                    {flow.frequency}
                  </TableCell>
                  <TableCell sx={{ fontSize: "12px" }}>{flow.source}</TableCell>
                  <TableCell sx={{ fontSize: "12px" }}>
                    {flow.destination}
                  </TableCell>
                  <TableCell sx={{ fontSize: "12px" }}>
                    {flow.transferredFiles.toLocaleString()}
                  </TableCell>
                  <TableCell sx={{ fontSize: "12px" }}>
                    {flow.averageSize}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </AccordionDetails>
    </Accordion>
  );
};
