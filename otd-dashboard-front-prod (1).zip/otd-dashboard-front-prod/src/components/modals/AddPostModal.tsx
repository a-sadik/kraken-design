// // ✅ AddPostModal.tsx

import { useEffect, useState } from "react";
import {
  TextField,
  Button,
  Box,
  Grid,
  Typography,
  CircularProgress,
  Snackbar,
  Alert,
} from "@mui/material";
import { useForm } from "react-hook-form";
import { z as zod } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

import MyModal from "@/components/modals/MyModal";
import { createPost } from "@/services/admin/PostService";

// ✅ Zod schema
const formSchema = zod.object({
  post_name: zod.string().trim().min(1, "Le nom du post est requis."),
});

// ✅ Typage
type FormAddPost = zod.infer<typeof formSchema>;

export const AddPostModal = ({ open, onClose, onSave }: any) => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isValid },
  } = useForm<FormAddPost>({
    resolver: zodResolver(formSchema),
    mode: "all",
    defaultValues: {
      post_name: "",
    },
  });

  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successSnackbar, setSuccessSnackbar] = useState(false);

  useEffect(() => {
    if (open) {
      reset(); // clear form when modal opens
      setErrorMessage(null);
    }
  }, [open, reset]);

  const handleSave = async (data: FormAddPost) => {
    setLoading(true);
    setErrorMessage(null);
    try {
      await createPost({ post_name: data.post_name });
      setSuccessSnackbar(true);
      onSave(); // refresh list in section
      onClose(); // close modal
    } catch (error: any) {
      console.error("Erreur lors de la création du post:", error);
      setErrorMessage("Échec de la création du post.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <MyModal open={open} onClose={onClose} title="Ajouter un Post">
        <form onSubmit={handleSubmit(handleSave)}>
          <Grid container spacing={2} sx={{ p: 2 }}>
            {/* Champ: Nom du Post */}
            <Grid item xs={12} container spacing={2} alignItems="center">
              <Grid item xs={4}>
                <Typography fontWeight="bold">Nom du Post</Typography>
              </Grid>
              <Grid item xs={8} style={{ width: 500 }}>
                <TextField
                  {...register("post_name")}
                  error={!!errors.post_name}
                  helperText={errors.post_name?.message}
                  fullWidth
                  placeholder="Entrer le nom du post"
                />
              </Grid>
            </Grid>

            {/* Erreur globale */}
            {errorMessage && (
              <Grid item xs={12}>
                <Alert severity="error" variant="filled">
                  {errorMessage}
                </Alert>
              </Grid>
            )}
          </Grid>

          {/* Boutons */}
          <Box textAlign="right" px={2} pb={2}>
            <Button onClick={onClose} sx={{ mr: 1 }}>
              Annuler
            </Button>
            <Button
              type="submit"
              variant="contained"
              disabled={!isValid || loading}
            >
              {loading ? <CircularProgress size={20} /> : "Ajouter"}
            </Button>
          </Box>
        </form>
      </MyModal>

      {/* ✅ Snackbar de succès */}
      <Snackbar
        open={successSnackbar}
        autoHideDuration={3000}
        onClose={() => setSuccessSnackbar(false)}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <Alert
          onClose={() => setSuccessSnackbar(false)}
          severity="success"
          variant="filled"
        >
          Post ajouté avec succès !
        </Alert>
      </Snackbar>
    </>
  );
};
