import EditIcon from "@mui/icons-material/Edit";
import VisibilityIcon from "@mui/icons-material/Visibility";
import DeployIcon from "@mui/icons-material/CloudUpload";
import ClearIcon from "@mui/icons-material/Clear";
import CompareArrowsIcon from "@mui/icons-material/CompareArrows";

import {
  Box,
  Button,
  IconButton,
  Typography,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Alert,
  Chip,
  Paper,
  Fade,
  CircularProgress,
  Snackbar,
  Tooltip,
} from "@mui/material";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import GetAppIcon from "@mui/icons-material/GetApp";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import { DataGrid, type GridRowSelectionModel } from "@mui/x-data-grid";
import {
  type Dispatch,
  type JSXElementConstructor,
  type SetStateAction,
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "react";
import KeyboardIcon from "@mui/icons-material/Keyboard";
import {
  export_AllServers,
  postBigFixDataApiUrl,
  postDeployMultipleSignatureApiUrl,
  postExportSignatureApiUrl,
} from "@/config/api.config";

// import Files
import { serverDataFormToRes, serverResToReq } from "@/mappers/ServerMapper";
import {
  createSingleServer,
  deleteServer,
  deployServerSignature,
  getAllServers,
  getHealthBackendData,
  getServerById,
  updateServer,
} from "@/services/ServerService";
import type { ServerResponseDTO } from "@/types/dto/response/ServerResponseDTO";
import type ServerView from "@/types/view/ServerView";
import { getBadgeColorEnvironment, getHardwareColor } from "@/utils/getDynamicColor";
import type { ErrorResponse } from "../../exceptions/ErrorResponse";
import CustomTooltip from "../basics/CustomToolTip";
import type { ServerFormData } from "../forms/ServerForm";
import ServerDetailsModal from "../modals/ServerDetailsModal";

// imports style
import "@/styles/reliability-data-table.css";
import {
  service_core,
  service_failure,
  service_unavailable,
} from "@/utils/customMessages";
import type { AxiosError } from "axios";
import ModifiedServerModal from "../modals/ModifiedServerModal";

import CustomToolBarServer from "./CustomToolBarServer";
import fetchWithAuth from "@/middleware/fetch-auth";

import DeleteServerButton from "@/hooks/useDeleteServer";
import { pastelTheme } from "../topology/config/topology-theme";
import DecomServerButton from "../modals/DecomServerButton";
import { SiBeatsbydre } from "react-icons/si";

interface ServerDataTableProps {
  openModal: boolean;
  setOpenModal: Dispatch<SetStateAction<boolean>>;
}


enum BigfixStatus {
  UNDECLARED = "Non Déclaré",
  UNCOMPLIANT = "Déclaré mais non conforme",
  COMPLIANT = "Conforme",
}

function getBigfixStatusFromRow(row: EnhancedServerView): BigfixStatus | null {
  const bigfixData = row.originalData?.bigfix_conformity;
  if (!bigfixData?.status) return null;

  const status = bigfixData.status.trim();
  if (status === BigfixStatus.UNDECLARED) return BigfixStatus.UNDECLARED;
  if (status === BigfixStatus.UNCOMPLIANT) return BigfixStatus.UNCOMPLIANT;
  if (status === BigfixStatus.COMPLIANT) return BigfixStatus.COMPLIANT;

  return null;
}


function ServerComparisonTable({
  bigfixData,
  inventoryData,
}: {
  bigfixData: any;
  inventoryData: ServerResponseDTO;
}) {
  const normalize = (val: any) => {
    if (val === null || val === undefined || val === "" || val === "Pas Encore Renseigné" || val === "N/A") return "";
    if (typeof val === "boolean") return val.toString();
    if (Array.isArray(val)) {
      return val
        .map(v => v?.toString().toLowerCase().trim())
        .filter(Boolean)
        .sort()
        .join(" | ");
    }
    return val.toString().toLowerCase().trim();
  };

  const fieldsToCompare = [
    { key: "hostname", label: "Hostname" },
    { key: "ip_addresses", label: "Adresses IP" },
    { key: "os_type", label: "Type OS" },
    { key: "os_detail", label: "Détail OS" },
    { key: "uname", label: "Uname", condition: (bigfix: { os_type: any; }, inv: { os_type: any; }) => (bigfix?.os_type || inv?.os_type)?.toLowerCase() === "aix" },
    { key: "natures_inventory", label: "Nature" },
    { key: "awb_administrateurs_technique", label: "Admins Technique" },
    { key: "awb_administrateurs_fonctionnel", label: "Admins Fonctionnel" },
    { key: "awb_tam", label: "TAM" },
    { key: "domains", label: "Domaines" },
    { key: "poles", label: "Pôles" },
    { key: "entities", label: "Entités" },
    { key: "tenant", label: "Tenant" },
    { key: "population_utilisateurs", label: "Population Utilisateurs" },
    { key: "type_de_service", label: "Type de Service" },
    // { key: "applicatif", label: "Applicatif" },
    // { key: "solution_applicative_type", label: "Solution Applicative Type" },
    { key: "awb_psi", label: "PSI" },
    { key: "awb_environnement", label: "Environnement" },
  ];

  const getValue = (obj: any, field: any, isBigfix: boolean = false) => {
    if (!obj) return null;

    // === CHAMP SPÉCIAL : solutions (noms) ===
    if (field.key === "solutions") {
      if (isBigfix) {
        return obj["Solution Applicative"] || null;
      } else {
        return (obj.solutions_inventory || [])
          .map((s: string) => s?.trim())
          .filter(Boolean);
      }
    }

    // === CHAMP SPÉCIAL : uname (uniquement si AIX) ===
    if (field.key === "uname") {
      if (isBigfix) {
        const osType = obj["os_type"]?.toLowerCase();
        if (osType !== "aix") return null;
        return obj["uname"] || null;
      } else {
        const osType = obj.os_type?.toLowerCase();
        if (osType !== "aix") return null;
        return obj.uname || null;
      }
    }

    // === CHAMP SPÉCIAL : environnement (toujours "environments" côté inventaire) ===
    if (field.key === "awb_environnement") {
      if (isBigfix) {
        return obj["AWB_Environnement"] || null;
      } else {
        const envs = obj.environments || [];
        return envs.length > 0 ? envs : null;
      }
    }

    // === MAPPING BigFix : champs plats (depuis /bigfix-info) ===
    const bigfixFieldMap: Record<string, string> = {
      hostname: "hostname",
      ip_addresses: "ip_address",
      os_type: "os_type",
      os_detail: "os_version",
      natures_inventory: "Nature_Serveur",
      domains: "domain",
      poles: "pole",
      entities: "entity",
      tenant: "Tenant",
      population_utilisateurs: "Population_Utilisateurs",
      type_de_service: "Type_de_Service",
      applicatif: "Applicatif",
      solution_applicative_type: "Solution_Applicative_Type",
      awb_psi: "AWB_PSI",
      awb_administrateurs_fonctionnel: "AWB_Administrateurs_Fonctionnel",
      awb_administrateurs_technique: "AWB_Administrateurs_Technique",
      awb_tam: "AWB_TAM",
    };

    // === CHAMPS MULTI (BigFix vs Inventaire) ===
    const multiValueFields = [
      "domains", "poles", "entities", "tenant", "banque", "siege",
      "population_utilisateurs", "type_de_service", "applicatif",
      "solution_applicative_type", "awb_psi",
      "awb_administrateurs_fonctionnel", "awb_administrateurs_technique", "awb_tam"
    ];

    if (multiValueFields.includes(field.key)) {
      // --- BIGFIX : champs plats ---
      if (isBigfix) {
        const mappedKey = bigfixFieldMap[field.key];
        if (!mappedKey) return null;
        const value = obj[mappedKey];
        const isEmpty = (v: any) => {
          if (v === null || v === undefined || v === "") return true;
          const s = v.toString().trim();
          return s === "" || s === "Pas Encore Renseigné" || s === "N/A" || s === "undefined";
        };
        if (Array.isArray(value)) {
          const filtered = value
            .map((v: any) => v?.toString().trim())
            .filter((v: string) => v && !isEmpty(v));
          return filtered.length > 0 ? filtered : null;
        }
        return isEmpty(value) ? null : value.toString().trim();
      }
      // --- INVENTAIRE : solutions_inventory_details[] ---
      else {
        // Fonction pour dédupliquer les tableaux
        const deduplicateArray = (array: any[]): any[] => {
          if (!array || array.length === 0) return [];
          return [...new Set(array.filter(item =>
            item !== null && item !== undefined && item.toString().trim() !== ""
          ))];
        };

        // Admins / TAM - DÉDUPLIQUER par email
        if (field.key.includes("awb_administrateurs") || field.key === "awb_tam") {
          const adminType = field.key === "awb_administrateurs_technique" ? "technical_admins" :
            field.key === "awb_administrateurs_fonctionnel" ? "functional_admins" :
              "tams";

          const uniqueEmails = new Set();
          const admins = (obj.solutions_inventory_details || [])
            .flatMap((sol: any) => sol.list_admins?.[adminType] || [])
            .filter((admin: any) => {
              const email = admin.email?.trim();
              if (email && email.includes("@") && email !== "" && !uniqueEmails.has(email)) {
                uniqueEmails.add(email);
                return true;
              }
              return false;
            })
            .map((admin: any) => admin.email);

          return admins.length > 0 ? admins : null;
        }

        // CORRECTION : Type de Service - DÉDUPLIQUER
        if (field.key === "type_de_service") {
          const values = (obj.solutions_inventory_details || [])
            .map((sol: any) => sol.service_type)
            .filter((v: any) => {
              const s = v?.toString().trim();
              return s && s !== "" && s !== "undefined" && s !== "Pas Encore Renseigné" && s !== "N/A";
            });
          return deduplicateArray(values).length > 0 ? deduplicateArray(values) : null;
        }

        // CORRECTION : PSI - DÉDUPLIQUER
        if (field.key === "awb_psi") {
          const values = (obj.solutions_inventory_details || [])
            .map((sol: any) => sol.psi)
            .filter((v: any) => {
              const s = v?.toString().trim();
              return s && s !== "" && s !== "undefined" && s !== "Pas Encore Renseigné" && s !== "N/A";
            });
          return deduplicateArray(values).length > 0 ? deduplicateArray(values) : null;
        }

        // CORRECTION : Population Utilisateurs - DÉDUPLIQUER
        if (field.key === "population_utilisateurs") {
          const values = (obj.solutions_inventory_details || [])
            .map((sol: any) => sol.solution_popularity)
            .filter((v: any) => {
              const s = v?.toString().trim();
              return s && s !== "" && s !== "undefined" && s !== "Pas Encore Renseigné" && s !== "N/A";
            });
          return deduplicateArray(values).length > 0 ? deduplicateArray(values) : null;
        }

        // Domaines, Pôles, Entités, Tenant - DÉDUPLIQUER
        const mappedKey = field.key === "domains" ? "domain" :
          field.key === "poles" ? "pole" :
            field.key === "entities" ? "entity" : field.key;

        const values = (obj.solutions_inventory_details || [])
          .map((sol: any) => sol[mappedKey])
          .filter((v: any) => {
            const s = v?.toString().trim();
            return s && s !== "" && s !== "undefined" && s !== "Pas Encore Renseigné" && s !== "N/A";
          });

        return deduplicateArray(values).length > 0 ? deduplicateArray(values) : null;
      }
    }

    // === CHAMPS SIMPLES (hors multi) ===
    if (isBigfix && bigfixFieldMap[field.key]) {
      const v = obj[bigfixFieldMap[field.key]];
      if (!v || v === "Pas Encore Renseigné" || v === "N/A") return null;
      return Array.isArray(v) ? v.map(i => i?.trim()).filter(Boolean) : v;
    }

    const val = obj[field.key];
    if (!val || val === "Pas Encore Renseigné" || val === "N/A") return null;
    return Array.isArray(val) ? val.map(i => i?.trim()).filter(Boolean) : val;
  };

  const getStatus = (bfVal: any, invVal: any) => {
    if ((bfVal === null || bfVal === undefined || bfVal === "") &&
      (invVal === null || invVal === undefined || invVal === "")) {
      return "same";
    }
    if ((bfVal === null || bfVal === undefined || bfVal === "") ||
      (invVal === null || invVal === undefined || invVal === "")) {
      return "different";
    }
    const bf = normalize(bfVal);
    const inv = normalize(invVal);
    return bf === inv ? "same" : "different";
  };

  const formatValue = (val: any) => {
    if (val === null || val === undefined || val === "" || val === "Pas Encore Renseigné" || val === "N/A") return [];
    if (Array.isArray(val)) return val;
    return [val.toString()];
  };

  // Calcul du score
  const totalFields = fieldsToCompare
    .filter(f => !f.condition || f.condition(bigfixData, inventoryData))
    .length;
  const matchingFields = fieldsToCompare
    .filter(field => {
      if (field.condition && !field.condition(bigfixData, inventoryData)) return false;
      const bfVal = getValue(bigfixData, field, true);
      const invVal = getValue(inventoryData, field, false);
      return getStatus(bfVal, invVal) === "same";
    })
    .length;
  const similarityScore = `${matchingFields}/${totalFields}`;

  return (
    <Paper elevation={3} sx={{ p: 3, borderRadius: 3, backgroundColor: "#FAFAFA" }}>
      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 2 }}>
        <Typography variant="h6" sx={{ fontWeight: 700, color: "#1F2937" }}>
          Comparaison complète du serveur
        </Typography>
        <Chip
          label={`Score: ${similarityScore}`}
          sx={{
            backgroundColor: matchingFields === totalFields ? "#D1FAE5" : matchingFields >= totalFields * 0.7 ? "#FEF3C7" : "#FEE2E2",
            color: matchingFields === totalFields ? "#059669" : matchingFields >= totalFields * 0.7 ? "#92400E" : "#DC2626",
            fontWeight: 700,
          }}
        />
      </Box>
      <Box sx={{ overflowX: "auto" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.875rem" }}>
          <thead>
            <tr>
              <th style={{ textAlign: "left", padding: "12px", backgroundColor: "#EEF2FF", color: "#4338CA", fontWeight: 600, position: "sticky", left: 0, zIndex: 2 }}>
                Champ
              </th>
              <th style={{ textAlign: "left", padding: "12px", backgroundColor: "#F0FDF4", color: "#166534", fontWeight: 600 }}>
                BigFix
              </th>
              <th style={{ textAlign: "left", padding: "12px", backgroundColor: "#FFFBEB", color: "#92400E", fontWeight: 600 }}>
                Inventaire
              </th>
              <th style={{ textAlign: "center", padding: "12px", backgroundColor: "#F3F4F6", color: "#374151", fontWeight: 600 }}>
                Statut
              </th>
            </tr>
          </thead>
          <tbody>
            {fieldsToCompare
              .filter(field => !field.condition || field.condition(bigfixData, inventoryData))
              .map((field) => {
                const bfValue = getValue(bigfixData, field, true);
                const invValue = getValue(inventoryData, field, false);
                const bfList = field.key === "solutions"
                  ? (bfValue ? [bfValue] : [])
                  : formatValue(bfValue);
                const invList = field.key === "solutions"
                  ? (Array.isArray(invValue) ? invValue : [])
                  : formatValue(invValue);
                const status = getStatus(bfList, invList);
                return (
                  <tr key={field.key} style={{ borderBottom: "1px solid #E5E7EB" }}>
                    <td
                      style={{
                        padding: "12px",
                        fontWeight: 500,
                        color: "#111827",
                        backgroundColor: "#F9FAFB",
                      }}
                    >
                      {field.label}
                    </td>
                    {/* Colonne BigFix */}
                    <td
                      style={{
                        padding: "12px",
                        backgroundColor: status === "different" ? "#FEF2F2" : "#F0FDF4",
                        color: status === "different" ? "#991B1B" : "#166534",
                      }}
                    >
                      {Array.isArray(bfList) && bfList.length > 0 ? (
                        <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
                          {bfList.map((sol: string, i: number) => (
                            <Chip
                              key={i}
                              label={sol}
                              size="small"
                              sx={{
                                backgroundColor: "#F3E5F5",
                                color: "#8B1A8B",
                                fontWeight: 600,
                                fontSize: "0.7rem",
                                height: 24,
                              }}
                            />
                          ))}
                        </Box>
                      ) : (
                        <Typography
                          variant="caption"
                          sx={{ color: "#9CA3AF", fontStyle: "italic" }}
                        >
                          Aucune
                        </Typography>
                      )}
                    </td>
                    {/* Colonne Inventaire */}
                    <td
                      style={{
                        padding: "12px",
                        backgroundColor: status === "different" ? "#FEF2F2" : "#FFFBEB",
                        color: status === "different" ? "#991B1B" : "#92400E",
                      }}
                    >
                      {Array.isArray(invList) && invList.length > 0 ? (
                        <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
                          {invList.map((sol: string, i: number) => (
                            <Chip
                              key={i}
                              label={sol}
                              size="small"
                              sx={{
                                backgroundColor: "#FEF3C7",
                                color: "#92400E",
                                fontWeight: 500,
                                fontSize: "0.7rem",
                                height: 22,
                              }}
                            />
                          ))}
                        </Box>
                      ) : (
                        <Typography
                          variant="caption"
                          sx={{ color: "#9CA3AF", fontStyle: "italic" }}
                        >
                          Aucune
                        </Typography>
                      )}
                    </td>
                    {/* Statut */}
                    <td style={{ textAlign: "center", padding: "12px" }}>
                      <Chip
                        label={status === "same" ? "Identique" : "Différent"}
                        size="small"
                        sx={{
                          backgroundColor: status === "same" ? "#D1FAE5" : "#FECACA",
                          color: status === "same" ? "#059669" : "#DC2626",
                          fontWeight: 600,
                          fontSize: "0.7rem",
                          minWidth: 80,
                        }}
                      />
                    </td>
                  </tr>
                );
              })}
          </tbody>
        </table>
      </Box>
      <Box sx={{ mt: 2, display: "flex", gap: 2, flexWrap: "wrap", justifyContent: "center" }}>
        <Chip label="Identique" sx={{ backgroundColor: "#D1FAE5", color: "#059669" }} />
        <Chip label="Différent" sx={{ backgroundColor: "#FEE2E2", color: "#DC2626" }} />
        <Chip label="Absente" sx={{ backgroundColor: "#F3F4F6", color: "#6B7280" }} />
      </Box>
    </Paper>
  );
}


interface FrontendServerFilterParams {
  global_search?: string;
  os_type?: string;
  environments?: string[];
  fiable?: boolean | undefined;
  solutions_inventory?: string;
  bigfix_conformity?: BigfixStatus[];
}

interface DeploymentFormData {
  username: string;
  password: string;
  sudo_password: string;
}

interface DeploymentResult {
  ip: string;
  status: "success" | "failure";
  raison?: string;
  step?: string[];
}

// Interface pour les statistiques d'environnement de l'API
interface EnvironmentCount {
  environement_name: string;
  server_count: number;
}

// Enhanced ServerView interface to include new fields
interface EnhancedServerView extends ServerView {
  isCasa: any;
  "Admin Technique": Array<{ name: string; email: string }>;
  "Admin Fonctionnel": Array<{ name: string; email: string }>;
  tenant: string | null;
  service_type: string | null;
  TAM: Array<{ name: string; email: string }>;
  Entities: string[];
  Fiabilité: boolean;
  originalData: ServerResponseDTO;
  to_decom: boolean;
  dataSource: "inventory" | "bigfix" | "none";
}

// Nouveau thème avec couleurs pastels cohérentes
const modernPastelTheme = createTheme({
  palette: {
    primary: {
      main: "#6366F1", // Indigo doux
      light: "#A5B4FC",
      dark: "#4338CA",
      contrastText: "#FFFFFF",
    },
    secondary: {
      main: "#EC4899", // Rose pastel
      light: "#F9A8D4",
      dark: "#BE185D",
      contrastText: "#FFFFFF",
    },
    success: {
      main: "#10B981", // Emerald
      light: "#a8e6b1",
      dark: "#047857",
    },
    error: {
      main: "#EF4444", // Rouge doux
      light: "#FCA5A5",
      dark: "#DC2626",
    },
    warning: {
      main: "#F59E0B", // Amber
      light: "#FCD34D",
      dark: "#D97706",
    },
    info: {
      main: "#3B82F6", // Bleu doux
      light: "#93C5FD",
      dark: "#1D4ED8",
    },
    background: {
      default: "#F8FAFC",
      paper: "#FFFFFF",
    },
    text: {
      primary: "#1F2937",
      secondary: "#6B7280",
    },
  },
  shape: {
    borderRadius: 16,
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: "none",
          fontWeight: 600,
          borderRadius: 12,
          padding: "10px 20px",
          boxShadow:
            "0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)",
          transition: "all 0.2s ease-in-out",
          "&:hover": {
            transform: "translateY(-2px)",
            boxShadow:
              "0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1)",
          },
        },
        containedPrimary: {
          background: "linear-gradient(135deg, #6366F1 0%, #8B5CF6 100%)",
          "&:hover": {
            background: "linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)",
          },
        },
        containedSecondary: {
          background: "linear-gradient(135deg, #EC4899 0%, #F472B6 100%)",
          "&:hover": {
            background: "linear-gradient(135deg, #DB2777 0%, #EC4899 100%)",
          },
        },
      },
    },
    MuiIconButton: {
      styleOverrides: {
        root: {
          borderRadius: 12,
          padding: 8,
          transition: "all 0.2s ease-in-out",
          "&:hover": {
            transform: "scale(1.1)",
          },
        },
      },
    },
    MuiDialog: {
      styleOverrides: {
        paper: {
          borderRadius: 20,
          boxShadow: "0 25px 50px -12px rgb(0 0 0 / 0.25)",
        },
      },
    },
    MuiDialogTitle: {
      styleOverrides: {
        root: {
          backgroundColor: "#F8FAFC",
          borderBottom: "1px solid #E2E8F0",
          fontWeight: 700,
          color: "#1F2937",
        },
      },
    },
    MuiTextField: {
      styleOverrides: {
        root: {
          "& .MuiOutlinedInput-root": {
            borderRadius: 12,
            "&:hover fieldset": {
              borderColor: "#6366F1",
            },
            "&.Mui-focused fieldset": {
              borderColor: "#6366F1",
              borderWidth: 2,
            },
          },
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          fontWeight: 500,
          "&.MuiChip-outlined": {
            borderColor: "#D1D5DB",
            backgroundColor: "#F9FAFB",
          },
        },
      },
    },
    MuiAlert: {
      styleOverrides: {
        root: {
          borderRadius: 12,
          boxShadow: "0 1px 3px 0 rgb(0 0 0 / 0.1)",
        },
      },
    },
  },
});

const commonArrayStyles = {
  display: "flex",
  alignItems: "center",
  justifyContent: "flex-start",
  gap: 0.5,
  flexWrap: "wrap",
  height: "100%",
  py: 1,
  pl: 1,
};

// Styles personnalisés pour les icônes d'action
const actionIconStyles = {
  view: {
    color: "#10B981",
    backgroundColor: "#ECFDF5",
    "&:hover": {
      backgroundColor: "#D1FAE5",
      color: "#047857",
    },
  },
  edit: {
    color: "#F59E0B",
    backgroundColor: "#FFFBEB",
    "&:hover": {
      backgroundColor: "#FEF3C7",
      color: "#D97706",
    },
  },
  delete: {
    color: "#EF4444",
    backgroundColor: "#FEF2F2",
    "&:hover": {
      backgroundColor: "#FECACA",
      color: "#DC2626",
    },
  },
  decom: {
    color: "#8B5CF6",
    backgroundColor: "#F3F4F6",
    "&:hover": {
      backgroundColor: "#EDE9FE",
      color: "#7C3AED",
    },
  },
  bigfix: {
    color: "#8B5CF6",
    backgroundColor: "#F5F3FF",
    "&:hover": {
      backgroundColor: "#EDE9FE",
      color: "#7C3AED",
    },
  },
};

function getDataSourceColor(source: string) {
  switch (source) {
    case "inventory":
      return { bgColor: "#e6f7e6", borderColor: "#a3d8a3" }; // Vert très clair
    case "bigfix":
      return { bgColor: "#f5f5f5", borderColor: "#d9d9d9" }; // Gris clair
    default:
      return { bgColor: "white", borderColor: "#e0e0e0" };
  }
}



const hasDecommissionPermission = (server: EnhancedServerView): boolean => {
  // Récupérer l'email de l'utilisateur connecté
  const getCurrentUserEmail = (): string | null => {
    const token = localStorage.getItem("access_token");
    if (token) {
      try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        return payload.email || payload.sub || null;
      } catch (error) {
        console.error("Erreur lors du décodage du token:", error);
      }
    }
    return null;
  };

  const userEmail = getCurrentUserEmail();
  if (!userEmail) return false;

  // 1. Vérifier si le serveur est fiable
  if (!server.Fiabilité) {
    return false;
  }

  // 2. Vérifier si l'utilisateur est TAM ou Admin Technique sur ce serveur
  const isTAM = server.TAM?.some(tam =>
    tam.email?.toLowerCase() === userEmail.toLowerCase()
  );

  const isTechnicalAdmin = server["Admin Technique"]?.some(admin =>
    admin.email?.toLowerCase() === userEmail.toLowerCase()
  );

  return isTAM || isTechnicalAdmin;
};


// Enhanced mapper function
function enhancedServerResToView(
  rawServers: ServerResponseDTO[],
): EnhancedServerView[] {
  return rawServers.map((originalServer) => {
    const deduplicateAdmins = (admins: Array<{ name: string; email: string }>): Array<{ name: string; email: string }> => {
      const uniqueAdmins = new Map();
      admins.forEach(admin => {
        const key = admin.email?.toLowerCase().trim() || admin.name?.toLowerCase().trim();
        if (key && !uniqueAdmins.has(key)) {
          uniqueAdmins.set(key, admin);
        }
      });
      return Array.from(uniqueAdmins.values());
    };

    // Initialiser les collections avec des valeurs par défaut
    const allTechnicalAdmins: Array<{ name: string; email: string }> = [];
    const allFunctionalAdmins: Array<{ name: string; email: string }> = [];
    const allTams: Array<{ name: string; email: string }> = [];
    let domainsToUse: string[] = [];
    let polesToUse: string[] = [];
    let entitiesToUse: string[] = [];

    // DÉTERMINER LA SOURCE DES DONNÉES (domaine, pole, entities, admins, TAM)
    const hasSolutionsInventory =
      originalServer.solutions_inventory_details &&
      originalServer.solutions_inventory_details.length > 0;

    const hasSolutionsBigFix =
      originalServer.solutions &&
      originalServer.solutions.length > 0;

    let dataSource: "inventory" | "bigfix" | "none" = "none";

    if (hasSolutionsInventory) {
      // CAS 1 & 2: solutions_inventory existe → on utilise l'inventaire
      dataSource = "inventory";
    } else if (hasSolutionsBigFix) {
      // CAS 3: solutions_inventory n'existe pas mais solutions existe → on utilise BigFix
      dataSource = "bigfix";
    }

    // TRAITEMENT DES DONNÉES SELON LA SOURCE
    if (dataSource === "inventory") {
      // Utiliser les données de l'inventaire
      originalServer.solutions_inventory_details?.forEach((solution) => {
        // Technical admins
        if (solution.list_admins?.technical_admins) {
          solution.list_admins.technical_admins.forEach((admin: { name: string; email: any; }) => {
            if (admin.name && admin.name.trim() !== "") {
              allTechnicalAdmins.push({
                name: admin.name,
                email: admin.email || "",
              });
            }
          });
        }

        // Functional admins
        if (solution.list_admins?.functional_admins) {
          solution.list_admins.functional_admins.forEach((admin: { name: string; email: any; }) => {
            if (admin.name && admin.name.trim() !== "") {
              allFunctionalAdmins.push({
                name: admin.name,
                email: admin.email || "",
              });
            }
          });
        }

        // TAMs
        if (solution.list_admins?.tams) {
          solution.list_admins.tams.forEach((tam: { name: string; email: any; }) => {
            if (tam.name && tam.name.trim() !== "") {
              allTams.push({
                name: tam.name,
                email: tam.email || ""
              });
            }
          });
        }

        // Domaines, poles, entities
        if (solution.domain && solution.domain.trim() !== "" && solution.domain !== "undefined") {
          domainsToUse.push(solution.domain);
        }
        if (solution.pole && solution.pole.trim() !== "" && solution.pole !== "undefined") {
          polesToUse.push(solution.pole);
        }
        if (solution.entity && solution.entity.trim() !== "" && solution.entity !== "undefined") {
          entitiesToUse.push(solution.entity);
        }
      });

      // Utiliser les domaines, pôles et entités de l'inventaire
      domainsToUse = (originalServer.domains_inventory || domainsToUse).filter(
        (d) => d && d.trim() !== "" && d !== "undefined",
      );
      polesToUse = (originalServer.poles_inventory || polesToUse).filter(
        (p) => p && p.trim() !== "" && p !== "undefined",
      );
      entitiesToUse = (originalServer.entities_inventory || entitiesToUse).filter(
        (e) => e && e.trim() !== "" && e !== "undefined",
      );

    } else if (dataSource === "bigfix") {
      // Utiliser les données BigFix
      originalServer.solutions?.forEach((solution) => {
        // Technical admins
        if (solution.list_admins?.technical_admins) {
          solution.list_admins.technical_admins.forEach((admin: { name: string; email: any; }) => {
            if (admin.name && admin.name.trim() !== "") {
              allTechnicalAdmins.push({
                name: admin.name,
                email: admin.email || "",
              });
            }
          });
        }

        // Functional admins
        if (solution.list_admins?.functional_admins) {
          solution.list_admins.functional_admins.forEach((admin: { name: string; email: any; }) => {
            if (admin.name && admin.name.trim() !== "") {
              allFunctionalAdmins.push({
                name: admin.name,
                email: admin.email || "",
              });
            }
          });
        }

        // TAMs
        if (solution.list_admins?.tams) {
          solution.list_admins.tams.forEach((tam: { name: string; email: any; }) => {
            if (tam.name && tam.name.trim() !== "") {
              allTams.push({
                name: tam.name,
                email: tam.email || ""
              });
            }
          });
        }

        // Domaines, poles, entities
        if (solution.domain && solution.domain.trim() !== "" && solution.domain !== "undefined") {
          domainsToUse.push(solution.domain);
        }
        if (solution.pole && solution.pole.trim() !== "" && solution.pole !== "undefined") {
          polesToUse.push(solution.pole);
        }
        if (solution.entity && solution.entity.trim() !== "" && solution.entity !== "undefined") {
          entitiesToUse.push(solution.entity);
        }
      });

      // Utiliser les domaines, pôles et entités de BigFix
      domainsToUse = (originalServer.domains || domainsToUse).filter(
        (d) => d && d.trim() !== "" && d !== "undefined",
      );
      polesToUse = (originalServer.poles || polesToUse).filter(
        (p) => p && p.trim() !== "" && p !== "undefined",
      );
      entitiesToUse = ((originalServer.entities as string[]) || entitiesToUse).filter(
        (e) => e && e.trim() !== "" && e !== "undefined",
      );
    }

    const enhancedServer: EnhancedServerView = {
      id: originalServer.server_id,
      Hostname: originalServer.hostname || "Non défini",
      Signature: originalServer.signed === "Anonyme" ? "Non signé" : originalServer.signed || "ERREUR",
      Fiabilité: originalServer.fiable || false,
      "Adresses IP": originalServer.ip_addresses || [],
      "Type OS": originalServer.os_type || "Non défini",
      "Détail OS": originalServer.os_detail || "Non défini",
      "Nature du serveur dans BigFix": originalServer.server_nature || [],
      "Détail de la nature dans BigFix": originalServer.nature_detail,
      "Nature du serveur dans L'inventaire": originalServer.natures_inventory,
      Uname: originalServer.uname || "_",
      Environnements: originalServer.environments || [],
      tenant: originalServer.tenant || null,
      to_decom: originalServer.to_decom || false,

      // AFFICHER TOUJOURS LES DEUX SOURCES DE SOLUTIONS (indépendamment de la logique ci-dessus)
      "Solutions dans Bigfix": originalServer.solutions || [],
      "Solutions dans l'inventaire":
        (originalServer.solutions_inventory || [])
          .map(s => String(s).trim())
          .filter(name => name && name !== "undefined")
      ,

      originalData: originalServer,

      // Utiliser les domaines, pôles, entités, admins et TAMs déterminés par la logique conditionnelle
      Domaine: domainsToUse,
      Pôle: polesToUse,
      Entities: entitiesToUse,
      "Admin Technique": deduplicateAdmins(allTechnicalAdmins),
      "Admin Fonctionnel": deduplicateAdmins(allFunctionalAdmins),
      TAM: deduplicateAdmins(allTams),
      dataSource: dataSource, // "inventory" | "bigfix" | "none"

      created_by: originalServer.created_by || "Non défini",
      updated_by: originalServer.updated_by || "Non défini",
      created_at: originalServer.created_at || "",
      updated_at: originalServer.updated_at || "",
      solutions_inventory: null,
      isCasa: undefined,
      service_type: null
    };

    return enhancedServer;
  });
}

export default function EnhancedServerDataTable({
  openModal,
  setOpenModal,
}: ServerDataTableProps) {
  const [dataKey, setDataKey] = useState(0);
  const [selectedRowData, setSelectedRowData] =
    useState<EnhancedServerView | null>(null);
  const [modalType, setModalType] = useState<string>("");
  const [servers, setServers] = useState<EnhancedServerView[] | null>([]);
  const [serverById, setServerById] = useState<ServerResponseDTO | null>(null);
  const [loading, setLoading] = useState(false);
  const [errorOperationMsg, setErrorOperationMsg] = useState<string | null>(
    null,
  );
  const [errorServiceMsg, setErrorServiceMsg] = useState<string | null>(null);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const [updatedServerId, setUpdatedServerId] = useState<number | null>(null);

  const [showComparison, setShowComparison] = useState(false);

  // Nouveaux états pour le déploiement
  const [selectedServers, setSelectedServers] = useState<GridRowSelectionModel>(
    [],
  );
  const [deployModalOpen, setDeployModalOpen] = useState(false);
  const [deploymentForm, setDeploymentForm] = useState<DeploymentFormData>({
    username: "",
    password: "",
    sudo_password: "",
  });
  const [deploymentResults, setDeploymentResults] = useState<
    DeploymentResult[]
  >([]);
  const [deploymentLoading, setDeploymentLoading] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [detailsModalOpen, setDetailsModalOpen] = useState(false);

  // États pour toutes les solutions (pour l'enrichissement des données)
  const [loadingAllSolutions] = useState<boolean>(false);

  // Nouvel état pour les statistiques d'environnement de l'API
  const [environmentStats] = useState<EnvironmentCount[]>([]);

  // Extended filter state with new filters
  const [filterState, setFilterState] = useState<FrontendServerFilterParams>(
    {},
  );

  const [selectedServerForBigFix, setSelectedServerForBigFix] = useState<EnhancedServerView | null>(null);
  const [bigFixModalOpen, setBigFixModalOpen] = useState(false);
  const [bigFixLoading, setBigFixLoading] = useState(false);
  const [bigFixResults, setBigFixResults] = useState<any>(null);

  // Fonction pour récupérer les données des serveurs
  const fetchServers = async () => {
    setLoading(true);
    setErrorOperationMsg(null);
    setErrorServiceMsg(null);
    try {
      await getHealthBackendData();

      // MODIFICATION : Charger tous les serveurs sans paramètres
      const allServers = await getAllServers();

      // Utiliser le mapper amélioré
      const processedServers = enhancedServerResToView(allServers);

      setDataKey(prev => prev + 1);
      setServers(processedServers);
      setErrorServiceMsg(null);
    } catch (err) {
      const error = err as AxiosError;
      console.error("Erreur lors de la récupération des serveurs :", err);
      if (error.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_core}`);
      else setErrorServiceMsg(`${service_failure} : ${service_core}`);
    } finally {
      setLoading(false);
    }
  };

  const refreshData = useCallback(() => {
    fetchServers();
  }, []);

  // FONCTION DE FILTRAGE
  const filterServers = (
    servers: EnhancedServerView[],
    filters: FrontendServerFilterParams,
  ): EnhancedServerView[] => {
    if (!servers) return [];

    const filtered = servers.filter((server) => {
      let shouldInclude = true;

      // Filtre de recherche globale
      if (filters.global_search && filters.global_search.trim() !== "") {
        const searchTerm = filters.global_search.toLowerCase().trim();

        // Fonction utilitaire pour normaliser et chercher dans n'importe quelle valeur
        const deepSearch = (value: any): boolean => {
          if (value === null || value === undefined) return false;
          if (typeof value === "string") {
            return value.toLowerCase().includes(searchTerm);
          }
          if (typeof value === "number" || typeof value === "boolean") {
            return value.toString().toLowerCase().includes(searchTerm);
          }
          if (Array.isArray(value)) {
            return value.some(deepSearch);
          }
          if (typeof value === "object") {
            return Object.values(value).some(deepSearch);
          }
          return false;
        };

        // Recherche dans TOUS les champs du serveur (même non visibles)
        const matchesGlobalSearch = deepSearch(server);

        if (!matchesGlobalSearch) {
          shouldInclude = false;
        }
      }

      // Filtre par type OS
      if (filters.os_type && filters.os_type !== "") {
        const serverOs = server["Type OS"];
        if (serverOs?.toString().toLowerCase() !== filters.os_type.toString().toLowerCase()) {
          shouldInclude = false;
        }
      }

      // Filtre par environnements
      if (filters.environments && filters.environments.length > 0) {
        const serverEnvs = server.Environnements || [];
        const hasSansEnvironnementFilter = filters.environments.includes("Sans environnement");

        let environmentMatch = false;

        if (hasSansEnvironnementFilter) {
          if (serverEnvs.length === 0) {
            environmentMatch = true;
          }
        } else {
          environmentMatch = filters.environments.some(env =>
            serverEnvs.includes(env as any)
          );
        }

        if (!environmentMatch) {
          shouldInclude = false;
        }
      }

      // Filtre par fiabilité
      if (filters.fiable !== undefined) {
        const serverFiabilite = Boolean(server.Fiabilité);
        const filterFiabilite = Boolean(filters.fiable);

        if (serverFiabilite !== filterFiabilite) {
          shouldInclude = false;
        }
      }

      // Filtre par solutions inventory
      if (
        filters.solutions_inventory &&
        filters.solutions_inventory.trim() !== ""
      ) {
        const solutionsInventory = server["Solutions dans l'inventaire"] || [];
        const searchSolution = filters.solutions_inventory.toLowerCase();

        const hasMatchingSolution = solutionsInventory.some((solution: any) => {
          if (typeof solution === "string") {
            return solution.toLowerCase().includes(searchSolution);
          } else if (solution && typeof solution === "object") {
            return solution.solution_name
              ?.toLowerCase()
              .includes(searchSolution);
          }
          return false;
        });

        if (!hasMatchingSolution) {
          shouldInclude = false;
        }
      }

      //  FILTRE : Conformité BigFix
      if (filters.bigfix_conformity && filters.bigfix_conformity.length > 0) {
        const serverStatus = getBigfixStatusFromRow(server);

        // Vérifie si le statut du serveur correspond à l'un des filtres sélectionnés
        const matchesBigFixFilter = filters.bigfix_conformity.some(
          (status) => status === serverStatus
        );

        if (!matchesBigFixFilter) {
          shouldInclude = false;
        }
      }

      return shouldInclude;
    });

    return filtered;
  };

  const handleFetchBigFixDataForServer = async (server: EnhancedServerView) => {
    setBigFixLoading(true);
    setBigFixResults(null);
    setSelectedServerForBigFix(server);
    setBigFixModalOpen(true);
    try {
      const hostnameToSend = server["Type OS"] === "AIX"
        ? server.Uname || server.Hostname
        : server.Hostname;

      const payload = {
        hostname: hostnameToSend,
        ips: Array.isArray(server["Adresses IP"])
          ? server["Adresses IP"]
          : [server["Adresses IP"]]
      };

      const response = await fetch(postBigFixDataApiUrl(), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      setBigFixResults({
        status: "success",
        data: data,
      });
    } catch (error) {
      console.error(`Erreur pour ${server.Hostname}:`, error);
      setBigFixResults({
        status: "error",
        error: error instanceof Error ? error.message : "Erreur inconnue",
      });
    } finally {
      setBigFixLoading(false);
    }
  };

  const handleCloseBigFixModal = () => {
    setBigFixModalOpen(false);
    setBigFixResults(null);
    setSelectedServerForBigFix(null);
  };

  const filteredServers = useMemo(() => {
    if (!servers) {
      console.log("Aucun serveur à filtrer");
      return [];
    }

    const result = filterServers(servers, filterState);

    return result;
  }, [servers, filterState]);

  useEffect(() => {
    fetchServers();
  }, []);

  useEffect(() => {
    if (updatedServerId) {
      const timer = setTimeout(() => {
        setUpdatedServerId(null);
      }, 3200); // Même durée que l'animation CSS

      return () => clearTimeout(timer);
    }
  }, [updatedServerId]);

  const getRowClassName = (params: any) => {
    const classes = [];

    if (params.row.to_decom) {
      classes.push('to-decom-row');
    }

    // Ajouter la classe pour la ligne modifiée
    if (updatedServerId === params.row.id) {
      classes.push('updated-row');
    }

    return classes.join(' ');
  };

  // Fonction pour formater les statistiques d'environnement pour l'affichage avec ordre spécifique
  const getFormattedEnvironmentStats = useMemo(() => {
    const formattedStats: Record<string, number> = {};

    environmentStats.forEach((stat) => {
      // Normaliser les noms d'environnement pour l'affichage
      let displayName = stat.environement_name;

      // Mapper les noms d'environnement si nécessaire
      switch (stat.environement_name.toLowerCase()) {
        case "production":
          displayName = "Production";
          break;
        case "préproduction":
        case "preproduction":
          displayName = "Préproduction";
          break;
        case "developpement":
          displayName = "Développement";
          break;
        case "formation":
          displayName = "Formation";
          break;
        case "recette":
          displayName = "Recette";
          break;
        case "integration":
          displayName = "Intégration";
          break;
        case "technique":
          displayName = "Technique";
          break;
        case "poc":
          displayName = "POC";
          break;
        case "environments undefined":
          displayName = "Sans environnement";
          break;
        default:
          displayName = stat.environement_name;
      }

      formattedStats[displayName] = stat.server_count;
    });

    // ordre pour les envs
    const orderedEnvironments = [
      "Production",
      "Préproduction",
      "Recette",
      "Développement",
      "Technique",
      "POC",
      "Intégration",
      "Formation",
      "Sans environnement",
    ];

    // Créer un objet ordonné
    const orderedStats: Record<string, number> = {};
    orderedEnvironments.forEach((env) => {
      if (formattedStats[env] !== undefined) {
        orderedStats[env] = formattedStats[env];
      }
    });

    Object.keys(formattedStats).forEach((env) => {
      if (!orderedEnvironments.includes(env)) {
        orderedStats[env] = formattedStats[env];
      }
    });

    return orderedStats;
  }, [environmentStats]);

  const handleExport = async () => {
    try {
      const token = localStorage.getItem("access_token");
      const response = await fetchWithAuth(export_AllServers(), {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);

      // Générer le timestamp au format AAAA-MM-JJ__HH-mm-ss
      const now = new Date();
      const timestamp = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}__${String(now.getHours()).padStart(2, "0")}-${String(now.getMinutes()).padStart(2, "0")}-${String(now.getSeconds()).padStart(2, "0")}`;

      const a = document.createElement("a");
      a.href = url;
      a.download = `signature_servers_export__${timestamp}.xlsx`;
      document.body.appendChild(a);
      a.click();
      a.remove();

      // Libérer l'URL pour éviter les fuites mémoire
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Erreur lors de l'export:", error);
      alert("Erreur lors de l'export. Veuillez réessayer.");
    }
  };


  const handleDisplayData = async (row: any, operationType: string) => {
    try {
      setLoading(true);
      setSelectedRowData(row);

      if (operationType === "Visualisation") {
        setDetailsModalOpen(true);
      } else {
        setModalType(operationType);
        setOpenModal(true);
      }

      await getHealthBackendData();
      const data = await getServerById(row.id);
      setServerById(data);
    } catch (error) {
      const err = error as AxiosError;
      console.error("Failed to fetch server data by ID:", error);
      if (err.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_core}`);
      else setErrorServiceMsg(`${service_failure} : ${service_core}`);
    } finally {
      setLoading(false);
    }
  };

  const handleAddManual = (section: string) => {
    setModalType(section);
    setSelectedRowData(null); // Réinitialiser
    setServerById(null); // Réinitialiser
    setOpenModal(true);
  };

  const handleCloseModal = () => {
    setModalType("");
    setSelectedRowData(null);
    setErrorOperationMsg(null);
    setOpenModal(false);
    setServerById(null);
  };

  const handleCloseDetailsModal = () => {
    setDetailsModalOpen(false);
    setSelectedRowData(null);
    setServerById(null);
  };

  // Fonction pour ouvrir le modal de déploiement
  const handleOpenDeployModal = () => {
    if (selectedServers.length === 0) {
      alert("Veuillez sélectionner au moins un serveur pour le déploiement.");
      return;
    }
    setDeployModalOpen(true);
    setShowResults(false);
    setDeploymentResults([]);
  };

  // Fonction pour fermer le modal de déploiement
  const handleCloseDeployModal = () => {
    setDeployModalOpen(false);
    setDeploymentForm({
      username: "",
      password: "",
      sudo_password: "",
    });
    setDeploymentResults([]);
    setShowResults(false);
  };

  // Fonction pour gérer le déploiement
  const handleDeployment = async () => {
    if (!deploymentForm.username || !deploymentForm.password) {
      alert("Veuillez remplir tous les champs obligatoires.");
      return;
    }

    setDeploymentLoading(true);

    try {
      // Récupérer les IPs des serveurs sélectionnés
      const selectedServerData =
        servers?.filter((server) => selectedServers.includes(server.id)) || [];

      const ips = selectedServerData.map((server) =>
        Array.isArray(server["Adresses IP"])
          ? server["Adresses IP"][0]
          : server["Adresses IP"],
      );

      // Préparer la payload
      const payload = {
        ip: ips,
        username: deploymentForm.username,
        password: deploymentForm.password,
        sudo_password: deploymentForm.sudo_password || deploymentForm.password,
      };
      const token = localStorage.getItem("access_token");
      // Appel API
      const response = await fetchWithAuth(
        postDeployMultipleSignatureApiUrl(),
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify(payload),
        },
      );

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const results: DeploymentResult[] = await response.json();
      setDeploymentResults(results);
      setShowResults(true);
    } catch (error) {
      console.error("Erreur lors du déploiement:", error);
      alert("Erreur lors du déploiement. Veuillez réessayer.");
    } finally {
      setDeploymentLoading(false);
      fetchServers();
    }
  };

  const handleExportSignature = async () => {
    setDeploymentLoading(true);

    try {
      // Récupérer les IPs des serveurs sélectionnés
      const selectedServerData =
        servers?.filter((server) => selectedServers.includes(server.id)) || [];

      const ips = selectedServerData.map((server) =>
        Array.isArray(server["Adresses IP"])
          ? server["Adresses IP"][0]
          : server["Adresses IP"],
      );

      // Préparer la payload
      const payload = {
        ip: ips,
      };
      const token = localStorage.getItem("access_token");
      // Appel API
      const response = await fetchWithAuth(postExportSignatureApiUrl(), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "signature_servers.zip"; // or any other filename you prefer
      document.body.appendChild(a);
      a.click();
      a.remove();

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
    } catch (error) {
      alert("Erreur lors de l'export. Veuillez réessayer., " + error);
    } finally {
      setDeploymentLoading(false);
      fetchServers();
    }
  };

  const hasActiveFilters = (filters: FrontendServerFilterParams): boolean => {
    return Object.entries(filters).some(([key, value]) => {
      if (key === "environments") return (value as string[]).length > 0;
      if (typeof value === "boolean") return value !== undefined;
      return !!value;
    });
  };



  const handleActionSubmit = async (data: ServerFormData) => {
    const dataServerResponseDTO = serverDataFormToRes(data);
    const solutionIdsForApi = (dataServerResponseDTO.solutions || []).map(
      (slt) => slt.solution_id,
    );
    const serverRequestDTO = serverResToReq(
      dataServerResponseDTO,
      solutionIdsForApi,
    );

    await getHealthBackendData();
    try {
      const deploy_payload: any = {};
      if (modalType === "Déploiment") {
        deploy_payload.ip = dataServerResponseDTO.ip_addresses[0];
        deploy_payload.username = data.login;
        deploy_payload.password = data.password;
        deploy_payload.sudo_password =
          data.sudo_password !== "" ? data.sudo_password : data.password;
      }

      switch (modalType) {
        case "Modification":
          await updateServer(
            selectedRowData ? selectedRowData.id : 0,
            serverRequestDTO,
            solutionIdsForApi,
          );

          // METTRE À JOUR UNIQUEMENT LE SERVEUR MODIFIÉ
          if (selectedRowData) {
            try {
              const serverData = await getServerById(selectedRowData.id);

              if (serverData) {
                const updatedServer = enhancedServerResToView([serverData])[0];

                setServers(prevServers => {
                  if (!prevServers) return prevServers;
                  return prevServers.map(server =>
                    server.id === selectedRowData.id ? updatedServer : server
                  );
                });

                // Afficher le message et colorer la ligne
                setSnackbarMessage("✅ Serveur modifié avec succès");
                setUpdatedServerId(selectedRowData.id);
                setSnackbarOpen(true);
              } else {
                console.log("Serveur non trouvé, rechargement complet");
                await fetchServers();
              }
            } catch (error) {
              console.error("Erreur mise à jour serveur:", error);
              await fetchServers();
            }
          }
          setSnackbarMessage("✅ Modification réussie");
          break;

        case "Ajout":
          await createSingleServer(serverRequestDTO);
          await fetchServers();
          setSnackbarMessage("✅ Serveur ajouté avec succès");
          setSnackbarOpen(true);
          break;

        case "Suppression":
          await deleteServer(selectedRowData ? selectedRowData.id : 0);
          if (selectedRowData) {
            setServers(prevServers => {
              if (!prevServers) return prevServers;
              return prevServers.filter(server => server.id !== selectedRowData.id);
            });
            setSnackbarMessage("✅ Serveur supprimé avec succès");
            setSnackbarOpen(true);
          }
          setSnackbarMessage("🗑️ Suppression confirmée");
          break;

        case "Déploiment":
          await deployServerSignature(
            selectedRowData ? selectedRowData.id : 0,
            deploy_payload,
          );
          if (selectedRowData) {
            try {
              const serverData = await getServerById(selectedRowData.id);

              if (serverData) {
                const deployedServer = enhancedServerResToView([serverData])[0];

                setServers(prevServers => {
                  if (!prevServers) return prevServers;
                  return prevServers.map(server =>
                    server.id === selectedRowData.id ? deployedServer : server
                  );
                });

                setSnackbarMessage("✅ Signature déployée avec succès");
                setUpdatedServerId(selectedRowData.id);
                setSnackbarOpen(true);
              } else {
                console.log("Serveur non trouvé après déploiement, rechargement complet");
                await fetchServers();
              }
            } catch (error) {
              console.error("Erreur mise à jour déploiement:", error);
              await fetchServers();
            }
          }
          setSnackbarMessage("🚀 Signature déployée");
          break;

        default:
          console.log("Operation not defined");
          await fetchServers();
      }

      setOpenModal(false);
      setSelectedRowData(null);
      setErrorOperationMsg(null);
    } catch (error) {
      const err = error as AxiosError<ErrorResponse>;

      if (err.status === 409) {
        setErrorOperationMsg(
          err.response?.data.message || "Undefined message error",
        );
      } else if (err.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_core}`);
      else setErrorServiceMsg(`${service_failure} : ${service_core}`);

      await fetchServers();
    }
  };

  const getPastelColorOS = (
    value: string,
  ): { bgColor: string; textColor: string } => {
    switch (value.toLowerCase()) {
      case "windows":
        return { bgColor: "#93C5FD", textColor: "#1E40AF" }; // bleu pastel
      case "linux":
        return { bgColor: "#a8e6b1", textColor: "#166534" }; // vert pastel
      case "macos":
        return { bgColor: "#F9A8D4", textColor: "#831843" }; // rose pastel
      case "aix":
        return { bgColor: "#fce38a", textColor: "#1E40AF" };
      default:
        return { bgColor: "#7fb2e6", textColor: "#000000" };
    }
  };

  const getPastelColorSignature = (
    value: string,
  ): { bgColor: string; textColor: string } => {
    switch (value.toLowerCase()) {
      case "signé":
        return { bgColor: "#a8e6b1", textColor: "#064E3B" }; // vert pastel
      case "expiré":
        return { bgColor: "#FEE2E2", textColor: "#DC2626" }; // Rouge clair
      case "non signé":
        return { bgColor: "#e2e2e2", textColor: "#000000" }; // rouge rosé
      case "anonyme":
        return { bgColor: "#e2e2e2", textColor: "#000000" }; // rouge rosé
      default:
        return { bgColor: "#C4B5FD", textColor: "#5B21B6" }; // violet pastel
    }
  };

  const getBigfixStatusColor = (status: string | null | undefined) => {
    if (!status) return { bg: "#F5F3FF", color: "#8B5CF6" }; // Mauve par défaut

    const s = status.trim().toLowerCase();

    if (s.includes("non déclaré") || s.includes("undeclared")) {
      return { bg: "#FF9800", color: "#FFFFFF" }; // Orange
    }
    if (s.includes("non conforme") || s.includes("uncompliant")) {
      return { bg: "#B0BEC5", color: "#37474F" }; // Gris
    }

    // Conforme ou inconnu → Mauve (couleur par défaut)
    return { bg: "#F5F3FF", color: "#8B5CF6" };
  };

  const getPastelColorDomain = (): { bgColor: string; textColor: string } => {
    return { bgColor: "#E0F2FE", textColor: "#0369A1" }; // Bleu ciel pastel
  };

  const getPastelColorPole = (): { bgColor: string; textColor: string } => {
    return { bgColor: "#F0FDF4", textColor: "#166534" }; // Vert menthe pastel
  };

  const getPastelColorSolutionInventory = (): {
    bgColor: string;
    textColor: string;
  } => {
    return { bgColor: "#FEF3C7", textColor: "#92400E" }; // Jaune pastel
  };

  const getPastelColorEntity = (): { bgColor: string; textColor: string } => {
    return { bgColor: "#DBEAFE", textColor: "#1E40AF" }; // Bleu clair pastel
  };

  const getPastelColorAdmin = (
    type: string,
  ): { bgColor: string; textColor: string } => {
    switch (type) {
      case "technical":
        return { bgColor: "#D1FAE5", textColor: "#059669" }; // Vert clair
      case "functional":
        return { bgColor: "#DBEAFE", textColor: "#2563EB" }; // Bleu clair
      case "tam":
        return { bgColor: "#FEE2E2", textColor: "#DC2626" }; // Rouge clair
      default:
        return { bgColor: "#F3F4F6", textColor: "#374151" }; // Gris
    }
  };

  const getPastelColorFiabilite = (
    value: boolean,
  ): { bgColor: string; textColor: string } => {
    return value
      ? { bgColor: "#D1FAE5", textColor: "#065F46" } // Vert pour fiable
      : { bgColor: "#FEE2E2", textColor: "#991B1B" }; // Rouge pour non fiable
  };

  const getResponsiveWidth = (key: string) => {
    const screenWidth = window.innerWidth;

    const tableColumns = [
      "Adresses IP",
      "Solutions dans l'inventaire",
      "Admin Technique",
      "Admin Fonctionnel",
      "TAM",
      "Entities",
    ];

    // Nouvelles colonnes hardware
    const hardwareColumns = ["CPU", "RAM", "Stockage", "Disques"];

    if (screenWidth < 600) {
      if (tableColumns.includes(key)) return 75;
      else if (hardwareColumns.includes(key)) return 70;
      else if (key === "Type OS") return 65;
      else if (key === "Fiabilité") return 80;
      return 80;
    } else if (screenWidth < 960) {
      if (tableColumns.includes(key)) return 140;
      else if (hardwareColumns.includes(key)) return 90;
      else if (key === "Type OS") return 65;
      else if (key === "Fiabilité") return 100;
      return 100;
    } else {
      if (key === tableColumns[0] || key === tableColumns[1]) return 160;
      else if (
        key === tableColumns[2] ||
        key === tableColumns[3] ||
        key === tableColumns[4] ||
        key === tableColumns[5]
      )
        return 180;
      else if (hardwareColumns.includes(key)) return 120;
      else if (key === "Type OS") return 65;
      else if (key === "Fiabilité") return 120;
      return 150;
    }
  };

  function valueContent(value: any, key: string, row: EnhancedServerView) {
    const isFromBigFix = row.dataSource === "bigfix";
    const dataSource = row.dataSource;
    const colors = getDataSourceColor(dataSource);
    const isToDecom = row.to_decom;

    // Déterminer si cette colonne doit avoir le style désactivé (uniquement pour les champs spécifiques)
    const shouldDisableStyle = isFromBigFix && [
      "Domaine",
      "Pôle",
      "Entities",
      "Admin Technique",
      "Admin Fonctionnel",
      "TAM"
    ].includes(key);

    // Gérer les valeurs null/undefined
    if (value === null || value === undefined) {
      return (
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-start",
            height: "100%",
            pl: 1,
            fontStyle: "italic",
            color: "#9CA3AF",
          }}
        >
          Non défini
        </Box>
      );
    }

    // Pour les tableaux vides
    if (Array.isArray(value) && value.length === 0) {
      return (
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-start",
            height: "100%",
            pl: 1,
            fontStyle: "italic",
            color: "#9CA3AF",
          }}
        >
          Aucune donnée
        </Box>
      );
    }

    // Pour les chaînes vides
    if (typeof value === "string" && value.trim() === "") {
      return (
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-start",
            height: "100%",
            pl: 1,
            fontStyle: "italic",
            color: "#9CA3AF",
          }}
        >
          Non défini
        </Box>
      );
    }

    const baseStyle = {
      backgroundColor: isToDecom ? "#FFE4E6" : (shouldDisableStyle ? "#f5f5f5" : colors.bgColor),
      borderLeft: `4px solid ${isToDecom ? "#EF4444" : (shouldDisableStyle ? "#d9d9d9" : colors.borderColor)}`,
      height: "100%",
      width: "100%",
      display: "flex",
      alignItems: "center",
      paddingLeft: "8px",
      opacity: shouldDisableStyle ? 0.7 : 1,
    };

    if (key === "Hostname") {
      return (
        <Box
          sx={{
            ...baseStyle,
            backgroundColor: row.isCasa ? "#fff7e6" : colors.bgColor,
            borderLeft: `4px solid ${row.isCasa ? "#ffd666" : colors.borderColor}`,
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "flex-start",
            height: "100%",
            pl: 1,
          }}
        >
          <Typography variant="body2" sx={{ fontWeight: 600 }}>
            {value}
          </Typography>

          {/* Afficher le uname uniquement pour AIX, toujours */}
          {row["Type OS"] === "AIX" && (
            <Typography
              variant="caption"
              sx={{
                color: pastelTheme.textSecondary,
                fontStyle: "italic",
                display: "block",
                mt: 0.5,
              }}
            >
              uname: {row["Uname"] || "_"}
            </Typography>
          )}

          {row.isCasa && (
            <Chip
              label="CASA"
              size="small"
              sx={{
                mt: 0.5,
                fontSize: "0.6rem",
                height: "20px",
              }}
            />
          )}
        </Box>
      );
    }

    if (typeof value === "object" && !Array.isArray(value)) {
      return (
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-start",
            height: "100%",
            pl: 1,
          }}
        >
          <CustomTooltip title={JSON.stringify(value, null, 2)}>
            <span>{Object.values(value).join(", ")}</span>
          </CustomTooltip>
        </Box>
      );
    }

    if (key === "Type OS") {
      const colors = getPastelColorOS(value);
      return (
        <Box sx={commonArrayStyles}>
          <Chip
            key={value}
            label={value}
            size="small"
            sx={{
              backgroundColor: colors.bgColor,
              color: colors.textColor,
              fontWeight: 600,
              fontSize: "0.75rem",
            }}
          />
        </Box>
      );
    }

    if (key === "Signature") {
      const colors = getPastelColorSignature(value);
      return (
        <Box sx={commonArrayStyles}>
          <Chip
            key={value}
            label={value}
            size="small"
            sx={{
              backgroundColor: colors.bgColor,
              color: colors.textColor,
              fontWeight: 600,
              fontSize: "0.75rem",
            }}
          />
        </Box>
      );
    }

    if (key === "Fiabilité") {
      const colors = getPastelColorFiabilite(value);
      return (
        <Box sx={commonArrayStyles}>
          <Chip
            key={value}
            label={value ? "Fiable" : "Non fiable"}
            size="small"
            sx={{
              backgroundColor: colors.bgColor,
              color: colors.textColor,
              fontWeight: 600,
              fontSize: "0.75rem",
            }}
          />
        </Box>
      );
    }

    if (Array.isArray(value)) {
      const commonArrayStyles = {
        display: "flex",
        alignItems: "center",
        justifyContent: "flex-start",
        gap: 0.5,
        flexWrap: "wrap",
        height: "100%",
        py: 1,
        pl: 1,
      };

      // Handle "Domaine", "Pôle", "Entities" - DÉSACTIVER LE STYLE SI BIGFIX
      if (key === "Domaine" || key === "Pôle" || key === "Entities") {
        let colors: { bgColor: string; textColor: string };
        if (key === "Domaine") colors = getPastelColorDomain();
        if (key === "Pôle") colors = getPastelColorPole();
        if (key === "Entities") colors = getPastelColorEntity();


        return (
          <Box sx={commonArrayStyles}>
            {value !== null && value.length > 1 && (
              <Chip
                label={value.length.toString()}
                size="small"
                sx={{
                  backgroundColor: "#EEF2FF",
                  color: "#6366F1",
                  fontWeight: 600,
                  fontSize: "0.75rem",
                }}
              />
            )}
            {value.map((item, index) => (
              <Chip
                key={index}
                label={String(item)}
                size="small"
                sx={{
                  backgroundColor: shouldDisableStyle ? "#f5f5f5" : colors.bgColor,
                  color: shouldDisableStyle ? "#6B7280" : colors.textColor,
                  fontWeight: 600,
                  fontSize: "0.75rem",
                }}
              />
            ))}
          </Box>
        );
      }

      // Handle Admin columns - DÉDOUBLONNÉS DÉJÀ DANS LES DONNÉES
      if (key === "Admin Technique" || key === "Admin Fonctionnel" || key === "TAM") {
        const adminType = key === "Admin Technique" ? "technical" : key === "Admin Fonctionnel" ? "functional" : "tam";
        const colors = getPastelColorAdmin(adminType);

        // Préparer le contenu du tooltip avec les emails
        const tooltipContent = value
          .map((admin: any) => {
            const name = typeof admin === "object" && admin !== null && "name" in admin
              ? admin.name
              : String(admin);
            const email = typeof admin === "object" && admin !== null && "email" in admin
              ? admin.email
              : "";

            const displayEmail = email && email.trim() !== "" ? email : "Email non disponible";
            return `${name}: ${displayEmail}`;
          })
          .join('\n');

        return (
          <Box sx={commonArrayStyles}>
            {/* Tooltip pour le compteur - UTILISE value.length QUI EST DÉJÀ DÉDOUBLONNÉ */}
            {value !== null && value.length > 1 && (
              <CustomTooltip title={tooltipContent}>
                <Chip
                  label={value.length.toString()} // ✅ Ce nombre est maintenant le nombre d'admins uniques
                  size="small"
                  sx={{
                    backgroundColor: "#EEF2FF",
                    color: "#6366F1",
                    fontWeight: 600,
                    fontSize: "0.75rem",
                    cursor: "help",
                  }}
                />
              </CustomTooltip>
            )}

            {/* Tooltip pour chaque admin - LES DONNÉES SONT DÉJÀ DÉDOUBLONNÉES */}
            {value.map((item: any, index: number) => {
              const name = typeof item === "object" && item !== null && "name" in item
                ? item.name
                : String(item);
              const email = typeof item === "object" && item !== null && "email" in item
                ? item.email
                : "";

              const displayEmail = email && email.trim() !== "" ? email : "Email non disponible";
              const tooltipTitle = `${name}: ${displayEmail}`;

              return (
                <CustomTooltip key={index} title={tooltipTitle}>
                  <Chip
                    label={name}
                    size="small"
                    sx={{
                      backgroundColor: shouldDisableStyle ? "#f5f5f5" : colors.bgColor,
                      color: shouldDisableStyle ? "#6B7280" : colors.textColor,
                      fontWeight: 600,
                      fontSize: "0.75rem",
                      cursor: "help",
                      maxWidth: "120px",
                      '& .MuiChip-label': {
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                      }
                    }}
                  />
                </CustomTooltip>
              );
            })}
          </Box>
        );
      }

     if (key === "Adresses IP") {
  return (
    <Box sx={commonArrayStyles}>
      {value !== null && value.length > 1 && (
        <Chip
          label={value.length.toString()}
          size="small"
          sx={{
            backgroundColor: "#EEF2FF",
            color: "#6366F1",
            fontWeight: 600,
            fontSize: "0.75rem",
          }}
        />
      )}

      {/* Bouton pour copier toutes les IPs */}
      {Array.isArray(value) && value.length > 0 && (
        <Tooltip title={`Copier toutes les IPs (${value.length})`}>
          <IconButton
            size="small"
            onClick={(e) => {
              e.stopPropagation();
              const ipsToCopy = value.join(", ");
              navigator.clipboard.writeText(ipsToCopy);

              setSnackbarMessage(`📋 ${value.length} IP(s) copiée(s)`);
              setSnackbarOpen(true);
            }}
            sx={{
              padding: 0.5,
              width: 24,
              height: 24,
              backgroundColor: "#F3F4F6",
              "&:hover": {
                backgroundColor: "#E5E7EB",
              },
              marginLeft: 0.5,
            }}
          >
            <ContentCopyIcon fontSize="small" />
          </IconButton>
        </Tooltip>
      )}

      {/* Afficher chaque IP individuellement - TAILLE AUGMENTÉE */}
      {value.map((item, index) => (
        <Box
          key={index}
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 0.5,
          }}
        >
          <Tooltip title={`Copier: ${item}`}>
            <Chip
              label={String(item)}
              size="small"
              variant="outlined"
              onClick={(e) => {
                e.stopPropagation();
                navigator.clipboard.writeText(String(item));

                setSnackbarMessage(`📋 IP copiée : ${item}`);
                setSnackbarOpen(true);
              }}
              sx={{
                backgroundColor: "#F8FAFC",
                borderColor: "#D1D5DB",
                fontSize: "0.85rem", // Augmenté de 0.75rem à 0.85rem
                cursor: "pointer",
                height: "28px", // Hauteur augmentée
                "& .MuiChip-label": {
                  paddingLeft: "10px", // Padding horizontal augmenté
                  paddingRight: "10px",
                },
                "&:hover": {
                  backgroundColor: "#F3F4F6",
                  borderColor: "#9CA3AF",
                  transform: "scale(1.02)", // Effet de zoom léger
                },
              }}
            />
          </Tooltip>
        </Box>
      ))}
    </Box>
  );
}

      // Handle "Nature du serveur dans BigFix", "Adresses IP", "Natures d'inventaire" - STYLE NORMAL
      if (
        key === "Nature du serveur dans BigFix" ||

        key === "Natures d'inventaire"
      ) {
        return (
          <Box sx={commonArrayStyles}>
            {value !== null && value.length > 1 && (
              <Chip
                label={value.length.toString()}
                size="small"
                sx={{
                  backgroundColor: "#EEF2FF",
                  color: "#6366F1",
                  fontWeight: 600,
                  fontSize: "0.75rem",
                }}
              />
            )}
            {value.map((item, index) => (
              <Chip
                key={index}
                label={String(item)}
                size="small"
                variant="outlined"
                sx={{
                  backgroundColor: "#F8FAFC",
                  borderColor: "#D1D5DB",
                  fontSize: "0.75rem",
                }}
              />
            ))}
          </Box>
        );
      }

      if (key === "Environnements") {
        return (
          <Box sx={commonArrayStyles}>
            {value.map((item, index) => (
              <Chip
                key={index}
                label={String(item)}
                size="small"
                sx={{
                  backgroundColor: getBadgeColorEnvironment(item),
                  color: "#000000",
                  fontWeight: 600,
                  fontSize: "0.75rem",
                }}
              />
            ))}
          </Box>
        );
      }

      // Special handling for "Solutions" (BigFix) and "Solutions dans l'inventaire" - STYLE NORMAL
      // === SOLUTIONS BIGFIX (avec solution_type) ===
      if (key === "Solutions dans Bigfix") {
        return (
          <Box sx={commonArrayStyles}>
            {value.map((item: any, index: number) => {
              const displayName = item.solution_name || "Solution sans nom";
              const type = item.solution_type || "Solution applicative";
              return (
                <CustomTooltip key={index} title={`${displayName} (${type})`}>
                  <Chip
                    label={displayName}
                    size="small"
                    sx={{
                      backgroundColor: "#f3e5f5",
                      color: "#6a1b9a",
                      fontWeight: 600,
                      fontSize: "0.75rem",
                    }}
                  />
                </CustomTooltip>
              );
            })}
          </Box>
        );
      }

      // === SOLUTIONS INVENTAIRE (nom uniquement) ===
      if (key === "Solutions dans l'inventaire") {
        const colors = getPastelColorSolutionInventory();
        return (
          <Box sx={commonArrayStyles}>
            {Array.isArray(value) && value.length > 0 ? (
              value.map((item, index) => (
                <Chip
                  key={index}
                  label={String(item).trim()}
                  size="small"
                  sx={{
                    backgroundColor: colors.bgColor,
                    color: colors.textColor,
                    fontWeight: 600,
                    fontSize: "0.75rem",
                  }}
                />
              ))
            ) : (
              <Typography variant="caption" sx={{ color: "#9CA3AF", fontStyle: "italic" }}>
                Aucune solution
              </Typography>
            )}
          </Box>
        );
      }

      // Fallback for any other array type
      return (
        <Box sx={commonArrayStyles}>
          {value.length > 1 && (
            <Chip
              label={value.length.toString()}
              size="small"
              sx={{
                backgroundColor: "#EEF2FF",
                color: "#6366F1",
                fontWeight: 600,
              }}
            />
          )}
          {value.map((item, index) => (
            <Chip
              key={index}
              label={String(item)}
              size="small"
              variant="outlined"
            />
          ))}
        </Box>
      );
    }

    return (
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "flex-start",
          height: "100%",
          pl: 1,
        }}
      >
        <CustomTooltip title={value !== null && value}>
          <Typography variant="body2" sx={{ color: "#374151" }}>
            {value}
          </Typography>
        </CustomTooltip>
      </Box>
    );
  }

  // Fonction pour formater les valeurs hardware
  const formatHardwareValue = (value: number, type: 'cpu' | 'ram' | 'storage' | 'disk') => {
    if (!value || value === 0) return "N/A";

    switch (type) {
      case 'cpu':
        return `${value} CPU`;
      case 'ram':
        return `${Math.round(value / 1024)} Go`; // Conversion MiB to GiB
      case 'storage':
      case 'disk':
        return `${Math.round(value / 1024 / 1024 / 1024)} Go`; // Conversion bytes to GiB
      default:
        return `${value}`;
    }
  };

  const columns = useMemo(() => {
    if (servers && servers.length === 0) return [];

    const actionColumn = {
      field: "actions",
      headerName: "Actions",
      width: 250, // Augmenter la largeur pour accueillir le nouveau bouton
      sortable: false,
      filterable: false,
      renderCell: (params: any) => {
        const isToDecom = params.row.to_decom;
        const hasPermission = hasDecommissionPermission(params.row);
        const isServerReliable = params.row.Fiabilité;

        return (
          <Box
            sx={{
              display: "flex",
              gap: 1,
              alignItems: "center",
              justifyContent: "center",
              height: "100%",
            }}
          >
            {/* Bouton BigFix */}
            <CustomTooltip
              title={
                <Box sx={{ textAlign: "center", p: 0.5 }}>
                  <Typography variant="subtitle2" sx={{ fontWeight: 600, fontSize: "0.75rem" }}>
                    BigFix
                  </Typography>
                  <Chip
                    label={(() => {
                      const status = getBigfixStatusFromRow(params.row);
                      return status || "Inconnu";
                    })()}
                    size="small"
                    sx={{
                      mt: 0.5,
                      fontSize: "0.65rem",
                      height: 18,
                      fontWeight: 600,
                      ...(() => {
                        const status = getBigfixStatusFromRow(params.row);
                        const colors = getBigfixStatusColor(status?.toString());
                        return {
                          backgroundColor: colors.bg,
                          color: colors.color,
                        };
                      })(),
                    }}
                  />
                </Box>
              }

              componentsProps={{
                tooltip: {
                  sx: {
                    bgcolor: "white",
                    border: "1px solid #E5E7EB",
                    borderRadius: 2,
                    boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
                    p: 1,
                  },
                },
              }}

            >
              <span>
                <IconButton
                  onClick={(e) => {
                    e.stopPropagation();
                    const status = getBigfixStatusFromRow(params.row);
                    if (status !== BigfixStatus.UNDECLARED) {
                      handleFetchBigFixDataForServer(params.row);
                    }
                  }}
                  disabled={getBigfixStatusFromRow(params.row) === BigfixStatus.UNDECLARED}
                  sx={{
                    padding: 0.5,
                    borderRadius: "12px",
                    transition: "all 0.2s ease",
                    width: 32,
                    height: 32,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    ...(() => {
                      const status = getBigfixStatusFromRow(params.row);
                      const colors = getBigfixStatusColor(status?.toString());

                      if (status === BigfixStatus.UNDECLARED) {
                        return {
                          backgroundColor: "#F3F4F6",
                          color: "#9CA3AF",
                          cursor: "not-allowed",
                          "&:hover": {
                            backgroundColor: "#F3F4F6",
                            transform: "none",
                          },
                          "& .MuiSvgIcon-root": { opacity: 0.5 },
                        };
                      }

                      return {
                        backgroundColor: colors.bg,
                        color: colors.color,
                        "&:hover": {
                          filter: "brightness(0.92)",
                          transform: "scale(1.08)",
                        },
                        "& .MuiSvgIcon-root": {
                          fontSize: "1rem",
                        },
                      };
                    })(),
                  }}
                  size="small"
                >
                  <SiBeatsbydre fontSize="small" />
                </IconButton>
              </span>
            </CustomTooltip>

            {/* Bouton Visualisation */}
            <IconButton
              onClick={() => handleDisplayData(params.row, "Visualisation")}
              sx={actionIconStyles.view}
              size="small"
            >
              <VisibilityIcon fontSize="small" />
            </IconButton>

            {/* Bouton Modification - désactivé si to_decom */}
            <IconButton
              onClick={() => handleDisplayData(params.row, "Modification")}
              sx={{
                ...actionIconStyles.edit,
                ...(isToDecom && {
                  opacity: 0.5,
                  cursor: "not-allowed",
                  "&:hover": {
                    backgroundColor: "#FFFBEB",
                    color: "#F59E0B",
                  }
                })
              }}
              size="small"
              disabled={isToDecom}
            >
              <EditIcon fontSize="small" />
            </IconButton>

            {/* Bouton Suppression */}
            <DeleteServerButton
              row={params.row}
              onDeleteSuccess={refreshData}
              onShowSnackbar={(message) => {
                setSnackbarMessage(message);
                setSnackbarOpen(true);
              }}
            />

            {/* Bouton Decom */}
            <DecomServerButton
              row={params.row}
              disabled={isToDecom || !hasPermission}
              onSuccess={() => {
                refreshData();
                setSnackbarMessage("🔄 Décommission en cours");
                setSnackbarOpen(true);
              }}
              tooltip={
                !isServerReliable
                  ? "Le serveur n'est pas fiable - Décommissionnement impossible"
                  : !hasPermission
                    ? "Vous n'avez pas les permissions nécessaires (TAM ou Admin Technique requis)"
                    : isToDecom
                      ? "Décommissionnement déjà en cours"
                      : undefined
              }
            />
          </Box>
        );
      },
    };

    // Define the desired column order
    const columnOrder = [
      "Hostname",
      "Signature",
      "Fiabilité",
      "Adresses IP",
      "Type OS",
      "Détail OS",
      "Nature du serveur dans BigFix",
      "Détail de la nature dans BigFix",
      "Nature du serveur dans L'inventaire",
      "Uname",
      "Environnements",
      "Solutions dans Bigfix",
      "Déclaré dans Bigfix",
      "Déclaré dans Itop",
      "Solutions dans l'inventaire",
      "Domaine",
      "Pôle",
      "Entities",
      "Admin Technique",
      "Admin Fonctionnel",
      "TAM",
      "CPU",
      "RAM",
      "Stockage",
      "Disques",
      "created_by",
      "updated_by",
      "created_at",
      "updated_at",
    ];

    const dataColumns = columnOrder
      .filter((key) => key !== "id") // Filter out 'id' as it's used for getRowId
      .map((key) => {
        if (key === "Déclaré dans Bigfix") {
          return {
            field: key,
            headerName: key,
            description: key,
            width: 150,
            renderCell: (params: any) => (
              <Box sx={commonArrayStyles}>
                {params.row["Solutions dans Bigfix"].map(
                  (solution: any, index: number) => (
                    <Chip
                      key={index}
                      label={solution.declarted_on_bigfix ? "Oui" : "Non"}
                      size="small"
                      sx={{
                        backgroundColor: solution.declarted_on_bigfix
                          ? "#a8e6b1"
                          : "#FCA5A5",
                        color: solution.declarted_on_bigfix
                          ? "#064E3B"
                          : "#991B1B",
                        fontWeight: 600,
                        fontSize: "0.75rem",
                      }}
                    />
                  ),
                )}
              </Box>
            ),
          };
        }

        if (key === "CPU") {
          return {
            field: key,
            headerName: "CPU",
            description: "Nombre de cores CPU",
            width: 100,
            renderCell: (params: any) => {
              const specs = params.row.originalData?.specs;
              const cpuCount = specs?.cpu?.count;

              if (!cpuCount) {
                return (
                  <Box sx={commonArrayStyles}>
                    <Typography variant="caption" sx={{ color: "#9CA3AF", fontStyle: "italic" }}>
                      N/A
                    </Typography>
                  </Box>
                );
              }

              const colors = getHardwareColor('cpu');
              return (
                <Box sx={commonArrayStyles}>
                  <Chip
                    label={formatHardwareValue(cpuCount, 'cpu')}
                    size="small"
                    sx={{
                      backgroundColor: colors.bgColor,
                      color: colors.textColor,
                      fontWeight: 600,
                      fontSize: "0.75rem",
                    }}
                  />
                </Box>
              );
            },
            sortable: true,
          };
        }

        if (key === "RAM") {
          return {
            field: key,
            headerName: "RAM",
            description: "Mémoire RAM",
            width: 100,
            renderCell: (params: any) => {
              const specs = params.row.originalData?.specs;
              const ramSize = specs?.memory?.size_MiB;

              if (!ramSize) {
                return (
                  <Box sx={commonArrayStyles}>
                    <Typography variant="caption" sx={{ color: "#9CA3AF", fontStyle: "italic" }}>
                      N/A
                    </Typography>
                  </Box>
                );
              }

              const colors = getHardwareColor('ram');
              return (
                <Box sx={commonArrayStyles}>
                  <Chip
                    label={formatHardwareValue(ramSize, 'ram')}
                    size="small"
                    sx={{
                      backgroundColor: colors.bgColor,
                      color: colors.textColor,
                      fontWeight: 600,
                      fontSize: "0.75rem",
                    }}
                  />
                </Box>
              );
            },
            sortable: true,
          };
        }

        if (key === "Stockage") {
          return {
            field: key,
            headerName: "Stockage",
            description: "Stockage total",
            width: 120,
            renderCell: (params: any) => {
              const specs = params.row.originalData?.specs;
              const storageSize = specs?.storage;

              if (!storageSize) {
                return (
                  <Box sx={commonArrayStyles}>
                    <Typography variant="caption" sx={{ color: "#9CA3AF", fontStyle: "italic" }}>
                      N/A
                    </Typography>
                  </Box>
                );
              }

              const colors = getHardwareColor('storage');
              return (
                <Box sx={commonArrayStyles}>
                  <Chip
                    label={formatHardwareValue(storageSize, 'storage')}
                    size="small"
                    sx={{
                      backgroundColor: colors.bgColor,
                      color: colors.textColor,
                      fontWeight: 600,
                      fontSize: "0.75rem",
                    }}
                  />
                </Box>
              );
            },
            sortable: true,
          };
        }

        if (key === "Disques") {
          return {
            field: key,
            headerName: "Disques",
            description: "Détails des disques",
            width: 150,
            renderCell: (params: any) => {
              const specs = params.row.originalData?.specs;
              const disks = specs?.disks;

              if (!disks || !Array.isArray(disks) || disks.length === 0) {
                return (
                  <Box sx={commonArrayStyles}>
                    <Typography variant="caption" sx={{ color: "#9CA3AF", fontStyle: "italic" }}>
                      N/A
                    </Typography>
                  </Box>
                );
              }

              const colors = getHardwareColor('disk');
              return (
                <Box sx={commonArrayStyles}>
                  <CustomTooltip
                    title={
                      <Box>
                        <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 1 }}>
                          Détails des disques:
                        </Typography>
                        {disks.map((disk: any, index: number) => (
                          <Typography key={index} variant="body2">
                            {disk.label}: {formatHardwareValue(disk.capacity, 'disk')}
                          </Typography>
                        ))}
                      </Box>
                    }
                  >
                    <Chip
                      label={`${disks.length} disque(s)`}
                      size="small"
                      sx={{
                        backgroundColor: colors.bgColor,
                        color: colors.textColor,
                        fontWeight: 600,
                        fontSize: "0.75rem",
                        cursor: "help",
                      }}
                    />
                  </CustomTooltip>
                </Box>
              );
            },
            sortable: true,
          };
        }

        if (key === "Déclaré dans Itop") {
          return {
            field: key,
            headerName: key,
            description: key,
            width: 150,
            renderCell: (params: any) => (
              <Box sx={commonArrayStyles}>
                {params.row["Solutions dans Bigfix"].map(
                  (solution: any, index: number) => (
                    <Chip
                      key={index}
                      label={solution.declarted_on_itop ? "Oui" : "Non"}
                      size="small"
                      sx={{
                        backgroundColor: solution.declarted_on_itop
                          ? "#a8e6b1"
                          : "#FCA5A5",
                        color: solution.declarted_on_itop
                          ? "#064E3B"
                          : "#991B1B",
                        fontWeight: 600,
                        fontSize: "0.75rem",
                      }}
                    />
                  ),
                )}
              </Box>
            ),
          };
        }

        return {
          field: key,
          headerName: key,
          description: key,
          width: getResponsiveWidth(key),
          fontSize: "2rem",
          renderCell: (params: any) => {
            return (
              <Box sx={{ width: "100%", height: "100%" }}>
                {valueContent(params.value, params.field, params.row)}
              </Box>
            );
          },
          sortable: true,
          sortComparator: (v1: string | [], v2: string | []) => {
            if (Array.isArray(v1) && Array.isArray(v2)) {
              return v1.join(", ").localeCompare(v2.join(", "));
            }
            if (typeof v1 === "string" && typeof v2 === "string") {
              return v1.localeCompare(v2);
            }
            return 0;
          },
        };
      });

    return [actionColumn, ...dataColumns];
  }, [servers, refreshData]);

  const defaultVisibleColumns: Record<string, boolean> = {
    actions: true,
    Hostname: true,
    "Adresses IP": true,
    "Type OS": true,
    "Détail OS": true,
    "Nature du serveur dans BigFix": true,
    "Détail de la nature dans BigFix": false,
    "Nature du serveur dans L'inventaire": true,
    Uname: false,
    "Déclaré dans Bigfix": false,
    "Déclaré dans Itop": false,
    Environnements: true,
    Signature: true,
    "Solutions dans Bigfix": true,
    "Solutions dans l'inventaire": true,
    Domaine: true,
    Pôle: true,
    Entities: true,
    "Admin Technique": true,
    "Admin Fonctionnel": true,
    TAM: true,
    "CPU": false,
    "RAM": false,
    "Stockage": false,
    "Disques": false,
    Fiabilité: true,
    created_by: false,
    updated_by: false,
    created_at: false,
    updated_at: false,
  };

  // Initialisation de la visibilité des colonnes
  const [columnVisibility, setColumnVisibility] = useState(
    defaultVisibleColumns,
  );

  if (loading || loadingAllSolutions)
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "100vh",
        }}
      >
        <CircularProgress />
      </Box>
    );
  else if (errorServiceMsg !== null) {
    return (
      <ThemeProvider theme={modernPastelTheme}>
        <Fade in={true} timeout={500}>
          <Paper
            elevation={2}
            sx={{
              p: 4,
              textAlign: "center",
              borderRadius: 3,
              backgroundColor: "#FEF2F2",
              border: "1px solid #FECACA",
            }}
          >
            <Typography
              variant="h6"
              sx={{
                color: "#DC2626",
                fontWeight: 600,
              }}
            >
              {errorServiceMsg}
            </Typography>
          </Paper>
        </Fade>
      </ThemeProvider>
    );
  } else
    return (
      <ThemeProvider theme={modernPastelTheme}>
        <Fade in={true} timeout={800}>
          <Box sx={{ p: 2 }}>
            {/* En-tête avec gradient */}
            <Paper
              elevation={0}
              sx={{
                background: "linear-gradient(135deg, #667eea 0%, #D6D7FC 100%)",
                borderRadius: 0.4,
                p: 3,
                mb: 3,
                color: "white",
              }}
            >
              <Box
                display="flex"
                justifyContent="space-between"
                alignItems="flex-start"
              >
                <Box sx={{ flex: 1 }}>
                  <Typography variant="h4" sx={{ fontWeight: 700, mb: 1 }}>
                    Gestion des Serveurs
                  </Typography>
                  <Typography variant="body1" sx={{ opacity: 0.9, mb: 2 }}>
                    {servers ? servers.length : 0} serveur(s) •{" "}
                    {selectedServers.length} sélectionné(s)
                  </Typography>

                  {/* Statistiques d'environnement */}
                  <Box
                    sx={{
                      display: "flex",
                      flexWrap: "wrap",
                      gap: 1,
                      alignItems: "center",
                    }}
                  >
                    {Object.entries(getFormattedEnvironmentStats).map(
                      ([env, count]) => (
                        <Chip
                          key={env}
                          label={`${env}: ${count}`}
                          size="small"
                          sx={{
                            backgroundColor: getBadgeColorEnvironment(env),
                            fontWeight: "600",
                            fontSize: "0.75rem",
                            borderRadius: "12px",
                          }}
                        />
                      ),
                    )}
                  </Box>
                </Box>

                {/* Snackbar amélioré pour tous les messages */}
                <Snackbar
                  open={snackbarOpen}
                  autoHideDuration={4000}
                  onClose={() => setSnackbarOpen(false)}
                  anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
                  sx={{
                    '& .MuiSnackbar-root': {
                      borderRadius: '12px',
                    }
                  }}
                >
                  <Paper
                    elevation={6}
                    sx={{
                      padding: '16px 20px',
                      borderRadius: '12px',
                      minWidth: '280px',
                      border: '1px solid',
                      display: 'flex',
                      alignItems: 'center',
                      gap: 2,
                      // Couleurs selon le type de message
                      ...(snackbarMessage.includes('✅') && {
                        backgroundColor: '#F0FDF4',
                        borderColor: '#BBF7D0',
                        color: '#166534',
                      }),
                      ...(snackbarMessage.includes('🗑️') && {
                        backgroundColor: '#FEF2F2',
                        borderColor: '#FECACA',
                        color: '#991B1B',
                      }),
                      ...(snackbarMessage.includes('🔄') && {
                        backgroundColor: '#FAF5FF',
                        borderColor: '#E9D5FF',
                        color: '#7C3AED',
                      }),
                      ...(snackbarMessage.includes('🚀') && {
                        backgroundColor: '#EFF6FF',
                        borderColor: '#BFDBFE',
                        color: '#1E40AF',
                      }),
                      ...(snackbarMessage.includes('❌') && {
                        backgroundColor: '#FEF2F2',
                        borderColor: '#FECACA',
                        color: '#DC2626',
                      }),
                    }}
                  >
                    {/* Icône */}
                    <Box
                      sx={{
                        width: '24px',
                        height: '24px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '18px',
                      }}
                    >
                      {snackbarMessage.includes('✅') && '✅'}
                      {snackbarMessage.includes('🗑️') && '🗑️'}
                      {snackbarMessage.includes('🔄') && '🔄'}
                      {snackbarMessage.includes('🚀') && '🚀'}
                      {snackbarMessage.includes('❌') && '❌'}
                    </Box>

                    {/* Message */}
                    <Typography variant="body2" sx={{ fontWeight: 600, flex: 1 }}>
                      {snackbarMessage.replace(/[✅🗑️🔄🚀❌]/g, '').trim()}
                    </Typography>

                    {/* Bouton fermer */}
                    <IconButton
                      size="small"
                      onClick={() => setSnackbarOpen(false)}
                      sx={{
                        color: 'inherit',
                        opacity: 0.7,
                        '&:hover': {
                          backgroundColor: 'rgba(0,0,0,0.04)',
                          opacity: 1,
                        }
                      }}
                    >
                      <ClearIcon fontSize="small" />
                    </IconButton>
                  </Paper>
                </Snackbar>

                {/* Boutons alignés à droite */}
                <Box display="flex" gap={2} sx={{ ml: 3 }}>
                  <Button
                    variant="contained"
                    startIcon={<KeyboardIcon />}
                    onClick={() => handleAddManual("Ajout")}
                    sx={{
                      backgroundColor: "rgba(255, 255, 255, 0.2)",
                      backdropFilter: "blur(10px)",
                      color: "white",
                      border: "1px solid rgba(255, 255, 255, 0.3)",
                      "&:hover": {
                        backgroundColor: "rgba(255, 255, 255, 0.3)",
                      },
                    }}
                  >
                    Ajouter un serveur
                  </Button>

                  <Button
                    variant="contained"
                    startIcon={<DeployIcon />}
                    onClick={handleOpenDeployModal}
                    disabled={selectedServers.length === 0}
                    sx={{
                      backgroundColor:
                        selectedServers.length === 0
                          ? "rgba(255, 255, 255, 0.1)"
                          : "rgba(236, 72, 153, 0.9)",
                      color: "white",
                      "&:hover": {
                        backgroundColor: "rgba(236, 72, 153, 1)",
                      },
                      "&:disabled": {
                        color: "rgba(255, 255, 255, 0.5)",
                      },
                    }}
                  >
                    Déployer signature ({selectedServers.length})
                  </Button>

                  <Button
                    variant="contained"
                    startIcon={<GetAppIcon />}
                    onClick={handleExport}
                    sx={{
                      backgroundColor: "rgba(52, 168, 83, 0.9)",
                      color: "white",
                      "&:hover": {
                        backgroundColor: "rgba(52, 168, 83, 1)",
                      },
                    }}
                  >
                    Exporter
                  </Button>
                </Box>
              </Box>
            </Paper>

            {servers && servers.length !== 0 ? (
              <Paper
                elevation={3}
                sx={{
                  borderRadius: 0.4,
                  overflow: "hidden",
                  background:
                    "linear-gradient(145deg, #ffffff 0%, #f8fafc 100%)",
                }}
              >
                <DataGrid
                  key={dataKey}
                  rows={filteredServers}
                  columns={columns}
                  getRowId={(row) => row.id}
                  getRowClassName={getRowClassName}
                  pageSizeOptions={[5, 10, 25, 50]}
                  checkboxSelection
                  rowSelectionModel={selectedServers}
                  onRowSelectionModelChange={(newSelection) => {
                    setSelectedServers(newSelection);
                  }}
                  columnVisibilityModel={columnVisibility}
                  onColumnVisibilityModelChange={setColumnVisibility}
                  initialState={{
                    pagination: {
                      paginationModel: { pageSize: 25, page: 0 },
                    },
                  }}
                  slots={{
                    toolbar: CustomToolBarServer as JSXElementConstructor<any>,
                  }}
                  slotProps={{
                    toolbar: {
                      filterState,
                      setFilterState,
                    } as any,
                  }}
                  sx={{
                    minHeight: 600,
                    "& .MuiDataGrid-toolbarContainer": {
                      padding: "16px",
                      backgroundColor: "#F8FAFC",
                      borderBottom: "1px solid #E2E8F0",
                    },
                    "& .MuiDataGrid-footerContainer": {
                      backgroundColor: "#F8FAFC",
                      borderTop: "1px solid #E2E8F0",
                    },
                    "& .to-decom-row": {
                      backgroundColor: "#FFE4E6",
                      "& .MuiDataGrid-cell": {
                        backgroundColor: "#FFE4E6",
                        borderBottom: "1px solid #FECACA",
                      },
                    },
                  }}
                />
              </Paper>
            ) : (
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  height: 300,
                  gap: 3,
                  p: 4,
                  textAlign: "center",
                }}
              >
                <Typography variant="h6" sx={{ color: "#6B7280" }}>
                  Aucun serveur trouvé avec les filtres actuels
                </Typography>

                {hasActiveFilters(filterState) && (
                  <Button
                    variant="contained"
                    onClick={() => setFilterState({})}
                    startIcon={<ClearIcon />}
                    sx={{
                      backgroundColor: "#EF4444",
                      "&:hover": {
                        backgroundColor: "#DC2626",
                      },
                    }}
                  >
                    Réinitialiser les filtres
                  </Button>
                )}

                <Button
                  variant="outlined"
                  onClick={() => window.location.reload()}
                  sx={{ mt: 1 }}
                >
                  Recharger la page
                </Button>
              </Box>
            )}

            {/* Modal de déploiement moderne */}
            <Dialog
              open={deployModalOpen}
              onClose={handleCloseDeployModal}
              maxWidth="md"
              fullWidth
              TransitionComponent={Fade}
              TransitionProps={{ timeout: 300 }}
            >
              <DialogTitle
                sx={{
                  background:
                    "linear-gradient(135deg, #6366F1 0%, #8B5CF6 100%)",
                  color: "white",
                  textAlign: "center",
                  py: 3,
                }}
              >
                <Box>
                  <Typography variant="h5" sx={{ fontWeight: 700, mb: 1 }}>
                    Déploiement de signature
                  </Typography>
                  {selectedServers.length > 0 && (
                    <Typography variant="body2" sx={{ opacity: 0.9 }}>
                      {selectedServers.length} serveur(s) sélectionné(s)
                    </Typography>
                  )}
                </Box>
              </DialogTitle>

              <DialogContent sx={{ p: 3 }}>
                {!showResults ? (
                  <Box sx={{ mt: 2 }}>
                    {/* Affichage moderne des serveurs sélectionnés */}
                    <Paper
                      elevation={1}
                      sx={{
                        p: 3,
                        mb: 3,
                        borderRadius: 0.4,
                        backgroundColor: "#F8FAFC",
                        border: "1px solid #E2E8F0",
                      }}
                    >
                      <Typography
                        variant="h6"
                        sx={{ fontWeight: 600, mb: 2, color: "#374151" }}
                      >
                        Serveurs sélectionnés
                      </Typography>
                      <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1.5 }}>
                        {servers
                          ?.filter((server) =>
                            selectedServers.includes(server.id),
                          )
                          .map((server) => (
                            <Chip
                              key={server.id}
                              label={`${server.Hostname} (${Array.isArray(server["Adresses IP"]) ? server["Adresses IP"][0] : server["Adresses IP"]})`}
                              variant="outlined"
                              sx={{
                                backgroundColor: "#EEF2FF",
                                borderColor: "#C7D2FE",
                                color: "#4338CA",
                                fontWeight: 500,
                                "& .MuiChip-label": {
                                  fontSize: "0.875rem",
                                },
                              }}
                            />
                          ))}
                      </Box>
                    </Paper>

                    {/* Formulaire de déploiement stylisé */}
                    <Paper
                      elevation={1}
                      sx={{
                        p: 3,
                        borderRadius: 0.4,
                        backgroundColor: "#FFFFFF",
                        border: "1px solid #E2E8F0",
                      }}
                    >
                      <Typography
                        variant="h6"
                        sx={{ fontWeight: 600, mb: 3, color: "#374151" }}
                      >
                        Informations de connexion
                      </Typography>

                      <Box
                        sx={{
                          display: "flex",
                          flexDirection: "column",
                          gap: 2.5,
                        }}
                      >
                        <TextField
                          fullWidth
                          label="Nom d'utilisateur"
                          required
                          value={deploymentForm.username}
                          onChange={(e) =>
                            setDeploymentForm((prev) => ({
                              ...prev,
                              username: e.target.value,
                            }))
                          }
                          sx={{
                            "& .MuiInputLabel-root": {
                              color: "#6B7280",
                              fontWeight: 500,
                            },
                            "& .MuiOutlinedInput-root": {
                              backgroundColor: "#F9FAFB",
                            },
                          }}
                        />

                        <TextField
                          fullWidth
                          label="Mot de passe"
                          type="password"
                          required
                          value={deploymentForm.password}
                          onChange={(e) =>
                            setDeploymentForm((prev) => ({
                              ...prev,
                              password: e.target.value,
                            }))
                          }
                          sx={{
                            "& .MuiInputLabel-root": {
                              color: "#6B7280",
                              fontWeight: 500,
                            },
                            "& .MuiOutlinedInput-root": {
                              backgroundColor: "#F9FAFB",
                            },
                          }}
                        />

                        <TextField
                          fullWidth
                          label="Mot de passe administrateur (sudo)"
                          type="password"
                          value={deploymentForm.sudo_password}
                          onChange={(e) =>
                            setDeploymentForm((prev) => ({
                              ...prev,
                              sudo_password: e.target.value,
                            }))
                          }
                          helperText="💡 Si vide, le mot de passe principal sera utilisé"
                          sx={{
                            "& .MuiInputLabel-root": {
                              color: "#6B7280",
                              fontWeight: 500,
                            },
                            "& .MuiOutlinedInput-root": {
                              backgroundColor: "#F9FAFB",
                            },
                            "& .MuiFormHelperText-root": {
                              color: "#6B7280",
                              fontSize: "0.875rem",
                            },
                          }}
                        />
                      </Box>
                    </Paper>
                  </Box>
                ) : (
                  <Box sx={{ mt: 2 }}>
                    <Typography
                      variant="h6"
                      sx={{ fontWeight: 700, mb: 3, color: "#374151" }}
                    >
                      Résultats du déploiement
                    </Typography>

                    <Box
                      sx={{ display: "flex", flexDirection: "column", gap: 2 }}
                    >
                      {deploymentResults.map((result, index) => (
                        <Alert
                          key={index}
                          severity={
                            result.status === "success" ? "success" : "error"
                          }
                          sx={{
                            borderRadius: 3,
                            "& .MuiAlert-icon": {
                              fontSize: "1.5rem",
                            },
                          }}
                        >
                          <Box>
                            <Typography
                              variant="subtitle1"
                              sx={{ fontWeight: 600 }}
                            >
                              IP: {result.ip}
                            </Typography>
                            <Typography variant="body2" sx={{ mt: 0.5 }}>
                              Status:{" "}
                              <strong>
                                {result.status === "success"
                                  ? "✅ Succès"
                                  : "❌ Échec"}
                              </strong>
                            </Typography>
                            {result.raison && (
                              <Typography variant="body2" sx={{ mt: 0.5 }}>
                                Raison: {result.raison}
                              </Typography>
                            )}
                            {result.step && result.step.length > 0 && (
                              <Typography variant="body2" sx={{ mt: 0.5 }}>
                                Dernière étape:{" "}
                                {result.step[result.step.length - 1]}
                              </Typography>
                            )}
                          </Box>
                        </Alert>
                      ))}
                    </Box>
                  </Box>
                )}
              </DialogContent>

              <DialogActions
                sx={{
                  p: 3,
                  backgroundColor: "#F8FAFC",
                  gap: 2,
                }}
              >
                <Button
                  onClick={handleCloseDeployModal}
                  variant="outlined"
                  sx={{
                    borderColor: "#D1D5DB",
                    color: "#6B7280",
                    "&:hover": {
                      borderColor: "#9CA3AF",
                      backgroundColor: "#F3F4F6",
                    },
                  }}
                >
                  {showResults ? "Fermer" : "Annuler"}
                </Button>

                {!showResults && (
                  <>
                    <Button
                      onClick={handleExportSignature}
                      variant="contained"
                      disabled={deploymentLoading}
                      sx={{
                        background: deploymentLoading
                          ? "linear-gradient(135deg, #9CA3AF 0%, #6B7280 100%)"
                          : "linear-gradient(135deg, #f8a9c3 0%, #f47ea5 100%)",
                        minWidth: 140,
                        "&:hover": {
                          background:
                            "linear-gradient(135deg, #f8a9c3 0%, #f47ea5 100%)",
                        },
                        "&:disabled": {
                          background:
                            "linear-gradient(135deg, #D1D5DB 0%, #9CA3AF 100%)",
                          color: "#6B7280",
                        },
                      }}
                    >
                      Export la signature{deploymentLoading ? "..." : ""}
                    </Button>

                    <Button
                      onClick={handleDeployment}
                      variant="contained"
                      disabled={
                        deploymentLoading ||
                        !deploymentForm.username ||
                        !deploymentForm.password
                      }
                      sx={{
                        background: deploymentLoading
                          ? "linear-gradient(135deg, #9CA3AF 0%, #6B7280 100%)"
                          : "linear-gradient(135deg, #10B981 0%, #059669 100%)",
                        minWidth: 140,
                        "&:hover": {
                          background:
                            "linear-gradient(135deg, #047857 0%, #065F46 100%)",
                        },
                        "&:disabled": {
                          background:
                            "linear-gradient(135deg, #D1D5DB 0%, #9CA3AF 100%)",
                          color: "#6B7280",
                        },
                      }}
                    >
                      Déployer{deploymentLoading ? "..." : ""}
                    </Button>
                  </>
                )}
              </DialogActions>
            </Dialog>

            {/* Modal BigFix pour un serveur individuel */}
            <Dialog
              open={bigFixModalOpen}
              onClose={handleCloseBigFixModal}
              maxWidth="md"
              fullWidth
              TransitionComponent={Fade}
              TransitionProps={{ timeout: 300 }}
            >
              <DialogTitle
                sx={{
                  background: "linear-gradient(135deg, #8B5CF6 0%, #6366F1 100%)",
                  color: "white",
                  textAlign: "center",
                  py: 3,
                }}
              >
                <Box>
                  <Typography variant="h5" sx={{ fontWeight: 700, mb: 1 }}>
                    Données BigFix
                  </Typography>
                  {selectedServerForBigFix && (
                    <Typography variant="body2" sx={{ opacity: 0.9 }}>
                      {selectedServerForBigFix.Hostname}
                    </Typography>
                  )}
                </Box>
              </DialogTitle>

              <DialogContent sx={{ p: 3 }}>
                {bigFixLoading ? (
                  <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", py: 6, gap: 2 }}>
                    <CircularProgress size={60} />
                    <Typography variant="body1" sx={{ color: "#6B7280" }}>Récupération des données en cours...</Typography>
                  </Box>
                ) : bigFixResults?.status === "success" && selectedServerForBigFix ? (
                  <Box sx={{ mt: 2 }}>
                    {/* Bouton Comparaison */}
                    <Box sx={{ mb: 3, textAlign: "center" }}>
                      <Button
                        variant="contained"
                        onClick={() => setShowComparison(!showComparison)}
                        startIcon={<CompareArrowsIcon />}
                        sx={{
                          background: showComparison
                            ? "linear-gradient(135deg, #EC4899 0%, #DB2777 100%)"
                            : "linear-gradient(135deg, #6366F1 0%, #4F46E5 100%)",
                          color: "white",
                          fontWeight: 600,
                          "&:hover": {
                            background: showComparison
                              ? "linear-gradient(135deg, #DB2777 0%, #BE185D 100%)"
                              : "linear-gradient(135deg, #4F46E5 0%, #4338CA 100%)",
                          },
                        }}
                      >
                        {showComparison ? "Masquer" : "Afficher"} la comparaison complète
                      </Button>
                    </Box>

                    {/* Comparaison complète */}
                    {showComparison && (
                      <ServerComparisonTable
                        bigfixData={bigFixResults.data[0]}
                        inventoryData={selectedServerForBigFix.originalData}
                      />
                    )}

                    {/* Données BigFix brutes */}
                    {!showComparison && (
                      <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
                        {bigFixResults.data.map((item: any, idx: number) => (
                          <Paper key={idx} elevation={1} sx={{ p: 3, backgroundColor: "#F9FAFB", borderRadius: 3, border: "1px solid #E5E7EB" }}>
                            <Typography variant="h6" sx={{ fontWeight: 600, mb: 2, color: "#374151", borderBottom: "2px solid #8B5CF6", pb: 1 }}>
                              Informations BigFix
                            </Typography>
                            <Box sx={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 2 }}>
                              {Object.entries(item).map(([key, value]) => (
                                <Box key={key}>
                                  <Typography variant="caption" sx={{ color: "#6B7280", fontWeight: 600, textTransform: "uppercase", fontSize: "0.7rem", display: "block", mb: 0.5 }}>
                                    {key.replace(/_/g, " ")}
                                  </Typography>
                                  <Typography variant="body2" sx={{ color: "#111827", fontWeight: 500 }}>
                                    {Array.isArray(value) ? value.join(", ") : value?.toString() || "N/A"}
                                  </Typography>
                                </Box>
                              ))}
                            </Box>
                          </Paper>
                        ))}
                      </Box>
                    )}
                  </Box>
                ) : (
                  <Alert severity="error" sx={{ borderRadius: 3 }}>
                    <strong>Erreur:</strong> {bigFixResults?.error || "Impossible de récupérer les données"}
                  </Alert>
                )}
              </DialogContent>

              <DialogActions
                sx={{
                  p: 3,
                  backgroundColor: "#F8FAFC",
                  gap: 2,
                }}
              >
                <Button
                  onClick={handleCloseBigFixModal}
                  variant="outlined"
                  sx={{
                    borderColor: "#D1D5DB",
                    color: "#6B7280",
                    "&:hover": {
                      borderColor: "#9CA3AF",
                      backgroundColor: "#F3F4F6",
                    },
                  }}
                >
                  Fermer
                </Button>

                {bigFixResults && bigFixResults.status === "success" && (
                  <Button
                    onClick={() => {
                      const dataStr = JSON.stringify(bigFixResults.data, null, 2);
                      const dataBlob = new Blob([dataStr], { type: "application/json" });
                      const url = URL.createObjectURL(dataBlob);
                      const link = document.createElement("a");
                      link.href = url;
                      link.download = `bigfix-${selectedServerForBigFix?.Hostname}-${new Date().toISOString()}.json`;
                      link.click();
                      URL.revokeObjectURL(url);
                    }}
                    variant="contained"
                    sx={{
                      background: "linear-gradient(135deg, #8B5CF6 0%, #6366F1 100%)",
                      "&:hover": {
                        background: "linear-gradient(135deg, #7C3AED 0%, #4F46E5 100%)",
                      },
                    }}
                  >
                    Exporter JSON
                  </Button>
                )}
              </DialogActions>
            </Dialog>

            {/* Modal principal */}
            <ModifiedServerModal
              open={openModal}
              onClose={handleCloseModal}
              initialData={serverById}
              onSubmit={(data) => {
                handleActionSubmit(data as any);
                handleCloseModal();
              }}
              isEditMode={modalType === "Modification"}
              isViewMode={modalType === "Visualisation"}
              isDeleteMode={modalType === "Suppression"}
              isDeployMode={modalType === "Déploiment"}
              isAddMode={modalType === "Ajout"}
              errorMessage={errorOperationMsg}
              modalType={modalType}
            />
            <ServerDetailsModal
              open={detailsModalOpen}
              onClose={handleCloseDetailsModal}
              rowData={selectedRowData}
              serverData={serverById}
            />
          </Box>
        </Fade>
      </ThemeProvider>
    );
}
