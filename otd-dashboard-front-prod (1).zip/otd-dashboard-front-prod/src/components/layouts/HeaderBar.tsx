// src/components/layoutes/HeaderBar.tsx

import { Link } from "react-router-dom";

import { Box, Stack, Typography, Divider, IconButton } from "@mui/material";

// import files
import CustomTooltip from "@/components/basics/CustomToolTip";
import { keycloak } from "@/auth/keycloakConnectAdapter";

// import icons
import PersonIcon from "@mui/icons-material/Person";
import LogoutIcon from "@mui/icons-material/Logout";

// import logo
import KrakenFullLogo from "/logos/KRAKEN/Kraken-Colors.svg";

export default function HeaderBar() {
  let roleLabel = "";
  if (keycloak.isAuthenticated !== null) {
    switch (true) {
      case keycloak.hasRoles("admin_role"):
        roleLabel = "Administrateur";
        break;
      case keycloak.hasRoles("tam_role"):
        roleLabel = "TAM";
        break;
      case keycloak.hasRoles("ops_role"):
        roleLabel = "Intégrateur";
        break;
      case keycloak.hasRoles("security_role"):
        roleLabel = "Sécurité";
        break;
      case keycloak.hasRoles("user.dev"):
        roleLabel = "Développeur";
        break;
      case keycloak.hasRoles("dev_role"):
        roleLabel = "Développeur";
        break;
      case keycloak.hasRoles("read_only_role"):
        roleLabel = "Read Only";
        break;
      case keycloak.hasRoles("vision_360_read_only_role"):
        roleLabel = "Vision 360";
        break;
      case keycloak.hasRoles("self_service_certificate_role"):
        roleLabel = "Self Service";
        break;
      case keycloak.hasRoles("self_service_release_role"):
        roleLabel = "Self Service - Release";
        break;

      default:
        roleLabel = "";
    }
  }

  return (
    <header className="header">
      <div className="container-fluid">
        <div className="row col-sm-12">
          <div className="brand--logo__wrapper">
            <CustomTooltip title="Attijariwafa Banque">
              <Link to="/">
                <img
                  src={KrakenFullLogo}
                  className="brand--logo__image"
                  style={{
                    position: "relative",
                    top: "-0.5rem",
                    width: "40px",
                    left: "0px",
                  }}
                  alt="Attijari Wafa Banque"
                />
              </Link>
            </CustomTooltip>
          </div>
          <div className="header-inner">
            <Box sx={{ display: "flex", width: "100%" }}>
              <Stack
                direction="row"
                spacing={2}
                alignItems="center"
                sx={{ color: "white", marginLeft: "auto" }}
              >
                <CustomTooltip
                  title="Information d'utilisateur"
                  fontSize="1.25rem"
                >
                  <Box sx={{ display: "flex", alignItems: "center" }}>
                    <PersonIcon sx={{ fontSize: "175%" }} />
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        flexDirection: "column",
                      }}
                    >
                      <Typography
                        variant="body1"
                        fontWeight="600"
                        sx={{ fontSize: "1.25rem", marginLeft: 1 }}
                      >
                        {keycloak.isAuthenticated !== null
                          ? `${keycloak.getFullName()}`
                          : "No user"}
                      </Typography>
                      <Typography
                        variant="body1"
                        fontWeight="400"
                        sx={{ fontSize: "1.25rem", marginLeft: 1 }}
                      >
                        {roleLabel}
                      </Typography>
                    </Box>
                  </Box>
                </CustomTooltip>

                <Divider
                  orientation="vertical"
                  flexItem
                  sx={{ bgcolor: "white", height: "24px" }}
                />

                <CustomTooltip title="Déconnecter" fontSize="1.25rem">
                  <IconButton
                    sx={{ padding: 0, display: "flex", alignItems: "center" }}
                    onClick={() => keycloak.logout()}
                  >
                    <LogoutIcon
                      sx={{ fontSize: 24, color: "white", alignSelf: "center" }}
                    />
                  </IconButton>
                </CustomTooltip>
              </Stack>
            </Box>
          </div>
        </div>
      </div>
    </header>
  );
}
