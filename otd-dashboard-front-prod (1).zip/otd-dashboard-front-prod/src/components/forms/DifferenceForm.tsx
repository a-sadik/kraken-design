// src/components/forms/DifferenceForm.tsx

import { useState } from "react";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import Button from "@mui/material/Button";
import Box from "@mui/material/Box";

// Import Files
import CustomListField from "../inputs/CustomListField";
import { getDelta } from "@/services/DeltaService";
import { getCssVariableValue } from "@/utils/getDynamicColor";
import { ResultDeltaView } from "@/types/view/ResultDeltaView";
const options = [
  "Inventaire",
  "BigFix",
  // "CMDB"
];

interface DifferenceFormProps {
  source: string | null;
  setSource: React.Dispatch<React.SetStateAction<string | null>>;
  destination: string | null;
  setDestination: React.Dispatch<React.SetStateAction<string | null>>;
  setLoading: React.Dispatch<React.SetStateAction<boolean>>;
  setResult: React.Dispatch<React.SetStateAction<ResultDeltaView | null>>;
}
export function DifferenceForm({
  source,
  setSource,
  destination,
  setDestination,
  setLoading,
  setResult,
}: DifferenceFormProps) {
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const isFormValid = !!source && !!destination;

  const onSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (isFormValid) {
      try {
        setLoading(true);
        const data = await getDelta(
          source.toLowerCase(),
          destination.toLowerCase(),
        );
        setResult(data);
        setErrorMsg(null);
      } catch (error) {
        console.error("Failed to fetch servers delta data:", error);
        setResult(null);
        setErrorMsg("Failed to fetch servers delta data");
      } finally {
        setLoading(false);
      }
    }
  };

  const filteredSourceOptions = options
    .filter((option) => option !== destination)
    .map((option, index) => ({ key: `source-${index}`, value: option }));

  const filteredDestinationOptions = options
    .filter((option) => option !== source)
    .map((option, index) => ({ key: `destination-${index}`, value: option }));

  const color = getCssVariableValue("--primary-color");

  const customTheme = createTheme({
    palette: {
      primary: { main: color },
    },
  });

  const buttonStyle = {
    backgroundColor: "#E25846",
    "&:hover": { backgroundColor: "#d85a4b" },
    padding: { xs: "6px 12px", sm: "8px 16px" },
    fontSize: { xs: "12px", sm: "14px" },
    textColor: "white",
    borderRadius: "100px",
  };

  return (
    <>
      <form onSubmit={onSubmit}>
        <Box
          display="flex"
          flexDirection="row"
          alignItems="center"
          justifyContent="center"
          gap={2}
          flexWrap="wrap"
        >
          <ThemeProvider theme={customTheme}>
            {/* Champ de premier source */}
            <CustomListField
              label="Premier Source"
              value={source}
              onChange={(_, newValue) => setSource(newValue)}
              options={filteredSourceOptions.map((item) => item.value)}
              required={true}
              borderColor={color}
            />

            {/* Champ de deuxième source */}
            <CustomListField
              label="Deuxième Source"
              value={destination}
              onChange={(_, newValue) => setDestination(newValue)}
              options={filteredDestinationOptions.map((item) => item.value)}
              required={true}
              borderColor={color}
            />

            {/* Boutton */}
            <Button
              variant="contained"
              sx={buttonStyle}
              type="submit"
              disabled={!isFormValid}
            >
              Comparer
            </Button>
          </ThemeProvider>
        </Box>
      </form>

      {/* Affichage des erreurs */}
      {errorMsg && (
        <Box
          color="error.main"
          sx={{ textAlign: "center", marginTop: 2, fontWeight: "bold" }}
        >
          {errorMsg}
        </Box>
      )}
    </>
  );
}
