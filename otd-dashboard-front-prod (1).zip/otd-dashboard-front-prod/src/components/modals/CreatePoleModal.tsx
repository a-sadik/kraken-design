// src/components/modals/CreatePoleModal.tsx

import React, { useEffect, useState } from "react";
import {
  Grid,
  TextField,
  Autocomplete,
  CircularProgress,
  Alert,
  Typography,
  Button,
  Box,
  Snackbar,
} from "@mui/material";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z as zod } from "zod";

import { PersonShortResponseDTO } from "@/types/dto/PersonDTO";
import { EntityShortResponseDTO } from "@/types/dto/EntityDTO";
import { getAllPersons } from "@/services/admin/PersonService";
import { getAllEntities } from "@/services/admin/EntityService";
import { createPole } from "@/services/admin/PoleService";

import {
  placeholder_entity_name,
  placeholder_one_person,
  required_hostname,
  required_one_solution,
} from "@/utils/customMessages";

import MyModal from "@/components/modals/MyModal";

const getFormSchema = () =>
  zod.object({
    pole_name: zod.string().trim().min(1, required_hostname),
    person: zod
      .union([
        zod.object({
          person_id: zod.number(),
          firstname: zod.string(),
          lastname: zod.string(),
        }),
        zod.literal(null),
      ])
      .refine((val) => val !== null, { message: required_one_solution }),
    entity: zod
      .union([
        zod.object({
          entity_id: zod.number(),
          entity_name: zod.string(),
          entity_manager_id: zod.number(),
        }),
        zod.literal(null),
      ])
      .refine((val) => val !== null, { message: required_one_solution }),
  });

export type FormCreatePoleData = zod.infer<ReturnType<typeof getFormSchema>>;

interface AddPoleModalProps {
  open: boolean;
  onClose: () => void;
  onSave: () => void;
  initialData?: any;
}

export const CreatePoleModal: React.FC<AddPoleModalProps> = ({
  open,
  onClose,
  onSave,
  initialData,
}) => {
  const formSchema = getFormSchema();

  const {
    control,
    register,
    handleSubmit,
    formState: { errors, isValid },
    setValue,
  } = useForm<FormCreatePoleData>({
    resolver: zodResolver(formSchema),
    mode: "all",
    defaultValues: initialData || {
      pole_name: "",
      person: null,
      entity: null,
    },
  });

  const [persons, setPersons] = useState<PersonShortResponseDTO[]>([]);
  const [entities, setEntities] = useState<EntityShortResponseDTO[]>([]);
  const [loadPersons, setLoadPersons] = useState(false);
  const [loadEntities, setLoadEntities] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const [successSnackbar, setSuccessSnackbar] = useState(false);

  const fetchPersons = async () => {
    setLoadPersons(true);
    try {
      const personsData = await getAllPersons();
      setPersons(Array.isArray(personsData) ? personsData : []);
    } catch (err) {
      console.error("Erreur lors du chargement des persons:", err);
      setPersons([]);
    } finally {
      setLoadPersons(false);
    }
  };

  const fetchEntities = async () => {
    setLoadEntities(true);
    try {
      const entitiesData = await getAllEntities();
      setEntities(Array.isArray(entitiesData) ? entitiesData : []);
    } catch (err) {
      console.error("Erreur lors du chargement des entités:", err);
      setEntities([]);
    } finally {
      setLoadEntities(false);
    }
  };

  useEffect(() => {
    if (initialData) {
      Object.keys(initialData).forEach((key) => {
        setValue(
          key as keyof FormCreatePoleData,
          initialData[key as keyof FormCreatePoleData],
        );
      });
    }
  }, [initialData, setValue]);

  useEffect(() => {
    if (open) {
      fetchPersons();
      fetchEntities();
    }
  }, [open]);

  const createNewPole = async (data: FormCreatePoleData) => {
    setErrorMessage(null);
    setLoading(true);
    try {
      await createPole({
        pole_name: data.pole_name,
        manager_id: data.person.person_id,
        entity_id: data.entity.entity_id,
      });

      onSave();
      setSuccessSnackbar(true);
      onClose();
    } catch (error: any) {
      console.error("Erreur lors de la création du pôle:", error);
      setErrorMessage("Erreur lors de la création du pôle.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <MyModal open={open} onClose={onClose} title="Ajouter un Pôle">
        <form onSubmit={handleSubmit(createNewPole)}>
          <Grid container spacing={2} sx={{ p: 2 }}>
            {/* Nom du Pôle */}
            <Grid item xs={12} container spacing={2} alignItems="center">
              <Grid item xs={4}>
                <Typography fontWeight="bold">Nom du Pôle</Typography>
              </Grid>
              <Grid item xs={8}>
                <TextField
                  {...register("pole_name")}
                  error={!!errors.pole_name}
                  helperText={errors.pole_name?.message}
                  fullWidth
                  placeholder={placeholder_entity_name}
                />
              </Grid>
            </Grid>

            {/* Responsable du Pôle */}
            <Grid item xs={12} container spacing={2} alignItems="center">
              <Grid item xs={4}>
                <Typography fontWeight="bold">Responsable du Pôle</Typography>
              </Grid>
              <Grid item xs={8}>
                <Controller
                  name="person"
                  control={control}
                  render={({ field }) => (
                    <Autocomplete
                      {...field}
                      options={persons}
                      getOptionLabel={(option) =>
                        option?.firstname
                          ? `${option.firstname} ${option.lastname}`
                          : ""
                      }
                      onOpen={fetchPersons}
                      loading={loadPersons}
                      onChange={(_, value) => field.onChange(value || null)}
                      isOptionEqualToValue={(option, value) =>
                        option.person_id === value?.person_id
                      }
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          placeholder={placeholder_one_person}
                          error={!!errors.person}
                          helperText={
                            errors.person?.message ||
                            (loadPersons ? "Chargement des personnes..." : "")
                          }
                          InputProps={{
                            ...params.InputProps,
                            endAdornment: (
                              <>
                                {loadPersons && <CircularProgress size={20} />}
                                {params.InputProps.endAdornment}
                              </>
                            ),
                          }}
                        />
                      )}
                    />
                  )}
                />
              </Grid>
            </Grid>

            {/* Entité associée */}
            <Grid item xs={12} container spacing={2} alignItems="center">
              <Grid item xs={4}>
                <Typography fontWeight="bold">Entité associée</Typography>
              </Grid>
              <Grid item xs={8}>
                <Controller
                  name="entity"
                  control={control}
                  render={({ field }) => (
                    <Autocomplete
                      {...field}
                      options={entities}
                      getOptionLabel={(option) =>
                        option?.entity_name ? option.entity_name : ""
                      }
                      onOpen={fetchEntities}
                      loading={loadEntities}
                      onChange={(_, value) => field.onChange(value || null)}
                      isOptionEqualToValue={(option, value) =>
                        option.entity_id === value?.entity_id
                      }
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          placeholder="Sélectionner une entité"
                          error={!!errors.entity}
                          helperText={
                            errors.entity?.message ||
                            (loadEntities ? "Chargement des entités..." : "")
                          }
                          InputProps={{
                            ...params.InputProps,
                            endAdornment: (
                              <>
                                {loadEntities && <CircularProgress size={20} />}
                                {params.InputProps.endAdornment}
                              </>
                            ),
                          }}
                        />
                      )}
                    />
                  )}
                />
              </Grid>
            </Grid>

            {/* Affichage erreur */}
            {errorMessage && (
              <Grid item xs={12}>
                <Alert variant="filled" severity="error">
                  <Typography variant="body1">{errorMessage}</Typography>
                </Alert>
              </Grid>
            )}
          </Grid>

          {/* Boutons d'action */}
          <Box textAlign="right" p={2}>
            <Button onClick={onClose} sx={{ mr: 1 }}>
              Annuler
            </Button>
            <Button
              type="submit"
              variant="contained"
              disabled={!isValid || loading}
            >
              {loading ? <CircularProgress size={20} /> : "Ajouter"}
            </Button>
          </Box>
        </form>
      </MyModal>
      <Snackbar
        open={successSnackbar}
        autoHideDuration={3000}
        onClose={() => setSuccessSnackbar(false)}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <Alert
          onClose={() => setSuccessSnackbar(false)}
          severity="success"
          variant="filled"
        >
          Pôle à été créer avec succès !
        </Alert>
      </Snackbar>
    </>
  );
};
