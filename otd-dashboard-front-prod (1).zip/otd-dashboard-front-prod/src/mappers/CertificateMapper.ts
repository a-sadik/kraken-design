// src/mappers/CertificateMapper.ts

import { InternCertificateFormData } from "@/components/forms/certificate/CreateInternCertificateForm";
import { ExternCertificateFormData } from "@/components/forms/certificate/CreateExternCertificateForm";
import {
  ExternCertificateRequestDTO,
  InternCertificateRequestDTO,
} from "@/types/dto/request/CertificateRequestDTO";
import { CertificateResponseDTO } from "@/types/dto/response/CertificateResponseDTO";
import CertificateView from "@/types/view/CertificateView";
import { CertificateStateEnum } from "@/enums/CertificateState";
import { getFormatedDate } from "@/utils";
import { formatKeyContent } from "@/utils/format.utils";

export const certificateResToView = (
  data: CertificateResponseDTO[],
): CertificateView[] => {
  return data.map((item) => ({
    id: item.certificate_id,
    "Réf de ticket iTop": item.itop_ticket_ref,
    id_itop_ticket: item.itop_ticket_num, // not visible for ui just for create link to itop platform
    Référence: item.certificate_request_ref,
    "Interne/Externe": item.certificate_target,
    "Statut de la demande": mapToStatut(item),
    "Common Name": item.common_name,
    "Statut de ticket": item.ticket_state,
    Solution: item.solution,
    Demandeur: item.applicant,
    Validateur: item.actor,
    "Date de création": getFormatedDate(item.created_at),
    "Date d'expiration": item.exp_date,
    Dns: item.dns,
    is_renewed: item.is_renewed,
  }));
};

// Mapping data form of intern certificate to response certificate
export const internCertificateDataFormToReq = (
  dataCertificateForm: InternCertificateFormData,
): InternCertificateRequestDTO => {
  return {
    certificate_target: dataCertificateForm.certificate_target || "",
    dns: dataCertificateForm.dns || [],
    common_name: dataCertificateForm.common_name || "",
    solution_id: dataCertificateForm.solution?.solution_id || 0,
    certificate_type: dataCertificateForm.certificate_type || "",
    application_comment: dataCertificateForm.description || "",
  };
};

// Mapping data form of extern certificate to response certificate
export const externCertificateDataFormToReq = (
  dataCertificateForm: ExternCertificateFormData,
): ExternCertificateRequestDTO => {
  return {
    certificate_target: dataCertificateForm.certificate_target || "",
    certificate_key:
      formatKeyContent(dataCertificateForm.certificate_key || "") || "-",
    dns: dataCertificateForm.dns || [],
    common_name: dataCertificateForm.dns?.at(0) || "",
    solution_id: dataCertificateForm.solution?.solution_id || 0,
    certificate_type: dataCertificateForm.certificate_type || "",
    application_comment: dataCertificateForm.description || "",
  };
};

const mapToStatut = (item: CertificateResponseDTO) => {
  const CertificateState = [];

  CertificateState.push(item.certificate_state);

  const exp_date = new Date(item.exp_date).getTime();
  const currentDate = new Date().getTime();

  if (item.exp_date && exp_date < currentDate) {
    CertificateState.push(CertificateStateEnum.EXPRIED);
  }

  if (item.is_renewed) {
    CertificateState.push(CertificateStateEnum.RENEWED);
  }
  return CertificateState;
};

// {
//   "certificate_target": "Interne",
//   "dns": [
//       "chaouki.com"
//   ],
//   "common_name": "api.attijari",
//   "applicant_id": 1,
//   "solution_id": 5,
//   "operation_by": "System"
// }
