// src/utils/customMessages.ts

// calling service message error
export const service_unavailable: string = "Indisponibilité de service";
export const service_failure: string = "Problème technique dans le service";
export const service_data: string = "Data";
export const service_core: string = "Core";
export const service_source: string = "Source";

// login form message error
export const username_empty: string = "Username cannot be empty or blank.";
export const password_empty: string = "Password cannot be empty or blank.";
export const username_requirement: string =
  "Username must be at least 2 characters.";
export const password_requirement: string =
  "Password must be at least 6 characters.";

// servers of file message error
export const invalid_file: string =
  "Fichier n'est pas valide ou n'a pas été accepté.";
export const file_data_empty: string =
  "Fichier ne contient aucune donnée. Veuillez vérifier votre fichier.";
export const invalid_hostname: string =
  "Valeurs de la colonne hostname doivent être non redondantes.";
export const invalid_ip_adresseses: string =
  "Valeurs de la colonne des adresses IP doivent être non redondantes dans toute la liste";

// server form message error
export const required_hostname: string = "Hostname est requis";
export const required_ip_address: string =
  "Au moins une adresse IP doit être saisie";
export const required_os_type: string =
  "Type de système d'exploitation est requis";
export const required_server_nature: string =
  "Au moins une nature doit être sélectionnée";
export const required_nature_detail: string = "Détail de la nature est requis";
export const required_environment: string =
  "Au moins un environnement doit être sélectionné";
export const required_multiple_solutions: string =
  "Au moins une solution doit être sélectionnée";

// server form message placeholder
export const placeholder_hostname: string = "Choisir un nouveau hostname";
export const placeholder_ip_addresses: string = "Ajoutez une adresse IP";
export const placeholder_os_type: string = "Choisir un type d'OS";
export const placeholder_server_nature: string =
  "Choisir une ou plusieurs natures...";
export const placeholder_nature_detail: string =
  "Décrivez ici, le détail de la nature : Spring Boot , RAC, Oracle...";
export const placeholder_environments: string =
  "Choisir un ou plusieurs environnements...";
export const placeholder_many_solutions: string =
  "Choisir une ou plusieurs solutions...";

export const null_os_detail: string = "Aucun détail précisé d'OS";

// solution form message placeholder
export const required_solution_name: string = "Nom est requis";
export const required_solution_popularity: string = "Popularité est requise";
export const required_solution_type: string = "Type est requis";
export const required_solution_role: string = "Rôle est requis";
export const required_technical_admin: string =
  "Au moins un admin technique doit être sélectionné";
export const required_functional_admin: string =
  "Au moins un admin fonctionnel doit être sélectionné";
export const required_tam: string = "TAM est requis";
export const required_pci: string = "PCI est requis";
export const required_domain: string = "Domaine est requis";

// solution form message placeholder
export const placeholder_solution_name: string = "Ecrire un nom valide...";
export const placeholder_solution_popularity: string =
  "Choisir une popularité...";
export const placeholder_solution_type: string =
  "Choisir un ou plusieurs types de solution...";
export const placeholder_solution_role: string = "Décrivez le rôle ici...";
export const placeholder_technical_admin: string =
  "Choisir un ou plusieurs admins techniques...";
export const placeholder_functional_admin: string =
  "Choisir un ou plusieurs admins fonctionnels...";
export const placeholder_tam: string =
  "Choisir un tam (technical account manager)...";
export const placeholder_pci: string = "Choisir un pci...";
export const placeholder_domain: string = "Choisir un domaine...";

// certificate form message error
export const required_common_name: string = "Common name est requis";
export const required_one_solution: string = "Solution est requise";
export const required_certificate_target: string =
  "Type de certificat est requis";
export const required_dns_min_lenght: string = "Le DNS ne peut pas être vide";
export const required_dns_max_lenght: string =
  "Le DNS ne doit pas passé 45 caractères";
export const required_dns_min_nbr: string = "Au moins un DNS est requis";
export const required_dns_max_nbr: string = "Maximum 5 DNS autorisés";
export const required_unique_dns: string = "Les DNS doivent être uniques";
export const required_domain_name_right: string =
  "Chaque DNS doit contenir un nom de domaine valide (******.**)";
export const required_domain_name_select: string = "Choisir un nom de domaine";

// certificate form message error
export const MAX_DNS_LENGTH = 45;

// solution form message placeholder
export const placeholder_common_name: string = "Ecrire un common name...";
export const placeholder_one_solution: string = "Choisir une solution...";
export const placeholder_domain_name_right: string =
  "Ecrire un nom de domaine...";
export const placeholder_domain_name_select: string =
  "Choisir un nom de domaine...";
export const placeholder_domain_name: string = "Choisir un nom de domaine...";

// certificate form message error
export const required_entity_name: string = "Entité est requise";
export const placeholder_entity_name: string = "Ecrire un nom d'entité...";

// person form message placeholder
export const placeholder_one_person: string = "Choisir une personne...";
