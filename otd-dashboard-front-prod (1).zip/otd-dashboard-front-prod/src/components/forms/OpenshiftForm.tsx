// src/components/OpenshiftForm.tsx

import { useEffect, useState } from "react";
import { useForm, Controller, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z as zod } from "zod";
import {
  TextField,
  Button,
  Grid,
  Autocomplete,
  Typography,
  CircularProgress,
  Box,
  Alert,
  InputAdornment,
  IconButton,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import AddIcon from "@mui/icons-material/Add";

// Imports file
import { SolutionDetailResponseDTO } from "@/types/dto/response/solution/SolutionDetailResponseDTO";
import { getAllSolutions } from "@/services/SolutionService";

// Import messages
import { required_one_solution } from "@/utils/customMessages";
import {
  placeholder_common_name,
  placeholder_one_solution,
} from "@/utils/customMessages";

// Schéma de validation avec Zod
const getFormSchema = (isDeleteMode: boolean) =>
  zod.object({
    certificate_target: isDeleteMode
      ? zod.string().optional()
      : zod.string().trim().min(1),
    solution: isDeleteMode
      ? zod
          .object({
            solution_id: zod.number(),
            solution_name: zod.string(),
            solution_popularity: zod.string(),
          })
          .optional()
      : zod
          .object({
            solution_id: zod.number(),
            solution_name: zod.string(),
            solution_popularity: zod.string(),
          })
          .refine((val) => val !== null, {
            message: required_one_solution,
          }),
    common_name: isDeleteMode
      ? zod.string().optional()
      : zod.string().trim().min(1),
    namespace: isDeleteMode
      ? zod.array(zod.string()).optional()
      : zod.array(zod.string()).optional(),
  });

export type OpenshiftFormData = zod.infer<ReturnType<typeof getFormSchema>>;
// export type namespaceFields = zod.infer<ReturnType<typeof zod.object({namespace:zod.array(zod.string())})>>;
const FormLabel = ({
  label,
  isRequired = false,
}: {
  label: string;
  isRequired?: boolean;
}) => (
  <Typography
    variant="body1"
    sx={{
      fontWeight: "bold",
      display: "flex",
      alignItems: "center",
      mb: "0.5rem",
      fontSize: "1.2rem",
    }}
  >
    {label}
    {isRequired && (
      <span style={{ color: "var(--error-color)", marginLeft: 2 }}>*</span>
    )}
  </Typography>
);

interface OpenshiftFormProps {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  initialData: any;
  onSubmit: (data: OpenshiftFormData) => void;
  isEditMode: boolean;
  isViewMode: boolean;
  isDeleteMode: boolean;
  errorMessage: string | null;
}

export function OpenshiftForm({
  initialData,
  onSubmit,
  isEditMode,
  isViewMode,
  isDeleteMode,
  errorMessage,
}: OpenshiftFormProps) {
  const formSchema = getFormSchema(isDeleteMode);

  const {
    control,
    register,
    handleSubmit,
    formState: { errors, isValid },
    setValue,
    watch,
    // getValues,
  } = useForm<OpenshiftFormData>({
    resolver: zodResolver(formSchema),
    mode: "all",
    defaultValues: initialData || {
      certificate_target: "Interne",
      solution: null,
      common_name: "",
      namespace: [""],
    },
  });
  const { fields, append, remove } = useFieldArray<any | null>({
    control,
    name: "namespace",
  });

  const watchFieldArray = watch("namespace");
  const controlledFields = fields.map((field, index) => {
    if (watchFieldArray) {
      return {
        ...field,
        watchFieldArray: watchFieldArray[index],
      };
    }
  });
  console.log("updated", controlledFields);
  //   {
  //     "certificate_target": "Interne",
  //     "namespace": [
  //         "chaouki.com"
  //     ],
  //     "common_name": "api.attijari",
  //     "applicant_id": 1,
  //     "solution_id": 5,
  //     "operation_by": "System"
  // }

  useEffect(() => {
    if (initialData) {
      // Si des données initiales sont fournies, remplissez les valeurs du formulaire
      Object.keys(initialData).forEach((key) => {
        setValue(
          key as keyof OpenshiftFormData,
          initialData[key as keyof OpenshiftFormData],
        );
      });
    }
  }, [initialData, setValue]);

  // loading solutions
  const [solutions, setSolutions] = useState<SolutionDetailResponseDTO[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  const fetchSolutions = async () => {
    setLoading(true);
    try {
      const solutionData: SolutionDetailResponseDTO[] = await getAllSolutions();

      if (Array.isArray(solutionData)) {
        setSolutions(solutionData);
      } else {
        console.error(
          "Les données reçues ne sont pas un tableau",
          solutionData,
        );
        setSolutions([]);
      }
    } catch (error) {
      console.error("Erreur lors du chargement des solutions :", error);
      setSolutions([]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <Grid container spacing={2}>
        {!isDeleteMode ? (
          <>
            {/* Champ common_name */}
            <Grid item xs={12} md={12}>
              <FormLabel label="Common name" isRequired />
              <TextField
                {...register("common_name")}
                error={!!errors.common_name}
                helperText={errors.common_name?.message}
                fullWidth
                disabled={isViewMode}
                placeholder={placeholder_common_name}
                slotProps={{
                  input: {
                    endAdornment: (
                      <InputAdornment position="end">
                        <Typography className="text-button-add">
                          {/* .attijariwafa.net */}
                        </Typography>
                      </InputAdornment>
                    ),
                  },
                }}
              />
            </Grid>
            {/* Champ common_name */}
            <Grid container item xs={12} md={12}>
              <div className="namespaceLabelWrapper">
                <FormLabel label="Ajouter un namespace" />
              </div>
              {/* <IconButton
                className="appendnamespace"
                aria-label="ADD"
                color="success"
                size="large"
                onClick={() => append(" ")}
                sx={{ color: 'success.contrastText' }}
              >
                <AddIcon />
              </IconButton> */}

              <TextField
                value={watch("common_name")}
                error={!!errors.common_name}
                helperText={errors.common_name?.message}
                fullWidth
                disabled={isViewMode}
                label="namespace.1"
                placeholder={placeholder_common_name}
                sx={{
                  marginTop: "20px",
                }}
                slotProps={{
                  input: {
                    endAdornment: (
                      <InputAdornment position="end">
                        <Typography className="text-button-add">
                          {/* .attijariwafa.net */}
                        </Typography>
                      </InputAdornment>
                    ),
                  },
                }}
              />

              {controlledFields.map((_, index) => {
                return (
                  <>
                    <TextField
                      {...register(`namespace.${index}`)}
                      error={!!errors.common_name}
                      helperText={errors.common_name?.message}
                      fullWidth
                      disabled={isViewMode}
                      label={`namespace.${index + 2}`}
                      placeholder={placeholder_common_name}
                      // margin="dense"
                      sx={{
                        marginTop: "15px",
                      }}
                      slotProps={{
                        input: {
                          endAdornment: (
                            <InputAdornment position="end">
                              <Typography className="text-button-add">
                                {/* .attijariwafa.net |{" "} */}
                              </Typography>
                              <IconButton
                                aria-label="delete"
                                color="error"
                                size="large"
                                onClick={() => remove(index)}
                              >
                                <DeleteIcon />
                              </IconButton>
                            </InputAdornment>
                          ),
                        },
                      }}
                    />
                  </>
                );
              })}
            </Grid>
            <Grid
              item
              xs={12}
              sx={{
                alignItems: "center",
                justifyContent: "flex-end",
                display: "flex",
              }}
            >
              <Button
                variant="contained"
                size="small"
                onClick={() => append("")}
                sx={{
                  width: "auto",
                  color: "success.contrastText",
                }}
                endIcon={<AddIcon />}
              >
                Ajouter un namespace
              </Button>
            </Grid>

            {/* Champ namespace */}
            {/* <Grid item xs={12} md={12}>
              <FormLabel label="namespace" />
              <Controller
                name="namespace"
                control={control}
                render={({ field }) => (
                  <Autocomplete
                    {...field}
                    freeSolo
                    multiple
                    options={[]}
                    getOptionLabel={(option) => option}
                    disabled={isViewMode}
                    onChange={(_, value) => field.onChange(value || [])}
                    isOptionEqualToValue={(option, value) => option === value}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        placeholder={placeholder_server_nature}
                        error={!!errors.namespace}
                        helperText={errors.namespace?.message}
                      />
                    )}
                  />
                )}
              />
            </Grid> */}

            {/* Champ Solution(s) */}
            <Grid item xs={12} md={12}>
              <FormLabel label="Solution" isRequired />
              <Controller
                name="solution"
                control={control}
                render={({ field }) => (
                  <Autocomplete
                    {...field}
                    options={solutions || []} // Utilisez un tableau vide par défaut
                    getOptionLabel={(option) => {
                      return option.solution_name
                        ? `${option.solution_name} (${option.solution_popularity})`
                        : "";
                    }}
                    disabled={isViewMode}
                    loading={loading}
                    onOpen={fetchSolutions}
                    onChange={(_, value) => field.onChange(value || [])}
                    isOptionEqualToValue={(option, value) =>
                      option.solution_id === value?.solution_id
                    }
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        placeholder={placeholder_one_solution}
                        error={!!errors.solution}
                        helperText={
                          errors.solution?.message ||
                          (loading ? "Chargement..." : "")
                        }
                        InputProps={{
                          ...params.InputProps,
                          endAdornment: (
                            <>
                              {loading && (
                                <CircularProgress color="inherit" size={20} />
                              )}
                              {params.InputProps.endAdornment}
                            </>
                          ),
                        }}
                      />
                    )}
                  />
                )}
              />
            </Grid>
          </>
        ) : (
          <Box margin="2rem">
            Êtes-vous sûr de vouloir supprimer cet certificat.
          </Box>
        )}

        {errorMessage !== null && (
          <Grid item xs={12}>
            <Alert variant="filled" severity="error">
              <Typography variant="body1">{errorMessage}</Typography>
            </Alert>
          </Grid>
        )}

        {/* Bouton Soumettre */}
        {!isViewMode && (
          <Grid
            item
            xs={12}
            sx={{
              alignItems: "center",
              justifyContent: "flex-end",
              display: "flex",
            }}
          >
            <Button
              type="submit"
              variant="contained"
              size="large"
              color="primary"
              disabled={isDeleteMode ? false : !isValid}
              sx={{
                width: "auto",
              }}
            >
              {isEditMode ? "Modifier" : isDeleteMode ? "Supprimer" : "Envoyer"}
            </Button>
          </Grid>
        )}
      </Grid>
    </form>
  );
}
