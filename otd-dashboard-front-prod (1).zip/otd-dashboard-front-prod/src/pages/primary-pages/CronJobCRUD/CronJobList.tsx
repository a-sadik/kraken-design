/* eslint-disable @typescript-eslint/no-explicit-any */
import { Card, CardContent, Typography, IconButton, Stack } from '@mui/material';
import { Edit, Delete } from '@mui/icons-material';

const CronJobList = ({ jobs, onEdit, onDelete }: any) => (
  <>
    {jobs.map((job: any) => (
      <Card key={job.id} sx={{ mb: 2, backgroundColor: '#e3f2fd' }}>
        <CardContent>
          <Typography variant="h6" color="primary">{job.name}</Typography>
          {job.description && (
            <Typography variant="body1" sx={{ fontStyle: 'italic', color: 'text.secondary', mb: 1, whiteSpace: 'pre-line' }}>
              {job.description}
            </Typography>
          )}
          <Typography variant="body2"><strong>Commande :</strong> {job.command}</Typography>
          <Typography variant="body2"><strong>Intervalle :</strong> {job.interval} min</Typography>
          <Typography variant="body2"><strong>Actif :</strong> {job.active ? '✅ Oui' : '❌ Non'}</Typography>
          <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
            <IconButton onClick={() => onEdit(job)} color="primary"><Edit /></IconButton>
            <IconButton onClick={() => onDelete(job.id)} color="error"><Delete /></IconButton>
          </Stack>
        </CardContent>
      </Card>
    ))}
  </>
);

export default CronJobList;