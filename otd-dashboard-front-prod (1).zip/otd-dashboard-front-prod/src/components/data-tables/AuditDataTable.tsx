/* eslint-disable @typescript-eslint/no-unused-expressions */
/* eslint-disable @typescript-eslint/no-explicit-any */
// src/components/data-tables/AuditDataTable.tsx
import { useState, useEffect, useMemo } from "react";

import { AxiosError } from "axios";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import { DataGrid } from "@mui/x-data-grid";
import { IconButton, Box, Typography } from "@mui/material";

// import files
import WidgetMainContainer from "@/components/containers/WidgetMainContainer";
import CustomTooltip from "@/components/basics/CustomToolTip";
import CustomLoading from "@/components/basics/CustomLoading";
import MyModal from "@/components/modals/MyModal";
import { getFormatedDate } from "@/utils";
import { getCssVariableValue } from "@/utils/getDynamicColor";
import { getHealthBackendData } from "@/services/ServerService";

import CertificateView from "@/types/view/CertificateView";
import { CertificateDetailResponseDTO } from "@/types/dto/response/CertificateResponseDTO";
import { isInvalid } from "@/utils/validationEnvVar";

// import icons
import VisibilityIcon from "@mui/icons-material/Visibility";

// imports style
import "@/styles/reliability-data-table.css";

// import files
import { getAllAudits } from "@/services/AuditService";

// import messages
import {
  service_unavailable,
  service_failure,
  service_data,
} from "@/utils/customMessages";
import { AuditView } from "@/types/view/AuditView";
import CustomBadge from "../basics/CustomBadge";
import CustomToolBarAudit from "./CustomToolBarAudit";

// import env varibales
const V_ITOP_TICKET_ID_URL = import.meta.env.VITE_ITOP_TICKET_ID_URL;

const requiredEnvVars = [
  { key: "ITOP_TICKET_ID_URL", value: V_ITOP_TICKET_ID_URL },
];

// Vérification des variables avec journalisation
requiredEnvVars.forEach(({ key, value }) => {
  if (isInvalid(value)) {
    console.error(`Environment variable '${key}' is missing or invalid.`);
    process.exit(1);
  }
});

export default function AuditDataTable() {
  // const [isSuccessOperation, setIsSuccessOperation] = useState(true);
  // const [isFailedOperation, setIsFailedOperation] = useState(true);

  const [selectedRowData, setSelectedRowData] =
    useState<CertificateView | null>(null);

  // modals use state
  const [modalType, setModalType] = useState<string>("");
  const [openModalDisplay, setOpenModalDisplay] = useState(false);

  const [audits, setAudits] = useState<AuditView[] | null>([]);
  const [auditById, setAuditById] =
    useState<CertificateDetailResponseDTO | null>(null);

  const [loading, setLoading] = useState(false);
  const [errorOperationMsg, setErrorOperationMsg] = useState<string | null>(
    null,
  );
  const [errorServiceMsg, setErrorServiceMsg] = useState<string | null>(null);
  const [columnVisibility, setColumnVisibility] = useState({});

  const [isSuccessOperation, setIsSuccessOperation] = useState(true);
  const [isFailedOperation, setIsFailedOperation] = useState(true);
  const [isCreateAction, setIsCreateAction] = useState(true);
  const [isUpdateAction, setIsUpdateAction] = useState(true);
  const [isDeleteAction, setIsDeleteAction] = useState(true);
  const [isSignInAction, setIsSignInAction] = useState(true);
  const [isSignOutAction, setIsSignOutAction] = useState(true);

  errorOperationMsg;
  selectedRowData;
  selectedRowData;
  auditById;

  // use case pour la validation en groupe
  const [selectedAuditData, setSelectedAuditData] = useState<AuditView | null>(
    null,
  );

  const enum operationStatusName {
    SUCCESS = "Réussie",
    FAILED = "Échoué",
  }

  const enum actionTypesName {
    CREATE = "Création",
    UPDATE = "Modifier",
    DELETE = "Suppression",
    SIGNIN = "Connecter",
    SIGNOUT = "Déconnecter",
  }

  const fetchAudits = async () => {
    setLoading(true);
    setErrorOperationMsg(null);
    setErrorServiceMsg(null);
    try {
      await getHealthBackendData();
      const data = await getAllAudits();
      setAudits(data);
      setErrorServiceMsg(null);
    } catch (err) {
      const error = err as AxiosError;
      console.error("Erreur lors de la récupération des certificats :", err);
      if (error.code === "ERR_NETWORK")
        setErrorServiceMsg(`${service_unavailable} : ${service_data}`);
      else setErrorServiceMsg(`${service_failure} : ${service_data}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAudits();
  }, []);

  const handleViewAudit = (rowData: AuditView) => {
    setSelectedAuditData(rowData);
    setModalType("Détails de l'audit");
    setOpenModalDisplay(true);
  };

  const handleCloseModal = () => {
    setOpenModalDisplay(false);

    setModalType("");
    setSelectedRowData(null);
    setErrorOperationMsg(null);
    setAuditById(null);
    setErrorOperationMsg(null);
  };

  const defaultVisibleColumns: Record<string, boolean> = {
    actions: true,
    Référence: true,
    Personne: true,
    Composant: true,
    "Status d'opération": true,
    Action: true,
    Description: true,
    "Adresse IP": true,
    "Date d'opération": true,
  };

  const initialVisibility = (columns: any[]) => {
    const initialVisibility: Record<string, boolean> = {};

    columns.forEach((column) => {
      initialVisibility[column.field] =
        defaultVisibleColumns[column.field] || false;
    });
    setColumnVisibility(initialVisibility);
  };

  const getResponsiveWidth = (key: string) => {
    const screenWidth = window.innerWidth;

    const tableColumns1 = ["Description"];
    const tableColumns2 = [
      "Référence",
      "Composant",
      "Adresse IP",
      "Status d'opération",
      "Action",
    ];

    const tableColumns3 = ["Personne", "Date d'opération"];

    if (screenWidth < 600) {
      if (tableColumns1.includes(key)) return 75;
      else if (tableColumns2.includes(key)) return 100;
      else if (tableColumns3.includes(key)) return 120;
      return 80;
    } else if (screenWidth < 960) {
      if (tableColumns1.includes(key)) return 140;
      else if (tableColumns2.includes(key)) return 100;
      else if (tableColumns3.includes(key)) return 180;
      return 100;
    } else {
      if (tableColumns1.includes(key)) return 160;
      else if (key === tableColumns1[2] || key === tableColumns1[3]) return 220;
      else if (tableColumns3.includes(key)) return 140;
      else if (tableColumns2.includes(key)) return 100;
      return 120;
    }
  };

  function valueContent(value: any, key: string) {
    // without value
    if (
      value === null ||
      value === "" ||
      (Array.isArray(value) && value.length === 0)
    ) {
      return (
        <span
          style={{
            textAlign: "center",
            fontWeight: "bold",
            fontSize: "2rem",
            display: "inline-block",
          }}
        >
          -
        </span>
      );
    }

    // string value
    if (typeof value === "string" && !Array.isArray(value)) {
      if (["Date d'opération"].includes(key)) {
        return (
          <CustomTooltip title={value !== null ? getFormatedDate(value) : ""}>
            <span>{getFormatedDate(value)}</span>
          </CustomTooltip>
        );
      }

      if (["Status d'opération"].includes(key)) {
        if (value === operationStatusName.SUCCESS)
          return (
            <CustomBadge
              text={value}
              backgroundColor={getCssVariableValue(
                "--audit-badge-status-success-background-color",
              )}
              textColor={getCssVariableValue(
                "--audit-badge-status-success-color",
              )}
              textSize={"0.8rem"}
              withBorder
              borderColor={getCssVariableValue(
                "--audit-badge-status-success-color",
              )}
            />
          );
        else if (value === operationStatusName.FAILED)
          return (
            <CustomBadge
              text={value}
              backgroundColor={getCssVariableValue(
                "--audit-badge-status-faild-background-color",
              )}
              textColor={getCssVariableValue(
                "--audit-badge-status-faild-color",
              )}
              textSize={"0.8rem"}
              withBorder
              borderColor={getCssVariableValue(
                "--audit-badge-status-faild-color",
              )}
            />
          );
      }

      if (["Action"].includes(key)) {
        switch (value) {
          case actionTypesName.CREATE:
            return (
              <CustomBadge
                text={value}
                backgroundColor={getCssVariableValue(
                  "--audit-badge-types-background-color",
                )}
                textColor={getCssVariableValue(
                  "--audit-badge-type-create-color",
                )}
                textSize={"0.8rem"}
                withBorder
                borderColor={getCssVariableValue(
                  "--audit-badge-type-create-color",
                )}
              />
            );
          case actionTypesName.UPDATE:
            return (
              <CustomBadge
                text={value}
                backgroundColor={getCssVariableValue(
                  "--audit-badge-types-background-color",
                )}
                textColor={getCssVariableValue(
                  "--audit-badge-type-update-color",
                )}
                textSize={"0.8rem"}
                withBorder
                borderColor={getCssVariableValue(
                  "--audit-badge-type-update-color",
                )}
              />
            );
          case actionTypesName.DELETE:
            return (
              <CustomBadge
                text={value}
                backgroundColor={getCssVariableValue(
                  "--audit-badge-types-background-color",
                )}
                textColor={getCssVariableValue(
                  "--audit-badge-type-delete-color",
                )}
                textSize={"0.8rem"}
                withBorder
                borderColor={getCssVariableValue(
                  "--audit-badge-type-delete-color",
                )}
              />
            );
          case actionTypesName.SIGNIN:
            return (
              <CustomBadge
                text={value}
                backgroundColor={getCssVariableValue(
                  "--audit-badge-types-background-color",
                )}
                textColor={getCssVariableValue(
                  "--audit-badge-type-signin-color",
                )}
                textSize={"0.8rem"}
                withBorder
                borderColor={getCssVariableValue(
                  "--audit-badge-type-signin-color",
                )}
              />
            );
          case actionTypesName.SIGNOUT:
            return (
              <CustomBadge
                text={value}
                backgroundColor={getCssVariableValue(
                  "--audit-badge-types-background-color",
                )}
                textColor={getCssVariableValue(
                  "--audit-badge-type-signout-color",
                )}
                textSize={"0.8rem"}
                withBorder
                borderColor={getCssVariableValue(
                  "--audit-badge-type-signout-color",
                )}
              />
            );
        }
      }

      if (key === "Adresse IP") {
        return (
          <CustomBadge
            text={value}
            backgroundColor={getCssVariableValue("--layout-background-color")}
          />
        );
      }
    }

    // other value
    return (
      <CustomTooltip title={value !== null && value}>
        <span>{value}</span>
      </CustomTooltip>
    );
  }

  const columns = useMemo(() => {
    if (audits && audits.length === 0) return [];

    const actionColumn = {
      field: "actions",
      headerName: "Actions",
      width: 100,
      sortable: false,
      filterable: false,
      renderCell: (params: any) => (
        <div
          style={{
            display: "flex",
            gap: "8px",
            alignItems: "center",
            justifyContent: "flex-start",
            marginLeft: "18px",
          }}
        >
          {/* certificat visualisation  */}
          <IconButton
            onClick={() => handleViewAudit(params.row)}
            className="icon-button certifcate"
            sx={{ mt: "1.2rem" }}
          >
            <VisibilityIcon className="data-table-icon-button" />
          </IconButton>
        </div>
      ),
    };

    const dataColumns = Object.keys(Array.isArray(audits) ? audits[0] : [])
      .filter((key) => key !== "id")
      .map((key) => ({
        field: key,
        headerName: key,
        description: key,
        width: getResponsiveWidth(key),
        fontSize: "2rem",
        renderCell: (params: any) => valueContent(params.value, key),
        sortable: true,
        sortComparator: (v1: string | [], v2: string | []) => {
          if (Array.isArray(v1) && Array.isArray(v2)) {
            return v1.join(", ").localeCompare(v2.join(", ")); // Transformer les tableaux en string pour comparer
          }
          if (typeof v1 === "string" && typeof v2 === "string") {
            return v1.localeCompare(v2);
          }
          return 0; // Par défaut, ne change pas l'ordre
        },
      }));
    initialVisibility([actionColumn, ...dataColumns]);

    return [actionColumn, ...dataColumns];
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [audits]);

  const customTheme = createTheme({
    palette: {
      primary: { main: getCssVariableValue("--certifcate-main-color") },
      success: {
        main: getCssVariableValue("--certifcate-badge-success"),
        contrastText: getCssVariableValue(
          "--certifcate-badge-success-contrastText",
        ),
      },
    },
  });

  const filteredRows = useMemo(() => {
    if (!audits) return [];

    return audits.filter((audit) => {
      // Filter by operation status
      if (
        audit["Status d'opération"] === operationStatusName.SUCCESS &&
        !isSuccessOperation
      ) {
        return false;
      }
      if (
        audit["Status d'opération"] === operationStatusName.FAILED &&
        !isFailedOperation
      ) {
        return false;
      }

      // Filter by action type
      if (audit["Action"] === actionTypesName.CREATE && !isCreateAction) {
        return false;
      }
      if (audit["Action"] === actionTypesName.UPDATE && !isUpdateAction) {
        return false;
      }
      if (audit["Action"] === actionTypesName.DELETE && !isDeleteAction) {
        return false;
      }
      if (audit["Action"] === actionTypesName.SIGNIN && !isSignInAction) {
        return false;
      }
      if (audit["Action"] === actionTypesName.SIGNOUT && !isSignOutAction) {
        return false;
      }

      return true;
    });
  }, [
    audits,
    isSuccessOperation,
    isFailedOperation,
    isCreateAction,
    isUpdateAction,
    isDeleteAction,
    isSignInAction,
    isSignOutAction,
  ]);

  if (loading) return <CustomLoading />;
  else if (errorServiceMsg !== null) {
    return (
      <>
        <Box
          color="error.main"
          sx={{ textAlign: "center", marginTop: 2, fontWeight: "bold" }}
        >
          {errorServiceMsg}
        </Box>
      </>
    );
  } else
    return (
      <ThemeProvider theme={customTheme}>
        <Box>
          <Box
            display="flex"
            justifyContent="space-between"
            alignItems="center"
            mb={3}
          >
            {/* Texte aligné à gauche */}
            <Typography className="data-table-title">
              {audits && audits.length === 0
                ? "Aucun audit disponible"
                : "Liste d'audit"}
            </Typography>
          </Box>

          {audits && audits.length !== 0 && (
            <WidgetMainContainer sx={{ borderColor: "--primary-color" }}>
              <DataGrid
                rows={filteredRows!}
                columns={columns}
                disableRowSelectionOnClick // Éviter la sélection par clic sur la ligne
                getRowId={(row) => row.id}
                pageSizeOptions={[5, 10, 25, 50]}
                initialState={{
                  pagination: {
                    paginationModel: { pageSize: 25, page: 0 },
                  },
                  columns: {
                    columnVisibilityModel: columnVisibility,
                  },
                }}
                onColumnVisibilityModelChange={(newModel) =>
                  setColumnVisibility(newModel)
                }
                slots={{ toolbar: CustomToolBarAudit }}
                slotProps={{
                  toolbar: {
                    isSuccessOperation,
                    setIsSuccessOperation,
                    isFailedOperation,
                    setIsFailedOperation,
                    isCreateAction,
                    setIsCreateAction,
                    isUpdateAction,
                    setIsUpdateAction,
                    isDeleteAction,
                    setIsDeleteAction,
                    isSignInAction,
                    setIsSignInAction,
                    isSignOutAction,
                    setIsSignOutAction,
                  } as any,
                }}
                sx={{
                  border: "none",
                  "& .MuiDataGrid-columnHeaderTitle": {
                    fontWeight: "bold",
                  },
                }}
              />
            </WidgetMainContainer>
          )}

          {/* Display a new request for certficate */}
          {openModalDisplay && selectedAuditData && (
            <MyModal
              mainColor="--certifcate-main-color"
              open={openModalDisplay}
              onClose={handleCloseModal}
              title={modalType}
              data={{}}
            >
              <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
                {Object.entries(selectedAuditData)
                  .filter(([key]) => key !== "id")
                  .map(([key, value]) => (
                    <Box
                      key={key}
                      sx={{
                        display: "flex",
                        borderBottom: "1px solid #eee",
                        py: 1,
                      }}
                    >
                      <Typography
                        sx={{
                          fontWeight: "bold",
                          width: "30%",
                          minWidth: "150px",
                        }}
                      >
                        {key}:
                      </Typography>
                      <Box sx={{ width: "70%" }}>
                        {value === null || value === "" ? (
                          <Typography fontWeight="bold" fontSize="1.2rem">
                            -
                          </Typography>
                        ) : typeof value === "string" &&
                          [
                            "Status d'opération",
                            "Type d'action",
                            "Adresse IP",
                            "Date d'opération",
                          ].includes(key) ? (
                          valueContent(value, key)
                        ) : (
                          <Typography>{value}</Typography>
                        )}
                      </Box>
                    </Box>
                  ))}
              </Box>
            </MyModal>
          )}
        </Box>
      </ThemeProvider>
    );
}
