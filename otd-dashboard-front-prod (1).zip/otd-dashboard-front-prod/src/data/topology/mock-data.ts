import type {
  BackupStatus,
  ChangeRequest,
  BatchJob,
  CftFlow,
} from "@/types/TopologyTypes";

export const generateBackupData = (): BackupStatus[] => {
  return Array.from({ length: 5 }, (_, i) => ({
    id: i + 1,
    name: `Backup-${["DB", "App", "Config", "Files", "Full"][i]}`,
    status: ["success", "success", "pending", "warning", "success"][i] as
      | "success"
      | "failed"
      | "pending"
      | "warning",
    lastBackup: new Date(
      Date.now() - Math.random() * 86400000 * 5,
    ).toLocaleString(),
    nextBackup: new Date(
      Date.now() + Math.random() * 86400000 * 5,
    ).toLocaleString(),
    size: `${(Math.random() * 100).toFixed(1)} GB`,
    retention: `${Math.floor(Math.random() * 30) + 1} jours`,
    type: [
      "Complète",
      "Différentielle",
      "Incrémentale",
      "Complète",
      "Différentielle",
    ][i],
  }));
};

export const generateEcabChanges = (): ChangeRequest[] => {
  return Array.from({ length: 4 }, (_, i) => ({
    id: `ECAB-${1000 + i}`,
    title: [
      "Mise à jour des certificats SSL",
      "Déploiement correctif sécurité",
      "Mise à niveau base de données",
      "Ajout de capacité serveurs",
    ][i],
    status: ["approved", "pending", "completed", "approved"][i] as
      | "approved"
      | "pending"
      | "rejected"
      | "completed",
    requestedBy: [
      "Jean Dupont",
      "Marie Martin",
      "Pierre Durand",
      "Sophie Lefebvre",
    ][i],
    requestedDate: new Date(
      Date.now() - Math.random() * 86400000 * 10,
    ).toLocaleDateString(),
    implementationDate: new Date(
      Date.now() + Math.random() * 86400000 * 15,
    ).toLocaleDateString(),
    priority: ["high", "medium", "medium", "low"][i] as
      | "high"
      | "medium"
      | "low",
    impact: ["medium", "high", "low", "low"][i] as "high" | "medium" | "low",
    type: ["Sécurité", "Correctif", "Performance", "Infrastructure"][i],
  }));
};

export const generateCabChanges = (): ChangeRequest[] => {
  return Array.from({ length: 3 }, (_, i) => ({
    id: `CAB-${2000 + i}`,
    title: [
      "Migration vers nouvelle infrastructure",
      "Refonte architecture microservices",
      "Implémentation solution monitoring",
    ][i],
    status: ["pending", "approved", "completed"][i] as
      | "approved"
      | "pending"
      | "rejected"
      | "completed",
    requestedBy: ["Équipe Architecture", "DevOps Team", "Équipe Monitoring"][i],
    requestedDate: new Date(
      Date.now() - Math.random() * 86400000 * 20,
    ).toLocaleDateString(),
    implementationDate: new Date(
      Date.now() + Math.random() * 86400000 * 30,
    ).toLocaleDateString(),
    priority: ["high", "high", "medium"][i] as "high" | "medium" | "low",
    impact: ["high", "high", "medium"][i] as "high" | "medium" | "low",
    type: ["Infrastructure", "Architecture", "Monitoring"][i],
  }));
};

export const generateBatchJobs = (): BatchJob[] => {
  return Array.from({ length: 6 }, (_, i) => ({
    id: i + 1,
    name: [
      "Traitement comptable quotidien",
      "Synchronisation données clients",
      "Génération rapports mensuels",
      "Nettoyage logs système",
      "Sauvegarde incrémentale",
      "Indexation base de données",
    ][i],
    status: [
      "running",
      "completed",
      "failed",
      "scheduled",
      "completed",
      "running",
    ][i] as "running" | "completed" | "failed" | "scheduled",
    startTime: new Date(Date.now() - Math.random() * 86400000).toLocaleString(),
    endTime:
      ["running", "scheduled"].includes(
        ["running", "completed", "failed", "scheduled", "completed", "running"][
          i
        ],
      ) || Math.random() > 0.5
        ? null
        : new Date(Date.now() - Math.random() * 3600000).toLocaleString(),
    duration: `${Math.floor(Math.random() * 120 + 5)} min`,
    progress: Math.floor(Math.random() * 100),
    server: [`SRV-BATCH-0${i + 1}`, `SRV-PROC-0${i + 1}`, `SRV-APP-0${i + 1}`][
      Math.floor(Math.random() * 3)
    ],
  }));
};

export const generateCftFlows = (): CftFlow[] => {
  return Array.from({ length: 5 }, (_, i) => ({
    id: i + 1,
    name: [
      "Flux comptabilité -> ERP",
      "Synchronisation RH",
      "Export données clients",
      "Import factures fournisseurs",
      "Transfert logs audit",
    ][i],
    status: ["active", "active", "error", "inactive", "active"][i] as
      | "active"
      | "inactive"
      | "error",
    lastExecution: new Date(
      Date.now() - Math.random() * 86400000 * 2,
    ).toLocaleString(),
    frequency: [
      "Quotidien",
      "Hebdomadaire",
      "Temps réel",
      "Mensuel",
      "Quotidien",
    ][i],
    source: [
      `SRC-${i + 1}`,
      `APP-${i + 1}`,
      `DB-${i + 1}`,
      `EXT-${i + 1}`,
      `LOG-${i + 1}`,
    ][i],
    destination: [
      `DEST-${i + 1}`,
      `TGT-${i + 1}`,
      `ARCH-${i + 1}`,
      `PROC-${i + 1}`,
      `AUDIT-${i + 1}`,
    ][i],
    transferredFiles: Math.floor(Math.random() * 1000) + 100,
    averageSize: `${(Math.random() * 10 + 1).toFixed(1)} MB`,
  }));
};

export const generateOverviewStats = () => ({
  uptime: Math.floor(Math.random() * 100) + 90 + "%",
  performance: Math.floor(Math.random() * 30) + 70 + "%",
  backupStatus: Math.random() > 0.2 ? "success" : "warning",
  lastIncident: Math.floor(Math.random() * 30) + 1 + " jours",
  healthScore: Math.floor(Math.random() * 30) + 70,
  alerts: Math.floor(Math.random() * 5),
});
