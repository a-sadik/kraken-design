// src/types/dto/response/ProjectAmountsResponseDTO.ts

export interface ProjectAmountsResponseDTO {
  name: string;
  budget: number;
  consumption: number;
  etat: "red" | "orange" | "green" | "grey";
  statistic: {
    servers?: number;
    apps?: number;
    interval?: number;
  };
}
