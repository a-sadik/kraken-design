// src/pages/primary-pages/auditadmin/sections/DomaineSection.tsx

import React, { useEffect, useMemo, useState } from "react";
import {
  Box,
  Grid,
  Stack,
  Typography,
  IconButton,
  Collapse,
  TextField,
  Snackbar,
  Alert as MuiAlert,
  Button,
  useMediaQuery,
} from "@mui/material";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";
import SearchIcon from "@mui/icons-material/Search";

import WidgetMainContainer from "@/components/containers/WidgetMainContainer";
import { MaterialReactTable, MRT_ColumnDef } from "material-react-table";

import { CreateDomainModal } from "@/components/modals/CreateDomainModal";
import { EditDomaineModal } from "@/components/modals/EditDomaineModal";
import { InfoModal } from "@/components/modals/InfoModal";

import { getAllDomains } from "@/services/admin/DomainService";
import { DomainShortResponseDTO } from "@/types/dto/DomainDTO";

const PAGE_SIZE = 5;

const DomaineSection: React.FC = () => {
  const [domains, setDomains] = useState<DomainShortResponseDTO[]>([]);
  const [loading, setLoading] = useState(false);

  const [collapseOpen, setCollapseOpen] = useState(true);
  const [globalFilter, setGlobalFilter] = useState("");
  const [snack, setSnack] = useState({
    open: false,
    msg: "",
    severity: "success" as "success" | "error",
  });

  const [addOpen, setAddOpen] = useState(false);
  const [selected, setSelected] = useState<DomainShortResponseDTO | null>(null);
  const [editOpen, setEditOpen] = useState(false);
  const [infoOpen, setInfoOpen] = useState(false);

  const isXs = useMediaQuery("(max-width:480px)");

  const fetchDomains = () => {
    setLoading(true);
    getAllDomains()
      // .then(setDomains)
      .then((data) => {
        // ⇢ On place le plus récent (post_id le plus élevé) en tête
        const sorted = [...data].sort((a, b) => b.domain_id - a.domain_id);
        setDomains(sorted);
      })
      .catch(() =>
        setSnack({
          open: true,
          msg: "Erreur de chargement",
          severity: "error",
        }),
      )
      .finally(() => setLoading(false));
  };
  useEffect(fetchDomains, []);

  const columns = useMemo<MRT_ColumnDef<DomainShortResponseDTO>[]>(
    () => [
      {
        header: "Domaine",
        accessorKey: "domain_name",
        muiTableBodyCellProps: {
          sx: {
            cursor: "pointer",
            color: "primary.main",
            "&:hover": { textDecoration: "underline" },
          },
        },
        Cell: ({ row }) => (
          <Typography
            onClick={() => {
              setSelected(row.original);
              setInfoOpen(true);
            }}
          >
            {row.original.domain_name}
          </Typography>
        ),
      },
      {
        header: "Actions",
        id: "actions",
        enableSorting: false,
        enableColumnFilter: false,
        muiTableHeadCellProps: { sx: { textAlign: "right" } },
        muiTableBodyCellProps: { sx: { textAlign: "right" } },
        Cell: ({ row }) => (
          <Stack direction="row" justifyContent="flex-end" spacing={1}>
            <Button
              variant="contained"
              color="info"
              size="small"
              onClick={() => {
                setSelected(row.original);
                setEditOpen(true);
              }}
            >
              Modifier
            </Button>
          </Stack>
        ),
      },
    ],
    [],
  );

  const data = useMemo(() => {
    if (!globalFilter) return domains;
    return domains.filter((d) =>
      d.domain_name.toLowerCase().includes(globalFilter.toLowerCase()),
    );
  }, [domains, globalFilter]);

  useEffect(() => {
    if (globalFilter.trim() && !collapseOpen) {
      setCollapseOpen(true);
    }
  }, [globalFilter]);

  return (
    <Grid container spacing={3} sx={{ mb: 3 }}>
      <Grid item xs={12}>
        <WidgetMainContainer>
          {/* Header */}
          <Stack
            direction="row"
            justifyContent="space-between"
            alignItems="center"
            flexWrap="wrap"
          >
            <Stack direction="row" alignItems="center" spacing={1}>
              <Typography variant="h6" fontWeight="bold">
                Domaines
              </Typography>
              <IconButton onClick={() => setAddOpen(true)}>
                <AddCircleOutlineIcon color="primary" />
              </IconButton>
            </Stack>

            <Stack
              direction="row"
              spacing={1}
              alignItems="center"
              flexWrap="wrap"
            >
              {isXs ? (
                <IconButton>
                  <SearchIcon />
                </IconButton>
              ) : (
                <Box sx={{ width: { xs: "120px", sm: "230px" } }}>
                  <TextField
                    size="small"
                    fullWidth
                    placeholder="Rechercher…"
                    value={globalFilter}
                    onChange={(e) => setGlobalFilter(e.target.value)}
                  />
                  {!collapseOpen && globalFilter && (
                    <Typography variant="caption" color="textSecondary">
                      Résultats filtrés — ouvrez la section pour les voir.
                    </Typography>
                  )}
                </Box>
              )}

              <IconButton onClick={() => setCollapseOpen((o) => !o)}>
                {collapseOpen ? <ExpandLessIcon /> : <ExpandMoreIcon />}
              </IconButton>
            </Stack>
          </Stack>

          {/* Table */}
          <Collapse in={collapseOpen}>
            <MaterialReactTable
              columns={columns}
              data={data}
              state={{ isLoading: loading, showProgressBars: loading }}
              enableColumnActions={false}
              enableDensityToggle={false}
              enableHiding={false}
              enableFullScreenToggle={false}
              enableToolbarInternalActions={false}
              enableGlobalFilter={false}
              initialState={{
                pagination: { pageIndex: 0, pageSize: PAGE_SIZE },
              }}
              muiTablePaperProps={{
                elevation: 0,
                sx: { boxShadow: "none", border: "none" },
              }}
              muiTableContainerProps={{
                sx: {
                  border: "none",
                  "& .MuiTableRow-root, & .MuiTableCell-root": {
                    borderBottom: "none",
                  },
                },
              }}
              muiTableHeadProps={{
                sx: {
                  display: "none",
                },
              }}
              muiTableBodyProps={{
                sx: {
                  paddingTop: 0,
                },
              }}
            />
          </Collapse>
        </WidgetMainContainer>
      </Grid>

      {/* Modals */}
      <CreateDomainModal
        open={addOpen}
        onClose={() => setAddOpen(false)}
        onSave={() => {
          fetchDomains();
          setAddOpen(false);
        }}
        initialData={null}
      />

      {selected && (
        <EditDomaineModal
          open={editOpen}
          onClose={() => setEditOpen(false)}
          onSave={() => {
            fetchDomains();
            setEditOpen(false);
          }}
          domainId={selected.domain_id}
          currentName={selected.domain_name}
          currentManagerId={selected.domain_manager_id}
          currentPoleId={selected.pole_id}
        />
      )}

      {selected && (
        <InfoModal
          open={infoOpen}
          onClose={() => setInfoOpen(false)}
          kind="domaine"
          id={selected.domain_id}
        />
      )}

      {/* Snackbar */}
      <Snackbar
        open={snack.open}
        autoHideDuration={3000}
        onClose={() => setSnack((s) => ({ ...s, open: false }))}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <MuiAlert severity={snack.severity} variant="filled">
          {snack.msg}
        </MuiAlert>
      </Snackbar>
    </Grid>
  );
};

export default DomaineSection;
