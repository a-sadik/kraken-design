/* eslint-disable react-refresh/only-export-components */
// src/routes.tsx
import { lazy } from "react";

// import icons
import AutoStoriesIcon from "@mui/icons-material/AutoStories";
import DifferenceIcon from "@mui/icons-material/Category";
import FactCheckIcon from "@mui/icons-material/FactCheck";
import SettingsIcon from "@mui/icons-material/Settings";
import HomeRepairServiceIcon from "@mui/icons-material/HomeRepairService";
import ListAltIcon from "@mui/icons-material/ListAlt";
import HubIcon from "@mui/icons-material/Hub";
import AdminPanelSettingsIcon from "@mui/icons-material/AdminPanelSettings";
import HistoryIcon from "@mui/icons-material/History";
import SpeedIcon from "@mui/icons-material/Speed";
import { TbWorldWww } from "react-icons/tb";
import { TbHierarchy3 } from "react-icons/tb";
import { SiBackstage } from "react-icons/si";
import Person from "@mui/icons-material/Person";

import CockpitPageGeneral from "./pages/primary-pages/CockpitPageGeneral";
import ServerCockpit from "./pages/primary-pages/ServerCockpit";
import MyViewPage from "./pages/primary-pages/MyViewPage";
import AitaCockpit from "./pages/primary-pages/AitaCockpit";
import AnnouncementsAdmin from "./pages/sub-pages/AnnouncementsAdminPage";
import AdminDocumentationPage from "./pages/sub-pages/AdminDocumentationPage";
import AdminReleaseNotesPage from "./pages/sub-pages/AdminReleaseNotesPage";
import { GrNotes } from "react-icons/gr";
// import CABCreationPage from "./pages/sub-pages/CABCreationPage";

const CockpitPage = lazy(() => import("./pages/primary-pages/CockpitPage"));
const CronJobCRUD = lazy(() => import("./pages/primary-pages/CronJobCRUD"));
const SignatureServersPage = lazy(() => import("./pages/primary-pages/SignatureServersPage"));
const SignatureNamespacesPage = lazy(() => import("./pages/primary-pages/SignatureNamespacesPage"));
const ReliabilityPage = lazy(() => import("./pages/primary-pages/ReliabilityPage"));
const SelfServicePage = lazy(() => import("./pages/primary-pages/SelfServicePage"));
const AuditAdminPage = lazy(() => import("./pages/primary-pages/AuditAdminPage"));
const CertifcatesPage = lazy(() => import("./pages/sub-pages/CertifcatesPage"));
const OpenshiftPage = lazy(() => import("./pages/sub-pages/OpenshiftPage"));
const AdminPage = lazy(() => import("./pages/primary-pages/auditadmin/AdminPage"));
const AuditPage = lazy(() => import("./pages/sub-pages/AuditPage"));
const NotFoundPage = lazy(() => import("./pages/primary-pages/NotFoundPage"));
const EntityPage = lazy(() => import("./pages/sub-pages/admin/EntityPage"));
const PolePage = lazy(() => import("./pages/sub-pages/admin/PolePage"));
const DomainPage = lazy(() => import("./pages/sub-pages/admin/DomainPage"));
const SolutionPage = lazy(() => import("./pages/sub-pages/admin/SolutionPage"));
const RolePage = lazy(() => import("./pages/sub-pages/admin/RolePage"));
const PersonPage = lazy(() => import("./pages/primary-pages/auditadmin/PersonPage"));
const BackstageOrganigrammePage = lazy(() => import("./pages/sub-pages/admin/BackstageOrganigrammePage"));
const BackstageDataPage = lazy(() => import("./pages/sub-pages/admin/BackstageDataPage"));
const VerifyURLPage = lazy(() => import("./pages/sub-pages/admin/VerifyURLPage"));
const MachineManagementApp = lazy(() => import("./pages/MachineManagementApp"));
const AdministrationPage = lazy(() => import("./pages/primary-pages/AdministrationPage"));
const AuditagePage = lazy(() => import("./pages/primary-pages/AuditPage"));
const IsolatedServerPage = lazy(() => import("./pages/primary-pages/IsolatedServerPage"));
const TopologyPage = lazy(() => import("./pages/primary-pages/TopologyPage"));
const SignaturePage = lazy(() => import("./pages/primary-pages/SignaturePage"));
const FiabilisationPage = lazy(() => import("./pages/primary-pages/FiabilisationPage"));
const ServerComparisonPage = lazy(() => import("./pages/primary-pages/ServerComparisonPage"));
const ActionsPage = lazy(() => import("./pages/primary-pages/BackupPage"));

export enum PageTitle {
  KRAKEN = "KRAKEN",
  Cockpit = "Cockpit",
  Cockpits = "Cockpit serveur",
  AitaCockpit = "Cockpit Aita",
  Cockpit_certif = "Cockpit signatures",
  SERVERS_SIGNATURE = "Signatures",
  DASHBOARD = "Dashboard",
  RELIABILITY = "Fiabilisation",
  SELF_SERVICE = "Self Service",
  AUDIT_ADMIN = "Audit & Admin",
  CERTIFICATES = "Certifcats",
  OPEN_SHIFT = "OpenShift",
  AUDIT = "Audit",
  ADMIN = "Admin",
  BACKSTAGE_ORG = "Organigramme",
  BACKSTAGE_DATA = "Data de BackStage",
  DOMAINENAME = "Verifier SSL",
  Machine = "demander une machine",
  AUDIT_REAL = "Vrai Audit",
  CRONJOBS_CRUD_PANEL = "Configuration CronJobs",
  MY_VIEW = "My View",
  Backup = "Backup",
  Announcement= "Annonce",
  Documentation= "Documentation",
  Release= "Release",
  CAB = "CAB"
}

const routes = [
  // 0 - 404
  {
    path: "*",
    element: <NotFoundPage />,
    icon: null,
    title: "Not Found",
    showInNave: false,
    requiredRoles: [],
  },

  // 1 - Cockpit Général
  {
    path: "/cockpit-general",
    element: <CockpitPageGeneral />,
    icon: <SpeedIcon />,
    title: PageTitle.Cockpit,
    showInNave: true,
    requiredRoles: ["admin_role", "read_only_role", "ops_role", "tam_role", "security_role"],
  },

  // 2 - Signatures Serveurs
  {
    path: "/signature-serveurs",
    element: <SignatureServersPage />,
    icon: <FactCheckIcon />,
    title: PageTitle.SERVERS_SIGNATURE,
    showInNave: true,
    requiredRoles: ["admin_role", "read_only_role", "ops_role", "tam_role", "dev_role"],
  },

  // 3 - Fiabilisation (old)
  {
    path: "/fiabilisation",
    element: <FiabilisationPage />,
    icon: <DifferenceIcon />,
    title: PageTitle.RELIABILITY,
    showInNave: false,
    requiredRoles: ["admin_role"],
  },

  // 4 - Self Service
  {
    path: "/self-service",
    element: <SelfServicePage />,
    icon: <HomeRepairServiceIcon />,
    title: PageTitle.SELF_SERVICE,
    showInNave: true,
    requiredRoles: ["ops_role", "tam_role", "self_service_certificate_role", "security_role", "self_service_release_role"],
  },

  // 5 - Certificats
  {
    path: "/certifcats",
    element: <CertifcatesPage />,
    title: PageTitle.CERTIFICATES,
    showInNave: false,
    requiredRoles: ["ops_role", "tam_role", "self_service_certificate_role", "security_role"],
  },

  // 6 - OpenShift
  {
    path: "/openShift",
    element: <OpenshiftPage />,
    title: PageTitle.OPEN_SHIFT,
    showInNave: false,
    requiredRoles: ["admin_role"],
  },

  // 7 - Vision 360
  {
    path: "/reliability/topology",
    element: <TopologyPage />,
    icon: <HubIcon />,
    title: "Vision 360",
    showInNave: true,
    requiredRoles: [
      "admin_role",
      "vision_360_read_only_role",
      // "tam_role",
      // "read_only_role",
      // "ops_role",
    ],
  },
  // 8 - Admin Page
  {
    path: "/auditadmin/admin",
    element: <AdminPage />,
    icon: <AdminPanelSettingsIcon />,
    title: PageTitle.ADMIN,
    showInNave: false,
    requiredRoles: ["admin_role"],
  },

  // 9 - Audit Page
  {
    path: "/auditadmin/audit",
    element: <AuditPage />,
    icon: <HistoryIcon />,
    title: PageTitle.AUDIT,
    showInNave: false,
    requiredRoles: ["admin_role"],
  },

  // 10 à 16 - Admin Subpages
  { path: "/admin/entite", element: <EntityPage />, title: "entite", showInNave: false, requiredRoles: ["admin_role"] },
  { path: "/admin/pole", element: <PolePage />, title: "pole", showInNave: false, requiredRoles: ["admin_role"] },
  { path: "/admin/domaine", element: <DomainPage />, title: "domaine", showInNave: false, requiredRoles: ["admin_role"] },
  { path: "/admin/solution", element: <SolutionPage />, title: "solution", showInNave: false, requiredRoles: ["admin_role"] },
  { path: "/admin/role", element: <RolePage />, title: "role", showInNave: false, requiredRoles: ["admin_role"] },
  { path: "/admin/personne", element: <PersonPage />, title: "personne", showInNave: false, requiredRoles: ["admin_role"] },

  // 17 - Backstage Organigramme
  {
    path: "/admin/backstage/organigramme",
    element: <BackstageOrganigrammePage />,
    icon: <TbHierarchy3 size={60} />,
    title: PageTitle.BACKSTAGE_ORG,
    showInNave: false,
    requiredRoles: ["admin_role"],
  },

  // 18 - Backstage Data
  {
    path: "/admin/backstage/data",
    element: <BackstageDataPage />,
    icon: <SiBackstage size={60} />,
    title: PageTitle.BACKSTAGE_DATA,
    showInNave: false,
    requiredRoles: ["admin_role"],
  },

  // 20 - Server Comparison
  {
    path: "/reliability/server-compare",
    element: <ServerComparisonPage />,
    icon: <ListAltIcon style={{ fontSize: '60px' }} />,
    title: "Fiabilisation v2",
    showInNave: false,
    requiredRoles: ["admin_role"],
  },

  // 21 - Isolated Servers
  {
    path: "/reliability/isolated",
    element: <IsolatedServerPage />,
    icon: <ListAltIcon />,
    title: "Fiabilisation v2",
    showInNave: false,
    requiredRoles: ["admin_role"],
  },

  // 22 - Signature des serveurs
  {
    path: "/reliability/signatures",
    element: <SignaturePage />,
    icon: <ListAltIcon />,
    title: "Signature des serveurs",
    showInNave: false,
    requiredRoles: ["admin_role"],
  },

  // 23 - Fiabilisation (old)
  {
    path: "/reliability/fiabilisation",
    element: <ReliabilityPage />,
    icon: <DifferenceIcon />,
    title: "Fiabilisation (old)",
    showInNave: false,
    requiredRoles: ["admin_role"],
  },

  // 24 - Verify URL
  {
    path: "/auditadmin/verifierUrl",
    element: <VerifyURLPage />,
    icon: <TbWorldWww />,
    title: PageTitle.DOMAINENAME,
    showInNave: false,
    requiredRoles: ["admin_role"],
  },

  // Signature Namespaces
  {
    path: "/signature-namespaces",
    element: <SignatureNamespacesPage />,
    icon: <FactCheckIcon />,
    title: PageTitle.SERVERS_SIGNATURE,
    showInNave: false,
    requiredRoles: ["admin_role", "ops_role", "tam_role"],
  },

  // Machine Management
  {
    path: "/self-service/machine",
    element: <MachineManagementApp />,
    icon: <DifferenceIcon />,
    title: "demander une machine",
    showInNave: false,
    requiredRoles: ["ops_role", "tam_role"],
  },

  // Administration
  {
    path: "/administration",
    element: <AdministrationPage />,
    icon: <DifferenceIcon />,
    title: "Administration",
    showInNave: false,
    requiredRoles: ["admin_role"],
  },

  // Cockpit Certif
  {
    path: "/cockpit",
    element: <CockpitPage />,
    icon: <SpeedIcon />,
    title: PageTitle.Cockpit_certif,
    showInNave: false,
    requiredRoles: ["admin_role", "read_only_role", "ops_role", "tam_role", "security_role"],
  },

  // Cockpit Serveur
  {
    path: "/cockpit-serveur",
    element: <ServerCockpit />,
    icon: <SpeedIcon />,
    title: PageTitle.Cockpits,
    showInNave: false,
    requiredRoles: ["admin_role", "read_only_role", "ops_role", "tam_role"],
  },

  // Cockpit AITA
  {
    path: "/cockpit-AITA",
    element: <AitaCockpit />,
    icon: <SpeedIcon />,
    title: PageTitle.AitaCockpit,
    showInNave: false,
    requiredRoles: ["admin_role", "tam_role"],
  },

  // Référentiel Apps (TAM ONLY)
  {
    path: "/Paramétrage",
    element: <AdministrationPage />,
    icon: <SettingsIcon />,
    title: "Référentiel Apps",
    showInNave: true,
    requiredRoles: ["tam_role"], 
  },

  // Audit Real
  {
    path: "/audting",
    element: <AuditagePage />,
    icon: <SettingsIcon />,
    title: PageTitle.AUDIT_REAL,
    showInNave: false,
    requiredRoles: ["admin_role"],
  },

  // Audit Admin
  {
    path: "/auditadmin",
    element: <AuditAdminPage />,
    icon: <AutoStoriesIcon />,
    title: PageTitle.AUDIT_ADMIN,
    showInNave: true,
    requiredRoles: ["admin_role"],
  },

  // My View
  {
    path: "/mes-applications",
    element: <MyViewPage />,
    icon: <Person />,
    title: PageTitle.MY_VIEW,
    showInNave: true,
    requiredRoles: ["read_only_role", "ops_role", "tam_role", "dev_role", "my_view_role"],
  },

  // CronJobs Config
  {
    path: "/cronjobs-config",
    element: <CronJobCRUD />,
    icon: <Person />,
    title: PageTitle.CRONJOBS_CRUD_PANEL,
    showInNave: false,
    requiredRoles: ["admin_role"],
  },


 // backup page
  {
    path: "/Backup",
    element: <ActionsPage />,
    icon: <Person />,
    title: PageTitle.Backup,
    showInNave: false,
    requiredRoles: ["admin_role"],
  },

  // Announcement page
  {
    path: "/Announcement",
    element: <AnnouncementsAdmin />,
    icon: <Person />,
    title: PageTitle.Announcement,
    showInNave: false,
    requiredRoles: ["admin_role"],
  },

  // Announcement page
  {
    path: "/Documentation",
    element: <AdminDocumentationPage />,
    icon: <Person />,
    title: PageTitle.Documentation,
    showInNave: false,
    requiredRoles: ["admin_role"],
  },

  // release note page
  {
    path: "/AdminReleaseNotesPage",
    element: <AdminReleaseNotesPage />,
    icon: <GrNotes />,
    title: PageTitle.Release,
    showInNave: false,
    requiredRoles: ["admin_role", "self_service_release_role", "ops_role"],
  },

  // // CAB page
  // {
  //   path: "/CABCreationPage",
  //   element: <CABCreationPage />,
  //   icon: <GrNotes />,
  //   title: PageTitle.CAB,
  //   showInNave: true,
  //   // requiredRoles: ["admin_role", "self_service_release_role", "ops_role"],
  // },
];

export default routes;