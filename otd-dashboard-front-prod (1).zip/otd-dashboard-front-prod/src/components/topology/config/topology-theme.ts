export const pastelTheme = {
  primary: "#99caff", // bleu windows
  secondary: "#a8e6b1", // vert linux
  accent: "#f3aebd", // rose macos
  surface: "#fce38a", // jaune par défaut
  background: "#F5F7FA",
  surfaceVariant: "#ffb3b3", // rouge production
  outline: "#D1D5DB",
  shadow: "rgba(0, 0, 0, 0.1)",
  cardBackground: "#FFFFFF",
  textPrimary: "#2D3748",
  textSecondary: "#4A5568",
};

// couleurs par niveau
export const colors = {
  entity: "#fce38a", // jaune pastel
  pole: "#c6b3ff", // violet pastel
  domain: "#b3ffcc", // vert pastel
  solution: "#b3e6ff", // bleu clair pastel
  namespace: "#a8e6b1", // vert linux
  deployment: "#f3aebd", // rose macos
  server: "#99caff", // bleu windows
  pod: "#ffd699", // orange pastel
};

export const darkColors = {
  entity: "#f5d95a",
  pole: "#b399ff",
  domain: "#99e6b3",
  solution: "#99d6ff",
  namespace: "#90d69e",
  deployment: "#e39eae",
  server: "#7fb2e6",
  pod: "#ffc266",
};

export const envColors = {
  Production: "#ffb3b3", // rouge pastel soutenu
  Préproduction: "#ffd699", // orange pastel soutenu
  Intégration: "#b3e6ff", // bleu clair pastel
  Recette: "#c6b3ff", // violet pastel doux
  Développement: "#a8e6b1", // vert pastel soutenu
  Formation: "#ffe6cc",
};

export const osColors = {
  Windows: "#99caff", // bleu pastel un peu plus soutenu
  Linux: "#a8e6b1", // vert pastel plus marqué
  MacOS: "#f3aebd", // rose pastel plus profond
  AIX: "#fce38a", // rose pastel plus profond
  Default: "#7fb2e6", // jaune pastel plus chaud
};

// Thème avec plus de contraste
export const modernTheme = {
  primary: "#2563EB",
  secondary: "#7C3AED",
  accent: "#059669",
  surface: "#FFCE14",
  background: "#F1F5F9", // Plus sombre
  surfaceVariant: "#e04434", // Plus sombre
  outline: "#CBD5E1", // Plus visible
  shadow: "rgba(15, 23, 42, 0.12)", // Plus prononcé
  cardBackground: "#FFFFFF",
  textPrimary: "#1E293B",
  textSecondary: "#475569",
};
