// src/components/CertificateConfigDisplay.tsx
import { CardContent, Typography } from "@mui/material";
import React from "react";

interface CertificateConfigProps {
  certificateById: {
    config_file: {
      countryName: string;
      stateOrProvinceName: string;
      localityName: string;
      organizationName: string;
      organizationalUnitName: string;
      commonName: string;
      emailAddress: string;
      postalCode: string;
      streetAddress: string;
      subjectAltName: string;
    };
    dns?: string[] | null;
  };
}

const CertificateConfigDisplay: React.FC<CertificateConfigProps> = ({
  certificateById,
}) => {
  const config = certificateById.config_file;

  return (
    <CardContent>
      <Typography variant="h6" component="p">
        <b>[req_distinguished_name]</b>
      </Typography>
      <Typography variant="h6" component="p">
        countryName = {config.countryName}
      </Typography>
      <Typography variant="h6" component="p">
        stateOrProvinceName = {config.stateOrProvinceName}
      </Typography>
      <Typography variant="h6" component="p">
        localityName = {config.localityName}
      </Typography>
      <Typography variant="h6" component="p">
        organizationName = {config.organizationName}
      </Typography>
      <Typography variant="h6" component="p">
        organizationalUnitName = {config.organizationalUnitName}
      </Typography>
      <Typography variant="h6" component="p">
        commonName = <b>{config.commonName}</b>
      </Typography>
      <Typography variant="h6" component="p">
        emailAddress = {config.emailAddress}
      </Typography>
      <Typography variant="h6" component="p">
        postalCode = {config.postalCode}
      </Typography>
      <Typography variant="h6" component="p">
        streetAddress = {config.streetAddress}
      </Typography>
      <Typography variant="h6" component="p">
        <b>[req_ext]</b>
      </Typography>
      <Typography variant="h6" component="p">
        subjectAltName = {config.subjectAltName}
      </Typography>
      <Typography variant="h6" component="p">
        <b>[alt_names]</b>
      </Typography>

      {certificateById.dns &&
        certificateById.dns.map((value, index) => (
          <Typography variant="h6" component="p" key={index}>
            <b>{`DNS.${index + 1}`}</b> = {value}
          </Typography>
        ))}
    </CardContent>
  );
};

export default CertificateConfigDisplay;
