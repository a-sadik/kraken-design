import React, { useEffect, useState } from "react";
import {
  Box,
  Button,
  CircularProgress,
  TextField,
  Autocomplete,
} from "@mui/material";
import axios from "axios";
import MyModal from "@/components/modals/MyModal";
// import { getAllPsiSolutions } from '@/services/SolutionService';

interface Item {
  id: string;
  name: string;
}

interface Props {
  open: boolean;
  onClose: () => void;
  onSave: () => void;
}

export const ModifierPsiSolutionModal: React.FC<Props> = ({
  open,
  onClose,
  onSave,
}) => {
  const [items, _] = useState<Item[]>([]);
  const [selected, setSelected] = useState<Item | null>(null);
  const [newName, setNewName] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open) {
      setLoading(true);
      // getAllPsiSolutions()
      //   .then((data) => setItems(data))
      //   .finally(() => setLoading(false));
      setSelected(null);
      setNewName("");
    }
  }, [open]);

  const handleSave = () => {
    if (!selected || !newName.trim()) return;

    axios
      .put(`/api/solution/psi/${selected.id}`, { name: newName })
      .then(() => {
        onSave();
        onClose();
      });
  };

  return (
    <MyModal open={open} onClose={onClose} title="Modifier un PSI">
      <Box sx={{ minWidth: 500, px: 2, pt: 1 }}>
        {loading ? (
          <Box textAlign="center" my={2}>
            <CircularProgress />
          </Box>
        ) : (
          <>
            <Autocomplete
              options={items}
              getOptionLabel={(o) => o.name}
              value={selected}
              onChange={(_, value) => {
                setSelected(value);
                setNewName(value?.name || "");
              }}
              renderInput={(params) => (
                <TextField {...params} label="Sélectionner un PSI" fullWidth />
              )}
            />

            <TextField
              fullWidth
              label="Nouveau nom du PSI"
              sx={{ mt: 2 }}
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              disabled={!selected}
            />
          </>
        )}

        <Box textAlign="right" mt={3}>
          <Button onClick={onClose} variant="outlined" sx={{ mr: 1 }}>
            Annuler
          </Button>
          <Button
            onClick={handleSave}
            variant="contained"
            disabled={!selected || !newName.trim()}
            sx={{
              backgroundColor: "#1976d2",
              color: "#fff",
              fontWeight: "bold",
              "&:hover": {
                backgroundColor: "#125ea9",
              },
            }}
          >
            Modifier
          </Button>
        </Box>
      </Box>
    </MyModal>
  );
};
