// src/types/enums/OperatingSystemType.ts

export enum OperatingSystemType {
  Windows = "Windows",
  Linux = "Linux",
  AIX = "AIX",
  MacOS = "MacOS",
}
