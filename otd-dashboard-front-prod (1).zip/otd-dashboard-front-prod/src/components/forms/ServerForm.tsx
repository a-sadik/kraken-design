// src/components/ServerForm.tsx

import { useEffect, useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z as zod } from "zod";
import {
  TextField,
  Button,
  Grid,
  Autocomplete,
  Typography,
  CircularProgress,
  Box,
  MenuItem,
  Alert,
  Paper,
  Chip,
} from "@mui/material";
import { styled } from "@mui/material/styles";

// Imports file
import { SolutionDetailResponseDTO } from "@/types/dto/response/solution/SolutionDetailResponseDTO";
import { OperatingSystemType } from "@/enums/OperatingSystemType";
import { ServerNature } from "@/enums/ServerNature";
import { Environnement } from "@/enums/Environnement";
import { getAllSolutions } from "@/services/SolutionService";

// Import messages
import {
  placeholder_environments,
  placeholder_hostname,
  placeholder_ip_addresses,
  placeholder_many_solutions,
  placeholder_nature_detail,
  placeholder_server_nature,
  required_environment,
  required_hostname,
  required_ip_address,
  required_multiple_solutions,
  required_os_type,
  required_server_nature,
} from "@/utils/customMessages";

// Palette de couleurs pastel
const colors = {
  primary: "#A8D8EA",
  secondary: "#AA96DA",
  accent: "#FCBAD3",
  background: "#FFFFD2",
  text: "#555555",
  error: "#FF6B6B",
  success: "#A8E6CF",
  warning: "#FFD3B6",
  info: "#DCE2F0",
};

// Composants stylisés
const StyledPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(3),
  borderRadius: "16px",
  // backgroundColor: colors.background,
  boxShadow: "0 4px 20px rgba(0,0,0,0.1)",
}));

const StyledButton = styled(Button)(() => ({
  borderRadius: "12px",
  padding: "10px 24px",
  fontWeight: "bold",
  textTransform: "none",
  fontSize: "1rem",
  boxShadow: "none",
  "&:hover": {
    boxShadow: "0 4px 8px rgba(0,0,0,0.1)",
  },
}));

const StyledTextField = styled(TextField)(() => ({
  "& .MuiOutlinedInput-root": {
    borderRadius: "12px",
    backgroundColor: "white",
    "& fieldset": {
      borderColor: colors.primary,
    },
    "&:hover fieldset": {
      borderColor: colors.secondary,
    },
    "&.Mui-focused fieldset": {
      borderColor: colors.accent,
    },
  },
}));

const StyledBadge = styled(Chip)(() => ({
  margin: "4px",
  borderRadius: "8px",
  fontWeight: "bold",
}));

// Schéma de validation avec Zod (inchangé)
const getFormSchema = (isDeleteMode: boolean, isDeployMode: boolean) =>
  zod.object({
    hostname: isDeleteMode
      ? zod.string().optional()
      : zod.string().trim().min(1, required_hostname),
    ip_addresses: isDeleteMode
      ? zod.array(zod.string()).optional()
      : zod
          .array(
            zod

              .string()
              .regex(
                /^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/,
                "Adresse IP invalide",
              ),
          )
          .min(1, required_ip_address),
    os_type: isDeleteMode
      ? zod.string().optional()
      : zod.string().trim().min(1, required_os_type),
    uname: isDeleteMode ? zod.string().optional() : zod.string().optional(), // Optionnel car seulement pour AIX
    server_nature: isDeleteMode
      ? zod.array(zod.string()).optional()
      : zod.array(zod.string()).min(1, required_server_nature),
    nature_detail: isDeleteMode
      ? zod.string().optional()
      : zod.string().trim().min(1, "Détail requis"),
    solutions: isDeleteMode
      ? zod
          .array(
            zod.object({
              solution_id: zod.number(),
              solution_name: zod.string(),
              solution_popularity: zod.string(),
            }),
          )
          .optional()
      : zod
          .array(
            zod.object({
              solution_id: zod.number(),
              solution_name: zod.string(),
              solution_popularity: zod.string(),
            }),
          )
          .min(1, required_multiple_solutions),
    solutions_inventory: zod.array(zod.string()).optional(),
    natures_inventory: zod.array(zod.string()).optional(),

    environments: isDeleteMode
      ? zod.array(zod.string()).optional()
      : zod.array(zod.string()).min(1, required_environment),
    login: isDeployMode
      ? zod.string().trim().min(1, "Login requis")
      : zod.string().optional(),
    password: isDeployMode
      ? zod.string().trim().min(1, "Mot de passe requis")
      : zod.string().optional(),
    sudo_password: isDeployMode
      ? zod.string().optional()
      : zod.string().optional(),
  });

export type ServerFormData = zod.infer<ReturnType<typeof getFormSchema>>;

const FormLabel = ({
  label,
  isRequired = false,
}: {
  label: string;
  isRequired?: boolean;
}) => (
  <Typography
    variant="body1"
    sx={{
      fontWeight: "bold",
      display: "flex",
      alignItems: "center",
      mb: "0.5rem",
      fontSize: "1.1rem",
      color: colors.text,
    }}
  >
    {label}
    {isRequired && (
      <span style={{ color: colors.error, marginLeft: 4 }}>*</span>
    )}
  </Typography>
);

interface ServerFormProps {
  initialData: any;
  onSubmit: (data: ServerFormData) => void;
  isEditMode: boolean;
  isViewMode: boolean;
  isDeleteMode: boolean;
  isDeployMode: boolean;
  errorMessage: string | null;
}

export function ServerForm({
  initialData,
  onSubmit,
  isEditMode,
  isViewMode,
  isDeleteMode,
  isDeployMode,
  errorMessage,
}: ServerFormProps) {
  const formSchema = getFormSchema(isDeleteMode, isDeployMode);

  const mockNaturesInventory = [
    "Nature 1",
    "Nature 2",
    "Nature 3",
    "Nature 4",
    "Nature 5",
  ];

  const mockSolutionsInventory = [
    "Solution 1",
    "Solution 2",
    "Solution 3",
    "Solution 4",
    "Solution 5",
  ];

  const {
    control,
    register,
    handleSubmit,
    formState: { errors, isValid },
    setValue,
    watch,
  } = useForm<ServerFormData>({
    resolver: zodResolver(formSchema),
    mode: "all",
    defaultValues: initialData || {
      hostname: "",
      ip_addresses: [],
      os_type: "",
      os_detail: "",
      uname: "",
      server_nature: [],
      nature_detail: "",
      solutions: [],
      environments: [],
      solutions_inventory: mockSolutionsInventory.slice(0, 2),
      natures_inventory: mockNaturesInventory.slice(0, 2),
    },
  });
  const watchedOsType = watch("os_type");
  const isAixOs = watchedOsType === "AIX";
  useEffect(() => {
    if (initialData) {
      Object.keys(initialData).forEach((key) => {
        setValue(
          key as keyof ServerFormData,
          initialData[key as keyof ServerFormData],
        );
      });
    } else {
      setValue("solutions_inventory", mockSolutionsInventory.slice(0, 2));
      setValue("natures_inventory", mockNaturesInventory.slice(0, 2));
      setValue("uname", "");
    }
  }, [initialData, setValue]);

  // Liste des options pour les champs
  const osTypeList = Object.values(OperatingSystemType);
  const solutionNatureList = Object.values(ServerNature);
  const environmentsList = Object.values(Environnement);

  // loading solutions
  const [solutions, setSolutions] = useState<SolutionDetailResponseDTO[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  const fetchSolutions = async () => {
    setLoading(true);
    try {
      const solutionData: SolutionDetailResponseDTO[] = await getAllSolutions();

      if (Array.isArray(solutionData)) {
        setSolutions(solutionData);
      } else {
        console.error(
          "Les données reçues ne sont pas un tableau",
          solutionData,
        );
        setSolutions([]);
      }
    } catch (error) {
      console.error("Erreur lors du chargement des solutions :", error);
      setSolutions([]);
    } finally {
      setLoading(false);
    }
  };

  const handleInputRestriction = (e: any) => {
    const validChars = /^[0-9.]*$/;
    if (!validChars.test(e.target.value)) {
      e.target.value = e.target.value.replace(/[^0-9.]/g, "");
    }
  };

  // Fonctions pour les couleurs des badges
  const getOSColor = (os: string) => {
    switch (os.toLowerCase()) {
      case "windows":
        return "#99caff";
      case "linux":
        return "#a8e6b1";
      case "macos":
        return "#f3aebd";
      case "aix":
        return "#fce38a";
      default:
        return "#7fb2e6";
    }
  };

  const getEnvColor = (env: string) => {
    switch (env.toLowerCase()) {
      case "production":
        return "#ffb3b3";
      case "préproduction":
        return "#FFD699";
      case "intégration":
        return "#B3E6FF";
      case "recette":
        return "#C6B3FF";
      case "développement":
        return "#A8E6B1";
      case "formation":
        return "#ffe6cc";
      default:
        return "#D9D9D9";
    }
  };

  return (
    <StyledPaper elevation={3}>
      <form onSubmit={handleSubmit(onSubmit)}>
        <Grid container spacing={3}>
          {isDeployMode ? (
            <>
              <Grid item xs={12}>
                <FormLabel label="Login" isRequired />
                <StyledTextField
                  {...register("login")}
                  error={!!errors.login}
                  helperText={errors.login?.message}
                  fullWidth
                  disabled={isViewMode}
                  placeholder="Entrez le login"
                />
              </Grid>
              <Grid item xs={12}>
                <FormLabel label="Mot de passe" isRequired />
                <StyledTextField
                  {...register("password")}
                  error={!!errors.password}
                  helperText={errors.password?.message}
                  fullWidth
                  type="password"
                  disabled={isViewMode}
                  placeholder="Entrez le mot de passe"
                />
              </Grid>
              <Grid item xs={12}>
                <FormLabel label="Mot de passe sudo" isRequired={false} />
                <StyledTextField
                  {...register("sudo_password")}
                  error={!!errors.sudo_password}
                  helperText={errors.sudo_password?.message}
                  fullWidth
                  type="password"
                  disabled={isViewMode}
                  placeholder="Entrez le mot de passe sudo (optionnel)"
                />
              </Grid>
            </>
          ) : !isDeleteMode ? (
            <>
              <Grid item xs={12}>
                <FormLabel label="Hostname" isRequired />
                <StyledTextField
                  {...register("hostname")}
                  error={!!errors.hostname}
                  helperText={errors.hostname?.message}
                  fullWidth
                  disabled={isViewMode}
                  placeholder={placeholder_hostname}
                />
              </Grid>

              <Grid item xs={12}>
                <FormLabel label="Adresses IP (v4)" isRequired />
                <Controller
                  name="ip_addresses"
                  control={control}
                  render={({ field }) => (
                    <Autocomplete
                      {...field}
                      multiple
                      freeSolo
                      options={[]}
                      disabled={isViewMode}
                      value={field.value || []}
                      onChange={(_, value) => field.onChange(value || [])}
                      renderInput={(params) => (
                        <StyledTextField
                          {...params}
                          error={!!errors.ip_addresses}
                          helperText={errors.ip_addresses?.message}
                          placeholder={placeholder_ip_addresses}
                          onInput={handleInputRestriction}
                        />
                      )}
                      renderTags={(value, getTagProps) =>
                        value.map((option, index) => (
                          <StyledBadge
                            label={option}
                            {...getTagProps({ index })}
                            style={{ backgroundColor: colors.info }}
                          />
                        ))
                      }
                    />
                  )}
                />
              </Grid>

              <Grid item xs={12}>
                <FormLabel label="Type d'OS" isRequired />
                <Controller
                  name="os_type"
                  control={control}
                  render={({ field }) => (
                    <StyledTextField
                      {...field}
                      select
                      fullWidth
                      disabled={isViewMode}
                      error={!!errors.os_type}
                      helperText={errors.os_type?.message}
                      SelectProps={{
                        native: false,
                        // Correction pour rendre le bouton dropdown cliquable
                        MenuProps: {
                          PaperProps: {
                            sx: {
                              maxHeight: 200,
                              "& .MuiMenuItem-root": {
                                padding: "8px 16px",
                              },
                            },
                          },
                        },
                      }}
                      sx={{
                        "& .MuiSelect-select": {
                          paddingRight: "32px !important", // Espace pour l'icône
                          minHeight: "20px",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "space-between", // Espace entre le contenu et le texte d'aide
                          "&::after": {
                            content: '"Cliquer ici pour choisir le type d\'OS"',
                            color: "#999999",
                            fontSize: "0.875rem",
                            fontStyle: "italic",
                            position: "absolute",
                            left: "50%",
                            transform: "translateX(-50%)",
                            flexShrink: 0,
                          },
                        },
                        "& .MuiSelect-icon": {
                          right: "8px",
                          pointerEvents: "none", // Désactiver les événements sur l'icône
                          cursor: "pointer",
                        },
                        // Assurer que toute la zone est cliquable
                        "& .MuiOutlinedInput-root": {
                          cursor: "pointer",
                          "&:hover": {
                            cursor: "pointer",
                          },
                          // Assurer que les clics sur toute la zone fonctionnent
                          "& .MuiSelect-select": {
                            cursor: "pointer",
                          },
                        },
                        // Solution alternative : créer une zone cliquable invisible sur l'icône
                        "&::after": {
                          content: '""',
                          position: "absolute",
                          right: "8px",
                          top: "50%",
                          transform: "translateY(-50%)",
                          width: "24px",
                          height: "24px",
                          cursor: "pointer",
                          zIndex: 1,
                        },
                      }}
                    >
                      <MenuItem value="" disabled>
                        <em style={{ color: "#999999" }}>
                          Cliquer ici pour choisir le type d'OS
                        </em>
                      </MenuItem>
                      {osTypeList.map((option) => (
                        <MenuItem key={option} value={option}>
                          <StyledBadge
                            label={option}
                            style={{
                              backgroundColor: getOSColor(option),
                              minWidth: "80px",
                              justifyContent: "center",
                            }}
                          />
                        </MenuItem>
                      ))}
                    </StyledTextField>
                  )}
                />
              </Grid>

              {isAixOs && (
                <Grid item xs={12}>
                  <FormLabel label="Uname (AIX)" isRequired />
                  <Controller
                    name="uname"
                    control={control}
                    defaultValue=""
                    render={({ field }) => (
                      <StyledTextField
                        {...field}
                        value={field.value || ""}
                        error={!!errors.uname}
                        helperText={
                          errors.uname?.message || "Champ spécifique pour AIX"
                        }
                        fullWidth
                        disabled={isViewMode}
                        placeholder="Valeur uname pour AIX"
                      />
                    )}
                  />
                </Grid>
              )}

              <Grid item xs={12}>
                <FormLabel label="Nature de serveur" isRequired />
                <Controller
                  name="server_nature"
                  control={control}
                  render={({ field }) => (
                    <Autocomplete
                      {...field}
                      multiple
                      options={solutionNatureList}
                      getOptionLabel={(option) => option}
                      disabled={isViewMode || isEditMode}
                      onChange={(_, value) => field.onChange(value || [])}
                      renderInput={(params) => (
                        <StyledTextField
                          {...params}
                          placeholder={placeholder_server_nature}
                          error={!!errors.server_nature}
                          helperText={errors.server_nature?.message}
                        />
                      )}
                      renderTags={(value, getTagProps) =>
                        value.map((option, index) => (
                          <StyledBadge
                            label={option}
                            {...getTagProps({ index })}
                            style={{ backgroundColor: colors.info }}
                          />
                        ))
                      }
                    />
                  )}
                />
              </Grid>

              <Grid item xs={12}>
                <FormLabel label="Détail de la nature" isRequired />
                <StyledTextField
                  {...register("nature_detail")}
                  disabled={isViewMode}
                  error={!!errors.nature_detail}
                  helperText={errors.nature_detail?.message}
                  fullWidth
                  multiline
                  rows={2}
                  placeholder={placeholder_nature_detail}
                />
              </Grid>

              <Grid item xs={12}>
                <FormLabel label="Solution(s)" isRequired />
                <Controller
                  name="solutions"
                  control={control}
                  render={({ field }) => (
                    <Autocomplete
                      {...field}
                      multiple
                      options={solutions || []}
                      getOptionLabel={(option) =>
                        `${option.solution_name} (${option.solution_popularity})`
                      }
                      disabled={isViewMode || isEditMode} // Add isEditMode here
                      loading={loading}
                      onOpen={fetchSolutions}
                      onChange={(_, value) => field.onChange(value || [])}
                      isOptionEqualToValue={(option, value) =>
                        option.solution_id === value?.solution_id
                      }
                      renderInput={(params) => (
                        <StyledTextField
                          {...params}
                          placeholder={placeholder_many_solutions}
                          error={!!errors.solutions}
                          helperText={errors.solutions?.message}
                          InputProps={{
                            ...params.InputProps,
                            endAdornment: (
                              <>
                                {loading && <CircularProgress size={20} />}
                                {params.InputProps.endAdornment}
                              </>
                            ),
                          }}
                        />
                      )}
                      renderTags={(value, getTagProps) =>
                        value.map((option, index) => (
                          <StyledBadge
                            label={option.solution_name}
                            {...getTagProps({ index })}
                            sx={{
                              backgroundColor: "#f3e5f5", // violet pastel
                              color: "#6a1b9a",
                              // fontWeight: 600,
                              // fontSize: '0.75rem'
                            }}
                          />
                        ))
                      }
                    />
                  )}
                />
              </Grid>

              <Grid item xs={12}>
                <FormLabel label="Environnement(s)" isRequired />
                <Controller
                  name="environments"
                  control={control}
                  render={({ field }) => (
                    <Autocomplete
                      {...field}
                      multiple
                      options={environmentsList || []}
                      getOptionLabel={(option) => option}
                      disabled={isViewMode}
                      onChange={(_, value) => field.onChange(value || [])}
                      renderOption={(props, option) => (
                        <li {...props}>
                          <StyledBadge
                            label={option}
                            style={{ backgroundColor: getEnvColor(option) }}
                          />
                        </li>
                      )}
                      renderTags={(value, getTagProps) =>
                        value.map((option, index) => (
                          <StyledBadge
                            label={option}
                            {...getTagProps({ index })}
                            style={{ backgroundColor: getEnvColor(option) }}
                          />
                        ))
                      }
                      renderInput={(params) => (
                        <StyledTextField
                          {...params}
                          placeholder={placeholder_environments}
                          error={!!errors.environments}
                          helperText={errors.environments?.message}
                        />
                      )}
                    />
                  )}
                />
              </Grid>

              <Grid item xs={12}>
                <FormLabel label="Solutions en inventaire" isRequired={false} />
                <Controller
                  name="solutions_inventory"
                  control={control}
                  render={({ field }) => (
                    <Autocomplete
                      {...field}
                      multiple
                      options={mockSolutionsInventory}
                      getOptionLabel={(option) => option}
                      onChange={(_, value) => field.onChange(value || [])}
                      renderInput={(params) => (
                        <StyledTextField
                          {...params}
                          placeholder="Solutions en inventaire"
                          error={!!errors.solutions_inventory}
                          helperText={errors.solutions_inventory?.message}
                        />
                      )}
                      renderTags={(value, getTagProps) =>
                        value.map((option, index) => (
                          <StyledBadge
                            label={option}
                            {...getTagProps({ index })}
                            style={{ backgroundColor: colors.info }}
                          />
                        ))
                      }
                    />
                  )}
                />
              </Grid>

              <Grid item xs={12}>
                <FormLabel label="Nature en inventaire" isRequired={false} />
                <Controller
                  name="natures_inventory"
                  control={control}
                  render={({ field }) => (
                    <Autocomplete
                      {...field}
                      multiple
                      options={mockNaturesInventory}
                      getOptionLabel={(option) => option}
                      onChange={(_, value) => field.onChange(value || [])}
                      renderInput={(params) => (
                        <StyledTextField
                          {...params}
                          placeholder="Nature en inventaire"
                          error={!!errors.natures_inventory}
                          helperText={errors.natures_inventory?.message}
                        />
                      )}
                      renderTags={(value, getTagProps) =>
                        value.map((option, index) => (
                          <StyledBadge
                            label={option}
                            {...getTagProps({ index })}
                            style={{ backgroundColor: colors.info }}
                          />
                        ))
                      }
                    />
                  )}
                />
              </Grid>
            </>
          ) : (
            <Grid item xs={12}>
              <Box textAlign="center" py={4}>
                <Typography variant="h6" color={colors.text}>
                  Êtes-vous sûr de vouloir supprimer ce serveur ?
                </Typography>
              </Box>
            </Grid>
          )}

          {errorMessage && (
            <Grid item xs={12}>
              <Alert severity="error" sx={{ borderRadius: "12px" }}>
                {errorMessage}
              </Alert>
            </Grid>
          )}

          {!isViewMode && (
            <Grid item xs={12} sx={{ mt: 2 }}>
              <StyledButton
                type="submit"
                variant="contained"
                fullWidth
                sx={{
                  backgroundColor: isDeleteMode ? colors.error : colors.primary,
                  color: colors.text,
                  "&:hover": {
                    backgroundColor: isDeleteMode ? "#E05555" : "#8FC7DA",
                  },
                }}
                disabled={isDeleteMode ? false : !isValid}
              >
                {isEditMode
                  ? "Modifier"
                  : isDeleteMode
                    ? "Confirmer la suppression"
                    : isDeployMode
                      ? "Déployer la signature"
                      : "Ajouter"}
              </StyledButton>
            </Grid>
          )}
        </Grid>
      </form>
    </StyledPaper>
  );
}
