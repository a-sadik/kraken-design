// src/pages/sub-pages/admin/BackstageDataPage.tsx

import { FC } from "react";

// import files
import OrganisationBackstageDataTable from "@/components/data-tables/BackstageDataTable";

const BackstageDataPage: FC = () => {
  return <OrganisationBackstageDataTable />;
};

export default BackstageDataPage;
