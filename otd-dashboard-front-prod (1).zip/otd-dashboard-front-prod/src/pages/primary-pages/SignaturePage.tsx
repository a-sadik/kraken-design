import { ExpandLess, ExpandMore } from "@mui/icons-material";
import {
  Alert,
  Avatar,
  Button,
  Card,
  CardContent,
  Chip,
  CircularProgress,
  Collapse,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  Grid,
  InputLabel,
  MenuItem,
  Pagination,
  Select,
  Tab,
  Tabs,
  TextField,
  Typography,
} from "@mui/material";
import axios from "axios";
import React, { useEffect, useState } from "react";

interface Server {
  id: number;
  hostname: string;
  ip_addresses: string[];
  os: string;
  environments: string[];
  tam: string;
  signed: string;
  [key: string]: any;
}

interface TabConfig {
  label: string;
  endpoint: keyof Counts;
}

interface Counts {
  bigfix: number;
  vmware: number;
  power: number;
  signed: number;
  expired: number;
}

interface ConnexionString {
  ip: string;
  username: string;
  password: string;
  sudo_password: string;
}

const tabs: TabConfig[] = [
  { label: "BigFix", endpoint: "bigfix" },
  { label: "VMWare", endpoint: "vmware" },
  { label: "Power", endpoint: "power" },
  { label: "Signés", endpoint: "signed" },
  { label: "Expirés", endpoint: "expired" },
];

const filterOptions = [
  { label: "OS", value: "os" },
  { label: "Environnement", value: "environments" },
  { label: "TAM", value: "tam" },
  { label: "Statut Signature", value: "signed" },
];

const basePath = `${import.meta.env.VITE_PREFIX_RELIABILITY_PATH}:${
  import.meta.env.VITE_RELIABILITY_SERVER_PORT
}/${import.meta.env.VITE_SUFFIX_RELIABILITY_PATH}`;

const SignaturePage: React.FC = () => {
  const [activeTab, setActiveTab] = useState(3);
  const [currentPage, setCurrentPage] = useState(1);
  const [servers, setServers] = useState<Server[]>([]);
  const [counts, setCounts] = useState<Counts | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [expandedServer, setExpandedServer] = useState<number | null>(null);
  const [openModal, setOpenModal] = useState(false);
  const [selectedServer, setSelectedServer] = useState<Server | null>(null);
  const [formData, setFormData] = useState({
    username: "",
    password: "",
    sudo_password: "",
    ip: "",
  });
  const [filter, setFilter] = useState({ type: "", value: "" });

  const fetchCounts = async () => {
    try {
      const response = await axios.get(
        `${basePath}/fiabilisation/servers/count/`,
      );
      setCounts(response.data);
    } catch (err) {
      console.error("Error fetching counts:", err);
    }
  };

  const fetchServers = async () => {
    try {
      setLoading(true);
      const response = await axios.get(
        `${basePath}/fiabilisation/servers/${tabs[activeTab].endpoint}/`,
        { params: { page: currentPage } },
      );
      setServers(response.data.results);
    } catch (err) {
      setError("Erreur lors du chargement des serveurs");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCounts();
    fetchServers();
  }, [activeTab, currentPage]);

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "signé":
        return "success";
      case "expiré":
        return "warning";
      default:
        return "default";
    }
  };
  const handleDeploy = async () => {
    const payload: ConnexionString = {
      ip: formData.ip,
      username: formData.username,
      password: formData.password,
      sudo_password: formData.sudo_password || formData.password,
    };

    try {
      await axios.post(`${basePath}/fiabilisation/deploy_signature/`, payload);
      setOpenModal(false);
      fetchServers();
      fetchCounts();
    } catch (err) {
      setError("Erreur lors du déploiement de la signature");
    }
  };

  const filteredServers = servers.filter((server) => {
    if (!filter.type || !filter.value) return true;
    const serverValue = server[filter.type];
    return Array.isArray(serverValue)
      ? serverValue.includes(filter.value)
      : serverValue === filter.value;
  });

  return (
    <div
      style={{
        padding: "20px",
        backgroundColor: "#f8f9fa",
        minHeight: "100vh",
        fontSize: "1.1rem",
      }}
    >
      <Tabs
        value={activeTab}
        onChange={(_, newValue) => {
          setActiveTab(newValue);
          setCurrentPage(1);
        }}
        variant="scrollable"
        sx={{ mb: 3 }}
      >
        {tabs.map((tab, index) => (
          <Tab
            key={index}
            label={
              <span style={{ fontSize: "1.1rem" }}>
                {tab.label}
                {counts && ` (${counts[tab.endpoint]})`}
              </span>
            }
          />
        ))}
      </Tabs>

      <div style={{ marginBottom: 20, display: "flex", gap: "1rem" }}>
        <FormControl variant="outlined" size="medium" sx={{ minWidth: 200 }}>
          <InputLabel>Filtrer par</InputLabel>
          <Select
            value={filter.type}
            onChange={(e) =>
              setFilter({
                ...filter,
                type: e.target.value as string,
                value: "",
              })
            }
            label="Filtrer par"
          >
            {filterOptions.map((option) => (
              <MenuItem
                key={option.value}
                value={option.value}
                sx={{ fontSize: "1.1rem" }}
              >
                {option.label}
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        {filter.type && (
          <FormControl variant="outlined" size="medium" sx={{ minWidth: 200 }}>
            <InputLabel>Valeur</InputLabel>
            <Select
              value={filter.value}
              onChange={(e) =>
                setFilter({ ...filter, value: e.target.value as string })
              }
              label="Valeur"
            >
              {[
                ...new Set(
                  servers
                    .map((s) => s[filter.type])
                    .flat()
                    .filter(Boolean),
                ),
              ].map((value) => (
                <MenuItem key={value} value={value} sx={{ fontSize: "1.1rem" }}>
                  {value}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        )}
      </div>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      {loading ? (
        <CircularProgress sx={{ display: "block", margin: "2rem auto" }} />
      ) : (
        <>
          <div style={{ marginTop: "20px" }}>
            {filteredServers.map((server) => (
              <Card
                key={server.id}
                sx={{
                  mb: 2,
                  background: "linear-gradient(145deg, #ffffff, #f8f9fa)",
                  boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
                  borderRadius: "12px",
                }}
              >
                <CardContent>
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "15px",
                      cursor: "pointer",
                    }}
                    onClick={() =>
                      setExpandedServer(
                        expandedServer === server.id ? null : server.id,
                      )
                    }
                  >
                    <Avatar
                      sx={{
                        bgcolor: "#4a90e2",
                        width: 48,
                        height: 48,
                        fontSize: "1.4rem",
                        fontWeight: "bold",
                      }}
                    >
                      {server.hostname[0]}
                    </Avatar>
                    <div>
                      <Typography
                        variant="h6"
                        sx={{ fontSize: "1.4rem", fontWeight: 600 }}
                      >
                        {server.hostname}
                      </Typography>
                      <div
                        style={{
                          display: "flex",
                          gap: "8px",
                          flexWrap: "wrap",
                        }}
                      >
                        <Chip
                          label={server.os}
                          size="medium"
                          sx={{
                            backgroundColor: "#e3f2fd",
                            fontSize: "1rem",
                          }}
                        />
                        <Chip
                          label={`IP: ${server.ip_addresses[0]}`}
                          size="medium"
                          sx={{
                            backgroundColor: "#f0f4c3",
                            fontSize: "1rem",
                          }}
                        />
                        <Chip
                          label={server.tam}
                          color="primary"
                          size="medium"
                          sx={{ fontSize: "1rem" }}
                        />
                        <Chip
                          label={server.signed}
                          color={getStatusColor(server.signed)}
                          size="medium"
                          sx={{
                            fontWeight: 600,
                            fontSize: "1rem",
                          }}
                        />
                      </div>
                    </div>
                    {expandedServer === server.id ? (
                      <ExpandLess />
                    ) : (
                      <ExpandMore />
                    )}
                  </div>

                  <Collapse in={expandedServer === server.id}>
                    <Grid container spacing={2} sx={{ mt: 2, p: 2 }}>
                      {Object.entries(server).map(([key, value]) => (
                        <Grid item xs={12} sm={6} md={4} key={key}>
                          <Typography
                            variant="body1"
                            sx={{
                              fontSize: "1.1rem",
                              lineHeight: 1.6,
                            }}
                          >
                            <strong style={{ color: "#4a90e2" }}>
                              {key.replace(/_/g, " ")}:
                            </strong>{" "}
                            {Array.isArray(value) ? value.join(", ") : value}
                          </Typography>
                        </Grid>
                      ))}
                    </Grid>

                    <Button
                      variant="contained"
                      color="primary"
                      sx={{
                        mt: 2,
                        fontSize: "1.1rem",
                        padding: "8px 20px",
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedServer(server);
                        setFormData({
                          ...formData,
                          ip: server.ip_addresses[0],
                        });
                        setOpenModal(true);
                      }}
                    >
                      Déployer signature
                    </Button>
                  </Collapse>
                </CardContent>
              </Card>
            ))}
          </div>

          <Pagination
            count={Math.ceil((counts?.[tabs[activeTab].endpoint] || 0) / 10)}
            page={currentPage}
            onChange={(_, value) => setCurrentPage(value)}
            sx={{
              mt: 4,
              "& .MuiPaginationItem-root": {
                fontSize: "1.1rem",
              },
            }}
          />
        </>
      )}

      <Dialog open={openModal} onClose={() => setOpenModal(false)}>
        <DialogTitle sx={{ fontSize: "1.3rem", fontWeight: 600 }}>
          Déployer une signature
        </DialogTitle>
        <DialogContent>
          {selectedServer?.os.toLowerCase().includes("win") && (
            <Alert severity="warning" sx={{ mb: 2, fontSize: "1.1rem" }}>
              Attention : Le déploiement sur les serveurs Windows n'est pas
              supporté
            </Alert>
          )}

          <TextField
            select
            fullWidth
            label="IP"
            value={formData.ip}
            onChange={(e) => setFormData({ ...formData, ip: e.target.value })}
            sx={{ mt: 2 }}
            size="medium"
          >
            {selectedServer?.ip_addresses.map((ip) => (
              <MenuItem key={ip} value={ip} sx={{ fontSize: "1.1rem" }}>
                {ip}
              </MenuItem>
            ))}
          </TextField>

          <TextField
            fullWidth
            label="Login"
            value={formData.username}
            onChange={(e) =>
              setFormData({ ...formData, username: e.target.value })
            }
            sx={{ mt: 2 }}
            size="medium"
          />

          <TextField
            fullWidth
            label="Password"
            type="password"
            value={formData.password}
            onChange={(e) =>
              setFormData({ ...formData, password: e.target.value })
            }
            sx={{ mt: 2 }}
            size="medium"
          />

          <TextField
            fullWidth
            label="Sudo Password (optionnel)"
            type="password"
            value={formData.sudo_password}
            onChange={(e) =>
              setFormData({ ...formData, sudo_password: e.target.value })
            }
            sx={{ mt: 2 }}
            size="medium"
          />
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => setOpenModal(false)}
            sx={{ fontSize: "1.1rem" }}
          >
            Annuler
          </Button>
          <Button
            onClick={handleDeploy}
            color="primary"
            variant="contained"
            sx={{ fontSize: "1.1rem" }}
          >
            Déployer
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default SignaturePage;
