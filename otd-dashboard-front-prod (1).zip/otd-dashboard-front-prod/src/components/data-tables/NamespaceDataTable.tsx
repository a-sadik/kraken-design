/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable no-empty-pattern */

import type React from "react";
import { colors } from "../topology/utils/colors";
import EditIcon from "@mui/icons-material/Edit";
import { useState, useEffect, useMemo } from "react";
import {
  Box,
  Button,
  IconButton,
  Typography,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  Select,
  MenuItem,
  OutlinedInput,
  Chip,
  Alert,
  Paper,
  Card,
  CardContent,
  Checkbox,
  TextField,
  InputAdornment,
  Autocomplete,
  InputLabel,
} from "@mui/material";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import { DataGrid, type GridColDef } from "@mui/x-data-grid";
import {
  Visibility as VisibilityIcon,
  Close as CloseIcon,
  Memory as MemoryIcon,
  Speed as CpuIcon,
  Schedule as TimeIcon,
  RestartAlt as RestartIcon,
  Source as SourceIcon,
  Search as SearchIcon,
  Clear as ClearIcon,
  Delete as DeleteIcon,
} from "@mui/icons-material";
import {
  getPodsbyNamespacesApiUrl,
  getNamespacesApiUrl,
  postAffechtNamespacesToSolutionsApiUrl,
  getSolutionsApiUrl,
} from "@/config/api.config";

// Import des types
import type { Namespace, Pod, Solution } from "@/types/Namespace";

// Import des composants
import CustomLoading from "@/components/basics/CustomLoading";
import CustomTooltip from "@/components/basics/CustomToolTip";

// Import des styles
import "@/styles/reliability-data-table.css";
import { LuRocket } from "react-icons/lu";
import { FiServer } from "react-icons/fi";
import { VscSymbolNamespace } from "react-icons/vsc";
import fetchWithAuth from "@/middleware/fetch-auth";
import { keycloak } from "@/auth/keycloakConnectAdapter";
import { SolutionDetailResponseDTO } from "@/types/dto/response/solution/SolutionDetailResponseDTO";

// Fonctions utilitaires pour les couleurs pastel
export function getBadgeColorEnvironment(value: string) {
  const textColor = "#000000"; // texte noir

  if (typeof value === "string") {
    switch (value.toLowerCase()) {
      case "préproduction":
      case "préprod":
        return { bg: "#ffd699", text: textColor, border: "#ffcc80" };
      case "production":
      case "prod":
        return { bg: "#ffb3b3", text: textColor, border: "#ff9999" };
      case "intégration":
        return { bg: "#b3e6ff", text: textColor, border: "#99ddff" };
      case "recette":
        return { bg: "#c6b3ff", text: textColor, border: "#b399ff" };
      case "développement":
        return { bg: "#ffe6cc", text: textColor, border: "#ffe6cc" };
      case "formation":
      case "dev":
        return { bg: "#b3ffcc", text: textColor, border: "#99ffb3" };
      case "poc":
        return { bg: "#ffccf2", text: textColor, border: "#ffb3e6" };
      case "tnr":
        return { bg: "#f4bfff", text: textColor, border: "#e6a6ff" };
      case "technique":
        return { bg: "#a9c0d9", text: textColor, border: "#90afc9" };
      default:
        return { bg: "#d9d9d9", text: textColor, border: "#cccccc" };
    }
  }

  return { bg: "#d9d9d9", text: textColor, border: "#cccccc" };
}

export function getBadgeColorSource(value: string) {
  const textColor = "#000000";

  if (typeof value === "string") {
    // Extraire le type d'environnement du nom de la source
    const lowerValue = value.toLowerCase();

    if (lowerValue.includes("développement") || lowerValue.includes("dev")) {
      return { bg: "#b3ffcc", text: textColor, border: "#99ffb3" };
    } else if (
      lowerValue.includes("préproduction") ||
      lowerValue.includes("préprod")
    ) {
      return { bg: "#ffd699", text: textColor, border: "#ffcc80" };
    } else if (
      lowerValue.includes("production") ||
      lowerValue.includes("prod")
    ) {
      return { bg: "#ffb3b3", text: textColor, border: "#ff9999" };
    } else if (lowerValue.includes("recette")) {
      return { bg: "#c6b3ff", text: textColor, border: "#b399ff" };
    } else if (lowerValue.includes("intégration")) {
      return { bg: "#b3e6ff", text: textColor, border: "#99ddff" };
    } else if (lowerValue.includes("formation")) {
      return { bg: "#ffe6cc", text: textColor, border: "#ffe6cc" };
    } else if (lowerValue.includes("technique")) {
      return { bg: "#a9c0d9", text: textColor, border: "#90afc9" };
    } else if (lowerValue.includes("poc")) {
      return { bg: "#ffccf2", text: textColor, border: "#ffb3e6" };
    } else if (lowerValue.includes("tnr")) {
      return { bg: "#f4bfff", text: textColor, border: "#e6a6ff" };
    } else {
      return { bg: "#d9d9d9", text: textColor, border: "#cccccc" };
    }
  }

  return { bg: "#d9d9d9", text: textColor, border: "#cccccc" };
}

export const EnvironmentBadge = ({ value }: { value: string }) => {
  const badge = getBadgeColorEnvironment(value);

  return (
    <span
      style={{
        backgroundColor: badge.bg,
        color: badge.text,
        border: `1px solid ${badge.border}`,
        padding: "4px 8px",
        borderRadius: "4px",
        fontWeight: "bold", // ici le gras
        display: "inline-block",
      }}
    >
      {value}
    </span>
  );
};

export function getBadgeColorStatus(value: string) {
  switch (value?.toLowerCase()) {
    case "running":
      return { bg: "#a8e6b1", text: "#006633", border: "#99ffb3" }; // vert pastel
    case "pending":
      return { bg: "#ffd699", text: "#cc6600", border: "#ffcc80" }; // orange pastel
    case "failed":
      return { bg: "#ffb3b3", text: "#8b0000", border: "#ff9999" }; // rouge pastel
    case "succeeded":
      return { bg: "#ccffcc", text: "#004d00", border: "#b3ffb3" }; // vert clair pastel
    default:
      return { bg: "#d9d9d9", text: "#666666", border: "#cccccc" }; // gris pastel
  }
}

export function getBadgeColorRestart(count: number) {
  if (count === 0) return { bg: "#b3ffcc", text: "#006633", border: "#99ffb3" }; // vert pastel
  if (count < 5) return { bg: "#ffd699", text: "#cc6600", border: "#ffcc80" }; // orange pastel
  return { bg: "#ffb3b3", text: "#8b0000", border: "#ff9999" }; // rouge pastel
}

interface NamespaceDataTableProps {
  openModal: boolean;
  setOpenModal: (open: boolean) => void;
}

// Composant pour ListItemText
const ListItemText = ({ primary }: { primary: string }) => (
  <Typography variant="body2" sx={{ ml: 1 }}>
    {primary}
  </Typography>
);

// Nouveau composant de filtres avec le style de votre exemple
const NamespaceFilters = ({
  filters,
  onFilterChange,
  searchValue,
  onSearchChange,
  onClearSearch,
  selectedSolutionFilter,
  onSolutionFilterChange,
  solutionsList,
}: {
  filters: {
    isProduction: boolean;
    isHorsProduction: boolean;
    isSansEnvironnement: boolean;
    isSansSolution: boolean;
    isPreproduction: boolean;
    isRecette: boolean;
    isIntegration: boolean;
    isDeveloppement: boolean;
    isFormation: boolean;
  };
  onFilterChange: (filters: any) => void;
  searchValue: string;
  onSearchChange: (value: string) => void;
  onClearSearch: () => void;
  selectedSolutionFilter: string;
  onSolutionFilterChange: (value: string) => void;
  solutionsList: string[];
}) => {
  return (
    <Box
      sx={{
        p: 2,
        display: "flex",
        flexWrap: "wrap",
        gap: 2,
        alignItems: "center",
        backgroundColor: "white",
        borderRadius: "12px",
        boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
        mb: 2,
      }}
    >
      {/* Barre de recherche - style identique à votre exemple */}
      <TextField
        variant="outlined"
        size="small"
        placeholder="Rechercher dans tous les namespaces..."
        value={searchValue}
        onChange={(e) => onSearchChange(e.target.value)}
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <SearchIcon />
            </InputAdornment>
          ),
          endAdornment: searchValue && (
            <InputAdornment position="end">
              <IconButton onClick={onClearSearch} size="small">
                <ClearIcon />
              </IconButton>
            </InputAdornment>
          ),
        }}
        sx={{ width: 300 }}
      />

      {/* Filtres avec style Select comme dans votre exemple */}
      <FormControl sx={{ width: 180 }} size="small">
        <InputLabel>Environnement</InputLabel>
        <Select
          multiple
          value={Object.keys(filters).filter(
            (key) => filters[key as keyof typeof filters],
          )}
          onChange={(e) => {
            const selectedFilters = e.target.value as string[];
            const newFilters = {
              isProduction: selectedFilters.includes("isProduction"),
              isPreproduction: selectedFilters.includes("isPreproduction"),
              isRecette: selectedFilters.includes("isRecette"),
              isIntegration: selectedFilters.includes("isIntegration"),
              isDeveloppement: selectedFilters.includes("isDeveloppement"),
              isFormation: selectedFilters.includes("isFormation"),
              isHorsProduction: selectedFilters.includes("isHorsProduction"),
              isSansEnvironnement: selectedFilters.includes(
                "isSansEnvironnement",
              ),
              isSansSolution: selectedFilters.includes("isSansSolution"),
            };
            onFilterChange(newFilters);
          }}
          input={<OutlinedInput label="Environnement" />}
          renderValue={(selected) => (
            <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
              {(selected as string[]).map((value) => {
                const labelMap: { [key: string]: string } = {
                  isProduction: "Production",
                  isPreproduction: "Préproduction",
                  isRecette: "Recette",
                  isIntegration: "Intégration",
                  isDeveloppement: "Développement",
                  isFormation: "Formation",
                  isHorsProduction: "Hors Production",
                  isSansEnvironnement: "Sans Environnement",
                  isSansSolution: "Sans Solution",
                };
                return (
                  <Chip
                    key={value}
                    label={labelMap[value] || value}
                    size="small"
                  />
                );
              })}
            </Box>
          )}
        >
          <MenuItem value="isProduction">
            <Checkbox checked={filters.isProduction} />
            <ListItemText primary="Production" />
          </MenuItem>
          <MenuItem value="isPreproduction">
            <Checkbox checked={filters.isPreproduction} />
            <ListItemText primary="Préproduction" />
          </MenuItem>
          <MenuItem value="isRecette">
            <Checkbox checked={filters.isRecette} />
            <ListItemText primary="Recette" />
          </MenuItem>
          <MenuItem value="isIntegration">
            <Checkbox checked={filters.isIntegration} />
            <ListItemText primary="Intégration" />
          </MenuItem>
          <MenuItem value="isDeveloppement">
            <Checkbox checked={filters.isDeveloppement} />
            <ListItemText primary="Développement" />
          </MenuItem>
          <MenuItem value="isFormation">
            <Checkbox checked={filters.isFormation} />
            <ListItemText primary="Formation" />
          </MenuItem>
          <MenuItem value="isHorsProduction">
            <Checkbox checked={filters.isHorsProduction} />
            <ListItemText primary="Hors Production" />
          </MenuItem>
          <MenuItem value="isSansEnvironnement">
            <Checkbox checked={filters.isSansEnvironnement} />
            <ListItemText primary="Sans Environnement" />
          </MenuItem>
          <MenuItem value="isSansSolution">
            <Checkbox checked={filters.isSansSolution} />
            <ListItemText primary="Sans Solution" />
          </MenuItem>
        </Select>
      </FormControl>

      {/* Filtre Solution avec Autocomplete */}
      <Autocomplete
        options={solutionsList}
        value={selectedSolutionFilter}
        onChange={(_event, newValue) => {
          onSolutionFilterChange(newValue || "");
        }}
        renderInput={(params) => (
          <TextField
            {...params}
            label="Solution"
            variant="outlined"
            size="small"
            InputProps={{
              ...params.InputProps,
              endAdornment: (
                <>
                  {selectedSolutionFilter && (
                    <InputAdornment position="end">
                      <IconButton
                        onClick={() => {
                          onSolutionFilterChange("");
                        }}
                        size="small"
                      >
                        <ClearIcon />
                      </IconButton>
                    </InputAdornment>
                  )}
                  {params.InputProps.endAdornment}
                </>
              ),
            }}
            sx={{ width: 200 }}
          />
        )}
      />

      {/* Bouton pour effacer tous les filtres */}
      <Button
        variant="outlined"
        onClick={() => {
          onFilterChange({
            isProduction: false,
            isHorsProduction: false,
            isSansEnvironnement: false,
            isSansSolution: false,
            isPreproduction: false,
            isRecette: false,
            isIntegration: false,
            isDeveloppement: false,
            isFormation: false,
          });
          onClearSearch();
          onSolutionFilterChange("");
        }}
        startIcon={<ClearIcon />}
        size="small"
      >
        Effacer filtres
      </Button>
    </Box>
  );
};

const NamespaceDataTable: React.FC<NamespaceDataTableProps> = ({ }) => {
  const [namespaces, setNamespaces] = useState<Namespace[]>([]);
  const [pods, setPods] = useState<Pod[]>([]);
  const [, setSolutions] = useState<Solution[]>([]);
  const [solutionsList, setSolutionsList] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [podsLoading, setPodsLoading] = useState(false);
  const [selectedNamespace, setSelectedNamespace] = useState<Namespace | null>(
    null,
  );
  const [showPods, setShowPods] = useState(false);
  const [assignDialogOpen, setAssignDialogOpen] = useState(false);
  const [selectedSolutions, setSelectedSolutions] = useState<string[]>([]);
  const [selectedEnvironment, setSelectedEnvironment] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [selectedNamespaces, setSelectedNamespaces] = useState<number[]>([]);

  const [, setSolutionsDetails] = useState<SolutionDetailResponseDTO[]>([]);
  const [solutionsMap, setSolutionsMap] = useState<Map<string, SolutionDetailResponseDTO>>(new Map());

  // État pour la recherche
  const [searchValue, setSearchValue] = useState("");

  // État pour le filtre solution
  const [selectedSolutionFilter, setSelectedSolutionFilter] =
    useState<string>("");

  // État pour tous les filtres
  const [filters, setFilters] = useState({
    isProduction: false,
    isHorsProduction: false,
    isSansEnvironnement: false,
    isSansSolution: false,
    isPreproduction: false,
    isRecette: false,
    isIntegration: false,
    isDeveloppement: false,
    isFormation: false,
  });

  // Charger la recherche sauvegardée au démarrage
useEffect(() => {
  const searchParams = new URLSearchParams(window.location.search);
  const savedSearch = searchParams.get('search') || '';
  setSearchValue(savedSearch);
}, []);

  // Sauvegarder la recherche à chaque changement
  useEffect(() => {
    localStorage.setItem("namespaceSearch", searchValue);
  }, [searchValue]);

  // Charger les filtres sauvegardés au démarrage
  useEffect(() => {
    const savedFilters = localStorage.getItem("namespaceFilters");
    if (savedFilters) {
      try {
        setFilters(JSON.parse(savedFilters));
      } catch (e) {
        console.error("Error loading filters:", e);
      }
    }
  }, []);

  // Sauvegarder les filtres à chaque changement
  useEffect(() => {
    localStorage.setItem("namespaceFilters", JSON.stringify(filters));
  }, [filters]);

  // Fetch namespaces
  const fetchNamespaces = async () => {
    setLoading(true);
    try {
      const response = await fetchWithAuth(getNamespacesApiUrl());
      if (!response.ok) throw new Error("Failed to fetch namespaces");
      const data = await response.json();
      setNamespaces(data);
    } catch (err) {
      setError("Erreur lors du chargement des namespaces");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Fetch pods for a namespace
  const fetchPods = async (namespaceId: number) => {
    setPodsLoading(true);
    try {
      const response = await fetchWithAuth(
        getPodsbyNamespacesApiUrl(namespaceId),
      );
      if (!response.ok) throw new Error("Failed to fetch pods");
      const data = await response.json();
      setPods(data);
    } catch (err) {
      setError("Erreur lors du chargement des pods");
      console.error(err);
    } finally {
      setPodsLoading(false);
    }
  };

  // Fetch solutions
  const fetchSolutions = async () => {
    try {
      const response = await fetchWithAuth(getSolutionsApiUrl());
      if (!response.ok) throw new Error("Failed to fetch solutions");
      const data = await response.json();
      setSolutions(data);
    } catch (err) {
      console.error("Error fetching solutions:", err);
    }
  };

  // Fetch solutions for filter
  useEffect(() => {
    const fetchSolutionsForFilter = async () => {
      try {
        const response = await fetchWithAuth(getSolutionsApiUrl());
        if (!response.ok) throw new Error("Failed to fetch solutions");
        const data: SolutionDetailResponseDTO[] = await response.json();

        // Stocker les détails complets
        setSolutionsDetails(data);

        // Créer une map pour un accès rapide
        const newMap = new Map<string, SolutionDetailResponseDTO>();
        data.forEach((solution) => {
          newMap.set(solution.solution_name, solution);
        });
        setSolutionsMap(newMap);

        // Garder la liste des noms pour l'autocomplete
        const sortedSolutions = data
          .map((solution) => solution.solution_name)
          .sort((a, b) => a.localeCompare(b));
        setSolutionsList(sortedSolutions);
      } catch (err) {
        console.error("Erreur lors du fetch des solutions :", err);
      }
    };

    fetchSolutionsForFilter();
  }, []);

  // Assign solutions and environment to namespace
  const assignSolutions = async (
    namespaceIds: number[],
    solutionNames: string[],
    environment: string,
  ) => {
    try {
      setLoading(true);
      const results = await Promise.all(
        namespaceIds.map(async (namespaceId) => {
          try {
            const response = await fetchWithAuth(
              postAffechtNamespacesToSolutionsApiUrl(namespaceId),
              {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                },
                body: JSON.stringify({
                  solutions: solutionNames,
                  environment: environment,
                }),
              },
            );

            return {
              namespaceId,
              success: response.ok,
              status: response.status,
              message: response.ok
                ? "Mis à jour avec succès"
                : await response.text().catch(() => "Erreur inconnue"),
            };
          } catch (err) {
            return {
              namespaceId,
              success: false,
              status: 500,
              message: "Erreur réseau",
            };
          }
        }),
      );

      const successful = results.filter((r) => r.success);
      const failed = results.filter((r) => !r.success);

      if (failed.length > 0) {
        setError(
          `${failed.length} affectations ont échoué sur ${results.length}`,
        );
      } else {
        setSuccessMessage(
          `Affectation réussie pour ${successful.length} namespace(s)`,
        );
      }

      fetchNamespaces();
    } catch (err) {
      setError("Une erreur est survenue lors de l'affectation");
      console.error(err);
    } finally {
      setLoading(false);
      setAssignDialogOpen(false);
    }
  };

  useEffect(() => {
    fetchNamespaces();
    fetchSolutions();
  }, []);

  const handleViewPods = (namespace: Namespace) => {
    setSelectedNamespace(namespace);
    setShowPods(true);
    fetchPods(namespace.id);
  };

  const handleAssignSolutions = (namespace?: Namespace) => {
    // Si appelé via l'icône, on crée une sélection temporaire
    const isIconCall = !!namespace;
    if (isIconCall) {
      setSelectedNamespaces([namespace.id]);
      // Pré-remplir avec les valeurs de ce namespace spécifique
      setSelectedSolutions(namespace.solutions || []);
      setSelectedEnvironment(namespace.environment || "");
    } else {
      // Si appelé via la toolbar avec sélection multiple
      if (selectedNamespaces.length === 1) {
        const selectedNs = namespaces.find(
          (ns) => ns.id === selectedNamespaces[0],
        );
        if (selectedNs) {
          setSelectedSolutions(selectedNs.solutions || []);
          setSelectedEnvironment(selectedNs.environment || "");
        }
      } else {
        // Pour sélection multiple, on réinitialise
        setSelectedSolutions([]);
        setSelectedEnvironment("");
      }
    }

    setAssignDialogOpen(true);
  };

  const getResponsiveWidth = (key: string) => {
    const screenWidth =
      typeof window !== "undefined" ? window.innerWidth : 1200;

    if (screenWidth < 600) {
      if (key === "solutions") return 120;
      else if (key === "environment") return 100;
      else if (key === "source") return 100;
      return 80;
    } else if (screenWidth < 960) {
      if (key === "solutions") return 160;
      else if (key === "environment") return 120;
      else if (key === "source") return 140;
      return 120;
    } else {
      if (key === "solutions") return 200;
      else if (key === "environment") return 150;
      else if (key === "source") return 180;
      return 150;
    }
  };

  const valueContent = (value: any, key: string) => {
    if (value === null || value === undefined) {
      return (
        <Box
          sx={{
            textAlign: "center",
            fontWeight: "medium",
            fontSize: "0.875rem",
            color: "#9E9E9E",
            fontStyle: "italic",
          }}
        >
          Non défini
        </Box>
      );
    }

    if (key === "environment") {
      const colors = getBadgeColorEnvironment(value);
      return (
        <Chip
          label={value}
          size="small"
          sx={{
            backgroundColor: colors.bg,
            color: colors.text,
            border: `1px solid ${colors.border}`,
            fontWeight: "medium",
            fontSize: "0.75rem",
            borderRadius: "6px",
            "&:hover": {
              backgroundColor: colors.bg,
              transform: "scale(1.05)",
            },
            transition: "all 0.2s ease",
          }}
        />
      );
    }

    if (key === "source") {
      const colors = getBadgeColorSource(value);
      return (
        <CustomTooltip title={value}>
          <Chip
            label={value}
            size="small"
            icon={<SourceIcon sx={{ fontSize: "14px !important" }} />}
            sx={{
              backgroundColor: colors.bg,
              color: colors.text,
              border: `1px solid ${colors.border}`,
              fontWeight: "medium",
              fontSize: "0.75rem",
              borderRadius: "6px",
              maxWidth: "100%",
              "&:hover": {
                backgroundColor: colors.bg,
                transform: "scale(1.02)",
              },
              transition: "all 0.2s ease",
              "& .MuiChip-label": {
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
              },
            }}
          />
        </CustomTooltip>
      );
    }

    // Nouveau style pastel pour les colonnes "name" et "solutions"
    if (key === "name") {
      const pastelColors = {
        name: { bg: "#e6f3ff", text: "#1565c0", border: "#b3d9ff" }, // bleu pastel
      };

      const colors = pastelColors[key as keyof typeof pastelColors];

      return (
        <CustomTooltip title={value}>
          <Chip
            label={value}
            size="small"
            sx={{
              backgroundColor: colors.bg,
              color: colors.text,
              border: `1px solid ${colors.border}`,
              fontWeight: "medium",
              fontSize: "0.75rem",
              borderRadius: "16px",
              maxWidth: "100%",
              "&:hover": {
                backgroundColor: colors.bg,
                transform: "scale(1.02)",
              },
              transition: "all 0.2s ease",
              "& .MuiChip-label": {
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
              },
            }}
          />
        </CustomTooltip>
      );
    }

    // Dans valueContent, remplacer le traitement de solution_name par :
    if (key === "solutions") {
      const values = Array.isArray(value) ? value : [value];
      const pastelColors = {
        bg: "#FEF3C7",
        text: "#92400E",
        border: "#d1c4e9",
      };

      return (
        <Box
          sx={{
            width: "100%",
            height: "100%",
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center",
            paddingLeft: "8px",
          }}
        >
          <Box
            sx={{
              display: "flex",
              flexWrap: "wrap",
              gap: 0.5,
            }}
          >
            {values.map((val, index) => (
              <Chip
                key={index}
                label={val}
                size="small"
                sx={{
                  backgroundColor: pastelColors.bg,
                  color: pastelColors.text,
                  border: `1px solid ${pastelColors.border}`,
                  fontWeight: "medium",
                  fontSize: "0.75rem",
                  borderRadius: "16px",
                  maxWidth: "100%",
                  "&:hover": { transform: "scale(1.02)" },
                  transition: "all 0.2s ease",
                }}
              />
            ))}
          </Box>
        </Box>
      );
    }

    return (
      <CustomTooltip title={value}>
        <Typography
          variant="body2"
          sx={{
            color: "#424242",
            fontWeight: "medium",
          }}
        >
          {value}
        </Typography>
      </CustomTooltip>
    );
  };

  // Styles personnalisés pour les icônes d'action
  const actionIconStyles = {
    view: {
      color: "#10B981",
      backgroundColor: "#ECFDF5",
      "&:hover": {
        backgroundColor: "#D1FAE5",
        color: "#047857",
      },
    },
    edit: {
      color: "#F59E0B",
      backgroundColor: "#FFFBEB",
      "&:hover": {
        backgroundColor: "#FEF3C7",
        color: "#D97706",
      },
    },
    delete: {
      color: "#EF4444",
      backgroundColor: "#FEF2F2",
      "&:hover": {
        backgroundColor: "#FECACA",
        color: "#DC2626",
      },
    },
  };

  // Colonnes pour le tableau des namespaces
  const columns = useMemo(() => {
    if (!namespaces || namespaces.length === 0) return [];

    const actionColumn = {
      field: "actions",
      headerName: "Actions",
      width: 80,
      sortable: false,
      filterable: false,
      renderCell: (params: any) => {
        return (
          <Box
            sx={{
              display: "flex",
              gap: 1,
              alignItems: "center",
              justifyContent: "flex-start",
              py: 1,
            }}
          >
            <IconButton
              onClick={() => handleViewPods(params.row)}
              sx={actionIconStyles.view}
              size="small"
            >
              <VisibilityIcon fontSize="small" />
            </IconButton>
            <IconButton
              onClick={() => handleAssignSolutions(params.row)}
              sx={actionIconStyles.edit}
              size="small"
            >
              <EditIcon fontSize="small" />
            </IconButton>
          </Box>
        );
      },
    };

    const dataColumns = [
      {
        field: "name",
        headerName: "Nom",
        description: "Nom",
        width: getResponsiveWidth("name"),
        renderCell: (params: any) => valueContent(params.value, "name"),
        sortable: true,
        sortComparator: (v1: string | [], v2: string | []) => {
          if (Array.isArray(v1) && Array.isArray(v2)) {
            return v1.join(", ").localeCompare(v2.join(", "));
          }
          if (typeof v1 === "string" && typeof v2 === "string") {
            return v1.localeCompare(v2);
          }
          return 0;
        },
      },
      {
        field: "solutions",
        headerName: "Solution",
        description: "Solution",
        width: getResponsiveWidth("solutions"),
        renderCell: (params: any) => valueContent(params.value, "solutions"),
        sortable: true,
        sortComparator: (v1: string | [], v2: string | []) => {
          if (Array.isArray(v1) && Array.isArray(v2)) {
            return v1.join(", ").localeCompare(v2.join(", "));
          }
          if (typeof v1 === "string" && typeof v2 === "string") {
            return v1.localeCompare(v2);
          }
          return 0;
        },
      },
      {
        field: "environment",
        headerName: "Environnement",
        description: "Environnement",
        width: getResponsiveWidth("environment"),
        renderCell: (params: any) => valueContent(params.value, "environment"),
        sortable: true,
        sortComparator: (v1: string | [], v2: string | []) => {
          if (Array.isArray(v1) && Array.isArray(v2)) {
            return v1.join(", ").localeCompare(v2.join(", "));
          }
          if (typeof v1 === "string" && typeof v2 === "string") {
            return v1.localeCompare(v2);
          }
          return 0;
        },
      },
      {
        field: "source",
        headerName: "Source",
        description: "Source",
        width: getResponsiveWidth("source"),
        renderCell: (params: any) => valueContent(params.value, "source"),
        sortable: true,
        sortComparator: (v1: string | [], v2: string | []) => {
          if (Array.isArray(v1) && Array.isArray(v2)) {
            return v1.join(", ").localeCompare(v2.join(", "));
          }
          if (typeof v1 === "string" && typeof v2 === "string") {
            return v1.localeCompare(v2);
          }
          return 0;
        },
      },
    ];

    return [actionColumn, ...dataColumns];
  }, [namespaces]);

  // Colonnes pour le tableau des pods - avec couleurs pastel
  const podColumns: GridColDef[] = useMemo(
    () => [
      {
        field: "pod_name",
        headerName: "Nom du Pod",
        width: 200,
        renderCell: (params: any) => (
          <Box display="flex" alignItems="center" height="100%">
            <CustomTooltip title={params.row.pod_uid}>
              <Typography
                variant="body2"
                sx={{
                  fontWeight: "medium",
                  color: "#424242",
                  lineHeight: "24px",
                }}
              >
                {params.value}
              </Typography>
            </CustomTooltip>
          </Box>
        ),
      },
      {
        field: "phase",
        headerName: "Statut",
        width: 120,
        renderCell: (params: any) => {
          const colors = getBadgeColorStatus(params.value);
          return (
            <Box display="flex" alignItems="center" height="100%">
              <Chip
                label={params.value}
                size="small"
                sx={{
                  backgroundColor: colors.bg,
                  color: colors.text,
                  border: `1px solid ${colors.border}`,
                  fontWeight: "medium",
                  fontSize: "0.75rem",
                  borderRadius: "12px",
                  height: "24px",
                  lineHeight: "24px",
                }}
              />
            </Box>
          );
        },
      },
      {
        field: "nodeName",
        headerName: "Namespace",
        width: 150,
        renderCell: (params: any) => (
          <Box display="flex" alignItems="center" height="100%" gap={1}>
            <VscSymbolNamespace style={{ fontSize: 16, color: "#cc6600" }} />
            <Typography
              variant="body2"
              sx={{
                color: "#424242",
                lineHeight: "24px",
              }}
            >
              {params.value}
            </Typography>
          </Box>
        ),
      },
      {
        field: "deployment_name",
        headerName: "Déploiement",
        width: 150,
        renderCell: (params: any) => (
          <Box display="flex" alignItems="center" height="100%" gap={1}>
            <LuRocket size={14} color={colors.deployment} />
            <Typography variant="body2" sx={{ color: "black" }}>
              {params.value}
            </Typography>
          </Box>
        ),
      },

      {
        field: "cpu",
        headerName: "CPU",
        width: 180,
        renderCell: (params: any) => (
          <Box display="flex" alignItems="center" height="100%" gap={1}>
            <CpuIcon sx={{ fontSize: 16, color: "#5c6bc0" }} />
            <Box display="flex" gap={1}>
              <Chip
                label={`Req: ${params.row.requestCPU || "N/A"}`}
                size="small"
                sx={{
                  backgroundColor: "#e3f2fd",
                  color: "#1565c0",
                  border: "1px solid #bbdefb",
                  fontSize: "0.7rem",
                  borderRadius: "8px",
                  height: "24px",
                  lineHeight: "24px",
                }}
              />
              <Chip
                label={`Lim: ${params.row.limitCPU || "N/A"}`}
                size="small"
                sx={{
                  backgroundColor: "#ffebee",
                  color: "#c62828",
                  border: "1px solid #ffcdd2",
                  fontSize: "0.7rem",
                  borderRadius: "8px",
                  height: "24px",
                  lineHeight: "24px",
                }}
              />
            </Box>
          </Box>
        ),
      },
      {
        field: "memory",
        headerName: "RAM",
        width: 180,
        renderCell: (params: any) => (
          <Box display="flex" alignItems="center" height="100%" gap={1}>
            <MemoryIcon sx={{ fontSize: 16, color: "#26a69a" }} />
            <Box display="flex" gap={1}>
              <Chip
                label={`Req: ${params.row.requestRAM || "N/A"}`}
                size="small"
                sx={{
                  backgroundColor: "#e0f7fa",
                  color: "#00838f",
                  border: "1px solid #b2ebf2",
                  fontSize: "0.7rem",
                  borderRadius: "8px",
                  height: "24px",
                  lineHeight: "24px",
                }}
              />
              <Chip
                label={`Lim: ${params.row.limitRAM || "N/A"}`}
                size="small"
                sx={{
                  backgroundColor: "#ffebee",
                  color: "#c62828",
                  border: "1px solid #ffcdd2",
                  fontSize: "0.7rem",
                  borderRadius: "8px",
                  height: "24px",
                  lineHeight: "24px",
                }}
              />
            </Box>
          </Box>
        ),
      },
      {
        field: "restartCount",
        headerName: "Redémarrages",
        width: 130,
        renderCell: (params: any) => {
          const restartCount =
            params.row.containerStatuses?.[0]?.restartCount || 0;
          const colors = getBadgeColorRestart(restartCount);

          return (
            <Box display="flex" alignItems="center" height="100%" gap={1}>
              <RestartIcon sx={{ fontSize: 16, color: colors.text }} />
              <Chip
                label={restartCount.toString()}
                size="small"
                sx={{
                  backgroundColor: colors.bg,
                  color: colors.text,
                  border: `1px solid ${colors.border}`,
                  fontSize: "0.75rem",
                  borderRadius: "8px",
                  height: "24px",
                  lineHeight: "24px",
                  fontWeight: "medium",
                }}
              />
            </Box>
          );
        },
      },
      {
        field: "creationTimestamp",
        headerName: "Créé le",
        width: 150,
        renderCell: (params: any) => (
          <Box display="flex" alignItems="center" height="100%" gap={1}>
            <TimeIcon sx={{ fontSize: 16, color: "#616161" }} />
            <CustomTooltip title={new Date(params.value).toLocaleString()}>
              <Typography
                variant="body2"
                sx={{
                  color: "#424242",
                  lineHeight: "24px",
                }}
              >
                {new Date(params.value).toLocaleDateString()}
              </Typography>
            </CustomTooltip>
          </Box>
        ),
      },
      {
        field: "hostIP",
        headerName: "IP Host",
        width: 130,
        renderCell: (params: any) => (
          <Box display="flex" alignItems="center" height="100%">
            <FiServer
              style={{ fontSize: 16, color: "#616161", marginRight: 8 }}
            />

            <Typography
              variant="body2"
              sx={{
                fontFamily: "monospace",
                backgroundColor: "#f2f2f2",
                padding: "2px 8px",
                borderRadius: "6px",
                fontSize: "0.8rem",
                color: "#424242",
                border: "1px solid #e6e6e6",
                lineHeight: "24px",
                height: "24px",
              }}
            >
              {params.value}
            </Typography>
          </Box>
        ),
      },
    ],
    [],
  );

  const customTheme = createTheme({
    palette: {
      primary: {
        main: "#b3e6ff",
        light: "#e6f7ff",
        dark: "#0066cc",
      },
      secondary: {
        main: "#ffccf2",
        light: "#ffe6f7",
        dark: "#cc0099",
      },
      background: {
        default: "#f9f9f9",
        paper: "#ffffff",
      },
      text: {
        primary: "#333333",
        secondary: "#666666",
      },
    },
    components: {
      MuiDialog: {
        styleOverrides: {
          paper: {
            borderRadius: "16px",
            boxShadow: "0 8px 25px rgba(0, 0, 0, 0.1)",
          },
        },
      },
      MuiButton: {
        styleOverrides: {
          root: {
            borderRadius: "12px",
            textTransform: "none",
            fontWeight: "600",
            padding: "10px 20px",
          },
          contained: {
            boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)",
            "&:hover": {
              boxShadow: "0 6px 16px rgba(0, 0, 0, 0.15)",
            },
          },
        },
      },
    },
  });

  // Logique de recherche
  const searchFilteredRows = useMemo(() => {
    if (!searchValue.trim()) {
      return namespaces;
    }

    const searchLower = searchValue.toLowerCase().trim();

    return namespaces.filter((namespace) => {
      // Recherche dans le nom
      if (namespace.name?.toLowerCase().includes(searchLower)) {
        return true;
      }

      // Recherche dans les solutions - CORRECTION ICI
      if (namespace.solutions && Array.isArray(namespace.solutions)) {
        const solutionMatch = namespace.solutions.some((solution: string) =>
          solution.toLowerCase().includes(searchLower),
        );
        if (solutionMatch) return true;
      }

      // Recherche dans l'environnement
      if (namespace.environment?.toLowerCase().includes(searchLower)) {
        return true;
      }

      // Recherche dans la source
      if (namespace.source?.toLowerCase().includes(searchLower)) {
        return true;
      }

      return false;
    });
  }, [namespaces, searchValue]);

  // Logique de filtrage combinée (recherche + filtres)
  const filteredRows = useMemo(() => {
    const isProductionEnv = (row: Namespace) =>
      row.environment?.toLowerCase() === "production";
    const isPreproductionEnv = (row: Namespace) =>
      row.environment?.toLowerCase().includes("préprod") ||
      row.environment?.toLowerCase().includes("preprod");
    const isRecetteEnv = (row: Namespace) =>
      row.environment?.toLowerCase().includes("recette");
    const isIntegrationEnv = (row: Namespace) =>
      row.environment?.toLowerCase().includes("intégration");
    const isDeveloppementEnv = (row: Namespace) =>
      row.environment?.toLowerCase().includes("développement") ||
      row.environment?.toLowerCase().includes("dev");
    const isFormationEnv = (row: Namespace) =>
      row.environment?.toLowerCase().includes("formation");
    const isHorsProductionEnv = (row: Namespace) =>
      row.environment &&
      !row.environment.toLowerCase().includes("production") &&
      !row.environment.toLowerCase().includes("préprod") &&
      !row.environment.toLowerCase().includes("preprod");
    const isSansEnvironnementEnv = (row: Namespace) =>
      !row.environment || row.environment.trim() === "";
    const isSansSolutionEnv = (row: Namespace) =>
      !row.solutions || row.solutions.length === 0;

    return searchFilteredRows.filter((row) => {
      // Filtre par solution
      if (selectedSolutionFilter) {
        const hasSolution =
          row.solutions && Array.isArray(row.solutions)
            ? row.solutions.some((solution) =>
              (solution as string)
                .toLowerCase()
                .includes(selectedSolutionFilter.toLowerCase()),
            )
            : false;
        if (!hasSolution) return false;
      }

      if (filters.isProduction) {
        return isProductionEnv(row);
      }
      if (filters.isPreproduction) {
        return isPreproductionEnv(row);
      }
      if (filters.isRecette) {
        return isRecetteEnv(row);
      }
      if (filters.isIntegration) {
        return isIntegrationEnv(row);
      }
      if (filters.isDeveloppement) {
        return isDeveloppementEnv(row);
      }
      if (filters.isFormation) {
        return isFormationEnv(row);
      }
      if (filters.isHorsProduction) {
        return isHorsProductionEnv(row);
      }
      if (filters.isSansEnvironnement) {
        return isSansEnvironnementEnv(row);
      }
      if (filters.isSansSolution) {
        return isSansSolutionEnv(row);
      }
      return true;
    });
  }, [filters, searchFilteredRows, selectedSolutionFilter]);

  const getEnvironmentAndSolutionStats = useMemo(() => {
    const stats: Record<string, number> = {
      Production: 0,
      Préproduction: 0,
      Développement: 0,
      Formation: 0,
      Recette: 0,
      Technique: 0,
      POC: 0,
      "Sans environnement": 0,
    };

    namespaces.forEach((namespace) => {
      if (!namespace.environment || namespace.environment.trim() === "") {
        stats["Sans environnement"]++;
      } else {
        const env = namespace.environment.toLowerCase();
        if (
          env.includes("prép") ||
          env.includes("préproduction") ||
          env.includes("preprod")
        ) {
          stats["Préproduction"]++;
        } else if (env.includes("prod") || env.includes("production")) {
          stats["Production"]++;
        } else if (env.includes("dev") || env.includes("développement")) {
          stats["Développement"]++;
        } else if (env.includes("dev") || env.includes("formation")) {
          stats["Formation"]++;
        } else if (env.includes("recette")) {
          stats["Recette"]++;
        } else if (env.includes("technique")) {
          stats["Technique"]++;
        } else if (env.includes("poc")) {
          stats["POC"]++;
        } else {
          stats[namespace.environment] =
            (stats[namespace.environment] || 0) + 1;
        }
      }
    });

    return stats;
  }, [namespaces]);

  const defaultVisibleColumns: Record<string, boolean> = {
    actions: true,
    name: true,
    solutions: true,
    environment: true,
    source: true,
  };

  const [columnVisibility, setColumnVisibility] = useState(() => {
    const initialVisibility: Record<string, boolean> = {};
    columns.forEach((column) => {
      initialVisibility[column.field] =
        defaultVisibleColumns[column.field] || false;
    });
    return initialVisibility;
  });

  // Fonction pour effacer la recherche
  const handleClearSearch = () => {
    setSearchValue("");
  };

  // Fonction pour effacer tous les champs du modal
  const handleClearModalFields = () => {
    setSelectedSolutions([]);
    setSelectedEnvironment("");
  };

  if (loading) return <CustomLoading />;

  if (error) {
    return (
      <Alert
        severity="error"
        sx={{
          m: 2,
          borderRadius: "12px",
          backgroundColor: "#ffb3b3",
          color: "#8b0000",
          border: "1px solid #ff9999",
        }}
      >
        {error}
      </Alert>
    );
  }

  return (
    <ThemeProvider theme={customTheme}>
      <Box sx={{ p: 2, backgroundColor: "#f9f9f9", minHeight: "100vh" }}>
        <Box>
          <Paper
            elevation={0}
            sx={{
              background: "linear-gradient(135deg, #D8F8F9 0%, #D8F8F9 100%)",
              borderRadius: 2,
              p: 3,
              mb: 3,
              color: "#004d00",
            }}
          >
            <Typography variant="h4" sx={{ fontWeight: 700, mb: 2 }}>
              Gestion des Namespaces
            </Typography>

            <Box sx={{ mb: 2 }}>
              <Typography variant="body1" sx={{ opacity: 0.9, mb: 1 }}>
                {namespaces?.length || 0} namespace(s) au total
                {searchValue && (
                  <span>
                    {" "}
                    - {filteredRows.length} résultat(s) pour "{searchValue}"
                  </span>
                )}
              </Typography>

              {/* Statistiques par environnement et solution */}
              <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1, mt: 2 }}>
                {Object.entries(getEnvironmentAndSolutionStats).map(
                  ([key, count]) => {
                    let colors;
                    if (key === "sans environnement") {
                      colors = {
                        bg: "#ffcccc",
                        text: "#cc0000",
                        border: "#ff9999",
                      };
                    } else if (key === "sans solution") {
                      colors = {
                        bg: "#ffebcc",
                        text: "#cc7b00",
                        border: "#ffd699",
                      };
                    } else {
                      colors = getBadgeColorEnvironment(key);
                    }

                    return (
                      <Chip
                        key={key}
                        label={`${key}: ${count}`}
                        size="small"
                        sx={{
                          backgroundColor: colors.bg,
                          color: colors.text,
                          border: `1px solid ${colors.border}`,
                          fontWeight: "600",
                          fontSize: "0.75rem",
                          borderRadius: "12px",
                          textTransform: "capitalize",
                        }}
                      />
                    );
                  },
                )}
              </Box>
            </Box>
          </Paper>
        </Box>

        {successMessage && (
          <Alert
            severity="success"
            sx={{
              mb: 3,
              borderRadius: "12px",
              backgroundColor: "#b3ffcc",
              color: "#006633",
              border: "1px solid #99ffb3",
            }}
            onClose={() => setSuccessMessage(null)}
          >
            {successMessage}
          </Alert>
        )}

        {/* NOUVEAU: Barre de filtres avec le style de votre exemple */}
        <NamespaceFilters
          filters={filters}
          onFilterChange={setFilters}
          searchValue={searchValue}
          onSearchChange={setSearchValue}
          onClearSearch={handleClearSearch}
          selectedSolutionFilter={selectedSolutionFilter}
          onSolutionFilterChange={setSelectedSolutionFilter}
          solutionsList={solutionsList}
        />

        {namespaces && namespaces.length !== 0 && (
          <Card
            sx={{
              borderRadius: "16px",
              boxShadow: "0 4px 12px rgba(0, 0, 0, 0.08)",
              border: "1px solid #e6e6e6",
            }}
          >
            <CardContent sx={{ p: 0 }}>
              <DataGrid
                rows={filteredRows}
                columns={columns}
                getRowId={(row) => row.id}
                pageSizeOptions={[5, 10, 25, 50]}
                initialState={{
                  pagination: {
                    paginationModel: { pageSize: 25, page: 0 },
                  },
                  columns: {
                    columnVisibilityModel: columnVisibility,
                  },
                }}
                onColumnVisibilityModelChange={(newModel) =>
                  setColumnVisibility(newModel)
                }
                // SUPPRIMER la toolbar personnalisée pour enlever la barre de recherche interne
                slots={{
                  toolbar: null,
                }}
                checkboxSelection
                onRowSelectionModelChange={(newSelection) => {
                  setSelectedNamespaces(newSelection as number[]);
                }}
                disableRowSelectionOnClick
                autoHeight
                // Désactiver toutes les fonctionnalités de filtrage interne
                disableColumnFilter
                disableColumnMenu
                disableColumnSelector
                disableDensitySelector
              />
            </CardContent>
          </Card>
        )}

        {/* Les modales restent identiques */}
        <Dialog
          open={showPods}
          onClose={() => setShowPods(false)}
          maxWidth="xl"
          fullWidth
          PaperProps={{
            sx: {
              borderRadius: "16px",
              boxShadow: "0 8px 25px rgba(0, 0, 0, 0.1)",
              border: "1px solid #e6e6e6",
            },
          }}
        >
          <DialogTitle sx={{ pb: 2 }}>
            <Box
              display="flex"
              alignItems="center"
              justifyContent="space-between"
            >
              <Box>
                <Typography
                  variant="h5"
                  sx={{ fontWeight: "600", color: "#333333", mb: 1 }}
                >
                  Pods du namespace: {selectedNamespace?.name}
                </Typography>
                <Chip
                  label={`${pods.length} pod(s) trouvé(s)`}
                  size="small"
                  sx={{
                    backgroundColor: "#b3e6ff",
                    color: "#0066cc",
                    fontWeight: "medium",
                    border: "1px solid #99ddff",
                  }}
                />
              </Box>
              <IconButton
                onClick={() => setShowPods(false)}
                sx={{
                  backgroundColor: "#ffb3b3",
                  color: "#8b0000",
                  "&:hover": {
                    backgroundColor: "#ff9999",
                  },
                }}
              >
                <CloseIcon />
              </IconButton>
            </Box>
          </DialogTitle>
          <DialogContent sx={{ p: 3 }}>
            {podsLoading ? (
              <CustomLoading />
            ) : (
              <Box>
                {pods.length === 0 ? (
                  <Alert
                    severity="info"
                    sx={{
                      borderRadius: "12px",
                      backgroundColor: "#b3e6ff",
                      color: "#0066cc",
                      border: "1px solid #99ddff",
                    }}
                  >
                    Aucun pod trouvé dans ce namespace
                  </Alert>
                ) : (
                  <Card
                    sx={{
                      borderRadius: "16px",
                      boxShadow: "0 4px 12px rgba(0, 0, 0, 0.08)",
                      border: "1px solid #e6e6e6",
                    }}
                  >
                    <CardContent sx={{ p: 0 }}>
                      <DataGrid
                        rows={pods}
                        columns={podColumns}
                        getRowId={(row) => row.id}
                        pageSizeOptions={[10, 25, 50]}
                        initialState={{
                          pagination: {
                            paginationModel: { pageSize: 10, page: 0 },
                          },
                        }}
                        disableRowSelectionOnClick
                        autoHeight
                      />
                    </CardContent>
                  </Card>
                )}
              </Box>
            )}
          </DialogContent>
        </Dialog>

        {/* MODAL D'AFFECTATION AMÉLIORÉ */}
        <Dialog
          open={assignDialogOpen}
          onClose={() => setAssignDialogOpen(false)}
          maxWidth="sm"
          fullWidth
          PaperProps={{
            sx: {
              borderRadius: "12px",
              border: "1px solid #e0e0e0",
            },
          }}
        >
          <DialogTitle
            sx={{
              backgroundColor: colors.namespace,
              borderBottom: "1px solid #e0e0e0",
              fontWeight: 600,
              fontSize: "1.25rem",
              py: 2,
              px: 3,
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            {selectedNamespaces.length > 1
              ? `Affecter à ${selectedNamespaces.length} namespaces`
              : `Affecter le namespace`}
            <IconButton
              onClick={() => setAssignDialogOpen(false)}
              size="small"
              sx={{
                color: "text.secondary",
                "&:hover": {
                  backgroundColor: "action.hover",
                },
              }}
            >
              <CloseIcon fontSize="small" />
            </IconButton>
          </DialogTitle>

          <DialogContent sx={{ p: 3 }}>
            <Box sx={{ mb: 3 }}>
              <Typography variant="body2" color="text.secondary">
                Les modifications seront appliquées à tous les namespaces
                sélectionnés.
              </Typography>
            </Box>

            {/* Sélecteur d'environnement avec badge visible */}
            <Box sx={{ mb: 3 }}>
              <Typography
                variant="subtitle2"
                gutterBottom
                sx={{ fontWeight: 600 }}
              >
                Environnement *
              </Typography>
              <FormControl fullWidth>
                <Select
                  value={selectedEnvironment}
                  onChange={(e) =>
                    setSelectedEnvironment(e.target.value as string)
                  }
                  input={
                    <OutlinedInput
                      sx={{
                        borderRadius: "4px",
                        "& .MuiOutlinedInput-input": {
                          padding: "10px 14px",
                          paddingRight: selectedEnvironment ? "40px" : "14px",
                        },
                      }}
                      endAdornment={
                        selectedEnvironment && (
                          <InputAdornment position="end">
                            <IconButton
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedEnvironment("");
                              }}
                              size="small"
                              color="error"
                              sx={{
                                mr: 4,
                                "&:hover": {
                                  backgroundColor: "rgba(211, 47, 47, 0.04)",
                                },
                              }}
                            >
                              <DeleteIcon fontSize="small" />
                            </IconButton>
                          </InputAdornment>
                        )
                      }
                    />
                  }
                  renderValue={(selected) => {
                    if (!selected)
                      return <em>Sélectionner un environnement</em>;

                    const colors = getBadgeColorEnvironment(selected);
                    return (
                      <Chip
                        label={selected}
                        sx={{
                          backgroundColor: colors.bg,
                          color: colors.text,
                          border: `1px solid ${colors.border}`,
                          fontWeight: 500,
                          fontSize: "0.875rem",
                          height: "32px",
                          "& .MuiChip-label": { px: 1.5 },
                        }}
                      />
                    );
                  }}
                >
                  {[
                    "Production",
                    "Préproduction",
                    "Recette",
                    "Développement",
                    "Intégration",
                    "Technique",
                    "TNR",
                    "POC",
                    "Formation",
                  ].map((env) => (
                    <MenuItem key={env} value={env}>
                      <Chip
                        label={env}
                        size="small"
                        sx={{
                          backgroundColor: getBadgeColorEnvironment(env).bg,
                          color: getBadgeColorEnvironment(env).text,
                          border: `1px solid ${getBadgeColorEnvironment(env).border
                            }`,
                          fontWeight: 500,
                          fontSize: "0.875rem",
                          height: "24px",
                          "& .MuiChip-label": { px: 1 },
                        }}
                      />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Box>

            {/* Sélecteur de solutions avec Autocomplete */}
            <Box sx={{ mb: 2 }}>
              <Typography
                variant="subtitle2"
                gutterBottom
                sx={{ fontWeight: 600 }}
              >
                Solutions
              </Typography>
              <Autocomplete
                multiple
                disableClearable
                options={solutionsList}
                value={selectedSolutions}
                onChange={(_event, newValue) => {
                  setSelectedSolutions(newValue);
                }}
                getOptionLabel={(option) => {
                  const solutionDetail = solutionsMap.get(option);
                  if (solutionDetail) {
                    const acronym = solutionDetail.entity_acronym || solutionDetail.entity || "AWB";
                    return `${solutionDetail.solution_name} (${acronym})`;
                  }
                  return option;
                }}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    variant="outlined"
                    placeholder="Sélectionner les solutions"
                    InputProps={{
                      ...params.InputProps,
                      sx: {
                        borderRadius: "4px",
                        "& .MuiOutlinedInput-input": {
                          padding: "10px 14px",
                          paddingRight:
                            selectedSolutions.length > 0 ? "40px" : "14px",
                        },
                      },
                      endAdornment: (
                        <>
                          {selectedSolutions.length > 0 && (
                            <InputAdornment position="end">
                              <IconButton
                                onClick={() => setSelectedSolutions([])}
                                size="small"
                                color="error"
                                sx={{
                                  mr: 1,
                                  "&:hover": {
                                    backgroundColor: "rgba(211, 47, 47, 0.04)",
                                  },
                                }}
                              >
                                <DeleteIcon fontSize="small" />
                              </IconButton>
                            </InputAdornment>
                          )}
                          {params.InputProps.endAdornment}
                        </>
                      ),
                    }}
                  />
                )}
                renderTags={(value, getTagProps) =>
                  value.map((option, index) => {
                    const solutionDetail = solutionsMap.get(option);
                    const displayName = solutionDetail
                      ? `${solutionDetail.solution_name} (${solutionDetail.entity_acronym || solutionDetail.entity || "AWB"})`
                      : option;

                    return (
                      <Chip
                        {...getTagProps({ index })}
                        key={option}
                        label={displayName}
                        sx={{
                          backgroundColor: "#FEF3C7",
                          color: "#92400E",
                          border: "1px solid #d1c4e9",
                          fontWeight: 500,
                          fontSize: "0.875rem",
                          height: "32px",
                          "& .MuiChip-label": { px: 1.5 },
                        }}
                      />
                    );
                  })
                }
              />
            </Box>

            {/* Bouton pour effacer tous les champs */}
            <Box sx={{ display: "flex", justifyContent: "center", mt: 2 }}>
              <Button
                startIcon={<ClearIcon />}
                onClick={handleClearModalFields}
                variant="outlined"
                color="warning"
                size="small"
              >
                Effacer tous les champs
              </Button>
            </Box>
          </DialogContent>

          <DialogActions
            sx={{
              p: 2,
              backgroundColor: "#f5f5f5",
              borderTop: "1px solid #882020ff",
              borderRadius: "0 0 12px 12px",
            }}
          >
            <Button
              onClick={() => setAssignDialogOpen(false)}
              variant="outlined"
              sx={{
                borderRadius: "4px",
                textTransform: "none",
                px: 3,
                py: 1,
                borderColor: "divider",
                color: "text.primary",
                "&:hover": {
                  backgroundColor: "action.hover",
                  borderColor: "divider",
                },
              }}
            >
              Annuler
            </Button>
            <Button
              onClick={() => {
                assignSolutions(
                  selectedNamespaces,
                  selectedSolutions,
                  selectedEnvironment,
                );
              }}
              variant="contained"
              disabled={
                selectedNamespaces.length === 0 ||
                !selectedEnvironment ||
                keycloak.hasRoles(["read_only_role"])
              }
              sx={{
                borderRadius: "4px",
                textTransform: "none",
                px: 3,
                py: 1,
                backgroundColor: "primary.main",
                color: "primary.contrastText",
                "&:hover": {
                  backgroundColor: "primary.dark",
                },
                "&:disabled": {
                  backgroundColor: "action.disabledBackground",
                  color: "action.disabled",
                },
              }}
            >
              Confirmer
            </Button>
          </DialogActions>
        </Dialog>
      </Box>
    </ThemeProvider>
  );
};

export default NamespaceDataTable;
