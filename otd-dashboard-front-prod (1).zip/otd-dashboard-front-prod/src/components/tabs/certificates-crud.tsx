import { useEffect, useMemo, useState } from "react";
import {
  Alert,
  Autocomplete,
  Box,
  Button,
  Chip,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  IconButton,
  Paper,
  Snackbar,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Tooltip,
  Typography,
} from "@mui/material";
import { Visibility, GroupAdd } from "@mui/icons-material";
import { getKrakenCORE_BaseUrl } from "@/config/api.config";

/* ================= Types ================= */
type Certificate = {
  id: number;
  certificate_request_ref: string;
  solution: string;
  generated_at: string;
  exp_date: string | null;
  is_renewed: boolean;
  certificate_type: string;
  actor: string | null;
  applicant: string;
  itop_ticket_ref: string;
  diffusion_domain: string[];
  certificate_state: string;
  common_name: string;
  dns: string[];
  config_file?: Record<string, any>;
  teams?: string[];
};

type Team = { id: number; name: string; default_emails: string[] };

/* ================= API ================= */
const API_BASE_URL = getKrakenCORE_BaseUrl();
const CERTS_ENDPOINT = `${API_BASE_URL}/certificates/external/`;
const CERT_ASSIGN_TEAMS = (id: number) =>
  `${API_BASE_URL}/certificates/external/${id}/assign-teams/`;
const TEAMS_ENDPOINT = `${API_BASE_URL}/certificates/team/`;

async function fetchWithAuth(input: RequestInfo, init?: RequestInit) {
  return fetch(input, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers || {}),
    },
  });
}

/* ================ Snackbar hook ================ */
function useSnackbar() {
  const [snackbar, setSnackbar] = useState<{
    open: boolean;
    message: string;
    severity: "success" | "error" | "info";
  }>({
    open: false,
    message: "",
    severity: "info",
  });
  const showSnackbar = (
    message: string,
    severity: "success" | "error" | "info" = "info",
  ) => setSnackbar({ open: true, message, severity });
  const handleCloseSnackbar = () => setSnackbar((s) => ({ ...s, open: false }));
  return { snackbar, showSnackbar, handleCloseSnackbar };
}

/* ================ Utils ================ */
function fmtDate(s?: string | null) {
  if (!s) return "-";
  if (/^\d{8}T\d{6}$/.test(s)) {
    const y = s.slice(0, 4),
      m = s.slice(4, 6),
      d = s.slice(6, 8);
    const hh = s.slice(9, 11),
      mm = s.slice(11, 13),
      ss = s.slice(13, 15);
    const dt = new Date(`${y}-${m}-${d}T${hh}:${mm}:${ss}`);
    return isNaN(dt.getTime()) ? s : dt.toLocaleString();
  }
  const dt = new Date(s);
  return isNaN(dt.getTime()) ? s : dt.toLocaleString();
}

function uniq<T>(arr: T[]) {
  return Array.from(new Set(arr));
}

/* ================= Page ================= */
export default function CertificatesPage() {
  const [rows, setRows] = useState<Certificate[]>([]);
  const [loading, setLoading] = useState(true);

  // dialogs
  const [detailsDialog, setDetailsDialog] = useState<Certificate | null>(null);
  const [assignDialog, setAssignDialog] = useState<{
    open: boolean;
    cert: Certificate | null;
    selectedNames: string[];
  }>({
    open: false,
    cert: null,
    selectedNames: [],
  });

  // caches
  const [teams, setTeams] = useState<Team[]>([]);
  const [teamsLoading, setTeamsLoading] = useState(false);

  const { snackbar, showSnackbar, handleCloseSnackbar } = useSnackbar();

  /* ============ FETCH LIST (pas de boucle) ============ */
  useEffect(() => {
    let isMounted = true;

    (async () => {
      try {
        setLoading(true);
        const res = await fetchWithAuth(CERTS_ENDPOINT, { cache: "no-store" });
        if (!res.ok) throw new Error(`Erreur API ${res.status}`);
        const data = await res.json();
        if (isMounted) setRows(Array.isArray(data) ? data : []);
      } catch (e) {
        console.error(e);
        if (isMounted) {
          showSnackbar("Erreur lors du chargement des certificats", "error");
          setRows([]);
        }
      } finally {
        if (isMounted) setLoading(false);
      }
    })();

    return () => {
      isMounted = false;
    };
  }, []);

  const refresh = async () => {
    try {
      setLoading(true);
      const res = await fetchWithAuth(CERTS_ENDPOINT);
      if (!res.ok) throw new Error(`Erreur API ${res.status}`);
      const data = await res.json();
      setRows(Array.isArray(data) ? data : []);
    } catch (e) {
      console.error(e);
      showSnackbar("Erreur lors du rafraîchissement", "error");
    } finally {
      setLoading(false);
    }
  };

  /* ============ lazy loads ============ */
  const ensureTeamsLoaded = async () => {
    if (teams.length) return;
    try {
      setTeamsLoading(true);
      const res = await fetchWithAuth(TEAMS_ENDPOINT);
      if (!res.ok) throw new Error(`GET teams ${res.status}`);
      const data = await res.json();
      setTeams(Array.isArray(data) ? data : []);
    } catch (e) {
      console.error(e);
      showSnackbar("Erreur chargement équipes", "error");
    } finally {
      setTeamsLoading(false);
    }
  };

  /* ====================== BIG FILTERS (multi) ====================== */
  // états des filtres
  const [fSolutions, setFSolutions] = useState<string[]>([]);
  const [fRenewed, setFRenewed] = useState<string[]>([]); // "Oui"/"Non"
  const [fTypes, setFTypes] = useState<string[]>([]);
  const [fApplicants, setFApplicants] = useState<string[]>([]);
  const [fStates, setFStates] = useState<string[]>([]);
  const [fRef, setFRef] = useState("");
  const [fItop, setFItop] = useState("");
  const [fSearch, setFSearch] = useState(""); // recherche combinée

  // options dérivées depuis rows
  const solutionOptions = useMemo(
    () => uniq(rows.map((r) => r.solution).filter(Boolean)),
    [rows],
  );
  const typeOptions = useMemo(
    () => uniq(rows.map((r) => r.certificate_type).filter(Boolean)),
    [rows],
  );
  const applicantOptions = useMemo(
    () => uniq(rows.map((r) => r.applicant).filter(Boolean)),
    [rows],
  );
  const stateOptions = useMemo(
    () => uniq(rows.map((r) => r.certificate_state).filter(Boolean)),
    [rows],
  );

  // filtre local
  const filteredRows = useMemo(() => {
    const s = fSearch.trim().toLowerCase();

    return rows.filter((r) => {
      if (fSolutions.length && !fSolutions.includes(r.solution)) return false;
      if (fTypes.length && !fTypes.includes(r.certificate_type)) return false;
      if (fApplicants.length && !fApplicants.includes(r.applicant))
        return false;
      if (fStates.length && !fStates.includes(r.certificate_state))
        return false;

      if (fRenewed.length) {
        const asText = r.is_renewed ? "Oui" : "Non";
        if (!fRenewed.includes(asText)) return false;
      }

      if (
        fRef &&
        !r.certificate_request_ref?.toLowerCase().includes(fRef.toLowerCase())
      )
        return false;
      if (
        fItop &&
        !r.itop_ticket_ref?.toLowerCase().includes(fItop.toLowerCase())
      )
        return false;

      if (s) {
        const hay = [
          r.generated_at,
          r.exp_date ?? "",
          (r.teams || []).join(" "),
          r.common_name || "",
          (r.dns || []).join(" "),
        ]
          .join(" ")
          .toLowerCase();
        if (!hay.includes(s)) return false;
      }

      return true;
    });
  }, [
    rows,
    fSolutions,
    fRenewed,
    fTypes,
    fApplicants,
    fStates,
    fRef,
    fItop,
    fSearch,
  ]);

  /* ============ Actions (POST endpoints) ============ */
  async function postAssignTeams(cert: Certificate, teamNames: string[]) {
    const res = await fetchWithAuth(CERT_ASSIGN_TEAMS(cert.id), {
      method: "POST",
      body: JSON.stringify({ teams: teamNames }),
    });
    if (!res.ok) throw new Error(`POST assign-teams ${res.status}`);
    return res.json();
  }

  /* ====================== RENDER ====================== */
  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          mb: 2,
        }}
      >
        <Typography variant="h5" sx={{ fontWeight: 700 }}>
          Certificats
        </Typography>
        <Button variant="outlined" onClick={refresh}>
          Rafraîchir
        </Button>
      </Box>

      {/* ================= Filtres ================= */}
      <Paper sx={{ p: 2.5, mb: 2, borderRadius: 2 }} elevation={1}>
        <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 1.5 }}>
          Filtres
        </Typography>

        <Stack direction={{ xs: "column", md: "row" }} spacing={1.5}>
          <Autocomplete
            multiple
            options={solutionOptions}
            value={fSolutions}
            onChange={(_, v) => setFSolutions(v)}
            renderInput={(p) => (
              <TextField {...p} label="Solution" size="small" />
            )}
            sx={{ minWidth: 220 }}
          />
          <Autocomplete
            multiple
            options={["Oui", "Non"]}
            value={fRenewed}
            onChange={(_, v) => setFRenewed(v)}
            renderInput={(p) => (
              <TextField {...p} label="Renouvelé" size="small" />
            )}
            sx={{ minWidth: 180 }}
          />
          <Autocomplete
            multiple
            options={typeOptions}
            value={fTypes}
            onChange={(_, v) => setFTypes(v)}
            renderInput={(p) => <TextField {...p} label="Type" size="small" />}
            sx={{ minWidth: 220 }}
          />
          <Autocomplete
            multiple
            options={applicantOptions}
            value={fApplicants}
            onChange={(_, v) => setFApplicants(v)}
            renderInput={(p) => (
              <TextField {...p} label="Demandeur" size="small" />
            )}
            sx={{ minWidth: 220 }}
          />
          <Autocomplete
            multiple
            options={stateOptions}
            value={fStates}
            onChange={(_, v) => setFStates(v)}
            renderInput={(p) => <TextField {...p} label="État" size="small" />}
            sx={{ minWidth: 220 }}
          />
        </Stack>

        <Stack
          direction={{ xs: "column", md: "row" }}
          spacing={1.5}
          sx={{ mt: 1.5 }}
        >
          <TextField
            label="Ref"
            size="small"
            value={fRef}
            onChange={(e) => setFRef(e.target.value)}
            sx={{ minWidth: 220 }}
          />
          <TextField
            label="Ticket iTop"
            size="small"
            value={fItop}
            onChange={(e) => setFItop(e.target.value)}
            sx={{ minWidth: 220 }}
          />
          <TextField
            label="Recherche combinée (Généré, Expiration, Équipes, CN, DNS)"
            size="small"
            fullWidth
            value={fSearch}
            onChange={(e) => setFSearch(e.target.value)}
          />
          <Button
            variant="text"
            onClick={() => {
              setFSolutions([]);
              setFRenewed([]);
              setFTypes([]);
              setFApplicants([]);
              setFStates([]);
              setFRef("");
              setFItop("");
              setFSearch("");
            }}
          >
            Réinitialiser
          </Button>
        </Stack>
      </Paper>

      {/* ================= Table ================= */}
      <Paper sx={{ borderRadius: 2, boxShadow: 3, overflow: "hidden" }}>
        {loading ? (
          <Box sx={{ display: "flex", justifyContent: "center", py: 6 }}>
            <CircularProgress />
          </Box>
        ) : (
          <TableContainer>
            <Table sx={{ minWidth: 1200 }}>
              <TableHead sx={{ bgcolor: "grey.100" }}>
                <TableRow>
                  <TableCell sx={{ minWidth: 160 }} align="center">
                    Actions
                  </TableCell>
                  <TableCell>Ref</TableCell>
                  <TableCell>Solution</TableCell>
                  <TableCell>Généré le</TableCell>
                  <TableCell>Expiration</TableCell>
                  <TableCell>Renouvelé</TableCell>
                  <TableCell>Type</TableCell>
                  <TableCell>Demandeur</TableCell>
                  <TableCell>Ticket iTop</TableCell>
                  <TableCell>Diffusion</TableCell>
                  <TableCell>État</TableCell>
                  <TableCell>Common Name</TableCell>
                  <TableCell>DNS</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredRows.map((c) => (
                  <TableRow
                    key={c.id}
                    sx={{ "&:nth-of-type(odd)": { bgcolor: "action.hover" } }}
                  >
                    {/* actions */}
                    <TableCell align="center">
                      <Stack
                        direction="row"
                        spacing={1}
                        flexWrap="nowrap"
                        justifyContent="center"
                        sx={{ whiteSpace: "nowrap" }}
                      >
                        <Tooltip title="Détails">
                          <IconButton
                            color="primary"
                            onClick={() => setDetailsDialog(c)}
                            size="small"
                          >
                            <Visibility fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Assigner à des équipes">
                          <IconButton
                            color="secondary"
                            onClick={async () => {
                              await ensureTeamsLoaded();
                              setAssignDialog({
                                open: true,
                                cert: c,
                                selectedNames: c.teams || [],
                              });
                            }}
                            size="small"
                          >
                            <GroupAdd fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        {/* Crayon “edit diffusion” supprimé */}
                      </Stack>
                    </TableCell>

                    {/* colonnes */}
                    <TableCell>{c.certificate_request_ref}</TableCell>
                    <TableCell>{c.solution || "-"}</TableCell>
                    <TableCell>{fmtDate(c.generated_at)}</TableCell>
                    <TableCell>{fmtDate(c.exp_date)}</TableCell>
                    <TableCell>{c.is_renewed ? "Oui" : "Non"}</TableCell>
                    <TableCell>{c.certificate_type || "-"}</TableCell>
                    <TableCell>{c.applicant || "-"}</TableCell>
                    <TableCell>{c.itop_ticket_ref || "-"}</TableCell>
                    <TableCell>
                      {/* Affiche les équipes assignées (par nom) : 2 + +N */}
                      <Stack direction="row" spacing={0.5} flexWrap="wrap">
                        {(c.teams || []).slice(0, 2).map((name) => (
                          <Chip key={name} label={name} size="small" />
                        ))}
                        {c.teams && c.teams.length > 2 && (
                          <Chip
                            label={`+${c.teams.length - 2}`}
                            size="small"
                            color="info"
                          />
                        )}
                      </Stack>
                    </TableCell>
                    <TableCell>{c.certificate_state || "-"}</TableCell>
                    <TableCell>{c.common_name || "-"}</TableCell>
                    <TableCell>
                      <Stack direction="row" spacing={0.5} flexWrap="wrap">
                        {c.dns?.map((d) => (
                          <Chip
                            key={d}
                            label={d}
                            size="small"
                            variant="outlined"
                          />
                        ))}
                      </Stack>
                    </TableCell>
                  </TableRow>
                ))}
                {filteredRows.length === 0 && !loading && (
                  <TableRow>
                    <TableCell colSpan={13} align="center">
                      <Typography>Aucun certificat</Typography>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </Paper>

      {/* ===================== DETAILS ===================== */}
      <Dialog
        open={!!detailsDialog}
        onClose={() => setDetailsDialog(null)}
        fullWidth
        maxWidth="md"
      >
        <DialogTitle>Détails du certificat</DialogTitle>
        <DialogContent dividers>
          {detailsDialog && (
            <Paper
              sx={{ p: 3, borderRadius: 2, bgcolor: "grey.50" }}
              elevation={0}
            >
              <Typography variant="h6" sx={{ mb: 2, fontWeight: 600 }}>
                Informations générales
              </Typography>
              <Stack spacing={1}>
                <Stack direction={{ xs: "column", sm: "row" }} spacing={2}>
                  <Typography flex={1}>
                    <b>Ref:</b> {detailsDialog.certificate_request_ref}
                  </Typography>
                  <Typography flex={1}>
                    <b>Solution:</b> {detailsDialog.solution || "-"}
                  </Typography>
                </Stack>
                <Stack direction={{ xs: "column", sm: "row" }} spacing={2}>
                  <Typography flex={1}>
                    <b>Généré le:</b> {fmtDate(detailsDialog.generated_at)}
                  </Typography>
                  <Typography flex={1}>
                    <b>Expiration:</b> {fmtDate(detailsDialog.exp_date)}
                  </Typography>
                </Stack>
                <Stack direction={{ xs: "column", sm: "row" }} spacing={2}>
                  <Typography flex={1}>
                    <b>Renouvelé:</b> {detailsDialog.is_renewed ? "Oui" : "Non"}
                  </Typography>
                  <Typography flex={1}>
                    <b>Type:</b> {detailsDialog.certificate_type || "-"}
                  </Typography>
                </Stack>
                <Stack direction={{ xs: "column", sm: "row" }} spacing={2}>
                  <Typography flex={1}>
                    <b>Demandeur:</b> {detailsDialog.applicant || "-"}
                  </Typography>
                  <Typography flex={1}>
                    <b>Ticket iTop:</b> {detailsDialog.itop_ticket_ref || "-"}
                  </Typography>
                </Stack>
                <Typography>
                  <b>État:</b> {detailsDialog.certificate_state || "-"}
                </Typography>
                <Typography>
                  <b>Common Name:</b> {detailsDialog.common_name || "-"}
                </Typography>
              </Stack>

              <Divider sx={{ my: 3 }} />

              {/* Toutes les équipes assignées */}
              <Typography variant="h6" sx={{ mb: 1, fontWeight: 600 }}>
                Équipes assignées
              </Typography>
              <Stack direction="row" spacing={0.5} flexWrap="wrap">
                {detailsDialog.teams?.length ? (
                  detailsDialog.teams.map((n) => (
                    <Chip key={n} label={n} size="small" />
                  ))
                ) : (
                  <Typography color="text.secondary">-</Typography>
                )}
              </Stack>

              <Divider sx={{ my: 3 }} />
              <Typography variant="h6" sx={{ mb: 1, fontWeight: 600 }}>
                DNS
              </Typography>
              <Stack direction="row" spacing={0.5} flexWrap="wrap">
                {detailsDialog.dns?.length ? (
                  detailsDialog.dns.map((d) => (
                    <Chip key={d} label={d} size="small" variant="outlined" />
                  ))
                ) : (
                  <Typography color="text.secondary">-</Typography>
                )}
              </Stack>

              <Divider sx={{ my: 3 }} />
              <Typography variant="h6" sx={{ mb: 1, fontWeight: 600 }}>
                Configuration
              </Typography>
              {detailsDialog.config_file ? (
                <Stack spacing={0.5}>
                  {Object.entries(detailsDialog.config_file)
                    .filter(([k]) => k !== "id")
                    .map(([k, v]) => (
                      <Typography key={k}>
                        <b>{k}:</b> {String(v ?? "-")}
                      </Typography>
                    ))}
                </Stack>
              ) : (
                <Typography color="text.secondary">Non disponible</Typography>
              )}
            </Paper>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDetailsDialog(null)} variant="outlined">
            Fermer
          </Button>
        </DialogActions>
      </Dialog>

      {/* ===================== ASSIGNER ÉQUIPES ===================== */}
      <Dialog
        open={assignDialog.open}
        onClose={() =>
          setAssignDialog({ open: false, cert: null, selectedNames: [] })
        }
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle>Assigner à des équipes</DialogTitle>
        <DialogContent dividers>
          <Typography variant="body2" sx={{ mb: 1.5, color: "text.secondary" }}>
            Sélectionne les équipes à associer à ce certificat. (Envoi des{" "}
            <b>noms</b> d’équipe)
          </Typography>
          <Autocomplete
            multiple
            options={teams}
            loading={teamsLoading}
            getOptionLabel={(o) => o.name}
            value={teams.filter((t) =>
              assignDialog.selectedNames.includes(t.name),
            )}
            onChange={(_, newValue) =>
              setAssignDialog((prev) => ({
                ...prev,
                selectedNames: newValue.map((v) => v.name),
              }))
            }
            renderInput={(params) => (
              <TextField {...params} label="Équipes" size="small" />
            )}
          />
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() =>
              setAssignDialog({ open: false, cert: null, selectedNames: [] })
            }
          >
            Annuler
          </Button>
          <Button
            variant="contained"
            onClick={async () => {
              if (!assignDialog.cert) return;
              try {
                // POST /assign-teams avec les NOMS
                const updated = await postAssignTeams(
                  assignDialog.cert,
                  assignDialog.selectedNames,
                );

                // MAJ UI : on privilégie la réponse API si elle contient teams,
                // sinon on applique la sélection locale.
                const nextTeamNames: string[] =
                  Array.isArray(updated?.teams) && updated.teams.length
                    ? updated.teams
                    : assignDialog.selectedNames;

                setRows((arr) =>
                  arr.map((r) =>
                    r.id === assignDialog.cert!.id
                      ? { ...r, teams: nextTeamNames }
                      : r,
                  ),
                );
                showSnackbar("Équipes assignées mises à jour", "success");
                setAssignDialog({ open: false, cert: null, selectedNames: [] });
              } catch (e) {
                console.error(e);
                showSnackbar("Erreur lors de l'assignation", "error");
              }
            }}
          >
            Enregistrer
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={5000}
        onClose={handleCloseSnackbar}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          sx={{ width: "100%" }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}
