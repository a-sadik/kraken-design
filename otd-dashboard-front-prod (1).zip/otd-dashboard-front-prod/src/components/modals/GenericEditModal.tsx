import React, { useEffect, useState } from "react";
import {
  TextField,
  Button,
  Box,
  CircularProgress,
  Autocomplete,
} from "@mui/material";
import axios from "axios";
import MyModal from "@/components/modals/MyModal";

interface Item {
  id: string;
  name: string;
}

interface Props {
  open: boolean;
  onClose: () => void;
  onSave: () => void;
  title: string;
  apiUrl: string;
  inputLabel: string;
  fetchUrl: string;
}

export const GenericEditModal: React.FC<Props> = ({
  open,
  onClose,
  onSave,
  title,
  apiUrl,
  inputLabel,
  fetchUrl,
}) => {
  const [items, setItems] = useState<Item[]>([]);
  const [selected, setSelected] = useState<Item | null>(null);
  const [newName, setNewName] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open) {
      setLoading(true);
      axios
        .get(fetchUrl)
        .then((r) => setItems(r.data))
        .catch(() => setItems([]))
        .finally(() => setLoading(false));
    }
  }, [open, fetchUrl]);

  const handleSave = () => {
    if (!selected) return;
    axios
      .put(`${apiUrl}/${selected.id}`, { name: newName })
      .then(() => onSave());
  };

  return (
    <MyModal open={open} onClose={onClose} title={title}>
      <Box sx={{ minWidth: 500, px: 2, pt: 1 }}>
        {loading ? (
          <Box textAlign="center" my={2}>
            <CircularProgress />
          </Box>
        ) : (
          <>
            <Autocomplete
              options={items}
              getOptionLabel={(o) => o.name}
              onChange={(_, value) => {
                setSelected(value);
                setNewName(value?.name || "");
              }}
              renderInput={(params) => (
                <TextField {...params} label="Sélectionner" fullWidth />
              )}
            />

            <TextField
              fullWidth
              label={inputLabel}
              sx={{ mt: 2 }}
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              disabled={!selected}
            />
          </>
        )}

        <Box textAlign="right" mt={3}>
          <Button onClick={onClose} variant="outlined" sx={{ mr: 1 }}>
            Annuler
          </Button>
          <Button
            onClick={handleSave}
            variant="contained"
            sx={{
              backgroundColor: "#1976d2",
              color: "#fff",
              fontWeight: "bold",
              "&:hover": {
                backgroundColor: "#125ea9",
              },
            }}
          >
            Modifier
          </Button>
        </Box>
      </Box>
    </MyModal>
  );
};
