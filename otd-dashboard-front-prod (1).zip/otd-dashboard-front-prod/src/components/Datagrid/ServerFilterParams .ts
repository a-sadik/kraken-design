export interface ServerFilterParams {
  id?: string; // exact
  hostname__icontains?: string; // icontains
  os_type__icontains?: string; // icontains
  os_detail__icontains?: string; // icontains
  nature_detail__icontains?: string; // icontains
  environments?: string[]; // exact (multiple values)
  signed__icontains?: string; // icontains
  created_by__icontains?: string; // icontains
  updated_by__icontains?: string; // icontains
  solutions__solution_name__icontains?: string; // icontains
  solutions__solution_role__icontains?: string; // icontains
  solutions__psi__PSI_name__icontains?: string; // icontains
  solutions__solution_type__solution_type_name__icontains?: string; // icontains
  solutions__solution_popularity__solution_popularity_name__icontains?: string; // icontains
  solutions__domain__domain_name__icontains?: string; // icontains
  solutions__itop_id__icontains?: string; // icontains
  solutions__declarted_on_itop?: boolean; // exact
  solutions__declarted_on_bigfix?: boolean; // exact
  ip_addresses?: string; // exact (assuming single IP for filter, based on example)
}
