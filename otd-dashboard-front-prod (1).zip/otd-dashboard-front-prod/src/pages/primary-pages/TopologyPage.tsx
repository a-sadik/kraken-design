/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import React, { useMemo } from "react";
import type { ReactElement } from "react";

import { useState, useEffect } from "react";
import {
  CircularProgress,
  InputAdornment,
  List,
  ListItem,
  ListItemText,
  TextField,
} from "@mui/material";
import { Memory, Search, Speed, Storage } from "@mui/icons-material";

import {
  Card,
  CardContent,
  Typography,
  Grid,
  Chip,
  Box,
  Paper,
  Breadcrumbs,
  Stack,
  Skeleton,
  Container,
  IconButton,
  Fade,
  Slide,
  Divider,
  Button,
} from "@mui/material";
import { alpha } from "@mui/material/styles";
import { DiOpenshift } from "react-icons/di";
import {
  Business,
  AccountTree,
  Apps,
  Person,
  NavigateNext,
  Home,
  KeyboardArrowRight,
  VisibilityOff,
  Visibility,
} from "@mui/icons-material";
import { PiCubeBold } from "react-icons/pi";
import { VscSymbolNamespace } from "react-icons/vsc";
import { LuRocket } from "react-icons/lu";
import { TbBuildingBank } from "react-icons/tb";
import { FiServer } from "react-icons/fi";
import {
  MdAdminPanelSettings,
  MdOutlineAdminPanelSettings,
} from "react-icons/md";
import { getTopologyRootApiUrl, getAllTopology, hardware_info_x86_info, hardware_info_openshift_info, hardware_info_power_info } from "@/config/api.config";
import type { BreadcrumbItem } from "@/types/TopologyTypes";
import fetchWithAuth from "@/middleware/fetch-auth";
import SolutionDetailView from "@/components/shared/SolutionDetailsView";
import { BiNetworkChart } from "react-icons/bi";
import { FaNetworkWired } from "react-icons/fa6";
// Fonction utilitaire pour extraire le nom d'affichage de manière sécurisée
const getDisplayName = (admin: any): string => {
  if (!admin) return "N/A";

  // Si admin est une chaîne de caractères (format pôles/domaines)
  if (typeof admin === "string") {
    if (admin.trim() === "" || admin === "N/A") return "N/A";
    // Extraire le nom avant @ si c'est un email
    if (admin.includes("@")) {
      return admin.split("@")[0].trim();
    }
    return admin.trim();
  }

  // Si admin est un objet (format solutions)
  if (typeof admin === "object") {
    // Si admin.email existe et n'est pas vide
    if (admin.email && typeof admin.email === "string") {
      const emailPrefix = admin.email.split("@")[0];
      // Si admin.name existe, l'utiliser, sinon utiliser le préfixe email
      return admin.name && typeof admin.name === "string"
        ? admin.name.replace(/@.*$/, "")
        : emailPrefix;
    }

    // Si admin.name existe mais pas d'email
    if (admin.name && typeof admin.name === "string") {
      return admin.name.replace(/@.*$/, "");
    }
  }

  // Fallback
  return "N/A";
};

// Fonction utilitaire pour formater le nom avec acronyme et filiale
const getFormattedName = (item: any, level: string): string => {
  const name = item[`${level}_name`] || item.name || item.hostname || item.pod_name || "—";

  let formattedName = name;
  const acronym = item.entity_acronym || item[`${level}_acronym`];
  if (acronym && acronym.trim() !== "") {
    formattedName = `${name} (${acronym})`;
  }

  return formattedName;
};

// Fonction utilitaire pour obtenir l'email de manière sécurisée
const getEmail = (admin: any): string => {
  if (!admin) return "N/A";

  // Si admin est une chaîne de caractères (format pôles/domaines)
  if (typeof admin === "string") {
    if (admin.trim() === "" || admin === "N/A") return "N/A";
    return admin.trim();
  }

  // Si admin est un objet (format solutions)
  if (typeof admin === "object") {
    return admin && admin.email && typeof admin.email === "string"
      ? admin.email
      : "N/A";
  }

  return "N/A";
};

// Fonction pour filtrer les administrateurs vides ou invalides
const filterValidAdmins = (admins: any[]): any[] => {
  if (!Array.isArray(admins)) return [];

  return admins.filter((admin) => {
    if (typeof admin === "string") {
      return admin.trim() !== "" && admin !== "N/A";
    }
    if (typeof admin === "object" && admin !== null) {
      return (
        (admin.email && admin.email.trim() !== "") ||
        (admin.name && admin.name.trim() !== "")
      );
    }
    return false;
  });
};

//  thème pastel
export const pastelTheme = {
  primary: "#99caff", // bleu windows
  secondary: "#a8e6b1", // vert linux
  accent: "#f3aebd", // rose macos
  surface: "#fce38a", // jaune par défaut
  background: "#F5F7FA",
  surfaceVariant: "#ffb3b3", // rouge production
  outline: "#D1D5DB",
  shadow: "rgba(0, 0, 0, 0.1)",
  cardBackground: "#FFFFFF",
  textPrimary: "#2D3748",
  textSecondary: "#4A5568",
  hoverBackground: "white",
  filliale: "#FFA500", // Orange pour les filiales
};

// couleurs par niveau
export const colors = {
  entity: "#fce38a", // jaune pastel
  pole: "#c6b3ff", // violet pastel
  domain: "#b3ffcc", // vert pastel
  solution: "#b3e6ff", // bleu clair pastel
  namespace: "#a8e6b1", // vert linux
  deployment: "#f3aebd", // rose macos
  server: "#99caff", // bleu windows
  pod: "#ffd699", // orange pastel
};

export const darkColors = {
  entity: "#f5d95a",
  pole: "#b399ff",
  domain: "#99e6b3",
  solution: "#99d6ff",
  namespace: "#90d69e",
  deployment: "#e39eae",
  server: "#7fb2e6",
  pod: "#ffc266",
};

export const envColors = {
  Production: "#ffb3b3", // rouge pastel soutenu
  Préproduction: "#ffd699", // orange pastel soutenu
  Intégration: "#b3e6ff", // bleu clair pastel
  Recette: "#c6b3ff", // violet pastel doux
  Développement: "#a8e6b1", // vert pastel soutenu
  Formation: "#ffe6cc",
  TNR: "#f4bfff", // Lavande claire
  Technique: "#a9c0d9", // bleu-gris doux
  "Environments undefined": "#bb688bff",
};

export const osColors = {
  Windows: "#99caff", // bleu pastel un peu plus soutenu
  Linux: "#a8e6b1", // vert pastel plus marqué
  MacOS: "#f3aebd", // rose pastel plus profond
  AIX: "#fce38a", // jaune pastel plus profond
  Default: "#7fb2e6", // jaune pastel plus chaud
};

export const AIX_DARK = "#a6842e";
export const AIX_MID = "#caa34b";


// Thème avec plus de contraste
export const modernTheme = {
  primary: "#2563EB",
  secondary: "#7C3AED",
  accent: "#059669",
  surface: "#FFCE14",
  background: "#F1F5F9", // Plus sombre
  surfaceVariant: "#e04434", // Plus sombre
  outline: "#CBD5E1", // Plus visible
  shadow: "rgba(15, 23, 42, 0.12)", // Plus prononcé
  cardBackground: "#FFFFFF",
  textPrimary: "#1E293B",
  textSecondary: "#475569",
};

interface NavigationState {
  currentLevel:
  | "entity"
  | "pole"
  | "domain"
  | "solution"
  | "solutionDetail"
  | "namespace"
  | "deployment"
  | "server"
  | "pod"
  | any;
  currentItem: any;
  breadcrumb: BreadcrumbItem[];
  history: Array<{
    level: string;
    item: any;
    data: any[];
    searchTerm?: string;
    environmentTabs?: Map<string, number>;
    solutionViewTab?: Map<string, number>;
  }>;
}



const TopologyPage: React.FC = () => {
  // État de navigation principal
  const [navigation, setNavigation] = useState<NavigationState>({
    currentLevel: "entity",
    currentItem: null,
    breadcrumb: [],
    history: [],
  });

  const orderedEnvironments = [
    "Production",
    "Préproduction",
    "Recette",
    "Développement",
    "Technique",
    "POC",
    "Intégration",
    "Formation",
    "Sans environnement",
  ];

  // Données originales conservées
  const [globalLoading, setGlobalLoading] = useState(false);
  const [entities, setEntities] = useState<Entity[]>([]);
  const [loadedData, setLoadedData] = useState<Map<string, any[]>>(new Map());
  const [loading, setLoading] = useState<Set<string>>(new Set());
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [_errors, setErrors] = useState<Map<string, string>>(new Map());
  const [hardwareData, setHardwareData] = useState<Map<string, Map<string, any>>>(new Map());
  const [hardwareLoading, setHardwareLoading] = useState<Set<string>>(new Set());

  //  ÉTATS POUR CaaS - AJOUTEZ CES LIGNES
  const [caasData, setCaasData] = useState<Map<string, Map<string, any>>>(new Map());
  const [caasLoading, setCaasLoading] = useState<Set<string>>(new Set());

  const [powerData, setPowerData] = useState<Map<string, Map<string, any>>>(new Map());
  const [powerLoading, setPowerLoading] = useState<Set<string>>(new Set());

  //  État pour suivre le chargement complet du niveau actuel
  const [currentLevelReady, setCurrentLevelReady] = useState(false);

  const [showRoleDetails, setShowRoleDetails] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  // Onglets pour les environnements
  const [environmentTabs, setEnvironmentTabs] = useState<Map<string, number>>(
    new Map(),
  );

  const [solutionViewTab, setSolutionViewTab] = useState<Map<string, number>>(
    new Map(),
  ); // 0: namespaces, 1: serveurs

  const [selectedPodEnvironments, setSelectedPodEnvironments] = useState<
    Map<string, string>
  >(new Map());

  // Données actuelles à afficher
  const [currentData, setCurrentData] = useState<any[]>([]);

  interface Entity {
    id: string;
    name: string;
    [key: string]: any;
  }



  // Fonction utilitaire pour récupérer les données CaaS d'un item spécifique
  const getCaasDataForItem = (scope: string, itemName: string) => {
    const caasKey = `${scope}-level-caas`;
    const levelCaasData = caasData.get(caasKey);

    if (!levelCaasData || !(levelCaasData instanceof Map)) {
      return null;
    }

    // 1. Chercher par nom exact d'abord
    let itemData = levelCaasData.get(itemName);
    if (itemData) {
      return itemData;
    }

    // 2. Nettoyer le nom pour retirer les acronymes et espaces supplémentaires
    const cleanName = (name: string) => {
      return name
        .toLowerCase()
        .replace(/\(.*?\)/g, '') // Supprimer les parenthèses et leur contenu
        .replace(/[^\w\s]/g, ' ') // Remplacer les caractères spéciaux par des espaces
        .replace(/\s+/g, ' ') // Supprimer les espaces multiples
        .trim();
    };

    const cleanedItemName = cleanName(itemName);

    // 3. Chercher avec correspondance exacte du nom nettoyé
    for (const [caasName, caasData] of levelCaasData.entries()) {
      const cleanedCaasName = cleanName(caasName);
      if (cleanedCaasName === cleanedItemName) {
        console.log(`✅ Correspondance exacte trouvée: "${caasName}" -> "${itemName}"`);
        return caasData;
      }
    }

    // 4. Pour les entités, vérifier si l'itemName fait partie des noms CaaS
    if (scope === 'entities') {
      for (const [caasName, caasData] of levelCaasData.entries()) {
        const cleanedCaasName = cleanName(caasName);
        const itemNameParts = cleanedItemName.split(' ');

        // Vérifier si tous les mots de l'item sont dans le nom CaaS
        const allWordsMatch = itemNameParts.every(part =>
          cleanedCaasName.includes(part)
        );

        if (allWordsMatch && itemNameParts.length > 0) {
          console.log(`✅ Correspondance partielle pour entité: "${caasName}" -> "${itemName}"`);
          return caasData;
        }
      }
    }

    console.log(`❌ Aucune correspondance CaaS trouvée pour: "${itemName}"`);
    return null;
  };

  // Fonction pour formater les ressources CaaS (CPU en millicores, RAM en Mio)
  const formatCaasResource = (value: string | number, type: 'cpu' | 'ram' | 'cpu-request' | 'ram-request') => {
    if (value === null || value === undefined) return "0";

    const normalized = typeof value === 'string' ? value.replace(',', '.') : String(value);
    const numValue = parseFloat(normalized);

    if (!Number.isFinite(numValue)) return "0";

    const fmt = (n: number, decimals = 1) => {
      const s = n.toFixed(decimals);
      return s.endsWith('.0') ? s.slice(0, -2) : s;
    };

    switch (type) {
      case 'cpu':
      case 'cpu-request':
        // Convertir les millicores en cores
        if (numValue >= 1000) {
          return `${fmt(numValue / 1000)} cores`;
        } else {
          return `${fmt(numValue)} millicores`;
        }

      case 'ram':
      case 'ram-request':
        // Convertir les Mio en Gio
        if (numValue >= 1024) {
          return `${fmt(numValue / 1024)} Gio`;
        } else {
          return `${fmt(numValue)} Mio`;
        }

      default:
        return `${numValue}`;
    }
  };

  // Fonction CORRIGÉE pour récupérer les données CaaS avec gestion des niveaux
  const fetchCaasDataForLevel = async (scope: string) => {
    const caasKey = `${scope}-level-caas`;

    if (caasData.has(caasKey) || caasLoading.has(caasKey)) {
      return caasData.get(caasKey) || new Map();
    }

    setCaasLoading((prev: Set<string>) => new Set(prev).add(caasKey));

    try {
      console.log(`☸️ Envoi requête CaaS pour scope: ${scope}`);

      const response = await fetchWithAuth(hardware_info_openshift_info(), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ scope: scope }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      console.log('📦 Réponse CaaS complète:', data);

      // La réponse est directement le tableau
      const caasArray = Array.isArray(data) ? data : [];
      console.log('🔢 Tableau CaaS:', caasArray);

      const caasMap = new Map();

      caasArray.forEach((caasItem: any, index: number) => {
        if (!caasItem) {
          console.log(`❌ Item CaaS ${index} est null/undefined`);
          return;
        }

        console.log(`📋 Item CaaS ${index}:`, caasItem);

        // DÉTERMINER LE NOM SELON LE SCOPE
        let itemName = "";
        let totalCpu = "";
        let totalRam = "";
        let requestCpu = "";
        let requestRam = "";

        switch (scope) {
          case 'entities':
            itemName = caasItem.entity_name || "";
            totalCpu = caasItem.total_cpu_m || "0";
            totalRam = caasItem.total_ram_mi || "0";
            requestCpu = caasItem.total_request_cpu_m || "0";
            requestRam = caasItem.total_request_ram_mi || "0";
            break;
          case 'poles':
            itemName = caasItem.pole_name || "";
            totalCpu = caasItem.total_cpu_m || "0";
            totalRam = caasItem.total_ram_mi || "0";
            requestCpu = caasItem.total_request_cpu_m || "0";
            requestRam = caasItem.total_request_ram_mi || "0";
            break;
          case 'domains':
            itemName = caasItem.domain_name || "";
            totalCpu = caasItem.total_cpu_m || "0";
            totalRam = caasItem.total_ram_mi || "0";
            requestCpu = caasItem.total_request_cpu_m || "0";
            requestRam = caasItem.total_request_ram_mi || "0";
            break;
          case 'solutions':
            itemName = caasItem.solution_name || "";
            totalCpu = caasItem.total_cpu_m || "0";
            totalRam = caasItem.total_ram_mi || "0";
            requestCpu = caasItem.total_request_cpu_m || "0";
            requestRam = caasItem.total_request_ram_mi || "0";
            break;
          default:
            // Fallback: chercher n'importe quelle clé contenant "name"
            const nameKey = Object.keys(caasItem).find(key =>
              key.includes('name') && caasItem[key] !== undefined
            );
            itemName = nameKey ? caasItem[nameKey] : "";
            totalCpu = caasItem.total_cpu_m || "0";
            totalRam = caasItem.total_ram_mi || "0";
            requestCpu = caasItem.total_request_cpu_m || "0";
            requestRam = caasItem.total_request_ram_mi || "0";
        }

        console.log(`🏷️ Nom de l'item (${scope}): "${itemName}"`);
        console.log(`⚡ CPU total: "${totalCpu}"`);
        console.log(`💾 RAM total: "${totalRam}"`);
        console.log(`🔵 CPU request: "${requestCpu}"`);
        console.log(`🟢 RAM request: "${requestRam}"`);

        if (itemName && itemName !== "undefined" && itemName.trim() !== "") {
          // ASSUREZ-VOUS QUE LES VALEURS NE SONT PAS VIDES
          const cpuValue = totalCpu?.toString().trim() || "0";
          const ramValue = totalRam?.toString().trim() || "0";
          const cpuRequestValue = requestCpu?.toString().trim() || "0";
          const ramRequestValue = requestRam?.toString().trim() || "0";

          console.log(`💾 Stockage: ${itemName} -> CPU: ${cpuValue}, RAM: ${ramValue}, CPU Request: ${cpuRequestValue}, RAM Request: ${ramRequestValue}`);

          caasMap.set(itemName, {
            total_cpu_m: cpuValue,
            total_ram_mi: ramValue,
            total_request_cpu_m: cpuRequestValue,
            total_request_ram_mi: ramRequestValue
          });
        } else {
          console.log(`❌ Nom invalide: "${itemName}"`);
        }
      });

      console.log('🗂️ Map CaaS finale:', Array.from(caasMap.entries()));

      setCaasData((prev: Map<string, Map<string, any>>) => {
        const newMap = new Map(prev);
        newMap.set(caasKey, caasMap);
        return newMap;
      });

      return caasMap;
    } catch (error) {
      console.error(`❌ Erreur CaaS pour le niveau ${scope}:`, error);
      return new Map();
    } finally {
      setCaasLoading((prev: Set<string>) => {
        const newSet = new Set(prev);
        newSet.delete(caasKey);
        return newSet;
      });
    }
  };

  // Fonction pour vérifier si le chargement CaaS est en cours pour un niveau
  const isCaasLoadingForLevel = (scope: string) => {
    return caasLoading.has(`${scope}-level-caas`);
  };



  // 1. Fonction pour récupérer les données hardware pour TOUT le niveau
  const fetchHardwareDataForLevel = async (scope: string) => {
    const hardwareKey = `${scope}-level`;

    if (hardwareData.has(hardwareKey) || hardwareLoading.has(hardwareKey)) {
      return hardwareData.get(hardwareKey) || new Map();
    }

    setHardwareLoading(prev => new Set(prev).add(hardwareKey));

    try {
      console.log(`🔧 Envoi requête hardware pour scope: ${scope}`);

      const response = await fetchWithAuth(hardware_info_x86_info(), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ scope: scope }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      // La réponse est directement le tableau
      const hardwareArray = Array.isArray(data) ? data : [];

      const hardwareMap = new Map();

      hardwareArray.forEach((hwItem: any) => {
        if (!hwItem) return;

        // DÉTERMINER LE NOM SELON LE SCOPE
        let itemName = "";

        switch (scope) {
          case 'entities':
            itemName = hwItem.entity_name;
            break;
          case 'poles':
            itemName = hwItem.pole_name; // ← CORRECTION ICI
            break;
          case 'domains':
            itemName = hwItem.domain_name; // ← CORRECTION ICI  
            break;
          case 'solutions':
            itemName = hwItem.solution_name; // ← CORRECTION ICI
            break;
          default:
            // Fallback: chercher n'importe quelle clé contenant "name"
            const nameKey = Object.keys(hwItem).find(key =>
              key.includes('name') && hwItem[key] !== undefined
            );
            itemName = nameKey ? hwItem[nameKey] : "";
        }

        if (itemName && itemName !== "undefined" && itemName.trim() !== "") {
          hardwareMap.set(itemName, {
            total_cpu: hwItem.total_cpu || "0",
            total_ram: hwItem.total_ram || "0",
            total_disk: hwItem.total_disk || "0",
            total_ram_gib: hwItem.total_ram || "0",
            total_disk_gib: hwItem.total_disk || "0"
          });
        }
      });

      setHardwareData(prev => {
        const newMap = new Map(prev);
        newMap.set(hardwareKey, hardwareMap);
        return newMap;
      });

      return hardwareMap;
    } catch (error) {
      console.error(`❌ Erreur hardware pour le niveau ${scope}:`, error);
      return new Map();
    } finally {
      setHardwareLoading(prev => {
        const newSet = new Set(prev);
        newSet.delete(hardwareKey);
        return newSet;
      });
    }
  };

  // 2. Fonction pour convertir le niveau en scope (garder celle existante)
  const getScopeFromLevel = (level: string): string => {
    switch (level) {
      case 'entity': return 'entities';
      case 'pole': return 'poles';
      case 'domain': return 'domains';
      case 'solution': return 'solutions';
      default: return '';
    }
  };

  // 3. Fonction utilitaire pour récupérer les données hardware d'un item spécifique
  const getHardwareDataForItem = (scope: string, itemName: string) => {
    const hardwareKey = `${scope}-level`;
    const levelHardwareData = hardwareData.get(hardwareKey);

    if (!levelHardwareData || !(levelHardwareData instanceof Map)) {
      return null;
    }

    // Chercher par nom exact d'abord
    let itemData = levelHardwareData.get(itemName);
    if (itemData) {
      return itemData;
    }

    // Si pas trouvé, essayer de nettoyer le nom
    const cleanName = (name: string) => {
      return name
        .replace(/\(.*?\)/g, '') // Supprimer les parenthèses et leur contenu
        .replace(/\s+/g, ' ')
        .trim();
    };

    const cleanedItemName = cleanName(itemName);

    // Chercher avec le nom nettoyé
    for (const [hwName, hwData] of levelHardwareData.entries()) {
      const cleanedHwName = cleanName(hwName);
      if (cleanedHwName === cleanedItemName) {
        return hwData;
      }
    }

    // Chercher par inclusion
    for (const [hwName, hwData] of levelHardwareData.entries()) {
      const cleanedHwName = cleanName(hwName);
      if (cleanedHwName.includes(cleanedItemName) || cleanedItemName.includes(cleanedHwName)) {
        return hwData;
      }
    }
    return null;
  };

  // 4. Fonction pour vérifier si le chargement hardware est en cours pour un niveau
  const isHardwareLoadingForLevel = (scope: string) => {
    return hardwareLoading.has(`${scope}-level`);
  };


  // 3. useEffect pour charger les données hardware par NIVEAU et gérer l'état ready
  useEffect(() => {
    const loadAllDataForCurrentLevel = async () => {
      if (!currentData.length) {
        setCurrentLevelReady(true);
        return;
      }

      const scope = getScopeFromLevel(navigation.currentLevel);
      if (!scope) {
        setCurrentLevelReady(true);
        return;
      }

      // Marquer que le niveau n'est pas encore prêt
      setCurrentLevelReady(false);

      try {
        // Charger les données hardware, CaaS et Power en parallèle
        const [hardwareMap, caasMap, powerMap] = await Promise.all([
          fetchHardwareDataForLevel(scope),
          fetchCaasDataForLevel(scope),
          fetchPowerDataForLevel(scope)
        ]);

        console.log('=== RÉSULTAT HARDWARE ===');
        console.log('Noms dans la réponse API hardware:', Array.from(hardwareMap.keys()));

        console.log('=== RÉSULTAT CaaS ===');
        console.log('Noms dans la réponse API CaaS:', Array.from(caasMap.keys()));

        console.log('=== RÉSULTAT POWER ===');
        console.log('Noms dans la réponse API Power:', Array.from(powerMap.keys()));

        // Vérifier la correspondance pour chaque item
        currentData.forEach(item => {
          const itemName = item.name || item[`${navigation.currentLevel}_name`] || item.entity_name || "Default";
          const hardwareData = getHardwareDataForItem(scope, itemName);
          const caasData = getCaasDataForItem(scope, itemName);
          const powerData = getPowerDataForItem(scope, itemName);

          console.log(`Item: "${itemName}" -> Hardware trouvé: ${!!hardwareData}, CaaS trouvé: ${!!caasData}, Power trouvé: ${!!powerData}`);
        });

        // Une fois terminé, marquer le niveau comme prêt
        setCurrentLevelReady(true);

      } catch (error) {
        console.error('Erreur lors du chargement des données:', error);
        setCurrentLevelReady(true);
      }
    };

    setCurrentLevelReady(false);
    loadAllDataForCurrentLevel();
  }, [currentData, navigation.currentLevel]);

  // Fonction pour récupérer les données Power pour TOUT le niveau
  const fetchPowerDataForLevel = async (scope: string) => {
    const powerKey = `${scope}-level-power`;

    if (powerData.has(powerKey) || powerLoading.has(powerKey)) {
      return powerData.get(powerKey) || new Map();
    }

    setPowerLoading(prev => new Set(prev).add(powerKey));

    try {
      console.log(`🔋 Envoi requête Power pour scope: ${scope}`);

      const response = await fetchWithAuth(hardware_info_power_info(), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ scope: scope }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      // La réponse est directement le tableau
      const powerArray = Array.isArray(data) ? data : [];

      const powerMap = new Map();

      powerArray.forEach((powerItem: any) => {
        if (!powerItem) return;

        // DÉTERMINER LE NOM SELON LE SCOPE
        let itemName = "";

        switch (scope) {
          case 'entities':
            itemName = powerItem.entity_name;
            break;
          case 'poles':
            itemName = powerItem.pole_name;
            break;
          case 'domains':
            itemName = powerItem.domain_name;
            break;
          case 'solutions':
            itemName = powerItem.solution_name;
            break;
          default:
            // Fallback: chercher n'importe quelle clé contenant "name"
            const nameKey = Object.keys(powerItem).find(key =>
              key.includes('name') && powerItem[key] !== undefined
            );
            itemName = nameKey ? powerItem[nameKey] : "";
        }

        if (itemName && itemName !== "undefined" && itemName.trim() !== "") {
          // Stocker les données Power avec les mêmes clés que x86 pour la compatibilité
          powerMap.set(itemName, {
            total_cpu: powerItem.cpu_limit_total || "0",
            total_ram: powerItem.total_ram || "0",
            total_disk: "0", // Power n'a peut-être pas de disque
            total_ram_gib: powerItem.total_ram || "0",
            total_disk_gib: "0",
            cpu_request_total: powerItem.cpu_request_total || "0"
          });
        }
      });

      setPowerData(prev => {
        const newMap = new Map(prev);
        newMap.set(powerKey, powerMap);
        return newMap;
      });

      return powerMap;
    } catch (error) {
      console.error(`❌ Erreur Power pour le niveau ${scope}:`, error);
      return new Map();
    } finally {
      setPowerLoading(prev => {
        const newSet = new Set(prev);
        newSet.delete(powerKey);
        return newSet;
      });
    }
  };

  // Fonction utilitaire pour récupérer les données Power d'un item spécifique
  const getPowerDataForItem = (scope: string, itemName: string) => {
    const powerKey = `${scope}-level-power`;
    const levelPowerData = powerData.get(powerKey);

    if (!levelPowerData || !(levelPowerData instanceof Map)) {
      return null;
    }

    // Chercher par nom exact d'abord
    let itemData = levelPowerData.get(itemName);
    if (itemData) {
      return itemData;
    }

    // Si pas trouvé, essayer de nettoyer le nom
    const cleanName = (name: string) => {
      return name
        .replace(/\(.*?\)/g, '') // Supprimer les parenthèses et leur contenu
        .replace(/\s+/g, ' ')
        .trim();
    };

    const cleanedItemName = cleanName(itemName);

    // Chercher avec le nom nettoyé
    for (const [powerName, powerDataItem] of levelPowerData.entries()) {
      const cleanedPowerName = cleanName(powerName);
      if (cleanedPowerName === cleanedItemName) {
        return powerDataItem;
      }
    }

    // Chercher par inclusion
    for (const [powerName, powerDataItem] of levelPowerData.entries()) {
      const cleanedPowerName = cleanName(powerName);
      if (cleanedPowerName.includes(cleanedItemName) || cleanedItemName.includes(cleanedPowerName)) {
        return powerDataItem;
      }
    }
    return null;
  };

  // Fonction pour vérifier si le chargement Power est en cours pour un niveau
  const isPowerLoadingForLevel = (scope: string) => {
    return powerLoading.has(`${scope}-level-power`);
  };



  const fetchEntities = async () => {
    setLoading((prev) => new Set(prev).add("entities"));
    try {
      const response = await fetchWithAuth(getTopologyRootApiUrl());
      if (!response.ok) throw new Error("Failed to fetch entities");
      const data: Entity[] = await response.json();
      setEntities(data);
      setCurrentData(data);
    } catch (error) {
      setErrors((prev) =>
        new Map(prev).set("entities", "Erreur lors du chargement des entités"),
      );
    } finally {
      setLoading((prev) => {
        const newSet = new Set(prev);
        newSet.delete("entities");
        return newSet;
      });
    }
  };

  useEffect(() => {
    fetchEntities();
  }, []);

  const fetchChildData = async (url: string, key: string) => {
    if (loadedData.has(key)) return loadedData.get(key);

    setLoading((prev) => new Set(prev).add(key));
    try {
      const response = await fetchWithAuth(url);
      if (!response.ok) throw new Error(`Failed to fetch ${key}`);
      const data = await response.json();

      const normalizedData = Array.isArray(data) ? data : [];
      setLoadedData((prev) => new Map(prev).set(key, normalizedData));
      return normalizedData;
    } catch (error) {
      setErrors((prev) =>
        new Map(prev).set(key, `Erreur lors du chargement de ${key}`),
      );
      return [];
    } finally {
      setLoading((prev) => {
        const newSet = new Set(prev);
        newSet.delete(key);
        return newSet;
      });
    }
  };

  // Fonction améliorée pour la navigation globale
  const fetchGlobalData = async (
    type: "entities" | "poles" | "domains" | "solutions",
  ) => {
    setGlobalLoading(true);
    setCurrentLevelReady(false); //  Réinitialiser l'état ready
    setLoading((prev) => new Set(prev).add(type));

    try {
      const response = await fetchWithAuth(getAllTopology(type));
      if (!response.ok) throw new Error(`Failed to fetch ${type}`);
      const data = await response.json();

      // Nettoyer COMPLÈTEMENT le cache et l'état
      setLoadedData(new Map());

      // Reset COMPLET de la navigation
      setNavigation({
        currentLevel: type.slice(0, -1) as NavigationState["currentLevel"],
        currentItem: null,
        breadcrumb: [],
        history: [],
      });

      // Réinitialiser TOUS les états
      setCurrentData(data);
      setSearchTerm("");
      setEnvironmentTabs(new Map());
      setSolutionViewTab(new Map());
      setSelectedPodEnvironments(new Map());

      // L'état currentLevelReady sera mis à jour par le useEffect

    } catch (error) {
      setErrors((prev) =>
        new Map(prev).set(type, `Erreur lors du chargement de ${type}`),
      );
    } finally {
      setGlobalLoading(false);
      setLoading((prev) => {
        const newSet = new Set(prev);
        newSet.delete(type);
        return newSet;
      });
    }
  };

  // Navigation vers un niveau enfant
  const navigateToChild = async (item: any, level: string) => {
    setGlobalLoading(true);
    setCurrentLevelReady(false);

    const newBreadcrumbItem: BreadcrumbItem = {
      name: getFormattedName(item, level),
      level: level as any,
      data: item,
      elementId: `${level}-${item[`${level}_id`] || item.id}`,
    };

    // IMPORTANT: Sauvegarder l'état COMPLET actuel dans l'historique AVANT de changer
    const historyItem = {
      level: navigation.currentLevel,
      item: navigation.currentItem,
      data: [...currentData], // Clone complet des données actuelles
      searchTerm: searchTerm, // Sauvegarder le terme de recherche
      environmentTabs: new Map(environmentTabs), // Clone des onglets
      solutionViewTab: new Map(solutionViewTab),
    };

    let childData: any[] = [];
    let nextLevel: NavigationState["currentLevel"];

    try {
      // Nettoyer les données en cache si on change d'élément au même niveau
      if (navigation.currentItem && navigation.currentItem.id !== item.id) {
        const keysToRemove: string[] = [];
        loadedData.forEach((_, key) => {
          if (
            key.includes(`${level}-${navigation.currentItem.id}`) ||
            key.includes(`${level}-${navigation.currentItem[`${level}_id`]}`)
          ) {
            keysToRemove.push(key);
          }
        });
        keysToRemove.forEach((key) => {
          setLoadedData((prev) => {
            const newMap = new Map(prev);
            newMap.delete(key);
            return newMap;
          });
        });
      }

      if (level === "entity" && item.child) {
        const childKey = `entity-${item.entity_id}-poles`;
        childData = (await fetchChildData(item.child, childKey)) || [];
        nextLevel = "pole";
      } else if (level === "pole" && item.child) {
        const childKey = `pole-${item.pole_id}-domains`;
        childData = (await fetchChildData(item.child, childKey)) || [];
        nextLevel = "domain";
      } else if (level === "domain" && item.child) {
        const childKey = `domain-${item.domain_id}-solutions`;
        childData = (await fetchChildData(item.child, childKey)) || [];
        nextLevel = "solution";
      } else if (level === "solution") {
        childData = [item];
        nextLevel = "solutionDetail";

        // Pré-charger les données de la solution
        if (item.child_pods) {
          const podsKey = `solution-${item.id}-pods`;
          await fetchChildData(item.child_pods, podsKey);
        }

        if (item.child_servers && item.child_servers.length > 0) {
          for (const serverEnv of item.child_servers) {
            const env = Object.keys(serverEnv)[0];
            const serverUrl = serverEnv[env];
            if (serverUrl) {
              const serverKey = `solution-${item.id}-servers-${env}`;
              await fetchChildData(serverUrl, serverKey);
            }
          }
        }

        if (item.child_admins) {
          const adminsKey = `solution-${item.id}-admins`;
          await fetchChildData(item.child_admins, adminsKey);
        }
      } else {
        return;
      }

      // Mettre à jour la navigation avec l'historique sauvegardé
      setNavigation((prev) => ({
        currentLevel: nextLevel,
        currentItem: item,
        breadcrumb: [...prev.breadcrumb, newBreadcrumbItem],
        history: [...prev.history, historyItem],
      }));

      setCurrentData(childData);
      setSearchTerm("");
    } finally {
      setGlobalLoading(false);
    }
  };

  // Navigation vers un niveau parent via breadcrumb
  const navigateToBreadcrumb = async (index: number) => {
    setGlobalLoading(true);
    setCurrentLevelReady(false);

    try {
      if (index === -1) {
        // Retour à l'accueil - nettoyer tout
        setLoadedData(new Map());
        setNavigation({
          currentLevel: "entity",
          currentItem: null,
          breadcrumb: [],
          history: [],
        });
        setCurrentData(entities);
        setSearchTerm("");
        setEnvironmentTabs(new Map());
        setSolutionViewTab(new Map());
        setSelectedPodEnvironments(new Map());
      } else {
        const targetBreadcrumb = navigation.breadcrumb[index];

        if (targetBreadcrumb && targetBreadcrumb.data) {
          const targetItem = targetBreadcrumb.data;
          const targetLevel = targetBreadcrumb.level;

          // Nettoyer le cache des niveaux plus profonds
          const currentDepth = navigation.breadcrumb.length;
          const targetDepth = index + 1;

          if (targetDepth < currentDepth) {
            const keysToRemove: string[] = [];
            loadedData.forEach((_, key) => {
              const breadcrumbsToClean =
                navigation.breadcrumb.slice(targetDepth);
              breadcrumbsToClean.forEach((breadcrumb) => {
                if (
                  key.includes(`${breadcrumb.level}-${breadcrumb.data.id}`) ||
                  key.includes(
                    `${breadcrumb.level}-${breadcrumb.data[`${breadcrumb.level}_id`]}`,
                  )
                ) {
                  keysToRemove.push(key);
                }
              });
            });
            keysToRemove.forEach((key) => {
              setLoadedData((prev) => {
                const newMap = new Map(prev);
                newMap.delete(key);
                return newMap;
              });
            });
          }

          // Charger les données enfants de l'item cliqué
          let childData: any[] = [];
          let nextLevel: NavigationState["currentLevel"];

          if (targetLevel === "entity" && targetItem.child) {
            const childKey = `entity-${targetItem.entity_id}-poles`;
            childData =
              (await fetchChildData(targetItem.child, childKey)) || [];
            nextLevel = "pole";
          } else if (targetLevel === "pole" && targetItem.child) {
            const childKey = `pole-${targetItem.pole_id}-domains`;
            childData =
              (await fetchChildData(targetItem.child, childKey)) || [];
            nextLevel = "domain";
          } else if (targetLevel === "domain" && targetItem.child) {
            const childKey = `domain-${targetItem.domain_id}-solutions`;
            childData =
              (await fetchChildData(targetItem.child, childKey)) || [];
            nextLevel = "solution";
          } else {
            // Si pas d'enfants, rester au même niveau
            childData = [targetItem];
            nextLevel = targetLevel as NavigationState["currentLevel"];
          }

          setNavigation({
            currentLevel: nextLevel,
            currentItem: targetItem,
            breadcrumb: navigation.breadcrumb.slice(0, index + 1),
            history: navigation.history.slice(0, index + 1),
          });

          setCurrentData(childData);
          setSearchTerm("");
          setEnvironmentTabs(new Map());
          setSolutionViewTab(new Map());
          setSelectedPodEnvironments(new Map());
        }
      }
    } finally {
      setGlobalLoading(false);
    }
  };

  const GlobalLoadingSpinner = () => {
    if (!globalLoading) return null;

    return (
      <Box
        sx={{
          position: "fixed",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          backgroundColor: "rgba(255, 255, 255, 0.8)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          zIndex: 9999,
          flexDirection: "column",
          gap: 2,
        }}
      >
        <CircularProgress
          size={60}
          sx={{
            color:
              colors[navigation.currentLevel as keyof typeof colors] ||
              colors.entity,
          }}
        />
        <Typography
          variant="h6"
          sx={{
            color:
              colors[navigation.currentLevel as keyof typeof colors] ||
              colors.entity,
            fontWeight: 600,
          }}
        >
          Chargement en cours...
        </Typography>
      </Box>
    );
  };

  const getLevelIcon = (level: string): ReactElement => {
    const iconMap: Record<string, ReactElement> = {
      entity: <Business />,
      pole: <AccountTree />,
      domain: <TbBuildingBank />,
      solution: <Apps />,
      namespace: <VscSymbolNamespace />,
      deployment: <LuRocket />,
      server: <FiServer />,
      pod: <PiCubeBold />,
    };
    return iconMap[level] || <Business />;
  };

  const getLevelColor = (level: string) => {
    return colors[level as keyof typeof colors] || modernTheme.primary;
  };

  const getLevelDarkColor = (level: string) => {
    return darkColors[level as keyof typeof darkColors] || modernTheme.primary;
  };

  // Composant pour les boutons de navigation globale
  const GlobalNavButtons = () => (
    <Paper
      elevation={0}
      sx={{
        background: `linear-gradient(135deg, ${pastelTheme.surface} 0%, ${pastelTheme.surface} 100%)`,
        borderBottom: `2px solid ${pastelTheme.outline}`,
        py: 2,
        px: 3,
        boxShadow: `0 2px 8px ${pastelTheme.shadow}`,
        borderRadius: 0,
      }}
    >
      <Stack
        direction="row"
        spacing={2}
        justifyContent="center"
        flexWrap="wrap"
      >
        <Button
          variant="contained"
          startIcon={<Apps />}
          onClick={() => navigateToBreadcrumb(-1)}
          // ... autres props
          sx={{
            backgroundColor: colors.entity,
            color: pastelTheme.textPrimary,
            fontWeight: 700,
            borderRadius: 3,
            px: 3,
            py: 1,
            "&:hover": {
              backgroundColor: darkColors.entity,
            },
          }}
        >
          Toutes les Entités
        </Button>

        <Button
          variant="contained"
          startIcon={<AccountTree />}
          onClick={() => fetchGlobalData("poles")}
          sx={{
            backgroundColor: colors.pole,
            color: pastelTheme.textPrimary,
            fontWeight: 700,
            borderRadius: 3,
            px: 3,
            py: 1,
            "&:hover": {
              backgroundColor: darkColors.pole,
            },
          }}
        >
          Tous les Pôles
        </Button>
        <Button
          variant="contained"
          startIcon={<TbBuildingBank />}
          onClick={() => fetchGlobalData("domains")}
          sx={{
            backgroundColor: colors.domain,
            color: pastelTheme.textPrimary,
            fontWeight: 700,
            borderRadius: 3,
            px: 3,
            py: 1,
            "&:hover": {
              backgroundColor: darkColors.domain,
            },
          }}
        >
          Tous les Domaines
        </Button>
        <Button
          variant="contained"
          startIcon={<Apps />}
          onClick={() => fetchGlobalData("solutions")}
          sx={{
            backgroundColor: colors.solution,
            color: pastelTheme.textPrimary,
            fontWeight: 700,
            borderRadius: 3,
            px: 3,
            py: 1,
            "&:hover": {
              backgroundColor: darkColors.solution,
            },
          }}
        >
          Toutes les Solutions
        </Button>
      </Stack>
    </Paper>
  );

  // Composant pour la barre de navigation sticky avec les stats
  const StatsNavBar = () => {
    const currentStats = navigation.currentItem || {};
    const currentLevelColor = getLevelColor(navigation.currentLevel);
    const [isVisible, setIsVisible] = useState(true);
    const [showAdmins, setShowAdmins] = useState(false);

    // Colonne 1 : Organisation
    const orgStats = [];
    if (currentStats.count_poles !== undefined)
      orgStats.push({
        label: "Pôles",
        value: currentStats.count_poles,
        icon: <AccountTree />,
      });
    if (currentStats.count_domains !== undefined)
      orgStats.push({
        label: "Domaines",
        value: currentStats.count_domains,
        icon: <TbBuildingBank />,
      });
    if (currentStats.count_solutions !== undefined)
      orgStats.push({
        label: "Solutions",
        value: currentStats.count_solutions,
        icon: <Apps />,
      });

    // Colonne 2 : Infrastructure
    const infraStats = [];
    if (currentStats.count_servers !== undefined)
      infraStats.push({
        label: "Serveurs",
        value: currentStats.count_servers,
        icon: <FiServer />,
      });
    if (currentStats.count_namespaces !== undefined)
      infraStats.push({
        label: "Namespaces",
        value: currentStats.count_namespaces,
        icon: <VscSymbolNamespace />,
      });
    if (currentStats.count_deployments !== undefined)
      infraStats.push({
        label: "Déploiements",
        value: currentStats.count_deployments,
        icon: <LuRocket />,
      });
    if (currentStats.count_pods !== undefined)
      infraStats.push({
        label: "Pods",
        value: currentStats.count_pods,
        icon: <PiCubeBold />,
      });

    // Colonne 3 : Administration
    const adminStats = [];
    if (currentStats.count_technical_admins !== undefined)
      adminStats.push({
        label: "Admins Techniques",
        value: currentStats.count_technical_admins,
        icon: <MdAdminPanelSettings />,
      });
    if (currentStats.count_functional_admins !== undefined)
      adminStats.push({
        label: "Admins Fonctionnels",
        value: currentStats.count_functional_admins,
        icon: <MdOutlineAdminPanelSettings />,
      });
    if (currentStats.count_tams !== undefined)
      adminStats.push({
        label: "TAMs",
        value: currentStats.count_tams,
        icon: <Person />,
      });
    if (currentStats.count_prod_architects !== undefined)
      adminStats.push({
        label: "Architecte De Production",
        value: currentStats.count_prod_architects,
        icon: <FaNetworkWired />,
      });
    if (currentStats.count_dsa_architects !== undefined)
      adminStats.push({
        label: "Architecte DSA",
        value: currentStats.count_dsa_architects,
        icon: <BiNetworkChart />,
      });

    if (
      orgStats.length === 0 &&
      infraStats.length === 0 &&
      adminStats.length === 0
    )
      return null;

    const handleAdminsClick = async () => {
      try {
        if (!currentStats.list_admins) {
          // Fetch administration data if not already loaded
          const adminsKey = `solution-${currentStats.solution_id}-admins`;
          const adminsData = await fetchChildData(
            currentStats.child_admins,
            adminsKey,
          );
          currentStats.list_admins = adminsData;
        }
        setShowAdmins(!showAdmins);
      } catch (error) {
        console.error("Erreur lors du chargement des administrateurs :", error);
      }
    };

    return (
      <>
        {/* Bouton de contrôle */}
        <Box
          sx={{
            position: "fixed",
            right: 16,
            top: 70,
            zIndex: 1100,
            display: "flex",
            gap: 1,
          }}
        >
          <IconButton
            onClick={handleAdminsClick}
            sx={{
              backgroundColor: colors.solution,
              color: "white",
              "&:hover": {
                backgroundColor: darkColors.solution,
              },
            }}
          >
            <MdAdminPanelSettings />
          </IconButton>
          <IconButton
            onClick={() => setIsVisible(!isVisible)}
            sx={{
              backgroundColor: currentLevelColor,
              color: "white",
              "&:hover": {
                backgroundColor:
                  darkColors[
                  navigation.currentLevel as keyof typeof darkColors
                  ],
              },
            }}
          >
            {isVisible ? <VisibilityOff /> : <Visibility />}
          </IconButton>
        </Box>

        {/* Barre de stats */}
        {isVisible && (
          <Box sx={{ position: "relative", zIndex: 1000, mb: 3 }}>
            <Grid container spacing={3}>
              {/* Colonne Organisation */}
              <Grid item xs={12} md={4}>
                <Box
                  sx={{
                    p: 2,
                    height: "100%",
                    borderLeft: `4px solid ${colors.entity}`,
                    bgcolor: alpha(colors.entity, 0.05),
                  }}
                >
                  <Typography
                    variant="subtitle2"
                    sx={{
                      fontWeight: 700,
                      mb: 1,
                      color: colors.entity,
                      display: "flex",
                      alignItems: "center",
                      gap: 1,
                    }}
                  >
                    <AccountTree /> Organisation
                  </Typography>

                  {/* Affichage du responsable */}
                  {currentStats.person && (
                    <Box sx={{ mb: 2 }}>
                      <Typography variant="body2">
                        <strong>TAM:</strong> {currentStats.person}
                      </Typography>
                    </Box>
                  )}

                  <Stack spacing={1}>
                    {orgStats.map((stat, index) => (
                      <Box
                        key={`org-${index}`}
                        sx={{ display: "flex", alignItems: "center", gap: 1 }}
                      >
                        {React.cloneElement(stat.icon, {
                          sx: { fontSize: 18, color: colors.entity },
                        })}
                        <Typography variant="body2" sx={{ flexGrow: 1 }}>
                          {stat.label}
                        </Typography>
                        <Chip
                          label={stat.value}
                          size="small"
                          sx={{
                            backgroundColor:
                              stat.value === 0
                                ? alpha(colors.entity, 0.3)
                                : colors.entity,
                            color: "white",
                            fontWeight: 700,
                          }}
                        />
                      </Box>
                    ))}
                  </Stack>
                </Box>
              </Grid>

              {/* Colonne Infrastructure */}
              <Grid item xs={12} md={4}>
                <Box
                  sx={{
                    p: 2,
                    height: "100%",
                    borderLeft: `4px solid ${colors.server}`,
                    bgcolor: alpha(colors.server, 0.05),
                  }}
                >
                  <Typography
                    variant="subtitle2"
                    sx={{
                      fontWeight: 700,
                      mb: 1,
                      color: colors.server,
                      display: "flex",
                      alignItems: "center",
                      gap: 1,
                    }}
                  >
                    <FiServer /> Infrastructure
                  </Typography>
                  <Stack spacing={1}>
                    {infraStats.map((stat, index) => (
                      <Box
                        key={`infra-${index}`}
                        sx={{ display: "flex", alignItems: "center", gap: 1 }}
                      >
                        {React.cloneElement(stat.icon, {
                          sx: { fontSize: 18, color: colors.server },
                        })}
                        <Typography variant="body2" sx={{ flexGrow: 1 }}>
                          {stat.label}
                        </Typography>
                        <Chip
                          label={stat.value}
                          size="small"
                          sx={{
                            backgroundColor:
                              stat.value === 0
                                ? alpha(colors.server, 0.3)
                                : colors.server,
                            color: "white",
                            fontWeight: 700,
                          }}
                        />
                      </Box>
                    ))}
                  </Stack>
                </Box>
              </Grid>

              {/* Colonne Administration */}
              <Grid item xs={12} md={4}>
                <Box
                  sx={{
                    p: 2,
                    height: "100%",
                    borderLeft: `4px solid ${colors.solution}`,
                    bgcolor: alpha(colors.solution, 0.05),
                  }}
                >
                  <Typography
                    variant="subtitle2"
                    sx={{
                      fontWeight: 700,
                      mb: 1,
                      color: colors.solution,
                      display: "flex",
                      alignItems: "center",
                      gap: 1,
                    }}
                  >
                    <MdAdminPanelSettings /> Administration
                  </Typography>
                  <Stack spacing={1}>
                    {adminStats.map((stat, index) => (
                      <Box
                        key={`admin-${index}`}
                        sx={{ display: "flex", alignItems: "center", gap: 1 }}
                      >
                        {React.cloneElement(stat.icon, {
                          sx: { fontSize: 18, color: colors.solution },
                        })}
                        <Typography variant="body2" sx={{ flexGrow: 1 }}>
                          {stat.label}
                        </Typography>
                        <Chip
                          label={stat.value}
                          size="small"
                          sx={{
                            backgroundColor:
                              stat.value === 0
                                ? alpha(colors.solution, 0.3)
                                : colors.solution,
                            color: "white",
                            fontWeight: 700,
                          }}
                          onClick={() => stat.value > 0 && handleAdminsClick()}
                        />
                      </Box>
                    ))}
                  </Stack>
                </Box>
              </Grid>
            </Grid>
          </Box>
        )}

        {/* Modal pour afficher la liste des administrateurs */}
        {showAdmins && currentStats.list_admins && (
          <Paper
            sx={{
              position: "fixed",
              top: "50%",
              left: "50%",
              transform: "translate(-50%, -50%)",
              zIndex: 1200,
              width: "80%",
              maxWidth: 800,
              maxHeight: "80vh",
              overflow: "auto",
              p: 3,
              boxShadow: 24,
              borderRadius: 3,
              backgroundColor: pastelTheme.cardBackground,
            }}
          >
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                mb: 2,
              }}
            >
              <Typography variant="h6" sx={{ color: colors.solution }}>
                Liste des Administrateurs
              </Typography>
              <IconButton onClick={() => setShowAdmins(false)}>
                <VisibilityOff />
              </IconButton>
            </Box>

            <Grid container spacing={2}>
              {/* Admins Techniques */}
              <Grid item xs={12} md={4}>
                <Paper
                  sx={{ p: 2, borderLeft: `4px solid ${colors.solution}` }}
                >
                  <Typography
                    variant="subtitle2"
                    sx={{ fontWeight: 700, mb: 1, color: colors.solution }}
                  >
                    Admins Techniques (
                    {currentStats.count_technical_admins || 0})
                  </Typography>
                  <List dense>
                    {filterValidAdmins(
                      currentStats.list_admins.technical_admins || [],
                    ).map((admin: any, index: any) => {
                      const displayName = getDisplayName(admin);
                      const email = getEmail(admin);
                      return (
                        <ListItem key={`tech-${index}`} sx={{ py: 0.5 }}>
                          <ListItemText
                            primary={displayName}
                            secondary={email}
                            primaryTypographyProps={{
                              fontSize: 14,
                              fontWeight: 600,
                            }}
                            secondaryTypographyProps={{ fontSize: 12 }}
                          />
                        </ListItem>
                      );
                    })}
                  </List>
                </Paper>
              </Grid>

              {/* Admins Fonctionnels */}
              <Grid item xs={12} md={4}>
                <Paper
                  sx={{ p: 2, borderLeft: `4px solid ${colors.solution}` }}
                >
                  <Typography
                    variant="subtitle2"
                    sx={{ fontWeight: 700, mb: 1, color: colors.solution }}
                  >
                    Admins Fonctionnels (
                    {currentStats.count_functional_admins || 0})
                  </Typography>
                  <List dense>
                    {filterValidAdmins(
                      currentStats.list_admins.functional_admins || [],
                    ).map((admin: any, index: any) => {
                      const displayName = getDisplayName(admin);
                      const email = getEmail(admin);
                      return (
                        <ListItem key={`func-${index}`} sx={{ py: 0.5 }}>
                          <ListItemText
                            primary={displayName}
                            secondary={email}
                            primaryTypographyProps={{
                              fontSize: 14,
                              fontWeight: 600,
                            }}
                            secondaryTypographyProps={{ fontSize: 12 }}
                          />
                        </ListItem>
                      );
                    })}
                  </List>
                </Paper>
              </Grid>

              {/* TAMs */}
              <Grid item xs={12} md={4}>
                <Paper
                  sx={{ p: 2, borderLeft: `4px solid ${colors.solution}` }}
                >
                  <Typography
                    variant="subtitle2"
                    sx={{ fontWeight: 700, mb: 1, color: colors.solution }}
                  >
                    Tams ({currentStats.count_tams || 0})
                  </Typography>
                  <List dense>
                    {filterValidAdmins(currentStats.list_admins.tams || []).map(
                      (admin: any, index: any) => {
                        const displayName = getDisplayName(admin);
                        const email = getEmail(admin);
                        return (
                          <ListItem key={`tam-${index}`} sx={{ py: 0.5 }}>
                            <ListItemText
                              primary={displayName}
                              secondary={email}
                              primaryTypographyProps={{
                                fontSize: 14,
                                fontWeight: 600,
                              }}
                              secondaryTypographyProps={{ fontSize: 12 }}
                            />
                          </ListItem>
                        );
                      },
                    )}
                  </List>
                </Paper>
              </Grid>

              {/* Architectes de Production */}
              <Grid item xs={12} md={6}>
                <Paper sx={{ p: 2, borderLeft: `4px solid ${colors.solution}` }}>
                  <Typography
                    variant="subtitle2"
                    sx={{ fontWeight: 700, mb: 1, color: colors.solution }}
                  >
                    Architectes de Production ({currentStats.count_prod_architects || 0})
                  </Typography>
                  <List dense>
                    {filterValidAdmins(
                      currentStats.list_admins?.prod_architects || []
                    ).map((admin: any, index: number) => {
                      const displayName = getDisplayName(admin);
                      const email = getEmail(admin);
                      return (
                        <ListItem key={`prod-arch-${index}`} sx={{ py: 0.5 }}>
                          <ListItemText
                            primary={displayName}
                            secondary={email}
                            primaryTypographyProps={{ fontSize: 14, fontWeight: 600 }}
                            secondaryTypographyProps={{ fontSize: 12 }}
                          />
                        </ListItem>
                      );
                    })}
                  </List>
                </Paper>
              </Grid>

              {/* Architectes DSA */}
              <Grid item xs={12} md={6}>
                <Paper sx={{ p: 2, borderLeft: `4px solid ${colors.solution}` }}>
                  <Typography
                    variant="subtitle2"
                    sx={{ fontWeight: 700, mb: 1, color: colors.solution }}
                  >
                    Architectes DSA ({currentStats.count_dsa_architects || 0})
                  </Typography>
                  <List dense>
                    {filterValidAdmins(
                      currentStats.list_admins?.dsa_architects || []
                    ).map((admin: any, index: number) => {
                      const displayName = getDisplayName(admin);
                      const email = getEmail(admin);
                      return (
                        <ListItem key={`dsa-arch-${index}`} sx={{ py: 0.5 }}>
                          <ListItemText
                            primary={displayName}
                            secondary={email}
                            primaryTypographyProps={{ fontSize: 14, fontWeight: 600 }}
                            secondaryTypographyProps={{ fontSize: 12 }}
                          />
                        </ListItem>
                      );
                    })}
                  </List>
                </Paper>
              </Grid>
            </Grid>
          </Paper>
        )}
      </>
    );
  };

  // Composant pour le breadcrumb
  const BreadcrumbNav = () => {
    const currentLevelColor = getLevelColor(navigation.currentLevel);

    return (
      <Paper
        elevation={0}
        sx={{
          background: `linear-gradient(135deg, ${alpha(currentLevelColor, 0.1)} 0%, ${alpha(currentLevelColor, 0.05)} 100%)`,
          borderBottom: `2px solid ${alpha(currentLevelColor, 0.3)}`,
          py: 2,
          px: 3,
          boxShadow: `0 2px 8px ${pastelTheme.shadow}`,
          borderRadius: 0,
        }}
      >
        <Stack direction="row" alignItems="center" spacing={2}>
          <IconButton
            onClick={() => navigateToBreadcrumb(-1)}
            sx={{
              backgroundColor: alpha(currentLevelColor, 0.2),
              color: currentLevelColor,
              "&:hover": {
                backgroundColor: alpha(currentLevelColor, 0.3),
              },
            }}
          >
            <Home />
          </IconButton>

          {navigation.breadcrumb.length > 0 && (
            <>
              <KeyboardArrowRight
                sx={{ color: alpha(currentLevelColor, 0.8) }}
              />

              <Breadcrumbs
                separator={
                  <NavigateNext
                    fontSize="small"
                    sx={{ color: pastelTheme.textSecondary }}
                  />
                }
                sx={{ flexGrow: 1 }}
              >
                {navigation.breadcrumb
                  .filter(
                    (item, index, self) =>
                      item &&
                      item.name &&
                      item.level &&
                      index ===
                      self.findIndex(
                        (t) => t.name === item.name && t.level === item.level,
                      ),
                  )
                  .map((item, index) => (
                    <Box
                      key={`breadcrumb-${index}-${item.level}-${item.name}`}
                      onClick={() => {
                        navigateToBreadcrumb(index);
                      }}
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        gap: 1,
                        cursor: "pointer",
                        padding: "6px 12px",
                        borderRadius: 3,
                        transition: "all 0.2s ease-in-out",
                        "&:hover": {
                          backgroundColor: alpha(
                            getLevelColor(item.level),
                            0.15,
                          ),
                        },
                      }}
                    >
                      {React.cloneElement(getLevelIcon(item.level), {
                        sx: { fontSize: 18, color: getLevelColor(item.level) },
                      })}
                      <Typography
                        variant="body2"
                        sx={{
                          fontWeight: 700,
                          color: pastelTheme.textPrimary,
                          fontSize: "14px",
                        }}
                      >
                        {item.name}
                      </Typography>
                    </Box>
                  ))}
              </Breadcrumbs>
            </>
          )}
        </Stack>
      </Paper>
    );
  };

  // Vue détaillée d'une solution
  const SolutionDetailViewWrapper = ({ solution }: { solution: any }) => (
    <SolutionDetailView
      solution={solution}
      podsData={loadedData}
      serversData={loadedData}
      environmentTabs={environmentTabs}
      setEnvironmentTabs={setEnvironmentTabs}
      selectedPodEnvironments={selectedPodEnvironments}
      setSelectedPodEnvironments={setSelectedPodEnvironments}
      solutionViewTab={solutionViewTab}
      setSolutionViewTab={setSolutionViewTab}
      showRoleDetails={showRoleDetails}
      setShowRoleDetails={setShowRoleDetails}
      loading={
        loading.has(`solution-${solution.id}-pods`) ||
        loading.has(`solution-${solution.id}-servers`)
      }
      caasData={caasData.get('solutions-level-caas') || new Map()}

    />
  );

  const ItemCard = ({
    item,
    level,
    onNavigate,
  }: {
    item: any;
    level: string;
    onNavigate: () => void;
  }) => {
    const hasChildren = item.child || item.child_namespace || item.child_servers;
    const levelColor = item.is_filliale ? pastelTheme.filliale : getLevelColor(level);
    const levelDarkColor = item.is_filliale ? "#FF8C00" : getLevelDarkColor(level);
    const cardColor = item.is_filliale
      ? alpha(levelColor, 0.3)
      : alpha(levelColor, 0.2);

    // Récupérer les données hardware depuis le cache du niveau
    const scope = getScopeFromLevel(level);
    const itemName = item.name || item[`${level}_name`] || item.entity_name || "Default";
    const hardwareDataForItem = scope ? getHardwareDataForItem(scope, itemName) : null;
    const hardwareLoadingForLevel = scope ? isHardwareLoadingForLevel(scope) : false;
    const caasDataForItem = scope ? getCaasDataForItem(scope, itemName) : null;
    const caasLoadingForLevel = scope ? isCaasLoadingForLevel(scope) : false;
    const powerDataForItem = scope ? getPowerDataForItem(scope, itemName) : null;
    const powerLoadingForLevel = scope ? isPowerLoadingForLevel(scope) : false;

    // Fonction pour formater la date
    const formatDate = (dateString: string) => {
      if (!dateString) return "—";
      try {
        const date = new Date(dateString);
        return date.toLocaleDateString("fr-FR", {
          day: "2-digit",
          month: "2-digit",
          year: "numeric",
        });
      } catch (error) {
        return "—";
      }
    };

    // Fonction pour formater les ressources hardware

    const formatResource = (value: string | number, type: 'cpu' | 'ram' | 'disk') => {
      if (value === null || value === undefined) return "0";

      const normalized = typeof value === 'string' ? value.replace(',', '.') : String(value);
      const numValue = parseFloat(normalized);
      if (!Number.isFinite(numValue)) return "0";

      const unitsDisk = ['octets', 'Ko', 'Mo', 'Go', 'To'];
      const unitsRam = ['Mo', 'Go', 'To'];

      const fmt = (n: number, decimals = 1) => {
        const s = n.toFixed(decimals);
        return s.endsWith('.0') ? s.slice(0, -2) : s;
      };

      switch (type) {
        case 'cpu':
          return `${numValue}`; // inchangé

        case 'ram': {
          // Entrée en Mo → Go → To
          let val = numValue;
          let unitIndex = 0; // Mo
          while (val >= 1024 && unitIndex < unitsRam.length - 1) {
            val = val / 1024;
            unitIndex++;
          }
          return `${fmt(val, 1)} ${unitsRam[unitIndex]}`;
        }

        case 'disk': {
          // Entrée en octets → Ko → Mo → Go → To
          let val = numValue;
          let unitIndex = 0; // octets
          while (val >= 1024 && unitIndex < unitsDisk.length - 1) {
            val = val / 1024;
            unitIndex++;
          }
          return `${fmt(val, 1)} ${unitsDisk[unitIndex]}`;
        }

        default:
          return `${numValue}`;
      }
    };


    // Fonction pour afficher les environnements
    const renderEnvironmentChips = (environments: string[]) => {
      if (!environments || !Array.isArray(environments) || environments.length === 0) {
        return (
          <Typography sx={{ fontSize: "11px", color: pastelTheme.textSecondary, mt: 1 }}>
            Aucun environnement
          </Typography>
        );
      }

      return (
        <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1, mt: 1 }}>
          {orderedEnvironments
            .filter((env) => environments.includes(env))
            .concat(
              environments.filter((env) => !orderedEnvironments.includes(env)),
            )
            .map((env, index) => (
              <Chip
                key={index}
                label={env}
                size="small"
                sx={{
                  fontSize: "11px",
                  fontWeight: 700,
                  borderRadius: 12,
                  backgroundColor: `${envColors[env as keyof typeof envColors]}CC`,
                  color: "white",
                  border: `1px solid ${alpha(envColors[env as keyof typeof envColors] || "#bb688bff", 0.5)}`,
                }}
              />
            ))}
        </Box>
      );
    };

    return (
      <Fade in timeout={300}>
        <Card
          elevation={0}
          sx={{
            height: "100%",
            display: "flex",
            flexDirection: "column",
            transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
            background: pastelTheme.cardBackground,
            border: `2px solid ${item.is_filliale ? levelDarkColor : pastelTheme.outline}`,
            borderRadius: 3,
            position: "relative",
            overflow: "hidden",
            cursor: hasChildren ? "pointer" : "default",
            boxShadow: item.is_filliale
              ? `0 8px 24px ${alpha(levelDarkColor, 0.3)}`
              : `0 8px 24px ${pastelTheme.shadow}`,
            "&:hover": hasChildren
              ? {
                transform: "translateY(-4px)",
                boxShadow: `0 8px 24px ${alpha(levelColor, 0.2)}`,
              }
              : {},
          }}
          onClick={hasChildren ? onNavigate : undefined}
        >
          {/* Bandeau de couleur - différent pour les filiales */}
          <Box
            sx={{
              height: 6,
              width: "100%",
              background: item.is_filliale
                ? `linear-gradient(90deg, ${pastelTheme.filliale}, #FF8C00)`
                : `linear-gradient(90deg, ${levelColor}, ${levelDarkColor})`,
            }}
          />

          {/* Tag Filiale */}
          {item.is_filliale && (
            <Box
              sx={{
                position: "absolute",
                top: 8,
                right: 8,
                backgroundColor: levelDarkColor,
                color: "white",
                padding: "2px 8px",
                borderRadius: 12,
                fontSize: "10px",
                fontWeight: 700,
                zIndex: 1,
              }}
            >
              Filiale
            </Box>
          )}

          <CardContent sx={{ p: 3, flexGrow: 1 }}>
            {/* En-tête avec icône et nom */}
            <Box sx={{ display: "flex", alignItems: "center", gap: 2, mb: 2 }}>
              <Box
                sx={{
                  p: 1.5,
                  borderRadius: "50%",
                  backgroundColor: cardColor,
                  color: levelDarkColor,
                  flexShrink: 0,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  border: item.is_filliale ? `2px solid ${levelDarkColor}` : "none",
                }}
              >
                {React.cloneElement(getLevelIcon(level), {
                  sx: { fontSize: 20 },
                })}
              </Box>

              <Box sx={{ flexGrow: 1, minWidth: 0 }}>
                <Typography
                  variant="h6"
                  sx={{
                    fontSize: "16px",
                    fontWeight: 800,
                    color: item.is_filliale ? levelDarkColor : pastelTheme.textPrimary,
                    mb: 0.5,
                    wordBreak: "break-word",
                  }}
                >
                  {getFormattedName(item, level)}
                </Typography>

                {["entity_manager", "pole_manager", "domain_manager"].some(
                  (key) => key in item,
                ) ? (
                  <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                    <Person sx={{ fontSize: 14, color: levelColor }} />
                    <Typography
                      variant="body2"
                      sx={{
                        fontSize: "12px",
                        color: pastelTheme.textSecondary,
                        fontWeight: 500,
                      }}
                    >
                      {item.entity_manager ||
                        item.pole_manager ||
                        item.domain_manager ||
                        "—"}
                    </Typography>
                  </Box>
                ) : null}
              </Box>
            </Box>



            {/* Dates */}
            <Box sx={{ display: "flex", gap: 1, mb: 2, flexWrap: "wrap" }}>
              <Chip
                label={`Créé: ${formatDate(item.created_at)}`}
                size="small"
                sx={{
                  fontSize: "10px",
                  backgroundColor: alpha(levelColor, 0.1),
                  color: pastelTheme.textSecondary,
                }}
              />
              <Chip
                label={`MAJ: ${formatDate(item.updated_at)}`}
                size="small"
                sx={{
                  fontSize: "10px",
                  backgroundColor: alpha(levelColor, 0.1),
                  color: pastelTheme.textSecondary,
                }}
              />
            </Box>

            {/* Responsables TAM/Admin Tech/Admin F - Toujours affiché */}
            <Box sx={{ mb: 2 }}>
              <Typography
                variant="caption"
                sx={{
                  fontWeight: 600,
                  color: pastelTheme.textSecondary,
                  display: "block",
                  mb: 0.5,
                }}
              >
                Responsables:
              </Typography>
              <Box
                sx={{
                  display: "flex",
                  gap: 1,
                  p: 1,
                  borderRadius: 2,
                  backgroundColor: alpha(levelColor, 0.05),
                  border: `1px solid ${alpha(levelColor, 0.2)}`,
                  flexWrap: "wrap",
                  alignItems: "center",
                }}
              >
                <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                  <Person sx={{ color: levelColor }} fontSize="small" />
                  <Typography sx={{ fontSize: "12px" }}>
                    TAM: {item.count_tams ?? 0}
                  </Typography>
                </Box>

                <Divider orientation="vertical" flexItem />

                <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                  <MdAdminPanelSettings size={14} color={levelColor} />
                  <Typography sx={{ fontSize: "12px" }}>
                    Admin T: {item.count_technical_admins ?? 0}
                  </Typography>
                </Box>

                <Divider orientation="vertical" flexItem />

                <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                  <MdOutlineAdminPanelSettings size={14} color={levelColor} />
                  <Typography sx={{ fontSize: "12px" }}>
                    Admin F: {item.count_functional_admins ?? 0}
                  </Typography>
                </Box>

                <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                  <FaNetworkWired size={14} color={levelColor} />
                  <Typography sx={{ fontSize: "12px" }}>
                    Architecte Prod: {item.count_prod_architects ?? 0}
                  </Typography>
                </Box>
                <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                  <BiNetworkChart size={14} color={levelColor} />
                  <Typography sx={{ fontSize: "12px" }}>
                    Architecte DSA: {item.count_dsa_architects ?? 0}
                  </Typography>
                </Box>
              </Box>
            </Box>

            {/* Pôles et Domaines - Toujours affiché */}
            {["count_solutions", "count_domains", "count_poles"].some(
              (key) => key in item,
            ) && (
                <Box sx={{ mb: 2 }}>
                  <Typography
                    variant="caption"
                    sx={{
                      fontWeight: 600,
                      color: pastelTheme.textSecondary,
                      display: "block",
                      mb: 0.5,
                    }}
                  >
                    Organisation:
                  </Typography>
                  <Box
                    sx={{
                      display: "flex",
                      gap: 1,
                      p: 1,
                      borderRadius: 2,
                      backgroundColor: alpha(levelColor, 0.05),
                      border: `1px solid ${alpha(levelColor, 0.2)}`,
                      flexWrap: "wrap",
                      alignItems: "center",
                    }}
                  >
                    {"count_poles" in item && (
                      <>
                        <Box
                          sx={{ display: "flex", alignItems: "center", gap: 0.5 }}
                        >
                          <Typography sx={{ fontSize: "12px" }}>
                            Pôles: {item.count_poles ?? 0}
                          </Typography>
                        </Box>
                        <Divider orientation="vertical" flexItem />
                      </>
                    )}

                    {"count_solutions" in item && (
                      <Box
                        sx={{ display: "flex", alignItems: "center", gap: 0.5 }}
                      >
                        <TbBuildingBank size={14} color={levelColor} />
                        <Typography sx={{ fontSize: "12px" }}>
                          {item.domain_name
                            ? item.domain_name
                            : `Domaines: ${item.count_domains ?? 0}`}
                        </Typography>
                      </Box>
                    )}
                  </Box>
                </Box>
              )}

                          {/* OpenShift Pod/Namespace/Deployment - Toujours affiché si au moins un existe */}
            {item.count_pods > 0 ||
              item.count_namespaces > 0 ||
              item.count_deployments > 0 ? (
              <Box sx={{ mb: 2, minHeight: 80 }}>
                <Typography
                  variant="caption"
                  sx={{
                    fontWeight: 600,
                    color: pastelTheme.textSecondary,
                    display: "flex",
                    alignItems: "center",
                    gap: 0.5,
                    mb: 0.5,
                  }}
                >
                  <DiOpenshift size={16} color="#EE0000" />
                  OpenShift:
                </Typography>
                <Box
                  sx={{
                    display: "flex",
                    gap: 1,
                    p: 1,
                    borderRadius: 2,
                    backgroundColor: alpha(levelColor, 0.05),
                    border: `1px solid ${alpha(levelColor, 0.2)}`,
                    flexWrap: "wrap",
                    alignItems: "center",
                  }}
                >
                  {/* Pods */}
                  {item.count_pods > 0 && (
                    <Box
                      sx={{ display: "flex", alignItems: "center", gap: 0.5 }}
                    >
                      <PiCubeBold size={14} color={colors.pod} />
                      <Typography sx={{ fontSize: "12px" }}>
                        {level === "pod"
                          ? item.pod_name || "—"
                          : `Pods: ${item.count_pods}`}
                      </Typography>
                    </Box>
                  )}

                  {item.count_namespaces > 0 && (
                    <Box
                      sx={{ display: "flex", alignItems: "center", gap: 0.5 }}
                    >
                      <VscSymbolNamespace size={14} color={colors.namespace} />
                      <Typography sx={{ fontSize: "12px" }}>
                        {item.namespace ||
                          `Namespaces: ${item.count_namespaces}`}
                      </Typography>
                    </Box>
                  )}

                  {item.count_deployments > 0 && (
                    <Box
                      sx={{ display: "flex", alignItems: "center", gap: 0.5 }}
                    >
                      <LuRocket size={14} color={colors.deployment} />
                      <Typography sx={{ fontSize: "12px" }}>
                        {item.deployment_name ||
                          `Deployments: ${item.count_deployments}`}
                      </Typography>
                    </Box>
                  )}
                </Box>
              </Box>
            ) : (
              <Box sx={{ mb: 2, minHeight: 80 }} /> // Espace réservé sans contenu
            )}

            {/* Solutions et Serveurs - Toujours affiché */}
            <Box sx={{ mb: 2 }}>
              <Box
                sx={{
                  display: "flex",
                  gap: 1,
                  p: 1,
                  borderRadius: 2,
                  backgroundColor: alpha(levelColor, 0.05),
                  border: `1px solid ${alpha(levelColor, 0.2)}`,
                  flexWrap: "wrap",
                  alignItems: "center",
                }}
              >
                {"count_solutions" in item && (
                  <>
                    <Box
                      sx={{ display: "flex", alignItems: "center", gap: 0.5 }}
                    >
                      <Typography sx={{ fontSize: "12px" }}>
                        Solutions: {item.count_solutions ?? 0}
                      </Typography>
                    </Box>
                    <Divider orientation="vertical" flexItem />
                  </>
                )}
                <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                  <FiServer size={14} color={levelColor} />
                  <Typography sx={{ fontSize: "12px" }}>
                    Serveurs: {item.count_servers ?? 0}
                  </Typography>
                </Box>
              </Box>
            </Box>

            {/* SECTION RESSOURCES HARDWARE - CORRIGÉE */}
            <Box sx={{ mb: 2 }}>
              <Typography
                variant="caption"
                sx={{
                  fontWeight: 600,
                  color: pastelTheme.textSecondary,
                  display: "block",
                  mb: 0.5,
                }}
              >
                Ressources x86:
              </Typography>
              {hardwareLoadingForLevel ? (
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "center",
                    py: 1,
                    borderRadius: 2,
                    backgroundColor: alpha(levelColor, 0.05),
                  }}
                >
                  <CircularProgress size={16} sx={{ color: levelColor }} />
                </Box>
              ) : hardwareDataForItem ? (
                <Box
                  sx={{
                    display: "flex",
                    gap: 1,
                    p: 1,
                    borderRadius: 2,
                    backgroundColor: alpha(levelColor, 0.05),
                    border: `1px solid ${alpha(levelColor, 0.2)}`,
                    flexWrap: "wrap",
                    alignItems: "center",
                  }}
                >
                  {/* CPU */}
                  <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                    <Speed sx={{ fontSize: "16px", color: "#FF6B6B" }} />
                    <Typography sx={{ fontSize: "10px", fontWeight: 600 }}>
                      {formatResource(hardwareDataForItem.total_cpu || "0", "cpu")} CPU
                    </Typography>
                  </Box>

                  <Divider orientation="vertical" flexItem />

                  {/* RAM */}
                  <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                    <Memory sx={{ fontSize: "16px", color: "#4ECDC4" }} />
                    <Typography sx={{ fontSize: "10px", fontWeight: 600 }}>
                      {formatResource(hardwareDataForItem.total_ram_gib || "0", "ram")} RAM
                    </Typography>
                  </Box>

                  <Divider orientation="vertical" flexItem />

                  {/* Stockage */}
                  <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                    <Storage sx={{ fontSize: "16px", color: "#45B7D1" }} />
                    <Typography sx={{ fontSize: "10px", fontWeight: 600 }}>
                      {formatResource(hardwareDataForItem.total_disk_gib || "0", "disk")} Storage
                    </Typography>
                  </Box>
                </Box>
              ) : (
                <Box
                  sx={{
                    p: 1,
                    borderRadius: 2,
                    backgroundColor: alpha(levelColor, 0.05),
                    border: `1px solid ${alpha(levelColor, 0.1)}`,
                    textAlign: "center",
                  }}
                >
                  <Typography sx={{ fontSize: "11px", color: pastelTheme.textSecondary }}>
                    Données non disponibles
                  </Typography>
                </Box>
              )}
            </Box>


            {/* SECTION RESSOURCES POWER (afficher uniquement s'il y a des données Power disponibles) */}

            {powerDataForItem ? (
              <Box sx={{ mb: 2 }}>
                <Typography
                  variant="caption"
                  sx={{
                    fontWeight: 600,
                    color: pastelTheme?.textSecondary ?? AIX_DARK,
                    display: "block",
                    mb: 0.5,
                  }}
                >
                  Ressources Power:
                </Typography>

                {powerLoadingForLevel ? (
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "center",
                      py: 1,
                      borderRadius: 2,
                      backgroundColor: alpha(osColors.AIX, 0.12), // léger fond AIX pendant le chargement
                      border: `1px solid ${alpha(osColors.AIX, 0.3)}`,
                    }}
                  >
                    <CircularProgress size={16} sx={{ color: AIX_DARK }} />
                  </Box>
                ) : (
                  <Box
                    sx={{
                      gap: 1,
                      p: 1,
                      borderRadius: 2,
                      backgroundColor: alpha(osColors.AIX, 0.16),     // fond principal AIX
                      border: `1px solid ${alpha(osColors.AIX, 0.35)}`, // bordure AIX
                    }}
                  >
                    {/* Ligne 1: CPU Limits */}
                    <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 1 }}>
                      <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                        <Speed style={{ fontSize: "14px", color: AIX_DARK }} />
                        <Typography sx={{ fontSize: "10px", fontWeight: 600, color: AIX_DARK }}>
                          CPU Limits:
                        </Typography>
                      </Box>
                      <Typography sx={{ fontSize: "10px", fontWeight: 700, color: AIX_DARK }}>
                        {formatResource(powerDataForItem.total_cpu || "0", "cpu")} CPU
                      </Typography>
                    </Box>

                    {/* Ligne 2: RAM - MODIFICATION ICI: type 'disk' pour octets */}
                    <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 1 }}>
                      <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                        <Memory style={{ fontSize: "14px", color: AIX_DARK }} />
                        <Typography sx={{ fontSize: "10px", fontWeight: 600, color: AIX_DARK }}>
                          RAM:
                        </Typography>
                      </Box>
                      <Typography sx={{ fontSize: "10px", fontWeight: 700, color: AIX_DARK }}>
                        {formatResource(powerDataForItem.total_ram_gib || "0", "disk")} {/* MODIFICATION: 'disk' au lieu de 'ram' */}
                      </Typography>
                    </Box>

                    <Divider sx={{ my: 1, borderColor: alpha(AIX_DARK, 0.3) }} />

                    {/* Ligne 3: CPU Requests */}
                    <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                      <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                        <Speed style={{ fontSize: "14px", color: AIX_MID }} />
                        <Typography sx={{ fontSize: "9px", fontWeight: 600, color: AIX_MID }}>
                          CPU Requests:
                        </Typography>
                      </Box>
                      <Typography sx={{ fontSize: "9px", fontWeight: 700, color: AIX_MID }}>
                        {formatResource(powerDataForItem.cpu_request_total || "0", "cpu")} CPU
                      </Typography>
                    </Box>
                  </Box>
                )}
              </Box>
            ) : (
              // Espace réservé pour conserver la place (ajustez la hauteur selon vos besoins)
              <Box sx={{ mb: 2, height: "100px" }} />
            )}




            {/* Type de solution (pour les solutions) */}
            {level === "solution" && (
              <Box sx={{ mb: 2 }}>
                <Typography
                  variant="caption"
                  sx={{ fontWeight: 600, color: pastelTheme.textSecondary }}
                >
                  Type:
                </Typography>
                <Chip
                  label={item.solution_type ?? "—"}
                  size="small"
                  sx={{
                    fontSize: "10px",
                    backgroundColor: alpha(levelColor, 0.1),
                    color: pastelTheme.textPrimary,
                    mt: 0.5,
                  }}
                />
              </Box>
            )}

            {/* SECTION RESSOURCES CaaS (afficher uniquement s'il y a des données CaaS disponibles) */}
            {(caasDataForItem && (item.count_namespaces > 0 || (item.list_environnements && item.list_environnements.length > 0))) ? (
              <Box sx={{ mb: 2 }}>
                <Typography
                  variant="caption"
                  sx={{
                    fontWeight: 600,
                    color: pastelTheme.textSecondary,
                    display: "block",
                    mb: 0.5,
                  }}
                >
                  Ressources CaaS (OpenShift):
                </Typography>
                {caasLoadingForLevel ? (
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "center",
                      py: 1,
                      borderRadius: 2,
                      backgroundColor: alpha(levelColor, 0.05),
                    }}
                  >
                    <CircularProgress size={16} sx={{ color: levelColor }} />
                  </Box>
                ) : (
                  <Box
                    sx={{
                      gap: 1,
                      p: 1,
                      borderRadius: 2,
                      backgroundColor: alpha('#EE0000', 0.05), // Rouge OpenShift
                      border: `1px solid ${alpha('#EE0000', 0.2)}`,
                    }}
                  >
                    {/* Ligne 1: CPU Limits */}
                    <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 1 }}>
                      <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                        <Speed style={{ fontSize: "14px", color: "#EE0000" }} />
                        <Typography sx={{ fontSize: "10px", fontWeight: 600 }}>
                          CPU Limits:
                        </Typography>
                      </Box>
                      <Typography sx={{ fontSize: "10px", fontWeight: 700, color: "#EE0000" }}>
                        {formatCaasResource(caasDataForItem.total_cpu_m || "0", "cpu")}
                      </Typography>
                    </Box>

                    {/* Ligne 2: RAM Limits */}
                    <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 1 }}>
                      <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                        <Memory style={{ fontSize: "14px", color: "#EE0000" }} />
                        <Typography sx={{ fontSize: "10px", fontWeight: 600 }}>
                          RAM Limits:
                        </Typography>
                      </Box>
                      <Typography sx={{ fontSize: "10px", fontWeight: 700, color: "#EE0000" }}>
                        {formatCaasResource(caasDataForItem.total_ram_mi || "0", "ram")}
                      </Typography>
                    </Box>

                    <Divider sx={{ my: 1, borderColor: alpha('#EE0000', 0.3) }} />

                    {/* Ligne 3: CPU Requests */}
                    <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 1 }}>
                      <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                        <Speed style={{ fontSize: "14px", color: "#FFA500" }} />
                        <Typography sx={{ fontSize: "9px", fontWeight: 600, color: "#FFA500" }}>
                          CPU Requests:
                        </Typography>
                      </Box>
                      <Typography sx={{ fontSize: "9px", fontWeight: 700, color: "#FFA500" }}>
                        {formatCaasResource(caasDataForItem.total_request_cpu_m || "0", "cpu-request")}
                      </Typography>
                    </Box>

                    {/* Ligne 4: RAM Requests */}
                    <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                      <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                        <Memory style={{ fontSize: "14px", color: "#FFA500" }} />
                        <Typography sx={{ fontSize: "9px", fontWeight: 600, color: "#FFA500" }}>
                          RAM Requests:
                        </Typography>
                      </Box>
                      <Typography sx={{ fontSize: "9px", fontWeight: 700, color: "#FFA500" }}>
                        {formatCaasResource(caasDataForItem.total_request_ram_mi || "0", "ram-request")}
                      </Typography>
                    </Box>

                    {/* Différence (si nécessaire) */}
                    {caasDataForItem.total_cpu_m && caasDataForItem.total_request_cpu_m &&
                      parseFloat(caasDataForItem.total_cpu_m) > parseFloat(caasDataForItem.total_request_cpu_m) && (
                        <Box sx={{ mt: 1, pt: 1, borderTop: `1px dashed ${alpha('#EE0000', 0.2)}` }}>
                          <Typography sx={{ fontSize: "8px", textAlign: "center", color: "#32CD32" }}>
                            Différence: {formatCaasResource(
                              parseFloat(caasDataForItem.total_cpu_m) - parseFloat(caasDataForItem.total_request_cpu_m),
                              "cpu"
                            )} CPU / {
                              formatCaasResource(
                                parseFloat(caasDataForItem.total_ram_mi) - parseFloat(caasDataForItem.total_request_ram_mi),
                                "ram"
                              )
                            } RAM
                          </Typography>
                        </Box>
                      )}

                    {/* Icône OpenShift */}
                    <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", mt: 1 }}>
                      <DiOpenshift style={{ fontSize: "16px", color: "#EE0000" }} />
                      <Typography sx={{ fontSize: "9px", fontWeight: 600, color: "#EE0000", ml: 0.5 }}>
                        OpenShift
                      </Typography>
                    </Box>
                  </Box>
                )}
              </Box>
            ) : (
              // Espace réservé pour conserver la place
              <Box sx={{ mb: 2, height: "120px" }} />
            )}

            {/* Environnements en bas — toujours affiché */}
            <Box sx={{ mt: "auto", pt: 2 }}>
              <Typography
                variant="caption"
                sx={{ fontWeight: 600, color: pastelTheme.textSecondary }}
              >
                Environnements:
              </Typography>
              {renderEnvironmentChips(item.list_environnements || [])}
            </Box>
          </CardContent>
          {hasChildren && (
            <Box
              sx={{
                p: 1,
                display: "flex",
                justifyContent: "flex-end",
                backgroundColor: alpha(levelColor, 0.05),
                borderTop: `1px solid ${pastelTheme.outline}`,
              }}
            >
              <KeyboardArrowRight sx={{ color: levelColor }} />
            </Box>
          )}
        </Card>
      </Fade>
    );
  };

  // Composant principal pour afficher les données
  const DataGrid = () => {
    // Filtrage et tri persistant même après clic
    const filteredData = useMemo(() => {
      const filtered = currentData.filter((item) => {
        const itemName = getFormattedName(item, navigation.currentLevel);
        const searchLower = searchTerm.toLowerCase();

        // Recherche dans le nom et l'acronyme
        return itemName.toLowerCase().includes(searchLower) ||
          (item.entity_acronym && item.entity_acronym.toLowerCase().includes(searchLower));
      });

      // Tri par nombre de serveurs décroissant
      return filtered.sort((a, b) => {
        const countA = a.count_servers || 0;
        const countB = b.count_servers || 0;
        return countB - countA; // Tri décroissant
      });
    }, [currentData, searchTerm, navigation.currentLevel]);

    //  Afficher le spinner si le niveau n'est pas prêt
    if (!currentLevelReady || (loading.has("entities") && filteredData.length === 0)) {
      return (
        <Grid container spacing={3}>
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Grid item xs={12} sm={6} md={4} key={i}>
              <Skeleton
                variant="rectangular"
                height={200}
                sx={{ borderRadius: 4 }}
              />
            </Grid>
          ))}
        </Grid>
      );
    }

    if (filteredData.length === 0) {
      return (
        <Box sx={{ textAlign: "center", py: 8 }}>
          <Typography variant="h6" color="text.secondary">
            {searchTerm
              ? "Aucun résultat trouvé"
              : "Aucune donnée disponible pour ce niveau"}
          </Typography>
        </Box>
      );
    }

    // Vue spéciale pour les solutions
    if (
      navigation?.currentLevel === "solutionDetail" &&
      navigation?.currentItem
    ) {
      return <SolutionDetailViewWrapper solution={navigation.currentItem} />;
    }

    return (
      <Slide direction="up" in timeout={400}>
        <Grid container spacing={3}>
          {filteredData?.map((item, index) => {
            return (
              <Grid item xs={12} sm={6} md={4} lg={3} key={item.id || index}>
                <ItemCard
                  item={item}
                  level={navigation.currentLevel}
                  onNavigate={() => navigateToChild(item, navigation.currentLevel)}
                />
              </Grid>
            );
          })}
        </Grid>
      </Slide>
    );
  };

  return (
    <Box sx={{ minHeight: "100vh", backgroundColor: pastelTheme.background }}>
      <GlobalLoadingSpinner /> {/*  Ajouter le spinner global */}
      <BreadcrumbNav />
      <GlobalNavButtons />
      <StatsNavBar />
      <Container maxWidth="xl" sx={{ py: 4 }}>
        {/* Barre de recherche persistante */}
        <Paper elevation={0} sx={{ p: 2, mb: 3, borderRadius: 3 }}>
          <TextField
            fullWidth
            variant="outlined"
            placeholder="Rechercher..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search />
                </InputAdornment>
              ),
            }}
          />
        </Paper>

        <DataGrid />
      </Container>
    </Box>
  );
};

export default TopologyPage;
