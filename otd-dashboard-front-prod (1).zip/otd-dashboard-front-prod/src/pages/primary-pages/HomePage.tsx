import { Typography, Container, Box } from "@mui/material";
// import { Card, CardContent, Grid } from "@mui/material";

// import { Link } from "react-router-dom";

// import FactCheckIcon from "@mui/icons-material/FactCheck";

// import DifferenceIcon from "@mui/icons-material/Category";

const HomePage = () => {
  // const features = [

  //   { path: "/signature-serveurs", title: "Signature des serveurs", icon: <FactCheckIcon fontSize="large" /> },

  //   { path: "/fiabilisation", title: "Fiabilisation", icon: <DifferenceIcon fontSize="large" /> },

  //   { path: "/certifcates", title: "Certificats", icon: <FactCheckIcon fontSize="large" /> },

  //   { path: "/self-service", title: "Self Service", icon: <FactCheckIcon fontSize="large" /> },

  // ];

  return (
    <Box
      sx={{
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        minHeight: "75vh", // prend toute la hauteur de l'écran
        textAlign: "center",
      }}
    >
      <Container maxWidth="md">
        <img
          src="/logos/KRAKEN/Kraken-logo-black.svg"
          alt="Kraken Logo"
          style={{
            width: "250px",
            height: "auto",
            marginBottom: "50px",
          }}
        />
        <Typography variant="h2" gutterBottom>
          Bienvenue sur Kraken
        </Typography>
        <Typography variant="h5" color="textSecondary" paragraph>
          Gérez vos signatures, certificats et processus de fiabilisation
          efficacement.
        </Typography>
      </Container>
    </Box>
  );
};

export default HomePage;
