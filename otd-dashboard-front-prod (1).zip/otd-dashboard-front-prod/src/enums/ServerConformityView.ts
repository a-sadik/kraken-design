export enum ServerConformityType {
  CONFORMES = "conformes",
  NON_CONFORMES = "non-conformes",
  NON_DECLARED = "non-declare",
}
