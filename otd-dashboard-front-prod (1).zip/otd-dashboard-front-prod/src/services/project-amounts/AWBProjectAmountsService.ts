// src/services/project-amounts/AWBProjectAmountsService.ts

// import files
import { ProjectAmountsResponseDTO } from "@/types/dto/response/ProjectAmountsResponseDTO";
import mockData from "@/data/project-amounts/awb.json";

export const getAWBProjectAmounts = async (): Promise<
  ProjectAmountsResponseDTO[]
> => {
  try {
    // Simuler un appel réseau avec un délai
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(mockData as ProjectAmountsResponseDTO[]);
      }, 3000);
    });
  } catch (error) {
    console.error("Error fetching AWB project money data:", error);
    throw error;
  }
};
