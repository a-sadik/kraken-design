/* eslint-disable @typescript-eslint/no-explicit-any */
import { useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Typography,
  IconButton,
  Tooltip,
  Box,
  Snackbar,
  Alert,
  CircularProgress,
} from "@mui/material";
import { Post_Decom } from "@/config/api.config";
import { HammerIcon } from "lucide-react";

interface DecomServerButtonProps {
  row: any;
  disabled?: boolean;
  tooltip?: string;
  onSuccess?: () => void;
}

export default function DecomServerButton({
  row,
  disabled = false,
  tooltip,
  onSuccess
}: DecomServerButtonProps) {
  const [open, setOpen] = useState(false);
  const [hostnameInput, setHostnameInput] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [successMessageOpen, setSuccessMessageOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  const expectedHostname = row.hostname || row.Hostname;
  const isInputValid = hostnameInput === expectedHostname;

  const handleClick = () => {
    if (disabled) return;
    setHostnameInput("");
    setError(null);
    setOpen(true);
  };

  const handleConfirm = async () => {
    if (!isInputValid) {
      setError(`Saisissez correctement : ${expectedHostname}`);
      return;
    }

    setLoading(true);

    try {
      const token = localStorage.getItem("access_token");
      if (!token) throw new Error("Token d'authentification manquant");

      const serverId = row.base_server_id || row.id;
      const apiUrl = `${Post_Decom()}${serverId}/`;

      const requestBody = {
        hostname: expectedHostname,
        ip_address: Array.isArray(row.ip_addresses) ? row.ip_addresses[0] : row["Adresses IP"]?.[0] || row["Adresses IP"],
      };

      const response = await fetch(apiUrl, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestBody),
      });

      if (!response.ok) {
        const errorText = await response.text();
        let errorMessage = `Erreur HTTP: ${response.status}`;
        try {
          const errorData = JSON.parse(errorText);
          errorMessage = errorData.detail || errorData.message || errorMessage;
        } catch {
          errorMessage = errorText || errorMessage;
        }
        throw new Error(errorMessage);
      }

      const result = await response.json();
      console.log("Décommissionnement initié:", result);

      setSuccessMessageOpen(true);
      setOpen(false);
      if (onSuccess) onSuccess();

    } catch (err: any) {
      console.error("Erreur:", err);
      setError(err.message || "Erreur lors du décommissionnement");
    } finally {
      setLoading(false);
    }
  };

  const renderButton = () => (
    <IconButton
      onClick={handleClick}
      size="small"
      disabled={disabled || loading}
      sx={{
        p: 0.3,
        width: 24,
        height: 24,
        color: disabled ? "#9CA3AF" : "#8B5CF6",
        backgroundColor: "#F3F4F6",
        "&:hover": disabled ? {} : {
          backgroundColor: "#EDE9FE",
          color: "#7C3AED",
        },
        ...(disabled && {
          opacity: 0.5,
          cursor: "not-allowed",
        })
      }}
    >
      {loading ? <CircularProgress size={16} /> : <HammerIcon style={{ width: 18, height: 18 }} />}
    </IconButton>
  );

  const buttonWithTooltip = disabled && tooltip ? (
    <Tooltip title={<Box sx={{ p: 0.5 }}><Typography variant="body2">{tooltip}</Typography></Box>} arrow placement="top">
      <span>{renderButton()}</span>
    </Tooltip>
  ) : renderButton();

  return (
    <>
      {buttonWithTooltip}

      <Dialog open={open} onClose={() => !loading && setOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ backgroundColor: "#F87171", color: "white", textAlign: "center" }}>
          Décommissionnement du serveur
        </DialogTitle>
        <DialogContent sx={{ mt: 2 }}>
          <Typography variant="body1" sx={{ mb: 2, fontWeight: 600 }}>
            Vous êtes sur le point de décommissionner le serveur :
          </Typography>

          <Box sx={{ p: 2, mb: 3, backgroundColor: "#FEF2F2", borderRadius: 2, border: "1px solid #FECACA" }}>
            <Typography variant="body2" sx={{ mb: 1 }}>
              <strong>Hostname:</strong> {expectedHostname}
            </Typography>
            <Typography variant="body2" sx={{ mb: 1 }}>
              <strong>IP:</strong> {Array.isArray(row.ip_addresses) ? row.ip_addresses[0] : row["Adresses IP"]?.[0] || row["Adresses IP"]}
            </Typography>
            <Typography variant="body2">
              <strong>OS:</strong> {row.os_type || row["Type OS"]} - {row.os_detail || row["Détail OS"]}
            </Typography>
          </Box>

          {error && (
            <Typography color="error" sx={{ mb: 2, fontWeight: 600 }}>
              {error}
            </Typography>
          )}

          <Typography variant="body2" sx={{ mb: 2 }}>
            Pour confirmer, saisissez l'hostname du serveur :
          </Typography>

          <TextField
            margin="dense"
            label="Hostname"
            fullWidth
            value={hostnameInput}
            onChange={(e) => setHostnameInput(e.target.value)}
            placeholder={expectedHostname}
            error={!!error}
            disabled={loading}
            sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
          />

          {hostnameInput && (
            <Typography
              variant="caption"
              sx={{
                mt: 1,
                display: "block",
                color: isInputValid ? "#10B981" : "#EF4444",
                fontWeight: 600
              }}
            >
              {isInputValid ? "✓ Hostname correct" : "✗ Hostname incorrect"}
            </Typography>
          )}

          {loading && (
            <Typography variant="caption" sx={{ mt: 1, display: "block", color: "#3B82F6", fontWeight: 600 }}>
              Décommissionnement en cours...
            </Typography>
          )}
        </DialogContent>
        <DialogActions sx={{ p: 3, gap: 1 }}>
          <Button onClick={() => setOpen(false)} variant="outlined" disabled={loading} sx={{ borderRadius: 2 }}>
            Annuler
          </Button>
          <Button
            variant="contained"
            onClick={handleConfirm}
            disabled={!isInputValid || loading}
            sx={{
              backgroundColor: "#F87171",
              color: "white",
              "&:hover": { backgroundColor: "#EF4444" },
              "&:disabled": { backgroundColor: "#F3F4F6", color: "#9CA3AF" },
              borderRadius: 2,
              boxShadow: "none",
            }}
          >
            {loading ? "Traitement..." : "Confirmer le décommissionnement"}
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar
        open={successMessageOpen}
        autoHideDuration={4000}
        onClose={() => setSuccessMessageOpen(false)}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        <Alert onClose={() => setSuccessMessageOpen(false)} severity="success" sx={{ width: '100%' }}>
          Décommissionnement initié avec succès ! Rafraîchissement...
        </Alert>
      </Snackbar>
    </>
  );
}