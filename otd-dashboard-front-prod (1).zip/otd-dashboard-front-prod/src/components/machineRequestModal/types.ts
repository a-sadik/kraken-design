import { ReactNode } from "react";

export interface MachineData {
  disks_gb: ReactNode;
  itop_ticket_ref: ReactNode;
  id: number;
  machine_request_ref: string;
  request_type: string; // "creation"
  cluster_type: string;
  os_type: string;
  os_version: string;
  ip_addresses: string[];
  cpu_cores: number;
  ram_gb: number;
  // disk1_gb: number;
  // disk2_gb: number;
  disks: string[];
  hostnames: string[];
  datacenter: string;
  environment_nature: string;
  status: string;
  requester_name: string;
}

export interface MachineRequest {
  request_type: string;
  cluster_type: string;
  os_type: string;
  os_version: string;
  ip_addresses: string[];
  cpu_cores: string;
  ram_gb: string;
  // disk1_gb: string;
  // disk2_gb: string;
  disks: string[];
  hostnames: string[];
  datacenter: string;
  environment_nature: string;
  user_email?: string;
}

export interface MachineRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}
