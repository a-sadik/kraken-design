// src/types/dto/PoleDTO.ts

export interface DomainRequestDTO {
  domain_name: string;
  manager_id: number | null;
  pole_id: number | null;
}

export interface DomainShortResponseDTO {
  domain_id: number;
  domain_name: string;
  domain_manager_id: number;
  created_at?: string;
  updated_at?: string;
  pole_id: number;
}

export interface DomainDetailtResponseDTO {
  domain_id: number;
  domain_name: string;
  manager_id: number;
  created_at?: string;
  updated_at?: string;
  pole_id: number;
}
