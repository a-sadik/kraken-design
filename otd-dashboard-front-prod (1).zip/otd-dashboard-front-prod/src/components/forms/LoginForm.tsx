// src/components/LoginForm.tsx

import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import {
  Stack,
  Button,
  Typography,
  Divider,
  Box,
  TextField,
} from "@mui/material";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

// import custom messages
import {
  username_empty,
  password_empty,
  username_requirement,
  password_requirement,
} from "@/utils/customMessages";

const formSchema = z.object({
  // username validation
  username: z
    .string()
    .min(2, { message: username_requirement })
    .refine((value) => value.trim().length > 0, { message: username_empty }),

  // password validation
  password: z
    .string()
    .min(6, { message: password_requirement })
    .refine((value) => value.trim().length > 0, { message: password_empty }),
});

export function LoginForm() {
  const navigate = useNavigate();

  const { register, handleSubmit, formState } = useForm({
    resolver: zodResolver(formSchema),
    mode: "onChange", // Pour valider en temps réel
    defaultValues: { username: "", password: "" },
  });

  const onSubmit = () => {
    navigate("/");
  };

  // Variables de style
  const textFieldStyle = {
    width: "90%", // Prendre toute la largeur du conteneur
    "& .MuiOutlinedInput-root": {
      padding: "4px",
      "& fieldset": { borderColor: "#ADB5BD" },
      "&:hover fieldset": { borderColor: "#F5B62E" },
      "&.Mui-focused fieldset": { borderColor: "#F5B62E" },
      "&.Mui-error fieldset": { borderColor: "#E25846" },
      "& input": {
        fontSize: "1.125rem",
        padding: "4px 12px",
      },
    },
    "& .MuiInputLabel-outlined": { color: "#000000" },
    "& .MuiInputLabel-outlined.Mui-focused": { color: "#000000" },
    "& .Mui-error .MuiInputLabel-outlined": { color: "#E25846" },
  };

  const buttonStyle = {
    backgroundColor: "#E25846",
    "&:hover": { backgroundColor: "#d85a4b" },
    padding: { xs: "6px 12px", sm: "8px 16px" },
    fontSize: { xs: "12px", sm: "14px" },
    textColor: "red",
    borderRadius: "100px",
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <Stack spacing={2} alignItems="center" mt={4}>
        <Typography
          variant="h4"
          gutterBottom
          sx={{
            fontSize: { xs: "2rem", sm: "2.75rem", md: "2.5rem", lg: "3rem" }, // Tailles adaptatives
          }}
        >
          <strong>Bienvenue</strong>
        </Typography>
        <Typography
          variant="h5"
          gutterBottom
          sx={{
            fontSize: {
              xs: "1.25rem",
              sm: "1.5rem",
              md: "1.5rem",
              lg: "1.5rem",
            }, // Tailles adaptatives
          }}
        >
          Pour accéder à l'application, merci de vous identifier
        </Typography>

        <Divider sx={{ width: "100%", mt: 4, mb: 6 }} />

        <TextField
          required
          id="outlined-input filled-error-helper-text"
          type="text"
          label="Username"
          variant="outlined"
          {...register("username")}
          error={!!formState.errors.username}
          helperText={
            formState.errors.username ? formState.errors.username.message : ""
          }
          margin="normal"
          InputProps={{ style: { padding: "10px" } }}
          sx={textFieldStyle}
        />

        <TextField
          required
          id="outlined-password-input filled-error-helper-text"
          type="password"
          label="Mot de passe"
          variant="outlined"
          {...register("password")}
          error={!!formState.errors.password}
          helperText={
            formState.errors.password ? formState.errors.password.message : ""
          }
          margin="normal"
          InputProps={{ style: { padding: "10px" } }}
          sx={textFieldStyle}
        />

        <Box display="flex" flexDirection="column" alignItems="flex-start">
          <Button
            variant="contained"
            sx={buttonStyle}
            type="submit"
            disabled={!formState.isValid}
          >
            Me connecter
          </Button>
          <Divider sx={{ width: "100%", mt: 3, mb: 2 }} />
        </Box>
      </Stack>
    </form>
  );
}
