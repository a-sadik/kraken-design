// src/types/dto/response/EstimatedBudgetResponseDTO.ts

export interface EstimatedBudgetResponseDTO {
  estimated_budget_id: number;
  estimated_budget_amount: number;
  estimated_budget_date: Date;
  created_at: Date;
  updated_at?: Date;
  created_by: string;
  updated_by?: string;
}
