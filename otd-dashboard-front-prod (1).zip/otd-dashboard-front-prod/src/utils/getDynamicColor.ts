// src/utils/getDynamicColor.ts

// Fonction pour récupérer la valeur d'une variable CSS
export function getCssVariableValue(variableName: string): string {
  const value = getComputedStyle(document.documentElement)
    .getPropertyValue(variableName)
    .trim();

  // Si la valeur est vide ou non définie, utiliser une valeur par défaut
  if (!value) {
    const defaultColors: Record<string, string> = {
      "--certifcate-main-color": "#1976d2",
      "--certifcate-badge-success": "#2e7d32",
      "--certifcate-badge-success-contrastText": "#ffffff",
      "--certifcate-badge-error": "#d32f2f",
      "--certifcate-badge-warning": "#ed6c02",
      "--certifcate-badge-hold": "#9e9e9e",
      "--certifcate-badge-renew": "#9c27b0",
      "--certifcate-badge-intern": "#1976d2",
      "--certifcate-badge-extern": "#ed6c02",
      "--certifcate-extern-color": "#ed6c02",
      "--key-download-color": "#9c27b0",
    };

    return defaultColors[variableName] || "#1976d2";
  }

  return value;
}

export function getBadgeColorEnvironment(value: string) {
  if (typeof value === "string") {
    switch (value.toLowerCase()) {
      case "production":
        return "#ffb3b3"; // rouge pastel soutenu
      case "préproduction":
        return "#ffd699"; // orange pastel soutenu
      case "intégration":
        return "#b3e6ff"; // bleu clair pastel
      case "recette":
        return "#c6b3ff"; // violet pastel doux
      case "développement":
        return "#a8e6b1"; // vert pastel soutenu
      case "formation":
        return "#ffe6cc";
      case "signé":
        return "#a8e6b1"; // vert pastel soutenu
      default:
        return "#d9d9d9"; // gris clair par défaut
    }
  }
  return "#d9d9d9";
}

export const getPastelColorOS = (osType: string) => {
  if (!osType || osType === "OS Type undefined") {
    return { bgColor: "#ccc", textColor: "#000000" }; // Gris par défaut
  }

  const os = osType.toLowerCase().trim();

  // Définition des couleurs pour chaque OS
  const colorMap = {
    windows: { bgColor: "#93C5FD", textColor: "#1E3A8A" }, // Bleu pastel
    linux: { bgColor: "#a8e6b1", textColor: "#166534" }, // Vert pastel
    macos: { bgColor: "#F9A8D4", textColor: "#831843" }, // Rose pastel
    aix: { bgColor: "#fce38a", textColor: "#1E40AF" },
    default: { bgColor: "#7fb2e6", textColor: "#000000" },
  };

  return colorMap[os as keyof typeof colorMap] || colorMap.default;
};

export const getPastelColorSignature = (
  value: string,
): { bgColor: string; textColor: string } => {
  switch (value.toLowerCase()) {
    case "signé":
      return { bgColor: "#a8e6b1", textColor: "#064E3B" }; // vert pastel
    case "expiré":
      return { bgColor: "#FCA5A5", textColor: "#991B1B" }; // rouge rosé
    default:
      return { bgColor: "#e2e2e2", textColor: "#000000" }; // gris
  }
};

export function getBadgeColorSignature(value: string): string {
  if (value === "OS Type undefined") {
    return "#ccc";
  }
  return getCssVariableValue(`--${value.toLowerCase()}-color`);
}

export function getBadgeColorOS(value: string) {
  if (value === "OS Type undefined") return "#ccc";
  return getCssVariableValue(`--${value.toLowerCase()}-color`);
}

export const theme = {
  primary: "#5B8DEF",
  secondary: "#7C3AED",
  accent: "#EC4899",
  success: "#10B981",
  warning: "#F59E0B",
  error: "#EF4444",
  background: "#F8FAFC",
  cardBackground: "#FFFFFF",
  textPrimary: "#1E293B",
  textSecondary: "#64748B",
  border: "#E2E8F0",
};

export const psiColors: Record<string, string> = {
  P1: "#EF4444",
  P2: "#F59E0B",
  P3: "#3B82F6",
  P4: "#10B981",
  P5: "#6B7280",
};

// Fonction pour obtenir les couleurs des ressources hardware
export const getHardwareColor = (type: 'cpu' | 'ram' | 'storage' | 'disk') => {
  switch (type) {
    case 'cpu':
      return { bgColor: "#FFFBEB", textColor: "#92400E" }; // Jaune/ambre
    case 'ram':
      return { bgColor: "#EFF6FF", textColor: "#1E40AF" }; // Bleu
    case 'storage':
      return { bgColor: "#F0FDF4", textColor: "#166534" }; // Vert
    case 'disk':
      return { bgColor: "#F5F3FF", textColor: "#5B21B6" }; // Violet
    default:
      return { bgColor: "#F3F4F6", textColor: "#374151" }; // Gris
  }
};

