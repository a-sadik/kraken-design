// src/components/layouts/Layout.tsx

import React from "react";
import { Outlet } from "react-router-dom";

import Stack from "@mui/material/Stack";
import Box from "@mui/material/Box";

// import files
import SideBar from "@/components/layouts/SideBarNav";
import HeaderBar from "@/components/layouts/HeaderBar";

const Layout: React.FC = () => {
  return (
    <Box
      sx={{
        height: "100vh",
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
      }}
    >
      {/* HeaderBar - Fixed at the top */}
      <Box
        sx={{
          width: "100%",
          height: "53px",
          position: "fixed",
          top: 0,
          zIndex: 1000,
        }}
      >
        <HeaderBar />
      </Box>

      <Stack
        direction="row"
        sx={{ flexGrow: 1, mt: "53px", overflow: "hidden" }}
      >
        {/* SideBar - Fixed on the left */}
        <Box
          sx={{
            width: "58px",
            height: "100%",
            position: "fixed",
            bottom: "0px",
            left: 0,
          }}
        >
          <SideBar />
        </Box>

        {/* Content - Takes remaining space and allows scrolling */}
        <Box
          sx={{
            flexGrow: 1,
            marginLeft: "58px", // To make space for the fixed sidebar
            padding: 2,
            overflowY: "auto", // Enable vertical scrolling
            height: "calc(100vh - 53px)", // Occupies the remaining space below the header
          }}
        >
          <Box sx={{ padding: "3rem", width: "100%" }}>
            <Outlet />
          </Box>
        </Box>
      </Stack>
    </Box>
  );
};

export default Layout;
