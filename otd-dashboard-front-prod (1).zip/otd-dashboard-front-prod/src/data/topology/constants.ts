// Color schemes
export const colors = {
  entity: "#E8F4FD",
  pole: "#F0F9E8",
  domain: "#FFF4E6",
  solution: "#F3E8FF",
  namespace: "#E8F8F5",
  deployment: "#FFF0F5",
  server: "#FDF2F8",
  pod: "#F0F4FF",
  overview: "#F0F7FF",
  backup: "#E3F2FD",
  ecab: "#E8F5E9",
  cab: "#FFF8E1",
  backupHistory: "#F3E5F5",
  batch: "#FFEBEE",
  cft: "#E0F7FA",
};

export const darkColors = {
  entity: "#1565C0",
  pole: "#2E7D32",
  domain: "#F57C00",
  solution: "#7B1FA2",
  namespace: "#00695C",
  deployment: "#D81B60",
  server: "#C2185B",
  pod: "#303F9F",
  overview: "#1976D2",
  backup: "#0288D1",
  ecab: "#43A047",
  cab: "#FFB300",
  backupHistory: "#8E24AA",
  batch: "#E53935",
  cft: "#00ACC1",
};

export const osColors = {
  Windows: "#0299F4",
  Linux: "#E25846",
  AIX: "#54CE8C",
};

export const envColors = {
  Production: "#90a213",
  Préproduction: "#e3e9ba",
  Intégration: "#cbe8ff",
  Recette: "#fddbbb",
  Développement: "#ff8a8a",
  Formation: "#ffe6cc",
};

export const statusColors = {
  success: "#4CAF50",
  failed: "#F44336",
  pending: "#FFC107",
  warning: "#FF9800",
  running: "#2196F3",
  completed: "#4CAF50",
  scheduled: "#9C27B0",
  approved: "#4CAF50",
  rejected: "#F44336",
  active: "#4CAF50",
  inactive: "#9E9E9E",
  error: "#F44336",
  high: "#F44336",
  medium: "#FFC107",
  low: "#4CAF50",
};
