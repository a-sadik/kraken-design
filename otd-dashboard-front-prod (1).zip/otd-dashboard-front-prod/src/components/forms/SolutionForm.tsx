// src/components/FormSolution.tsx

import { useEffect, useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z as zod } from "zod";
import {
  TextField,
  Button,
  Grid,
  Autocomplete,
  Typography,
  Box,
  CircularProgress,
} from "@mui/material";

// Imports file
import { SolutionType } from "@/enums/SolutionType";
import { SolutionPopularity } from "@/enums/SolutionPopularity";
import { PCI } from "@/enums/PCI";
import { getAllDomains } from "@/services/admin/DomainService";
import {
  placeholder_domain,
  placeholder_functional_admin,
  placeholder_pci,
  placeholder_solution_name,
  placeholder_solution_popularity,
  placeholder_solution_role,
  placeholder_solution_type,
  placeholder_tam,
  placeholder_technical_admin,
  required_functional_admin,
  required_pci,
  required_solution_name,
  required_solution_popularity,
  required_solution_role,
  required_solution_type,
  required_tam,
  required_technical_admin,
} from "@/utils/customMessages";
import { DomainShortResponseDTO } from "@/types/dto/DomainDTO";

// Schéma de validation avec Zod
const getFormSchema = (isDeleteMode: boolean) =>
  zod.object({
    solution_name: zod.string().trim().min(1, required_solution_name),
    solution_popularity: zod
      .string()
      .trim()
      .min(1, required_solution_popularity),
    solution_type: zod.string().trim().min(1, required_solution_type),
    solution_role: zod.string().trim().min(1, required_solution_role),
    technical_admin: isDeleteMode
      ? zod.array(zod.string()).optional()
      : zod.array(zod.string()).min(1, required_technical_admin),
    functional_admin: isDeleteMode
      ? zod.array(zod.string()).optional()
      : zod.array(zod.string()).min(1, required_functional_admin),
    tam: zod.string().trim().min(1, required_tam),
    pci: zod.string().trim().min(1, required_pci),
    domain: isDeleteMode
      ? zod
          .object({
            domain_id: zod.number(),
            domain_name: zod.string(),
            // domain_manager: zod.string(),
          })
          .optional()
      : zod
          .object({
            domain_id: zod.number(),
            domain_name: zod.string(),
            // domain_manager: zod.string(),
          })
          .required(),
  });

export type SolutionFormData = zod.infer<ReturnType<typeof getFormSchema>>;

const FormLabel = ({
  label,
  isRequired = false,
}: {
  label: string;
  isRequired?: boolean;
}) => (
  <Typography
    variant="body1"
    sx={{
      fontWeight: "bold",
      display: "flex",
      alignItems: "center",
      mb: "0.5rem",
      fontSize: "1.2rem",
    }}
  >
    {label}
    {isRequired && (
      <span style={{ color: "var(--error-color)", marginLeft: 2 }}>*</span>
    )}
  </Typography>
);

interface SignatureFormSolutionProps {
  initialData: any;
  onSubmit: (data: SolutionFormData) => void;
  isEditMode: boolean;
  isViewMode: boolean;
  isDeleteMode: boolean;
}

export function SignatureFormSolution({
  initialData,
  onSubmit,
  isEditMode,
  isViewMode,
  isDeleteMode,
}: SignatureFormSolutionProps) {
  const formSchema = getFormSchema(isDeleteMode);

  const {
    control,
    register,
    handleSubmit,
    formState: { errors, isValid },
    setValue,
  } = useForm<SolutionFormData>({
    resolver: zodResolver(formSchema),
    mode: "all",
    defaultValues: initialData || {
      solution_name: "",
      solution_popularity: "",
      solution_type: "",
      solution_role: "",
      technical_admin: [],
      functional_admin: [],
      tam: "",
      pci: "",
      domain: "",
    },
  });

  // loading domains
  const [domains, setDomains] = useState<DomainShortResponseDTO[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  const fetchDomains = async () => {
    setLoading(true);
    try {
      const domainsData = await getAllDomains();
      if (Array.isArray(domainsData)) {
        setDomains(domainsData);
      } else {
        console.error(
          "Les données reçues du domaine ne sont pas un tableau",
          domainsData,
        );
        setDomains([]);
      }
    } catch (error) {
      console.error("Erreur lors du chargement des domains :", error);
      setDomains([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (initialData) {
      // Si des données initiales sont fournies, remplissez les valeurs du formulaire
      Object.keys(initialData).forEach((key) => {
        setValue(
          key as keyof SolutionFormData,
          initialData[key as keyof SolutionFormData],
        );
      });
    }
  }, [initialData, setValue]);

  // Liste des options pour les champs
  const solutionPopularity = Object.values(SolutionPopularity);
  const solutionType = Object.values(SolutionType);
  const pcis = Object.values(PCI);
  const technical_admins = Array.from(
    { length: 50 },
    (_, i) => `Admin Tech ${i + 1}`,
  );
  const functional_admins = Array.from(
    { length: 50 },
    (_, i) => `Admin Func ${i + 1}`,
  );
  const tams = ["TAM 1", "TAM 2", "TAM 3", "TAM 4", "TAM 5", "TAM 6", "TAM 7"];

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <Grid container spacing={2}>
        {!isDeleteMode ? (
          <>
            {/* Champ Nom */}
            <Grid item xs={12} md={6}>
              <FormLabel label="Nom" isRequired />
              <TextField
                {...register("solution_name")}
                error={!!errors.solution_name}
                helperText={errors.solution_name?.message}
                fullWidth
                disabled={isViewMode}
                placeholder={placeholder_solution_name}
              />
            </Grid>

            {/* Champ Popularité */}
            <Grid item xs={12} md={6}>
              <FormLabel label="Popularité" isRequired />
              <Controller
                name="solution_popularity"
                control={control}
                render={({ field }) => (
                  <Autocomplete
                    {...field}
                    options={solutionPopularity}
                    getOptionLabel={(option) => option}
                    disabled={isViewMode}
                    onChange={(_, value) => field.onChange(value || "")}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        error={!!errors.solution_popularity}
                        helperText={errors.solution_popularity?.message}
                        placeholder={placeholder_solution_popularity}
                      />
                    )}
                  />
                )}
              />
            </Grid>

            {/* Champ Type */}
            <Grid item xs={12} md={6}>
              <FormLabel label="Type" isRequired />
              <Controller
                name="solution_type"
                control={control}
                render={({ field }) => (
                  <Autocomplete
                    {...field}
                    options={solutionType}
                    getOptionLabel={(option) => option}
                    disabled={isViewMode}
                    onChange={(_, value) => field.onChange(value || "")}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        error={!!errors.solution_type}
                        helperText={errors.solution_type?.message}
                        placeholder={placeholder_solution_type}
                      />
                    )}
                  />
                )}
              />
            </Grid>

            {/* Champ Domaine */}
            <Grid item xs={12} md={6}>
              <FormLabel label="Domaine" isRequired />
              <Controller
                name="domain"
                control={control}
                render={({ field }) => (
                  <Autocomplete
                    {...field}
                    options={domains || []}
                    getOptionLabel={(option) =>
                      option?.domain_name
                        ? `${option?.domain_name} (${option?.domain_name})`
                        : ""
                    }
                    disabled={isViewMode}
                    loading={loading}
                    onOpen={fetchDomains}
                    onChange={(_, value) => field.onChange(value || null)}
                    isOptionEqualToValue={(option, value) =>
                      option?.domain_id === value?.domain_id
                    }
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        placeholder={placeholder_domain}
                        error={!!errors.domain}
                        helperText={
                          errors.domain?.message ||
                          (loading ? "Chargement..." : "")
                        }
                        InputProps={{
                          ...params.InputProps,
                          endAdornment: (
                            <>
                              {loading && (
                                <CircularProgress color="inherit" size={20} />
                              )}
                              {params.InputProps.endAdornment}
                            </>
                          ),
                        }}
                      />
                    )}
                  />
                )}
              />
            </Grid>

            {/* Champ Admin(s) Technique(s) */}
            <Grid item xs={12} md={12}>
              <FormLabel label="Admin(s) technique(s)" isRequired />
              <Controller
                name="technical_admin"
                control={control}
                render={({ field }) => (
                  <Autocomplete
                    {...field}
                    multiple
                    limitTags={2}
                    options={technical_admins}
                    getOptionLabel={(option) => option}
                    disabled={isViewMode}
                    onChange={(_, value) => field.onChange(value || [])}
                    isOptionEqualToValue={(option, value) => option === value}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        placeholder={placeholder_technical_admin}
                        error={!!errors.technical_admin}
                        helperText={errors.technical_admin?.message}
                      />
                    )}
                  />
                )}
              />
            </Grid>

            {/* Champ Admin(s) Fonctionnel(s) */}
            <Grid item xs={12} md={12}>
              <FormLabel label="Admin(s) fonctionnel(s)" isRequired />
              <Controller
                name="functional_admin"
                control={control}
                render={({ field }) => (
                  <Autocomplete
                    {...field}
                    multiple
                    limitTags={2}
                    options={functional_admins}
                    getOptionLabel={(option) => option}
                    disabled={isViewMode}
                    onChange={(_, value) => field.onChange(value || [])}
                    isOptionEqualToValue={(option, value) => option === value}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        placeholder={placeholder_functional_admin}
                        error={!!errors.functional_admin}
                        helperText={errors.functional_admin?.message}
                      />
                    )}
                  />
                )}
              />
            </Grid>

            {/* Champ TAM */}
            <Grid item xs={12} md={6}>
              <FormLabel label="TAM" isRequired />
              <Controller
                name="tam"
                control={control}
                render={({ field }) => (
                  <Autocomplete
                    {...field}
                    options={tams}
                    getOptionLabel={(option) => option}
                    onChange={(_, value) => field.onChange(value || "")}
                    disabled={isViewMode}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        error={!!errors.tam}
                        helperText={errors.tam?.message}
                        disabled={isViewMode}
                        placeholder={placeholder_tam}
                      />
                    )}
                  />
                )}
              />
            </Grid>

            {/* Champ PCI */}
            <Grid item xs={12} md={6}>
              <FormLabel label="PCI" isRequired />
              <Controller
                name="pci"
                control={control}
                render={({ field }) => (
                  <Autocomplete
                    {...field}
                    options={pcis}
                    getOptionLabel={(option) => option}
                    onChange={(_, value) => field.onChange(value || "")}
                    disabled={isViewMode}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        error={!!errors.tam}
                        helperText={errors.tam?.message}
                        disabled={isViewMode}
                        placeholder={placeholder_pci}
                      />
                    )}
                  />
                )}
              />
            </Grid>

            {/* Champ Rôle */}
            <Grid item xs={12} md={12}>
              <FormLabel label="Rôle" isRequired />
              <TextField
                {...register("solution_role")}
                error={!!errors.solution_role}
                helperText={errors.solution_role?.message}
                fullWidth
                multiline
                rows={3}
                placeholder={placeholder_solution_role}
                disabled={isViewMode}
              />
            </Grid>
          </>
        ) : (
          <Box margin="2rem">
            Êtes-vous sûr de vouloir supprimer la solution{" "}
            <strong>{initialData?.name}</strong>.
          </Box>
        )}

        {/* Bouton Soumettre */}
        {!isViewMode && !isDeleteMode && (
          <Grid item xs={12}>
            <Button
              type="submit"
              variant="contained"
              color="primary"
              disabled={!isValid}
              fullWidth
            >
              {isEditMode ? "Modifier" : isDeleteMode ? "Supprimer" : "Ajouter"}
            </Button>
          </Grid>
        )}

        {isDeleteMode && (
          <Grid item xs={12}>
            <Button type="submit" variant="contained" color="primary" fullWidth>
              Supprimer
            </Button>
          </Grid>
        )}
      </Grid>
    </form>
  );
}
