// src/services/PoleService.ts

import { AxiosError } from "axios";

// import files
import {
  PoleDetailtResponseDTO,
  PoleRequestDTO,
  PoleShortResponseDTO,
} from "@/types/dto/PoleDTO";
import apiClient from "../apiClientHttp";
import { ErrorResponse } from "@/exceptions/ErrorResponse";

const path = "/poles";

// Function to get all poles
export const getAllPoles = async (): Promise<PoleShortResponseDTO[]> => {
  try {
    const response =
      await apiClient.dataApiClient.get<PoleShortResponseDTO[]>(path);
    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;
    console.error("Error to get all poles:", err.response?.data.message);
    throw err;
  }
};

// Function to recieve one pole by id
export const getPoleById = async (
  id: number,
): Promise<PoleShortResponseDTO | null> => {
  try {
    const response =
      await apiClient.dataApiClient.get<PoleShortResponseDTO | null>(
        `${path}/${id}`,
      );
    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;
    console.error("Error fetching pole data by id:", err.response?.data);
    throw error;
  }
};

// Function to create pole
export const createPole = async (
  reqBody: PoleRequestDTO,
): Promise<PoleRequestDTO | null> => {
  try {
    const response =
      await apiClient.dataApiClient.post<PoleDetailtResponseDTO | null>(
        `${path}`,
        reqBody,
      );
    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error("Error creating new pole:", err.response?.data);
    throw error;
  }
};

// Function to update entity
export const updatePole = async (
  id: number,
  reqBody: PoleRequestDTO,
): Promise<PoleRequestDTO | null> => {
  try {
    const response =
      await apiClient.dataApiClient.put<PoleDetailtResponseDTO | null>(
        `${path}/${id}`,
        reqBody,
      );
    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error("Error updating new pole:", err.response?.data);
    throw error;
  }
};
