// import React from 'react';
// import { alpha, Box, Card, CardContent, Chip, Divider, Fade, Typography } from '@mui/material';
// import { Person, KeyboardArrowRight } from '@mui/icons-material';
// import { DiOpenshift } from 'react-icons/di';
// import { FiServer } from 'react-icons/fi';
// import { LuRocket } from 'react-icons/lu';
// import { MdAdminPanelSettings, MdOutlineAdminPanelSettings } from 'react-icons/md';
// import { PiCubeBold } from 'react-icons/pi';
// import { TbBuildingBank } from 'react-icons/tb';
// import { VscSymbolNamespace } from 'react-icons/vsc';
// import { pastelTheme } from '../basics/ThemeButton';
// import { colors } from './utils/colors';

// interface ItemCardProps {
//   item: any;
//   level: string;
//   onNavigate: () => void;
// }
// const defaultColor = '#87CEEB' ; // Bleu ciel pastel
// const ItemCard = ({ item, level, onNavigate }: { item: any; level: string; onNavigate: () => void }) => {
//     const hasChildren = item.child || item.child_namespace || item.child_servers
//     const defaultColor = '#87CEEB' ; // Bleu ciel pastel

//     // Fonction pour formater la date
//     const formatDate = (dateString: string) => {
//       const date = new Date(dateString)
//       return date.toLocaleDateString('fr-FR', {
//         day: '2-digit',
//         month: '2-digit',
//         year: 'numeric',
//       })
//     }

//     function getLevelIcon(level: string): React.FunctionComponentElement<{ sx: { fontSize: number; }; }> {
//         throw new Error('Function not implemented.');
//     }

//     function renderEnvironmentChips(list_environnements: any): React.ReactNode {
//         throw new Error('Function not implemented.');
//     }

//     return (
//       <Fade in timeout={300}>
//         <Card
//           elevation={0}
//           sx={{
//             height: "100%",
//             display: "flex",
//             flexDirection: "column",
//             transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
//             background: pastelTheme.cardBackground,
//             border: `1px solid ${pastelTheme.outline}`,
//             borderRadius: 3,
//             position: "relative",
//             overflow: "hidden",
//             cursor: hasChildren ? "pointer" : "default",
//             boxShadow: `0 8px 24px ${pastelTheme.shadow}`,
//             "&:hover": hasChildren
//               ? {
//                 transform: "translateY(-4px)",
//                 boxShadow: `0 8px 24px ${alpha(defaultColor, 0.2)}`,
//               }
//               : {},
//           }}
//           onClick={hasChildren ? onNavigate : undefined}
//         >
//           {/* Bandeau de couleur */}
//           <Box
//             sx={{
//               height: 6,
//               width: "100%",
//               background: `linear-gradient(90deg, ${defaultColor}, ${defaultColor})`,
//             }}
//           />

//           <CardContent sx={{ p: 3, flexGrow: 1 }}>
//             {/* En-tête avec icône et nom */}
//             <Box sx={{ display: "flex", alignItems: "center", gap: 2, mb: 2 }}>
//               <Box
//                 sx={{
//                   p: 1.5,
//                   borderRadius: "50%",
//                   backgroundColor: alpha(defaultColor, 0.2),
//                   color: defaultColor,
//                   flexShrink: 0,
//                   display: "flex",
//                   alignItems: "center",
//                   justifyContent: "center",
//                 }}
//               >
//                 {React.cloneElement(getLevelIcon(level), { sx: { fontSize: 20 } })}
//               </Box>

//               <Box sx={{ flexGrow: 1, minWidth: 0 }}>
//                 <Typography
//                   variant="h6"
//                   sx={{
//                     fontSize: "16px",
//                     fontWeight: 800,
//                     color: pastelTheme.textPrimary, // Utiliser la couleur textPrimary du thème
//                     mb: 0.5,
//                     wordBreak: "break-word",
//                   }}
//                 >
//                   {item[`${level}_name`] || item.name || item.hostname || item.pod_name}
//                 </Typography>

//                 {/* Manager pour les entités */}
//                 {item.entity_manager && (
//                   <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
//                     <Person sx={{ fontSize: 14, color: defaultColor }} />
//                     <Typography
//                       variant="body2"
//                       sx={{ fontSize: "12px", color: pastelTheme.textSecondary, fontWeight: 500 }}
//                     >
//                       {item.entity_manager}
//                     </Typography>
//                   </Box>
//                 )}
//               </Box>
//             </Box>
//             {/* Dates */}
//             <Box sx={{ display: "flex", gap: 1, mb: 2, flexWrap: 'wrap' }}>
//               {item.created_at && (
//                 <Chip
//                   label={`Créé: ${formatDate(item.created_at)}`}
//                   size="small"
//                   sx={{
//                     fontSize: "10px",
//                     backgroundColor: alpha(defaultColor, 0.1),
//                     color: pastelTheme.textSecondary,
//                   }}
//                 />
//               )}
//               {item.updated_at && (
//                 <Chip
//                   label={`MAJ: ${formatDate(item.updated_at)}`}
//                   size="small"
//                   sx={{
//                     fontSize: "10px",
//                     backgroundColor: alpha(defaultColor, 0.1),
//                     color: pastelTheme.textSecondary,
//                   }}
//                 />
//               )}
//             </Box>

//             {/* Responsables TAM/Admin Tech/Admin Fonc - Même ligne */}
//             {(item.count_tams > 0 || item.count_technical_admins > 0 || item.count_functional_admins > 0) && (
//               <Box sx={{ mb: 2 }}>
//                 <Typography variant="caption" sx={{ fontWeight: 600, color: pastelTheme.textSecondary, display: 'block', mb: 0.5 }}>
//                   Responsables:
//                 </Typography>
//                 <Box sx={{
//                   display: 'flex',
//                   gap: 1,
//                   p: 1,
//                   borderRadius: 2,
//                   backgroundColor: alpha(defaultColor, 0.05),
//                   border: `1px solid ${alpha(defaultColor, 0.2)}`,
//                   flexWrap: 'wrap',
//                 }}>
//                   {item.count_tams > 0 && (
//                     <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
//                       <Person sx={{ color: defaultColor }} fontSize="small" />
//                       <Typography sx={{ fontSize: '12px' }}>TAM: {item.count_tams}</Typography>
//                     </Box>
//                   )}
//                   {item.count_technical_admins > 0 && (
//                     <>
//                       {item.count_tams > 0 && <Divider orientation="vertical" flexItem />}
//                       <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
//                         <MdAdminPanelSettings size={14} color={defaultColor} />
//                         <Typography sx={{ fontSize: '12px' }}>Admin T: {item.count_technical_admins}</Typography>
//                       </Box>
//                     </>
//                   )}
//                   {item.count_functional_admins > 0 && (
//                     <>
//                       {(item.count_tams > 0 || item.count_technical_admins > 0) && <Divider orientation="vertical" flexItem />}
//                       <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
//                         <MdOutlineAdminPanelSettings size={14} color={defaultColor} />
//                         <Typography sx={{ fontSize: '12px' }}>Admin F: {item.count_functional_admins}</Typography>
//                       </Box>
//                     </>
//                   )}
//                 </Box>
//               </Box>
//             )}

//             {/* Pôles et Domaines - Même ligne */}
//             {(item.count_poles > 0 || item.count_domains > 0 || item.domain_name) && (
//               <Box sx={{ mb: 2 }}>
//                 <Typography variant="caption" sx={{ fontWeight: 600, color: pastelTheme.textSecondary, display: 'block', mb: 0.5 }}>
//                   Organisation:
//                 </Typography>
//                 <Box sx={{
//                   display: 'flex',
//                   gap: 1,
//                   p: 1,
//                   borderRadius: 2,
//                   backgroundColor: alpha(defaultColor, 0.05),
//                   border: `1px solid ${alpha(defaultColor, 0.2)}`,
//                   flexWrap: 'wrap',
//                 }}>
//                   {item.count_poles > 0 && (
//                     <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
//                       <Typography sx={{ fontSize: '12px' }}>Pôles: {item.count_poles}</Typography>
//                     </Box>
//                   )}
//                   {(item.count_domains > 0 || item.domain_name) && (
//                     <>
//                       {item.count_poles > 0 && <Divider orientation="vertical" flexItem />}
//                       <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
//                         <TbBuildingBank size={14} color={defaultColor} />
//                         <Typography sx={{ fontSize: '12px' }}>
//                           {item.domain_name ? item.domain_name : `Domaines: ${item.count_domains}`}
//                         </Typography>
//                       </Box>
//                     </>
//                   )}
//                 </Box>
//               </Box>
//             )}

//             {/* Solutions et Serveurs - Même ligne */}
//             {(item.count_solutions > 0 || item.count_servers > 0) && (
//               <Box sx={{ mb: 2 }}>

//                 <Box sx={{
//                   display: 'flex',
//                   gap: 1,
//                   p: 1,
//                   borderRadius: 2,
//                   backgroundColor: alpha(defaultColor, 0.05),
//                   border: `1px solid ${alpha(defaultColor, 0.2)}`,
//                   flexWrap: 'wrap',
//                 }}>
//                   {item.count_solutions > 0 && (
//                     <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>

//                       <Typography sx={{ fontSize: '12px' }}>Solutions: {item.count_solutions}</Typography>
//                     </Box>
//                   )}
//                   {item.count_servers > 0 && (
//                     <>
//                       {item.count_solutions > 0 && <Divider orientation="vertical" flexItem />}
//                       <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
//                         <FiServer size={14} color={defaultColor} />
//                         <Typography sx={{ fontSize: '12px' }}>Serveurs: {item.count_servers}</Typography>
//                       </Box>
//                     </>
//                   )}
//                 </Box>
//               </Box>
//             )}

//             {/* OpenShift Pod/Namespace/Deployment - Même ligne */}
//             {(level === "pod" || level === "namespace" || level === "deployment" || item.namespace || item.deployment_name || item.count_pods > 0 || item.count_namespaces > 0 || item.count_deployments > 0) && (
//               <Box sx={{ mb: 2 }}>
//                 <Typography
//                   variant="caption"
//                   sx={{
//                     fontWeight: 600,
//                     color: pastelTheme.textSecondary,
//                     display: 'flex',
//                     alignItems: 'center',
//                     gap: 0.5,
//                     mb: 0.5,
//                   }}
//                 >
//                   <DiOpenshift size={16} color="#EE0000" />
//                   OpenShift:
//                 </Typography>
//                 <Box sx={{
//                   display: 'flex',
//                   gap: 1,
//                   p: 1,
//                   borderRadius: 2,
//                   backgroundColor: alpha(defaultColor, 0.05),
//                   border: `1px solid ${alpha(defaultColor, 0.2)}`,
//                   flexWrap: 'wrap',
//                 }}>
//                   {/* Affichage des pods */}
//                   {(level === "pod" || item.count_pods > 0) && (
//                     <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
//                       <PiCubeBold size={14} color={colors.pod} />
//                       <Typography sx={{ fontSize: '12px' }}>
//                         {level === "pod" ? item.pod_name : `Pods: ${item.count_pods}`}
//                       </Typography>
//                     </Box>
//                   )}

//                   {/* Affichage des namespaces */}
//                   {(item.namespace || item.count_namespaces > 0) && (
//                     <>
//                       {(level === "pod" || item.count_pods > 0) && <Divider orientation="vertical" flexItem />}
//                       <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
//                         <VscSymbolNamespace size={14} color={colors.namespace} />
//                         <Typography sx={{ fontSize: '12px' }}>
//                           {item.namespace ? item.namespace : `Namespaces: ${item.count_namespaces}`}
//                         </Typography>
//                       </Box>
//                     </>
//                   )}

//                   {/* Affichage des deployments */}
//                   {(item.deployment_name || item.count_deployments > 0) && (
//                     <>
//                       {((level === "pod" || item.count_pods > 0) || (item.namespace || item.count_namespaces > 0)) && <Divider orientation="vertical" flexItem />}
//                       <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
//                         <LuRocket size={14} color={colors.deployment} />
//                         <Typography sx={{ fontSize: '12px' }}>
//                           {item.deployment_name ? item.deployment_name : `Deployments: ${item.count_deployments}`}
//                         </Typography>
//                       </Box>
//                     </>
//                   )}
//                 </Box>
//               </Box>
//             )}

//             {/* Type de solution (pour les solutions) */}
//             {level === "solution" && item.solution_type && (
//               <Box sx={{ mb: 2 }}>
//                 <Typography variant="caption" sx={{ fontWeight: 600, color: pastelTheme.textSecondary }}>
//                   Type:
//                 </Typography>
//                 <Chip
//                   label={item.solution_type}
//                   size="small"
//                   sx={{
//                     fontSize: "10px",
//                     backgroundColor: alpha(defaultColor, 0.1),
//                     color: pastelTheme.textPrimary,
//                     mt: 0.5,
//                   }}
//                 />
//               </Box>
//             )}

//             {/* Environnements en bas */}
//             {item.list_environnements && (
//               <Box sx={{ mt: 'auto', pt: 2 }}>
//                 <Typography variant="caption" sx={{ fontWeight: 600, color: pastelTheme.textSecondary }}>
//                   Environnements:
//                 </Typography>
//                 {renderEnvironmentChips(item.list_environnements)}
//               </Box>
//             )}
//           </CardContent>

//           {hasChildren && (
//             <Box
//               sx={{
//                 p: 1,
//                 display: "flex",
//                 justifyContent: "flex-end",
//                 backgroundColor: alpha(defaultColor, 0.05),
//                 borderTop: `1px solid ${pastelTheme.outline}`,
//               }}
//             >
//               <KeyboardArrowRight sx={{ color: defaultColor }} />
//             </Box>
//           )}
//         </Card>
//       </Fade>
//     )
//   }

// export default ItemCard;
