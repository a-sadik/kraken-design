import { getCoreROOTApiUrl } from "@/config/api.config";
import fetchWithAuth from "@/middleware/fetch-auth";

// Base URL for your API endpoints
const BASE_URL = getCoreROOTApiUrl();

// --- Interface Definitions ---

export interface Solution {
  id: number;
  solution_name: string;
  solution_role: string;
  psi: string;
  solution_popularity: string;
  solution_type: string;
  domain: string;
  pole: string;
  entity: string;
  tams: string[];
  technical_admins: string[];
  functional_admins: string[];
  declarted_on_bigfix: boolean;
  declarted_on_itop: boolean;
  fiable: boolean;
}

// Base interface for all server types, including a 'source' to identify its origin
export interface BaseServer {
  hostname: string;
  ip_addresses: string[];
  os_type: string;
  created_at: string;
  created_by: string;
  updated_at: string;
  updated_by: string;
  source: "vmware" | "power" | "bigfix" | "inventory";
}

// Specific interfaces for each server type, extending BaseServer
export interface Vmware extends BaseServer {
  os_detail: string;
}

export interface Power extends BaseServer {
  // No additional fields beyond BaseServer for Power based on provided interface
}

export interface Bigfix extends BaseServer {
  os_detail: string;
  nature_detail: string;
  server_nature: string[];
  environments: string[];
  solutions: Solution[]; // Bigfix also has a solutions array
}

export interface Inventory extends BaseServer {
  os_detail: string;
  nature_detail: null | string;
  server_nature: string[];
  environments: string[];
  solutions: Solution[];
}

// The structure of the response from the isolated servers API
export interface RootObject {
  vmware: Vmware[];
  power: Power[];
  bigfix: Bigfix[];
  inventory: Inventory[];
}

// Payload types for the inventorize POST request
export interface ProvisionMapEntry {
  ip: string;
  source: "vmware" | "power" | "bigfix"; // Only these sources can be inventorized
}

export interface InventorizePayload {
  solutions: string[];
  provision_map: ProvisionMapEntry[];
}

// Response type for the inventorize POST request (Multi-Status)
export interface InventorizeResponseItem {
  ip: string;
  status_code: number;
  status: string;
  message: string;
}

// --- API Functions ---

/**
 * Fetches the list of available solutions/applications.
 * @returns A promise that resolves to an array of Solution objects.
 */
export async function fetchSolutions(): Promise<Solution[]> {
  const response = await fetchWithAuth(`${BASE_URL}/api/v2/admin/solutions`);
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  return response.json();
}

/**
 * Fetches the categorized list of isolated servers.
 * @returns A promise that resolves to a RootObject containing server arrays.
 */
export async function fetchIsolatedServers(): Promise<RootObject> {
  const response = await fetchWithAuth(
    `${BASE_URL}/api/v2/fiabilisation/servers/isolated`,
  );
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  return response.json();
}

/**
 * Sends a request to inventorize selected servers with chosen solutions.
 * @param payload The data containing solutions and server provision map.
 * @returns A promise that resolves to an array of InventorizeResponseItem,
 *          indicating the status for each inventorized IP.
 */
export async function postInventorize(
  payload: InventorizePayload,
): Promise<InventorizeResponseItem[]> {
  const response = await fetchWithAuth(
    `${BASE_URL}/api/v2/fiabilisation/servers/inventorize/`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    },
  );

  // The API returns 207 Multi-Status for partial success, which is still 'ok'.
  // We only throw for true network/server errors (e.g., 5xx, or non-2xx/207).
  if (!response.ok && response.status !== 207) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  return response.json();
}
