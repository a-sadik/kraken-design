// src/components/modals/EditDomaineModal.tsx

import React, { useEffect, useState } from "react";
import {
  Grid,
  Typography,
  TextField,
  Autocomplete,
  Box,
  Button,
  CircularProgress,
  Alert,
  Snackbar,
} from "@mui/material";
import MyModal from "@/components/modals/MyModal";
import { getAllPersons } from "@/services/admin/PersonService";
import { getAllPoles } from "@/services/admin/PoleService";
import { updateDomain } from "@/services/admin/DomainService";
import { PersonShortResponseDTO } from "@/types/dto/PersonDTO";
import { PoleShortResponseDTO } from "@/types/dto/PoleDTO";

interface EditDomaineModalProps {
  open: boolean;
  onClose: () => void;
  onSave: () => void;
  domainId: number;
  currentName: string;
  currentManagerId?: number;
  currentPoleId?: number;
}

export const EditDomaineModal: React.FC<EditDomaineModalProps> = ({
  open,
  onClose,
  onSave,
  domainId,
  currentName,
  currentManagerId,
  currentPoleId,
}) => {
  const [newName, setNewName] = useState("");
  const [persons, setPersons] = useState<PersonShortResponseDTO[]>([]);
  const [poles, setPoles] = useState<PoleShortResponseDTO[]>([]);

  const [selectedManager, setSelectedManager] =
    useState<PersonShortResponseDTO | null>(null);
  const [selectedPole, setSelectedPole] = useState<PoleShortResponseDTO | null>(
    null,
  );

  const [loadingPersons, setLoadingPersons] = useState(false);
  const [loadingPoles, setLoadingPoles] = useState(false);
  const [loadingSave, setLoadingSave] = useState(false);

  const [successSnackbar, setSuccessSnackbar] = useState(false);

  // Charger les données
  useEffect(() => {
    if (!open) return;

    setLoadingPersons(true);
    getAllPersons()
      .then(setPersons)
      .finally(() => setLoadingPersons(false));

    setLoadingPoles(true);
    getAllPoles()
      .then(setPoles)
      .finally(() => setLoadingPoles(false));
  }, [open]);

  // Initialiser les champs à l’ouverture
  useEffect(() => {
    if (!open) return;
    setNewName(currentName);

    const foundManager = persons.find((p) => p.person_id === currentManagerId);
    setSelectedManager(foundManager ?? null);

    const foundPole = poles.find((p) => p.pole_id === currentPoleId);
    setSelectedPole(foundPole ?? null);
  }, [open, currentName, currentManagerId, currentPoleId, persons, poles]);

  const hasChanges =
    newName.trim() !== currentName.trim() ||
    (selectedManager?.person_id ?? null) !== (currentManagerId ?? null) ||
    (selectedPole?.pole_id ?? null) !== (currentPoleId ?? null);

  const handleSave = async () => {
    setLoadingSave(true);
    try {
      await updateDomain(domainId, {
        domain_name: newName,
        manager_id: selectedManager?.person_id ?? null,
        pole_id: selectedPole?.pole_id ?? null,
      });

      onSave();
      setSuccessSnackbar(true);
      onClose();
    } catch (err) {
      console.error("Erreur lors de la mise à jour du domaine :", err);
    } finally {
      setLoadingSave(false);
    }
  };

  return (
    <>
      <MyModal open={open} onClose={onClose} title="Modifier le domaine">
        <Grid container spacing={2} sx={{ px: 2, pt: 1 }}>
          {/* Nom du Domaine */}
          <Grid item xs={12} container alignItems="center" spacing={2}>
            <Grid item xs={4}>
              <Typography fontWeight="bold">Nouveau nom</Typography>
            </Grid>
            <Grid item xs={8}>
              <TextField
                fullWidth
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
              />
            </Grid>
          </Grid>

          {/* Manager */}
          <Grid item xs={12} container alignItems="center" spacing={2}>
            <Grid item xs={4}>
              <Typography fontWeight="bold">Manager</Typography>
            </Grid>
            <Grid item xs={8}>
              {loadingPersons ? (
                <CircularProgress size={24} />
              ) : (
                <Autocomplete
                  options={persons}
                  getOptionLabel={(opt) => `${opt.firstname} ${opt.lastname}`}
                  value={selectedManager}
                  onChange={(_, val) => setSelectedManager(val)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Sélectionner un manager"
                      fullWidth
                    />
                  )}
                />
              )}
            </Grid>
          </Grid>

          {/* Pôle associé */}
          <Grid item xs={12} container alignItems="center" spacing={2}>
            <Grid item xs={4}>
              <Typography fontWeight="bold">Pôle associé</Typography>
            </Grid>
            <Grid item xs={8}>
              {loadingPoles ? (
                <CircularProgress size={24} />
              ) : (
                <Autocomplete
                  options={poles}
                  getOptionLabel={(opt) => opt.pole_name}
                  value={selectedPole}
                  onChange={(_, val) => setSelectedPole(val)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Sélectionner un pôle"
                      fullWidth
                    />
                  )}
                />
              )}
            </Grid>
          </Grid>
        </Grid>

        {/* Actions */}
        <Box textAlign="right" p={2}>
          <Button onClick={onClose} sx={{ mr: 1 }}>
            Annuler
          </Button>
          <Button
            variant="contained"
            onClick={handleSave}
            disabled={!hasChanges || loadingSave}
          >
            {loadingSave ? "Sauvegarde…" : "Modifier"}
          </Button>
        </Box>
      </MyModal>
      <Snackbar
        open={successSnackbar}
        autoHideDuration={3000}
        onClose={() => setSuccessSnackbar(false)}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <Alert
          onClose={() => setSuccessSnackbar(false)}
          severity="success"
          variant="filled"
        >
          Domaine mis à jour avec succès !
        </Alert>
      </Snackbar>
    </>
  );
};
