// src/pages/AuditAndAdminPAge.tsx

import React from "react";
import { useNavigate } from "react-router-dom";

import { Button, Grid2 } from "@mui/material";

// import files
import { keycloak } from "../../auth/keycloakConnectAdapter";

// import icons
import { AiOutlineAudit } from "react-icons/ai";
import { RiAdminLine } from "react-icons/ri";

const AuditAndAdminPAge: React.FC = () => {
  const navigate = useNavigate();

  const goToPage = (path: string) => {
    navigate(path);
  };

  return (
    <Grid2
      container
      spacing={{ xs: 3, md: 5 }}
      justifyContent="center"
      alignItems="centre"
    >
      {/* audit  */}
      {keycloak.hasRoles(["security_role", "ops_role"]) && (
        <Grid2 size={{ xs: 4, md: 3 }}>
          <Button
            className="btn-self-service certificat"
            color="primary"
            variant="contained"
            size="large"
            startIcon={<AiOutlineAudit />}
            onClick={() => {
              goToPage("/Audit");
            }}
          >
            AUDIT
          </Button>
        </Grid2>
      )}

      {/* admin  */}
      {keycloak.hasRoles("ops_role") && (
        <Grid2 size={{ xs: 4, md: 3 }}>
          <Button
            className="btn-self-service certificat"
            color="primary"
            variant="contained"
            size="large"
            startIcon={<RiAdminLine />}
          >
            Admin
          </Button>
        </Grid2>
      )}
    </Grid2>
  );
};

export default AuditAndAdminPAge;
