// src/components/modals/AffecterModal.tsx
import React from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Autocomplete,
  TextField,
  CircularProgress,
} from "@mui/material";

interface Props {
  open: boolean;
  onClose: () => void;
  // section: string;
  item: string;
  options: string[];
  loading: boolean;
  selected: string[];
  onChange: (values: string[]) => void;
  onSave: () => void;
}
export const AffecterModal: React.FC<Props> = ({
  open,
  onClose,
  item,
  options,
  loading,
  selected,
  onChange,
  onSave,
}) => (
  <Dialog open={open} onClose={onClose} fullWidth maxWidth="sm">
    <DialogTitle>
      Affecter personnes à <strong>{item}</strong>
    </DialogTitle>
    <DialogContent>
      <Autocomplete
        multiple
        options={options}
        value={selected}
        loading={loading}
        onChange={(_, vals) => onChange(vals)}
        renderInput={(params) => (
          <TextField
            {...params}
            label="Personne(s)"
            margin="normal"
            InputProps={{
              ...params.InputProps,
              endAdornment: (
                <>
                  {loading && <CircularProgress size={20} />}
                  {params.InputProps.endAdornment}
                </>
              ),
            }}
          />
        )}
      />
    </DialogContent>
    <DialogActions>
      <Button onClick={onClose}>Fermer</Button>
      <Button variant="contained" color="secondary" onClick={onSave}>
        Enregistrer
      </Button>
    </DialogActions>
  </Dialog>
);
