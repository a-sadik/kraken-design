import React from "react";
import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Button,
} from "@mui/material";

interface DialogModalProps {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title?: string;
  contentText?: string;
  confirmText?: string;
  cancelText?: string;
  confirmColor?:
    | "primary"
    | "error"
    | "secondary"
    | "inherit"
    | "success"
    | "info"
    | "warning";
  cancelColor?:
    | "primary"
    | "error"
    | "secondary"
    | "inherit"
    | "success"
    | "info"
    | "warning";
}

const DialogModal: React.FC<DialogModalProps> = ({
  open,
  onClose,
  onConfirm,
  title = "Confirmation",
  contentText = "Êtes-vous sûr de vouloir effectuer cette action ?",
  confirmText = "Confirmer",
  cancelText = "Annuler",
  confirmColor = "error",
  cancelColor = "primary",
}) => {
  return (
    <Dialog open={open} onClose={onClose}>
      <DialogTitle>{title}</DialogTitle>
      <DialogContent>
        <DialogContentText>{contentText}</DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} color={cancelColor}>
          {cancelText}
        </Button>
        <Button onClick={onConfirm} color={confirmColor}>
          {confirmText}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default DialogModal;
