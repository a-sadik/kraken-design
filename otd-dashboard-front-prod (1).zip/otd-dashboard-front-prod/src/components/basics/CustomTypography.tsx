// src/components/basics/CustomTypography.tsx

import { FC } from "react";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";

//import files
import CustomBadge from "../basics/CustomBadge";

interface CustomTypographyProps {
  text: string;
  color?: string;
  fontSize?: {
    xs?: string;
    sm?: string;
    md?: string;
    lg?: string;
  };
  contentBadge?: number;
}

const CustomTypography: FC<CustomTypographyProps> = ({
  text,
  color = "primary.main",
  fontSize = { xs: "1rem", sm: "1.25rem", md: "1.5rem", lg: "1.75rem" },
  contentBadge = null,
}) => {
  const style = {
    fontFamily: "Open Sans, sans-serif",
    fontWeight: "bold",
    fontSize: fontSize,
    color: color,
    mb: "1rem",
    // ml: '0.2rem'
  };

  return (
    <>
      <Typography sx={style}>{text}</Typography>
      <Box></Box>
      {contentBadge && (
        <CustomBadge text={contentBadge.toString()} textSize={"1.2rem"} />
      )}
    </>
  );
};

export default CustomTypography;
