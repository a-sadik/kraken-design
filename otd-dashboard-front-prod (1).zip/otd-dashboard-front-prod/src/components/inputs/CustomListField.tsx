// src/components/basics/inputs/CustomListField.tsx

import React from "react";
import { Autocomplete, TextField } from "@mui/material";

interface CustomListFieldProps {
  label: string;
  value: string | null;
  onChange: (event: React.SyntheticEvent, newValue: string | null) => void;
  options: string[];
  required?: boolean;
  borderColor: string;
}

const CustomListField: React.FC<CustomListFieldProps> = ({
  label,
  value,
  onChange,
  options,
  borderColor,
}) => {
  return (
    <Autocomplete
      options={options}
      value={value}
      onChange={onChange}
      renderInput={(params) => (
        <TextField
          required
          {...params}
          label={label}
          sx={{
            ml: "auto",
            width: "30rem",
            transition: "width 0.3s ease",
            "& .MuiOutlinedInput-root": {
              "& fieldset": {
                borderColor: "grey", // Couleur de la bordure par défaut
              },
              "&:hover fieldset": {
                borderColor: borderColor, // Couleur de la bordure au survol
              },
              "&.Mui-focused fieldset": {
                borderColor: borderColor, // Couleur de la bordure au focus
              },
            },
          }}
        />
      )}
    />
  );
};

export default CustomListField;
