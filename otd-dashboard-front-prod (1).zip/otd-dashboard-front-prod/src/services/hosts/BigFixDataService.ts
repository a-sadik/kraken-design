// src/services/hosts/BigFixDataService.ts

import axios from "axios";

// import files
import { HostView } from "@/types/view/HostView";
import DataResponseDTO from "@/types/dto/response/DataResponseDTO";
import { mapData } from "@/mappers/DataMapper";

const PREFIX_PATH = import.meta.env.VITE_PREFIX_SOURCE_PATH;
const SUFFIX_PATH = import.meta.env.VITE_SUFFIX_SOURCE_PATH;
const SERVER_PORT = import.meta.env.VITE_SOURCE_SERVER_PORT;
const path = `${PREFIX_PATH}:${SERVER_PORT}/${SUFFIX_PATH}/bigfix/hosts`;

export const getBigFixData = async (): Promise<HostView> => {
  try {
    const response = await axios.get<DataResponseDTO[]>(path);

    // Mapper les données
    const mappedData = mapData(response.data);

    // Construire l'objet HostView
    const hostData: HostView = {
      source: "BigFix",
      number: mappedData.length,
      data: mappedData,
      primaryColor: "#90a213",
      secondaryColor: "#e3e9ba",
    };

    return hostData;
  } catch (error) {
    console.error("Error fetching bigfix data:", error);
    throw error;
  }
};
