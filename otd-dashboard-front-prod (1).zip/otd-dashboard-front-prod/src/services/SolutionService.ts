// src/services/SolutionService.ts

// import files
import { SolutionResponseDTO } from "@/types/dto/response/SolutionResponseDTO";
import { SolutionDetailResponseDTO } from "@/types/dto/response/solution/SolutionDetailResponseDTO";
import apiClient from "./apiClientHttp";
import { SolutionShortDTO } from "@/types/dto/response/solution/SolutionShortDTO";
import { AxiosError } from "axios";
import { ErrorResponse } from "@/exceptions/ErrorResponse";

const PREFIX_PATH = import.meta.env.VITE_PREFIX_DATA_PATH;
const SUFFIX_PATH = import.meta.env.VITE_SUFFIX_DATA_PATH;
const SERVER_PORT = import.meta.env.VITE_DATA_SERVER_PORT;
const path = `${PREFIX_PATH}:${SERVER_PORT}/${SUFFIX_PATH}/solutions`;

export const getAllSolutions = async (): Promise<
  SolutionDetailResponseDTO[]
> => {
  try {
    const response =
      await apiClient.dataApiClient.get<SolutionDetailResponseDTO[]>(path);

    return response.data;
  } catch (error) {
    console.error("Error fetching all solution data:", error);
    throw error;
  }
};

// Fonction pour récupérer la liste des solutions par server id
export const getSolutionsByServerId = async (
  id: number,
): Promise<SolutionResponseDTO[]> => {
  try {
    const response = await apiClient.dataApiClient.get<SolutionResponseDTO[]>(
      `${path}/by-server/${id}`,
    );
    return response.data;
  } catch (error) {
    console.error("Error fetching solutions by IDs:", error);
    throw error;
  }
};

// Fonction pour récupérer une solution par son id
export const getSolutionById = async (
  id: number,
): Promise<SolutionDetailResponseDTO | null> => {
  try {
    const response =
      await apiClient.dataApiClient.get<SolutionDetailResponseDTO | null>(
        `${path}/${id}`,
      );
    return response.data;
  } catch (error) {
    console.error("Error fetching solution by ID:", error);
    throw error;
  }
};

// Fonction pour récupérer une solution par son nom
export const getSolutionByName = async (
  name: string,
): Promise<SolutionResponseDTO | undefined> => {
  const response =
    await apiClient.dataApiClient.get<SolutionResponseDTO | null>(
      `${path}/by-name/${name}`,
    );
  return response.data as SolutionResponseDTO | undefined;
};

const paths = "/solutions";

// Function to get all Popularite Solutions
export const getAllPopulariteSolutions = async (): Promise<
  SolutionShortDTO[]
> => {
  try {
    const response = await apiClient.dataApiClient.get<SolutionShortDTO[]>(
      `${paths}`,
    );
    const allSolutions = response.data;

    const seen = new Set<string>();
    const uniquePopularites: SolutionShortDTO[] = [];

    allSolutions.forEach((solution) => {
      const pop = solution.solution_popularity?.trim();
      if (pop && !seen.has(pop)) {
        seen.add(pop);
        uniquePopularites.push({
          solution_id: solution.solution_id, // utiliser l’ID original
          solution_popularity: pop,
        } as SolutionShortDTO);
      }
    });

    return uniquePopularites;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;
    console.error(
      "Erreur lors de la récupération des popularités:",
      err.response?.data.message,
    );
    throw err;
  }
};

// Function to get all types Solutions
export const getAllTypeSolutions = async (): Promise<SolutionShortDTO[]> => {
  try {
    const response = await apiClient.dataApiClient.get<SolutionShortDTO[]>(
      `${paths}`,
    );
    const allSolutions = response.data;

    const seen = new Set<string>();
    const uniqueTypes: SolutionShortDTO[] = [];

    allSolutions.forEach((solution) => {
      const type = solution.solution_type?.trim();
      if (type && !seen.has(type)) {
        seen.add(type);
        uniqueTypes.push({
          solution_id: solution.solution_id, // on garde l’ID d'origine
          solution_type: type,
          solution_name: "",
          solution_popularity: "",
          solution_role: "",
          psi: "",
        });
      }
    });

    return uniqueTypes;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;
    console.error(
      "Erreur lors de la récupération des types:",
      err.response?.data.message,
    );
    throw err;
  }
};

// Function to create post
export const createSolution = async (
  reqBody: SolutionShortDTO,
): Promise<SolutionShortDTO | null> => {
  try {
    const response =
      await apiClient.dataApiClient.post<SolutionShortDTO | null>(
        `${path}`,
        reqBody,
      );
    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error("Error creating new solution:", err.response?.data);
    throw error;
  }
};

// Function to update post
export const updateSolution = async (
  id: number,
  reqBody: SolutionShortDTO,
): Promise<SolutionShortDTO | null> => {
  try {
    const response = await apiClient.dataApiClient.put<SolutionShortDTO | null>(
      `${path}/${id}`,
      reqBody,
    );
    return response.data;
  } catch (error) {
    const err = error as AxiosError<ErrorResponse>;

    console.error("Error updating new solution:", err.response?.data);
    throw error;
  }
};
