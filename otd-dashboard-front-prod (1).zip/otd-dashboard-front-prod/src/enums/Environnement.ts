// src/types/enums/Environnement.ts

export enum Environnement {
  Production = "Production",
  Preproduction = "Préproduction",
  Recette = "Recette",
  Integration = "Intégration",
  Developpement = "Développement",
  Formation = "Formation",
  Technique = "Technique",
  TNR = "TNR",
  POC = "POC",
}
