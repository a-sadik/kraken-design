// src/pages/sub-pages/admin/PersonPage.tsx

import { FC } from "react";

// import files
import PersonDataTable from "@/components/data-tables/PersonDataTable";

const PersonPage: FC = () => {
  return <PersonDataTable />;
};

export default PersonPage;
